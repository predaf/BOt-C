# Security & Secrets

This project uses exchange API credentials.

## Immediate actions
- Do NOT commit or share `.env`.
- If you ever shared a `.env` that contains real API keys/secrets, rotate/revoke them immediately.

## Recommended setup
1. Copy `.env.example` to `.env` locally.
2. Populate keys using environment variables (preferred) or `.env` (local only).

## Production hardening
- Keep the control API bound to localhost OR protect it with authentication.
- Run with minimum permissions and IP-restricted exchange keys.

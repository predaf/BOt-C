import os
import json
import time
import sqlite3
import math
from typing import Any, Dict, Optional, List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import JSONResponse


def _sanitize_jsonable(x: Any) -> Any:
    """Sanitize NaN/Inf so JSON serialization won't crash (Starlette uses allow_nan=False)."""
    try:
        if x is None or isinstance(x, (str, int, bool)):
            return x
        if isinstance(x, float):
            return x if math.isfinite(x) else None
        if hasattr(x, "item") and callable(getattr(x, "item")):
            try:
                return _sanitize_jsonable(x.item())
            except Exception:
                pass
        if isinstance(x, dict):
            return {str(k): _sanitize_jsonable(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [_sanitize_jsonable(v) for v in x]
        if isinstance(x, set):
            return [_sanitize_jsonable(v) for v in sorted(list(x))]
        return str(x)
    except Exception:
        return str(x)


class SafeJSONResponse(JSONResponse):
    def render(self, content: Any) -> bytes:
        return super().render(_sanitize_jsonable(content))


app = FastAPI(title="Crypto Bot Local API", version="0.2", default_response_class=SafeJSONResponse)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _load_json(path: str) -> Optional[Dict[str, Any]]:
    try:
        if not path or not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _resolve_path(base_dir: str, p: str) -> str:
    if not p:
        return p
    if os.path.isabs(p):
        return p
    return os.path.normpath(os.path.join(base_dir, p))


def _load_config() -> Dict[str, Any]:
    """
    Load config from:
    - env BOT_CONFIG (full path), else
    - ./config.json
    """
    cfg_path = (os.environ.get("BOT_CONFIG") or "").strip()
    if cfg_path and os.path.exists(cfg_path):
        cfg = _load_json(cfg_path) or {}
        cfg["_cfg_path"] = cfg_path
        return cfg

    local = os.path.join(os.getcwd(), "config.json")
    cfg = _load_json(local) or {}
    cfg["_cfg_path"] = local
    return cfg


def _get_paths(cfg: Dict[str, Any]) -> Dict[str, str]:
    cfg_path = cfg.get("_cfg_path") or os.path.join(os.getcwd(), "config.json")
    base_dir = os.path.dirname(os.path.abspath(cfg_path))

    sqlite_cfg = cfg.get("sqlite", {}) or {}
    db_rel = str(sqlite_cfg.get("path", "bot.db"))
    db_path = _resolve_path(base_dir, db_rel)

    state_cfg = cfg.get("state", {}) or {}
    state_rel = str(state_cfg.get("path", "state.json"))
    state_path = _resolve_path(base_dir, state_rel)

    return {
        "base_dir": base_dir,
        "db_path": db_path,
        "state_path": state_path,
        "cfg_path": cfg_path,
    }


def _db_connect(db_path: str) -> Optional[sqlite3.Connection]:
    try:
        if not db_path or not os.path.exists(db_path):
            return None
        return sqlite3.connect(db_path, check_same_thread=False)
    except Exception:
        return None


def _db_tables(conn: sqlite3.Connection) -> List[str]:
    q = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
    return [r[0] for r in conn.execute(q).fetchall()]


def _db_latest_equity(conn: sqlite3.Connection) -> Optional[float]:
    try:
        tables = _db_tables(conn)
        if "snapshots" not in tables:
            return None

        cols = [r[1] for r in conn.execute("PRAGMA table_info(snapshots);").fetchall()]
        eq_col = None
        for c in ["equity", "balance", "equity_usd", "account_equity"]:
            if c in cols:
                eq_col = c
                break
        if not eq_col:
            return None

        row = conn.execute(f"SELECT {eq_col} FROM snapshots ORDER BY ts DESC LIMIT 1;").fetchone()
        if not row:
            return None
        v = row[0]
        return float(v) if v is not None else None
    except Exception:
        return None


def _db_recent(conn: sqlite3.Connection, table: str, limit: int = 200) -> List[Dict[str, Any]]:
    limit = max(1, min(int(limit), 5000))
    try:
        tables = _db_tables(conn)
        if table not in tables:
            return []

        cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table});").fetchall()]
        order_col = None
        for c in ["ts", "time", "created_ts", "id"]:
            if c in cols:
                order_col = c
                break

        if order_col:
            q = f"SELECT * FROM {table} ORDER BY {order_col} DESC LIMIT {limit};"
        else:
            q = f"SELECT * FROM {table} ORDER BY rowid DESC LIMIT {limit};"

        cur = conn.execute(q)
        names = [d[0] for d in cur.description]
        out = []
        for r in cur.fetchall():
            out.append({names[i]: r[i] for i in range(len(names))})
        return out
    except Exception:
        return []


def _engine_liveness(state_path: str, save_interval_sec: float = 30.0) -> Dict[str, Any]:
    """
    Heuristic: if state.json was modified recently, engine likely running.
    """
    try:
        if not state_path or not os.path.exists(state_path):
            return {"alive": False, "stale_sec": None, "mtime": None}
        mtime = os.path.getmtime(state_path)
        stale = time.time() - mtime
        alive = stale <= max(10.0, 2.5 * float(save_interval_sec))
        return {"alive": bool(alive), "stale_sec": float(stale), "mtime": float(mtime)}
    except Exception:
        return {"alive": False, "stale_sec": None, "mtime": None}


@app.get("/status")
def status() -> Dict[str, Any]:
    cfg = _load_config()
    paths = _get_paths(cfg)

    state = _load_json(paths["state_path"]) or {}
    guard = (state.get("guard") or {})
    positions = (state.get("positions_meta") or {})
    pending = (state.get("pending") or {})
    pairs = (state.get("pairs") or [])

    save_int = float((cfg.get("state") or {}).get("save_interval_sec", 30))
    live = _engine_liveness(paths["state_path"], save_interval_sec=save_int)

    conn = _db_connect(paths["db_path"])
    equity_last = _db_latest_equity(conn) if conn else None

    open_positions = 0
    try:
        for _, p in (positions or {}).items():
            if isinstance(p, dict) and float(p.get("qty", 0.0) or 0.0) > 0:
                open_positions += 1
    except Exception:
        open_positions = 0

    return {
        "ok": True,
        "ts": _now_iso(),
        "engine_alive": live.get("alive"),
        "engine_stale_sec": live.get("stale_sec"),
        "state_mtime": live.get("mtime"),
        "exchange": cfg.get("exchange"),
        "mode": cfg.get("mode"),
        "enable_futures": bool(cfg.get("enable_futures", False)),
        "halted": bool(guard.get("halted", False)),
        "day_start_equity": guard.get("day_start_equity"),
        "peak_equity": guard.get("peak_equity"),
        "equity_last": equity_last,
        "open_positions": open_positions,
        "pending_orders": len(pending) if isinstance(pending, dict) else 0,
        "pairs_count": len(pairs) if isinstance(pairs, list) else 0,
        "pairs": pairs[:50] if isinstance(pairs, list) else [],
        "paths": {
            "cfg": paths["cfg_path"],
            "db": paths["db_path"],
            "state": paths["state_path"],
            "base_dir": paths["base_dir"],
        },
    }


@app.get("/positions")
def positions() -> Dict[str, Any]:
    cfg = _load_config()
    paths = _get_paths(cfg)
    state = _load_json(paths["state_path"]) or {}
    return {"ok": True, "ts": _now_iso(), "positions": state.get("positions_meta") or {}}


@app.get("/pending")
def pending() -> Dict[str, Any]:
    cfg = _load_config()
    paths = _get_paths(cfg)
    state = _load_json(paths["state_path"]) or {}
    return {"ok": True, "ts": _now_iso(), "pending": state.get("pending") or {}}


@app.get("/trades")
def trades(limit: int = 200) -> Dict[str, Any]:
    cfg = _load_config()
    paths = _get_paths(cfg)
    conn = _db_connect(paths["db_path"])
    if not conn:
        return {"ok": False, "ts": _now_iso(), "error": f"db not found: {paths['db_path']}"}
    return {"ok": True, "ts": _now_iso(), "rows": _db_recent(conn, "trades", limit=limit)}


@app.get("/signals")
def signals(limit: int = 200) -> Dict[str, Any]:
    cfg = _load_config()
    paths = _get_paths(cfg)
    conn = _db_connect(paths["db_path"])
    if not conn:
        return {"ok": False, "ts": _now_iso(), "error": f"db not found: {paths['db_path']}"}
    return {"ok": True, "ts": _now_iso(), "rows": _db_recent(conn, "signals", limit=limit)}

# Patch v9 — Adaptive pair rotation when no trade candidates

## What it does
- Tracks the last time the engine saw an **actionable** buy/sell signal (based on `signal_thresholds`).
- If the currently selected universe (e.g., first 60 pairs) yields **no actionable signals** for a short window,
  the engine will **force-refresh the pair list early**, instead of waiting for `pair_refresh_sec`.

## Defaults (no config changes required)
- Enabled by default.
- Window: 60 seconds without actionable signals.
- Minimum wait between refresh attempts: 30 seconds.

## Optional config (root-level)
```json
"pair_rotation": {
  "enabled": true,
  "no_candidate_window_sec": 60,
  "min_wait_sec": 30
}
```

## Logs
- You will see messages like:
  `[pairs] no actionable signals for 63s (last=BTC/USDT). Forcing pair refresh...`

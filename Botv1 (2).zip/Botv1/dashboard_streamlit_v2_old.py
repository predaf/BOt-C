import os
import time
import sqlite3
from typing import Optional, Dict, Any, List, Tuple

import pandas as pd
import streamlit as st
from streamlit_autorefresh import st_autorefresh

import plotly.express as px
import plotly.graph_objects as go

import ccxt
import requests


st.set_page_config(page_title="Crypto Bot Dashboard v2", layout="wide")


# ----------------------------
# SQLite helpers (optional)
# ----------------------------
def _connect(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path, check_same_thread=False)


def list_tables(conn: sqlite3.Connection) -> List[str]:
    q = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
    return [r[0] for r in conn.execute(q).fetchall()]


def read_table(conn: sqlite3.Connection, table: str, limit: int = 500) -> pd.DataFrame:
    limit = int(max(1, min(limit, 20000)))
    cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table});").fetchall()]

    order_col = None
    for c in ["ts", "time", "created_ts", "updated_ts", "id"]:
        if c in cols:
            order_col = c
            break

    if order_col:
        q = f"SELECT * FROM {table} ORDER BY {order_col} DESC LIMIT {limit};"
    else:
        q = f"SELECT * FROM {table} ORDER BY rowid DESC LIMIT {limit};"

    return pd.read_sql_query(q, conn)


def safe_dt_from_df(df: pd.DataFrame) -> pd.Series:
    if "dt" in df.columns:
        return pd.to_datetime(df["dt"], errors="coerce", utc=True)
    if "time" in df.columns:
        return pd.to_datetime(df["time"], errors="coerce", utc=True)
    if "created_ts" in df.columns:
        try:
            return pd.to_datetime(df["created_ts"], unit="s", errors="coerce", utc=True)
        except Exception:
            return pd.to_datetime(df["created_ts"], errors="coerce", utc=True)
    if "ts" in df.columns:
        # ts can be epoch seconds OR ISO string
        try:
            return pd.to_datetime(df["ts"], unit="s", errors="coerce", utc=True)
        except Exception:
            return pd.to_datetime(df["ts"], errors="coerce", utc=True)
    return pd.to_datetime(pd.Series([pd.NaT] * len(df)), errors="coerce", utc=True)


# ----------------------------
# API helpers (FastAPI)
# ----------------------------
def api_get(api_url: str, path: str, timeout_sec: float = 3.5) -> Optional[Dict[str, Any]]:
    if not api_url:
        return None
    api_url = api_url.rstrip("/")
    try:
        r = requests.get(f"{api_url}{path}", timeout=timeout_sec)
        if r.status_code == 200:
            data = r.json()
            # normalize in case backend returns bare dict
            if isinstance(data, dict) and "ok" not in data:
                data = {"ok": True, "data": data}
            return data
        return {"ok": False, "http_status": r.status_code, "text": r.text[:3000]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def unpack_data(resp: Optional[Dict[str, Any]]) -> Any:
    if not isinstance(resp, dict):
        return None
    if not resp.get("ok", False):
        return None
    return resp.get("data")


def engine_badge(ok: Optional[bool], stale_sec: Optional[float]) -> Tuple[str, str]:
    if ok is True:
        if stale_sec is not None and stale_sec > 120:
            return ("ENGINE: RUNNING (stale)", "orange")
        return ("ENGINE: RUNNING", "green")
    if ok is False:
        return ("ENGINE: ERROR", "red")
    return ("ENGINE: UNKNOWN", "gray")


def fmt_float(x: Any, nd: int = 2) -> str:
    try:
        if x is None:
            return "—"
        return f"{float(x):.{nd}f}"
    except Exception:
        return "—"


# ----------------------------
# CCXT helpers (spot vs futures)
# ----------------------------
def is_swap_symbol(sym: str) -> bool:
    # bot symbols like "APT/USDT:USDT" indicate swap/futures in your system
    return isinstance(sym, str) and (":USDT" in sym or ":USD" in sym)


def to_ccxt_symbol(sym: str) -> str:
    # "APT/USDT:USDT" -> "APT/USDT"
    if not sym:
        return sym
    return str(sym).split(":")[0]


@st.cache_resource
def ccxt_client(exchange_id: str, market_type: str):
    """
    market_type: 'spot' or 'swap'
    Binance:
      - spot  -> ccxt.binance
      - USDT-M futures -> ccxt.binanceusdm
    Bybit:
      - use ccxt.bybit with options.defaultType
    """
    ex_id = (exchange_id or "binance").strip().lower()
    market_type = (market_type or "spot").strip().lower()

    if ex_id == "bybit":
        # bybit unified: 'spot' or 'swap'
        return ccxt.bybit({
            "enableRateLimit": True,
            "options": {"defaultType": "swap" if market_type == "swap" else "spot"}
        })

    # default binance
    if market_type == "swap":
        return ccxt.binanceusdm({"enableRateLimit": True})
    return ccxt.binance({"enableRateLimit": True})


def fetch_last_price(exchange_id: str, sym: str, enable_futures: bool) -> Optional[float]:
    """
    Try swap first if symbol indicates swap OR futures enabled. Fallback to spot.
    """
    s = to_ccxt_symbol(sym)
    prefer_swap = is_swap_symbol(sym) or bool(enable_futures)

    for mt in (["swap", "spot"] if prefer_swap else ["spot", "swap"]):
        try:
            ex = ccxt_client(exchange_id, mt)
            # ensure markets loaded (helps for some exchanges)
            try:
                ex.load_markets()
            except Exception:
                pass
            t = ex.fetch_ticker(s)
            return float(t.get("last") or t.get("close") or t.get("bid") or t.get("ask"))
        except Exception:
            continue
    return None


def fetch_ohlcv(exchange_id: str, sym: str, enable_futures: bool, timeframe: str = "1m", limit: int = 200) -> Optional[pd.DataFrame]:
    s = to_ccxt_symbol(sym)
    prefer_swap = is_swap_symbol(sym) or bool(enable_futures)

    for mt in (["swap", "spot"] if prefer_swap else ["spot", "swap"]):
        try:
            ex = ccxt_client(exchange_id, mt)
            try:
                ex.load_markets()
            except Exception:
                pass
            ohlcv = ex.fetch_ohlcv(s, timeframe=timeframe, limit=int(limit))
            df = pd.DataFrame(ohlcv, columns=["ts", "open", "high", "low", "close", "volume"])
            df["dt"] = pd.to_datetime(df["ts"], unit="ms", utc=True, errors="coerce")
            return df
        except Exception:
            continue
    return None


# ----------------------------
# Normalizers for latest API shapes
# ----------------------------
def normalize_positions(data: Any) -> pd.DataFrame:
    """
    Latest API: /positions -> {"ok":true,"data":[{symbol,qty,entry,stop,tp,...}, ...]}
    qty sign indicates long/short (positive long, negative short)
    """
    rows = []
    if isinstance(data, list):
        rows = [r for r in data if isinstance(r, dict)]
    elif isinstance(data, dict):
        # fallback old shape: dict keyed by symbol
        for _, p in data.items():
            if isinstance(p, dict):
                rows.append(p)

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    if "side" not in df.columns:
        # infer side from qty
        if "qty" in df.columns:
            q = pd.to_numeric(df["qty"], errors="coerce").fillna(0.0)
            df["side"] = q.apply(lambda x: "long" if x > 0 else ("short" if x < 0 else "flat"))
        else:
            df["side"] = "—"

    for c in ["qty", "entry", "stop", "tp", "opened_ts", "trailing"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def normalize_pending(data: Any) -> pd.DataFrame:
    """
    Latest API: /pending -> {"ok":true,"data":[...]} (often empty list)
    """
    rows = []
    if isinstance(data, list):
        rows = [r for r in data if isinstance(r, dict)]
    elif isinstance(data, dict):
        for _, p in data.items():
            if isinstance(p, dict):
                rows.append(p)

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    for c in ["qty", "price", "created_ts", "reposts", "atr_pct", "filled_qty"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def normalize_trades(data: Any) -> pd.DataFrame:
    """
    Latest API: /trades -> {"ok":true,"data":[{ts,exchange,mode,symbol,side,qty,price,fee,reason,realized_pnl}, ...]}
    ts is ISO string in your outputs.
    """
    rows = []
    if isinstance(data, list):
        rows = [r for r in data if isinstance(r, dict)]
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    if "ts" in df.columns:
        df["dt"] = pd.to_datetime(df["ts"], errors="coerce", utc=True)
    for c in ["qty", "price", "notional", "fee", "realized_pnl"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)
    return df


# ----------------------------
# UI
# ----------------------------
def main():
    st.title("Crypto Bot Dashboard (Streamlit) — v2 (API-aligned)")

    with st.sidebar:
        st.header("Settings")

        refresh_sec = st.slider("Auto-refresh (sec)", min_value=1, max_value=30, value=3)
        auto_refresh = st.toggle("Auto-refresh", value=True)

        st.divider()
        st.subheader("Bot API (recommended)")
        api_url = st.text_input("API URL", value="http://127.0.0.1:8000")
        poll_api = st.toggle("Poll API (/status,/portfolio,/positions,/pending,/trades)", value=True)

        trades_limit = st.slider("Trades limit", min_value=50, max_value=5000, value=800, step=50)

        st.divider()
        st.subheader("SQLite (optional)")
        use_sqlite = st.toggle("Use SQLite DB explorer", value=False)
        default_db = os.path.join(os.getcwd(), "bot.db")
        db_path = st.text_input("SQLite DB path (full file path)", value=default_db)
        table_limit = st.number_input("Row limit per table", min_value=50, max_value=20000, value=800, step=50)

        st.caption("Tip: pentru charts pe futures symbols (:USDT) dashboard-ul folosește automat binanceusdm/bybit swap.")

    # ----------------------------
    # API poll
    # ----------------------------
    status_r = portfolio_r = positions_r = pending_r = trades_r = None
    status = portfolio = positions_data = pending_data = trades_data = None

    if poll_api and api_url:
        status_r = api_get(api_url, "/status")
        portfolio_r = api_get(api_url, "/portfolio")
        positions_r = api_get(api_url, "/positions")
        pending_r = api_get(api_url, "/pending")
        trades_r = api_get(api_url, f"/trades?limit={int(trades_limit)}")

        status = unpack_data(status_r)
        portfolio = unpack_data(portfolio_r)
        positions_data = unpack_data(positions_r)
        pending_data = unpack_data(pending_r)
        trades_data = unpack_data(trades_r)

    # ----------------------------
    # Header metrics
    # ----------------------------
    col1, col2, col3, col4, col5, col6 = st.columns(6)

    with col1:
        st.metric("API", "ON" if isinstance(status_r, dict) and status_r.get("ok") else "—")

    with col2:
        if isinstance(status, dict):
            st.metric("Mode", str(status.get("mode", "—")))
        else:
            st.metric("Mode", "—")

    with col3:
        if isinstance(status, dict):
            st.metric("Exchange", str(status.get("exchange", "—")))
        else:
            st.metric("Exchange", "—")

    with col4:
        if isinstance(status, dict):
            st.metric("Enable futures", str(bool(status.get("enable_futures", False))))
        else:
            st.metric("Enable futures", "—")

    with col5:
        if isinstance(status, dict):
            st.metric("Halted", str(bool(status.get("halted", False))))
        else:
            st.metric("Halted", "—")

    with col6:
        if isinstance(status, dict):
            st.metric("Equity", fmt_float(status.get("equity"), 2))
        else:
            # fallback from /portfolio if needed
            if isinstance(portfolio, dict):
                st.metric("Equity", fmt_float(portfolio.get("equity"), 2))
            else:
                st.metric("Equity", "—")

    # Warnings
    if isinstance(status_r, dict) and not status_r.get("ok", True):
        st.warning(f"/status error: {status_r}")
    if isinstance(trades_r, dict) and not trades_r.get("ok", True):
        st.warning(f"/trades error: {trades_r}")

    st.divider()

    # ----------------------------
    # Positions + Pending (API)
    # ----------------------------
    st.subheader("Open Positions & Pending Orders (API)")

    pos_df = normalize_positions(positions_data)
    pend_df = normalize_pending(pending_data)

    pcol, ocol = st.columns(2)

    with pcol:
        st.markdown("### Open Positions")
        if pos_df is None or pos_df.empty:
            st.info("No open positions.")
        else:
            # add notional estimate from last price (best-effort)
            st.dataframe(pos_df.sort_values(["symbol"], ascending=True), use_container_width=True)

    with ocol:
        st.markdown("### Pending Orders")
        if pend_df is None or pend_df.empty:
            st.info("No pending orders.")
        else:
            st.dataframe(pend_df.sort_values(["created_ts"], ascending=False), use_container_width=True)

    st.divider()

    # ----------------------------
    # Position chart (Live via CCXT)
    # ----------------------------
    st.subheader("Position Chart (Live via CCXT)")

    if pos_df is not None and not pos_df.empty and "symbol" in pos_df.columns:
        sym_list = [s for s in pos_df["symbol"].dropna().astype(str).unique().tolist() if s]
        sym_sel = st.selectbox("Select open position", sym_list)

        exchange_id = "binance"
        enable_futures = False
        if isinstance(status, dict):
            exchange_id = str(status.get("exchange") or "binance").lower()
            enable_futures = bool(status.get("enable_futures", False))

        tf = st.selectbox("Timeframe", ["1m", "5m", "15m", "1h"], index=1)
        candle_limit = st.slider("Candles", min_value=50, max_value=500, value=200, step=50)

        row = pos_df[pos_df["symbol"] == sym_sel].iloc[0].to_dict()
        entry = row.get("entry")
        stop = row.get("stop")
        tp = row.get("tp")
        side = row.get("side")

        last = fetch_last_price(exchange_id, sym_sel, enable_futures=enable_futures)
        dfc = fetch_ohlcv(exchange_id, sym_sel, enable_futures=enable_futures, timeframe=tf, limit=int(candle_limit))

        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Symbol", sym_sel)
        m2.metric("Side", str(side or "—"))
        m3.metric("Entry", fmt_float(entry, 6))
        m4.metric("Stop", fmt_float(stop, 6))
        m5.metric("TP", fmt_float(tp, 6))

        st.caption(f"Exchange: {exchange_id} | Live last: {fmt_float(last, 6)} | CCXT symbol used: {to_ccxt_symbol(sym_sel)}")

        if dfc is None or dfc.empty:
            st.warning("Could not load OHLCV. Cel mai des: simbolul nu există pe spot; acum încercăm swap/spot automat. Dacă tot nu merge, perechea poate fi delistată sau CCXT nu o expune pe timeframe-ul selectat.")
        else:
            fig = go.Figure(
                data=[
                    go.Candlestick(
                        x=dfc["dt"],
                        open=dfc["open"],
                        high=dfc["high"],
                        low=dfc["low"],
                        close=dfc["close"],
                        name="Price",
                    )
                ]
            )

            # Horizontal markers
            try:
                if entry is not None and float(entry) > 0:
                    fig.add_hline(y=float(entry), line_dash="solid", annotation_text="Entry")
            except Exception:
                pass
            try:
                if stop is not None and float(stop) > 0:
                    fig.add_hline(y=float(stop), line_dash="dash", annotation_text="Stop")
            except Exception:
                pass
            try:
                if tp is not None and float(tp) > 0:
                    fig.add_hline(y=float(tp), line_dash="dash", annotation_text="TP")
            except Exception:
                pass
            try:
                if last is not None and float(last) > 0:
                    fig.add_hline(y=float(last), line_dash="dot", annotation_text="Last")
            except Exception:
                pass

            fig.update_layout(height=520, margin=dict(l=10, r=10, t=30, b=10))
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No open positions to chart.")

    st.divider()

    # ----------------------------
    # Trades (API) + quick PnL
    # ----------------------------
    st.subheader("Trades (API)")

    tdf = normalize_trades(trades_data)
    if tdf is None or tdf.empty:
        st.info("No trades returned by /trades.")
    else:
        c1, c2, c3 = st.columns(3)
        with c1:
            st.metric("Trades loaded", str(len(tdf)))
        with c2:
            st.metric("Sum realized PnL", fmt_float(float(tdf["realized_pnl"].sum()), 6))
        with c3:
            st.metric("Sum fees", fmt_float(float(tdf["fee"].sum()), 6))

        st.dataframe(
            tdf[["ts", "symbol", "side", "qty", "price", "fee", "reason", "realized_pnl"]].head(800),
            use_container_width=True
        )

    st.divider()

    # ----------------------------
    # Equity curve (SQLite snapshots) - optional
    # ----------------------------
    if use_sqlite:
        st.subheader("SQLite Diagnostics (optional)")
        if not os.path.exists(db_path):
            st.error(f"DB file not found: {db_path}")
        else:
            conn = _connect(db_path)
            tables = list_tables(conn)

            st.caption(f"DB: {db_path} | size: {os.path.getsize(db_path)/1_000_000:.2f} MB | tables: {len(tables)}")

            if "snapshots" in tables:
                snaps = read_table(conn, "snapshots", limit=int(table_limit))
                if not snaps.empty:
                    if "ts" in snaps.columns:
                        try:
                            snaps["dt"] = pd.to_datetime(snaps["ts"], unit="s", utc=True, errors="coerce")
                        except Exception:
                            snaps["dt"] = pd.to_datetime(snaps["ts"], errors="coerce", utc=True)
                    else:
                        snaps["dt"] = safe_dt_from_df(snaps)

                    eq_col = "equity" if "equity" in snaps.columns else None
                    if eq_col and snaps["dt"].notna().any():
                        snaps = snaps.sort_values("dt")
                        fig = px.line(snaps, x="dt", y=eq_col)
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("Could not detect dt/equity columns in snapshots.")
                        st.dataframe(snaps.head(200), use_container_width=True)
                else:
                    st.info("snapshots table is empty.")

            st.markdown("### Database Explorer")
            tsel = st.selectbox("Table", tables, index=0)
            df = read_table(conn, tsel, limit=int(table_limit))
            st.dataframe(df, use_container_width=True)

    # ----------------------------
    # Auto refresh
    # ----------------------------
    if auto_refresh:
        st_autorefresh(interval=int(refresh_sec * 1000), key="auto_refresh")


if __name__ == "__main__":
    main()

import os
import time
import sqlite3
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime, timedelta

import pandas as pd
import numpy as np
import streamlit as st
from streamlit_autorefresh import st_autorefresh

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import ccxt
import requests


st.set_page_config(
    page_title="Crypto Bot Dashboard v3",
    layout="wide",
    page_icon="📊"
)


# ----------------------------
# Session State Initialization
# ----------------------------
def init_session_state():
    """Initialize session state variables."""
    defaults = {
        'auto_refresh': True,
        'refresh_sec': 3,
        'api_url': "http://127.0.0.1:8000",
        'poll_api': True,
        'use_sqlite': False,
        'trace_limit': 400,
        'trace_level': "info",
        'trades_limit': 800,
        'table_limit': 800,
        'candle_limit': 200,
        'chart_tf': "5m",
        'show_sma': False,
        'sma_period': 20,
        'show_volume': True,
        'chart_mode': "positions",
        'manual_symbol': "BTC/USDT",
        'last_update': None,
        'api_status': {},
        'positions_data': pd.DataFrame(),
        'trades_data': pd.DataFrame(),
        'trace_data': pd.DataFrame(),
        'portfolio_data': {},
        'pending_data': pd.DataFrame(),
    }
    
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


# ----------------------------
# SQLite helpers
# ----------------------------
@st.cache_resource
def get_db_connection(db_path: str) -> sqlite3.Connection:
    """Get cached database connection."""
    return sqlite3.connect(db_path, check_same_thread=False)


def list_tables(conn: sqlite3.Connection) -> List[str]:
    """List all tables in database."""
    q = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
    return [r[0] for r in conn.execute(q).fetchall()]


def read_table(conn: sqlite3.Connection, table: str, limit: int = 500) -> pd.DataFrame:
    """Read table with limit and proper ordering."""
    limit = int(max(1, min(limit, 20000)))
    
    # Get table columns
    cols_info = conn.execute(f"PRAGMA table_info({table});").fetchall()
    if not cols_info:
        return pd.DataFrame()
    
    cols = [r[1] for r in cols_info]
    
    # Determine order column
    order_col = None
    for c in ["ts", "time", "created_ts", "updated_ts", "id"]:
        if c in cols:
            order_col = c
            break
    
    if order_col:
        q = f"SELECT * FROM {table} ORDER BY {order_col} DESC LIMIT {limit};"
    else:
        q = f"SELECT * FROM {table} ORDER BY rowid DESC LIMIT {limit};"
    
    try:
        return pd.read_sql_query(q, conn)
    except Exception:
        return pd.DataFrame()


def safe_dt_from_df(df: pd.DataFrame) -> pd.Series:
    """Safely extract datetime column from DataFrame."""
    if df.empty:
        return pd.Series([], dtype='datetime64[ns, UTC]')
    
    dt_cols = ["dt", "time", "created_ts", "ts", "timestamp"]
    
    for col in dt_cols:
        if col in df.columns:
            try:
                if col == "created_ts" or col == "ts":
                    # Try epoch seconds first
                    try:
                        return pd.to_datetime(df[col], unit='s', errors='coerce', utc=True)
                    except Exception:
                        return pd.to_datetime(df[col], errors='coerce', utc=True)
                else:
                    return pd.to_datetime(df[col], errors='coerce', utc=True)
            except Exception:
                continue
    
    return pd.to_datetime(pd.Series([pd.NaT] * len(df)), errors='coerce', utc=True)


# ----------------------------
# API helpers
# ----------------------------
def api_get(api_url: str, path: str, params: Optional[Dict] = None, timeout: float = 5.0) -> Optional[Dict[str, Any]]:
    """Make GET request to bot API."""
    if not api_url:
        return None
    
    api_url = api_url.rstrip("/")
    url = f"{api_url}{path}"
    
    try:
        response = requests.get(url, params=params, timeout=timeout)
        
        if response.status_code == 200:
            data = response.json()
            # Normalize response format
            if isinstance(data, dict):
                if "ok" not in data:
                    return {"ok": True, "data": data, "status_code": response.status_code}
                return {**data, "status_code": response.status_code}
            else:
                return {"ok": True, "data": data, "status_code": response.status_code}
        else:
            return {
                "ok": False,
                "status_code": response.status_code,
                "error": f"HTTP {response.status_code}",
                "text": response.text[:1000]
            }
    except requests.exceptions.Timeout:
        return {"ok": False, "error": "Request timeout", "status_code": 408}
    except requests.exceptions.ConnectionError:
        return {"ok": False, "error": "Connection failed", "status_code": 0}
    except Exception as e:
        return {"ok": False, "error": str(e), "status_code": 0}


def unpack_data(response: Optional[Dict]) -> Any:
    """Extract data from API response."""
    if not isinstance(response, dict):
        return None
    if not response.get("ok", False):
        return None
    return response.get("data")


def format_float(value: Any, decimals: int = 2) -> str:
    """Format float with specified decimals."""
    try:
        if value is None or pd.isna(value):
            return "—"
        return f"{float(value):.{decimals}f}"
    except Exception:
        return "—"


def format_percent(value: Any, decimals: int = 2) -> str:
    """Format as percentage."""
    try:
        if value is None or pd.isna(value):
            return "—"
        return f"{float(value) * 100:.{decimals}f}%"
    except Exception:
        return "—"


# ----------------------------
# Exchange helpers
# ----------------------------
def is_swap_symbol(symbol: str) -> bool:
    """Check if symbol is a swap/futures symbol."""
    if not isinstance(symbol, str):
        return False
    return ":USDT" in symbol or ":USD" in symbol or "/PERP" in symbol


def to_ccxt_symbol(symbol: str) -> str:
    """Convert bot symbol to CCXT symbol."""
    if not symbol:
        return symbol
    # Remove swap suffix if present
    return str(symbol).split(":")[0].replace("/PERP", "")


@st.cache_resource(ttl=60)
def get_ccxt_client(exchange_id: str, market_type: str = "spot") -> Optional[ccxt.Exchange]:
    """Get cached CCXT client."""
    exchange_id = exchange_id.lower().strip() if exchange_id else "binance"
    market_type = market_type.lower().strip() if market_type else "spot"
    
    try:
        if exchange_id == "bybit":
            client = ccxt.bybit({
                "enableRateLimit": True,
                "options": {
                    "defaultType": "swap" if market_type == "swap" else "spot"
                }
            })
        elif exchange_id == "binance":
            if market_type == "swap":
                client = ccxt.binanceusdm({"enableRateLimit": True})
            else:
                client = ccxt.binance({"enableRateLimit": True})
        elif exchange_id == "okx":
            client = ccxt.okx({
                "enableRateLimit": True,
                "options": {
                    "defaultType": "swap" if market_type == "swap" else "spot"
                }
            })
        else:
            # Try generic exchange
            client_class = getattr(ccxt, exchange_id, None)
            if client_class:
                client = client_class({"enableRateLimit": True})
            else:
                return None
        
        # Load markets (cached)
        try:
            client.load_markets()
        except Exception:
            pass
        
        return client
    except Exception:
        return None


def fetch_last_price(exchange_id: str, symbol: str, enable_futures: bool = False) -> Optional[float]:
    """Fetch last price for symbol."""
    ccxt_symbol = to_ccxt_symbol(symbol)
    prefer_swap = is_swap_symbol(symbol) or enable_futures
    
    market_types = ["swap", "spot"] if prefer_swap else ["spot", "swap"]
    
    for market_type in market_types:
        try:
            client = get_ccxt_client(exchange_id, market_type)
            if not client:
                continue
            
            ticker = client.fetch_ticker(ccxt_symbol)
            price = ticker.get("last") or ticker.get("close") or ticker.get("bid") or ticker.get("ask")
            if price:
                return float(price)
        except Exception:
            continue
    
    return None


@st.cache_data(ttl=10, show_spinner=False)
def fetch_ohlcv_data(
    exchange_id: str,
    symbol: str,
    enable_futures: bool = False,
    timeframe: str = "5m",
    limit: int = 200
) -> Tuple[Optional[pd.DataFrame], Optional[float]]:
    """Fetch OHLCV data with caching."""
    ccxt_symbol = to_ccxt_symbol(symbol)
    prefer_swap = is_swap_symbol(symbol) or enable_futures
    market_types = ["swap", "spot"] if prefer_swap else ["spot", "swap"]
    
    for market_type in market_types:
        try:
            client = get_ccxt_client(exchange_id, market_type)
            if not client:
                continue
            
            # Validate timeframe
            timeframes = client.timeframes if hasattr(client, 'timeframes') else {}
            if timeframe not in timeframes:
                # Try to find closest match
                if timeframe == "1m" and "1m" not in timeframes:
                    timeframe = "1m" if "1m" in timeframes else list(timeframes.keys())[0]
            
            ohlcv = client.fetch_ohlcv(ccxt_symbol, timeframe=timeframe, limit=min(limit, 1000))
            
            if not ohlcv:
                continue
            
            df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
            df["dt"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
            
            # Calculate SMA if requested
            if st.session_state.get('show_sma', False):
                period = st.session_state.get('sma_period', 20)
                df['sma'] = df['close'].rolling(window=period, min_periods=1).mean()
            
            last_price = float(df['close'].iloc[-1]) if not df.empty else None
            
            return df, last_price
            
        except Exception:
            continue
    
    return None, None


# ----------------------------
# Data normalizers
# ----------------------------
def normalize_positions(data: Any) -> pd.DataFrame:
    """Normalize positions data."""
    if not data:
        return pd.DataFrame()
    
    rows = []
    
    if isinstance(data, list):
        rows = [dict(r) for r in data if isinstance(r, dict)]
    elif isinstance(data, dict):
        # Could be dict of positions keyed by symbol
        if all(isinstance(v, dict) for v in data.values()):
            rows = list(data.values())
        else:
            rows = [data]
    
    if not rows:
        return pd.DataFrame()
    
    df = pd.DataFrame(rows)
    
    # Ensure required columns
    if "symbol" not in df.columns and len(df) > 0:
        return pd.DataFrame()
    
    # Calculate derived columns
    if "qty" in df.columns:
        df["qty"] = pd.to_numeric(df["qty"], errors="coerce").fillna(0)
        df["side"] = df["qty"].apply(lambda x: "long" if x > 0 else "short" if x < 0 else "flat")
    
    # Numeric columns
    numeric_cols = ["entry", "stop", "tp", "size", "unrealized_pnl", "realized_pnl", "leverage"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    
    # Calculate current value if entry and qty available
    if "entry" in df.columns and "qty" in df.columns:
        df["current_value"] = df["entry"] * abs(df["qty"])
    
    return df


def normalize_pending(data: Any) -> pd.DataFrame:
    """Normalize pending orders data."""
    if not data:
        return pd.DataFrame()
    
    rows = []
    
    if isinstance(data, list):
        rows = [dict(r) for r in data if isinstance(r, dict)]
    elif isinstance(data, dict):
        # Could be dict keyed by order id
        if all(isinstance(v, dict) for v in data.values()):
            rows = list(data.values())
        else:
            rows = [data]
    
    if not rows:
        return pd.DataFrame()
    
    df = pd.DataFrame(rows)
    
    # Ensure required columns
    required_cols = ["id", "symbol", "side", "type", "qty"]
    for col in required_cols:
        if col not in df.columns:
            df[col] = None
    
    # Numeric columns
    numeric_cols = ["qty", "price", "filled_qty", "created_ts", "updated_ts"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    
    # Parse timestamps
    if "created_ts" in df.columns:
        df["created_dt"] = pd.to_datetime(df["created_ts"], unit="s", utc=True, errors="coerce")
    
    return df


def normalize_trades(data: Any) -> pd.DataFrame:
    """Normalize trades data."""
    if not data:
        return pd.DataFrame()
    
    rows = []
    
    if isinstance(data, list):
        rows = [dict(r) for r in data if isinstance(r, dict)]
    elif isinstance(data, dict) and "trades" in data:
        rows = data["trades"]
    
    if not rows:
        return pd.DataFrame()
    
    df = pd.DataFrame(rows)
    
    # Parse timestamp
    if "ts" in df.columns:
        df["dt"] = pd.to_datetime(df["ts"], unit="s", utc=True, errors="coerce")
    elif "timestamp" in df.columns:
        df["dt"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True, errors="coerce")
    
    # Numeric columns
    numeric_cols = ["qty", "price", "fee", "realized_pnl", "cost", "notional"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    
    # Calculate PnL percentage if entry price available
    if "entry_price" in df.columns and "price" in df.columns:
        df["pnl_pct"] = (df["price"] - df["entry_price"]) / df["entry_price"] * 100
    
    return df


def normalize_portfolio(data: Any) -> Dict[str, Any]:
    """Normalize portfolio data."""
    if not isinstance(data, dict):
        return {}
    
    portfolio = data.copy()
    
    # Ensure numeric fields
    numeric_fields = ["equity", "cash", "total_value", "unrealized_pnl", "realized_pnl", 
                     "daily_pnl", "daily_pnl_pct", "total_pnl", "total_pnl_pct"]
    
    for field in numeric_fields:
        if field in portfolio:
            try:
                portfolio[field] = float(portfolio[field])
            except (ValueError, TypeError):
                portfolio[field] = 0.0
    
    return portfolio


# ----------------------------
# Performance metrics - FIXED VERSION
# ----------------------------
def calculate_performance_metrics(trades_df: pd.DataFrame) -> Dict[str, Any]:
    """Calculate trading performance metrics with NaN protection."""
    if trades_df.empty:
        return {
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "win_rate": 0,
            "total_pnl": 0,
            "avg_win": 0,
            "avg_loss": 0,
            "profit_factor": 0,
            "max_drawdown": 0,
            "sharpe_ratio": 0,
        }
    
    df = trades_df.copy()
    
    # Ensure we have PnL data
    if "realized_pnl" not in df.columns:
        return {"total_trades": len(df), "total_pnl": 0}
    
    # Replace NaN values with 0
    df["realized_pnl"] = pd.to_numeric(df["realized_pnl"], errors="coerce").fillna(0)
    
    # Basic metrics with NaN protection
    winning_trades = df[df["realized_pnl"] > 0]
    losing_trades = df[df["realized_pnl"] < 0]
    
    total_trades = len(df)
    winning_count = len(winning_trades)
    losing_count = len(losing_trades)
    
    win_rate = winning_count / total_trades if total_trades > 0 else 0
    
    total_pnl = df["realized_pnl"].sum()
    
    # Safe mean calculation
    avg_win = winning_trades["realized_pnl"].mean() if not winning_trades.empty else 0
    avg_loss = losing_trades["realized_pnl"].mean() if not losing_trades.empty else 0
    
    # Profit factor with zero division protection
    gross_profit = winning_trades["realized_pnl"].sum() if not winning_trades.empty else 0
    gross_loss = abs(losing_trades["realized_pnl"].sum()) if not losing_trades.empty else 0
    
    if gross_loss != 0:
        profit_factor = gross_profit / gross_loss
        if np.isinf(profit_factor) or np.isnan(profit_factor):
            profit_factor = 0
    else:
        profit_factor = 0 if gross_profit == 0 else float('inf')
    
    # Calculate cumulative PnL for drawdown
    df = df.sort_values("dt")
    df["cumulative_pnl"] = df["realized_pnl"].cumsum()
    df["running_max"] = df["cumulative_pnl"].cummax()
    df["drawdown"] = df["cumulative_pnl"] - df["running_max"]
    
    max_drawdown = df["drawdown"].min() if not df.empty and "drawdown" in df.columns else 0
    
    # Sharpe ratio (simplified) with NaN protection
    if len(df) > 1:
        returns = df["realized_pnl"].pct_change().replace([np.inf, -np.inf], 0).fillna(0)
        returns_std = returns.std()
        
        if returns_std > 0 and not np.isnan(returns_std):
            # Avoid division by very small numbers
            if returns_std < 1e-10:
                sharpe_ratio = 0
            else:
                returns_mean = returns.mean()
                if np.isnan(returns_mean):
                    sharpe_ratio = 0
                else:
                    sharpe_ratio = (returns_mean / returns_std) * np.sqrt(365 * 24)  # Annualized
        else:
            sharpe_ratio = 0
    else:
        sharpe_ratio = 0
    
    # Convert any remaining NaN/Inf to 0
    return {
        "total_trades": int(total_trades),
        "winning_trades": int(winning_count),
        "losing_trades": int(losing_count),
        "win_rate": float(win_rate),
        "total_pnl": float(total_pnl) if not np.isnan(total_pnl) else 0.0,
        "avg_win": float(avg_win) if not np.isnan(avg_win) else 0.0,
        "avg_loss": float(avg_loss) if not np.isnan(avg_loss) else 0.0,
        "profit_factor": float(profit_factor) if not (np.isnan(profit_factor) or np.isinf(profit_factor)) else 0.0,
        "max_drawdown": float(max_drawdown) if not np.isnan(max_drawdown) else 0.0,
        "sharpe_ratio": float(sharpe_ratio) if not np.isnan(sharpe_ratio) else 0.0,
    }


# ----------------------------
# Chart functions
# ----------------------------
def create_price_chart(
    ohlcv_df: pd.DataFrame,
    positions: pd.DataFrame,
    symbol: str,
    entry_price: Optional[float] = None,
    stop_price: Optional[float] = None,
    take_profit: Optional[float] = None
) -> go.Figure:
    """Create price chart with positions."""
    if ohlcv_df.empty:
        return go.Figure()
    
    # Create subplot for price and volume
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.05,
        row_heights=[0.7, 0.3],
        subplot_titles=(f"{symbol} Price", "Volume")
    )
    
    # Candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=ohlcv_df["dt"],
            open=ohlcv_df["open"],
            high=ohlcv_df["high"],
            low=ohlcv_df["low"],
            close=ohlcv_df["close"],
            name="Price",
            showlegend=False
        ),
        row=1, col=1
    )
    
    # Add SMA if available
    if "sma" in ohlcv_df.columns and st.session_state.get('show_sma', False):
        fig.add_trace(
            go.Scatter(
                x=ohlcv_df["dt"],
                y=ohlcv_df["sma"],
                name=f"SMA {st.session_state.get('sma_period', 20)}",
                line=dict(color="orange", width=2),
                opacity=0.7
            ),
            row=1, col=1
        )
    
    # Add position lines
    line_colors = {
        "entry": "green",
        "stop": "red",
        "tp": "blue"
    }
    
    lines = [
        ("Entry", entry_price, "solid"),
        ("Stop", stop_price, "dash"),
        ("Take Profit", take_profit, "dot")
    ]
    
    for name, price, dash in lines:
        if price is not None and price > 0:
            color = line_colors.get(name.lower().replace(" ", ""), "gray")
            fig.add_hline(
                y=price,
                line_dash=dash,
                line_color=color,
                annotation_text=name,
                annotation_position="right",
                row=1, col=1
            )
    
    # Volume chart
    if st.session_state.get('show_volume', True) and "volume" in ohlcv_df.columns:
        colors = []
        for i in range(len(ohlcv_df)):
            if i < len(ohlcv_df):
                if ohlcv_df['close'].iloc[i] < ohlcv_df['open'].iloc[i]:
                    colors.append('red')
                else:
                    colors.append('green')
            else:
                colors.append('gray')
        
        fig.add_trace(
            go.Bar(
                x=ohlcv_df["dt"],
                y=ohlcv_df["volume"],
                name="Volume",
                marker_color=colors,
                showlegend=False
            ),
            row=2, col=1
        )
    
    # Update layout
    fig.update_layout(
        height=600,
        margin=dict(l=10, r=10, t=50, b=10),
        xaxis_rangeslider_visible=False,
        hovermode="x unified"
    )
    
    fig.update_xaxes(title_text="Time", row=2, col=1)
    fig.update_yaxes(title_text="Price", row=1, col=1)
    fig.update_yaxes(title_text="Volume", row=2, col=1)
    
    return fig


# ----------------------------
# Main UI
# ----------------------------
def main():
    """Main application."""
    # Initialize session state
    init_session_state()
    
    # Header
    st.title("📊 Crypto Trading Bot Dashboard v3")
    st.markdown("Real-time monitoring and analytics for your trading bot")
    
    # ----------------------------
    # Sidebar
    # ----------------------------
    with st.sidebar:
        st.header("⚙️ Settings")
        
        # Refresh settings
        st.session_state.auto_refresh = st.toggle("Auto Refresh", value=True)
        st.session_state.refresh_sec = st.slider("Refresh Interval (seconds)", 1, 30, 3)
        
        st.divider()
        
        # API settings
        st.subheader("🤖 Bot API")
        st.session_state.api_url = st.text_input("API URL", value="http://127.0.0.1:8000")
        st.session_state.poll_api = st.toggle("Poll API", value=True)
        
        if st.session_state.poll_api:
            col1, col2 = st.columns(2)
            with col1:
                st.session_state.trades_limit = st.slider("Trades Limit", 50, 5000, 800, 50)
            with col2:
                st.session_state.trace_limit = st.slider("Trace Limit", 50, 2000, 400, 50)
            
            st.session_state.trace_level = st.selectbox(
                "Trace Level",
                ["debug", "info", "warning", "error"],
                index=1
            )
        
        st.divider()
        
        # Chart settings
        st.subheader("📈 Chart Settings")
        st.session_state.chart_tf = st.selectbox(
            "Timeframe",
            ["1m", "3m", "5m", "15m", "30m", "1h", "4h", "1d"],
            index=2
        )
        st.session_state.candle_limit = st.slider("Candles", 50, 500, 200, 50)
        
        col1, col2 = st.columns(2)
        with col1:
            st.session_state.show_sma = st.toggle("Show SMA", value=False)
        with col2:
            st.session_state.show_volume = st.toggle("Show Volume", value=True)
        
        if st.session_state.show_sma:
            st.session_state.sma_period = st.slider("SMA Period", 5, 100, 20, 5)
        
        st.divider()
        
        # Database settings
        st.subheader("💾 Database")
        st.session_state.use_sqlite = st.toggle("Use SQLite", value=False)
        
        if st.session_state.use_sqlite:
            default_db = os.path.join(os.getcwd(), "bot.db")
            db_path = st.text_input("Database Path", value=default_db)
            st.session_state.table_limit = st.slider("Rows per Table", 50, 20000, 800, 50)
        
        st.divider()
        
        # Manual symbol input
        st.subheader("🔍 Manual Chart")
        st.session_state.manual_symbol = st.text_input("Symbol", value="BTC/USDT")
        
        if st.button("Update All Data", type="primary"):
            st.cache_data.clear()
            st.cache_resource.clear()
            st.rerun()
    
    # ----------------------------
    # API Polling
    # ----------------------------
    if st.session_state.poll_api and st.session_state.api_url:
        with st.spinner("Fetching data from bot API..."):
            # Parallel API calls
            endpoints = {
                'status': '/status',
                'portfolio': '/portfolio',
                'positions': '/positions',
                'pending': '/pending',
                'trades': f'/trades?limit={st.session_state.trades_limit}',
                'trace': f'/trace?limit={st.session_state.trace_limit}',
            }
            
            responses = {}
            for key, endpoint in endpoints.items():
                responses[key] = api_get(st.session_state.api_url, endpoint)
            
            # Store data in session state
            st.session_state.api_status = unpack_data(responses.get('status')) or {}
            st.session_state.portfolio_data = normalize_portfolio(unpack_data(responses.get('portfolio')))
            st.session_state.positions_data = normalize_positions(unpack_data(responses.get('positions')))
            st.session_state.pending_data = normalize_pending(unpack_data(responses.get('pending')))
            st.session_state.trades_data = normalize_trades(unpack_data(responses.get('trades')))
            st.session_state.trace_data = unpack_data(responses.get('trace')) or []
            
            st.session_state.last_update = datetime.now()
    
    # ----------------------------
    # Main Tabs
    # ----------------------------
    tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "📈 Charts", "📋 Logs", "💾 Database"])
    
    # ----------------------------
    # Tab 1: Dashboard
    # ----------------------------
    with tab1:
        # Status metrics
        st.subheader("📊 Status Overview")
        
        col1, col2, col3, col4, col5, col6 = st.columns(6)
        
        with col1:
            status_ok = st.session_state.api_status.get('running', False)
            status_color = "green" if status_ok else "red"
            st.metric(
                "Bot Status",
                "🟢 Running" if status_ok else "🔴 Stopped",
                delta=None,
                delta_color=status_color
            )
        
        with col2:
            mode = st.session_state.api_status.get('mode', 'unknown')
            st.metric("Mode", mode.title())
        
        with col3:
            exchange = st.session_state.api_status.get('exchange', 'unknown')
            st.metric("Exchange", exchange.title())
        
        with col4:
            equity = st.session_state.portfolio_data.get('equity', 0)
            st.metric("Equity", f"${format_float(equity, 2)}")
        
        with col5:
            unrealized_pnl = st.session_state.portfolio_data.get('unrealized_pnl', 0)
            pnl_color = "green" if unrealized_pnl >= 0 else "red"
            st.metric(
                "Unrealized PnL",
                f"${format_float(unrealized_pnl, 2)}",
                delta_color=pnl_color
            )
        
        with col6:
            realized_pnl = st.session_state.portfolio_data.get('realized_pnl', 0)
            pnl_color = "green" if realized_pnl >= 0 else "red"
            st.metric(
                "Realized PnL",
                f"${format_float(realized_pnl, 2)}",
                delta_color=pnl_color
            )
        
        # Performance metrics
        st.divider()
        st.subheader("📈 Performance Metrics")
        
        if not st.session_state.trades_data.empty:
            metrics = calculate_performance_metrics(st.session_state.trades_data)
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Trades", metrics['total_trades'])
                st.metric("Win Rate", format_percent(metrics['win_rate'], 1))
            
            with col2:
                st.metric("Total PnL", f"${format_float(metrics['total_pnl'], 2)}")
                st.metric("Profit Factor", format_float(metrics['profit_factor'], 2))
            
            with col3:
                st.metric("Avg Win", f"${format_float(metrics['avg_win'], 2)}")
                st.metric("Avg Loss", f"${format_float(metrics['avg_loss'], 2)}")
            
            with col4:
                st.metric("Max Drawdown", f"${format_float(metrics['max_drawdown'], 2)}")
                st.metric("Sharpe Ratio", format_float(metrics['sharpe_ratio'], 2))
        else:
            st.info("No trade data available for performance metrics.")
        
        # Positions and Orders
        st.divider()
        st.subheader("📊 Positions & Orders")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Open Positions")
            if not st.session_state.positions_data.empty:
                # Calculate current prices and PnL
                positions_df = st.session_state.positions_data.copy()
                
                # Add current price and unrealized PnL
                exchange_id = st.session_state.api_status.get('exchange', 'binance')
                enable_futures = st.session_state.api_status.get('enable_futures', False)
                
                current_prices = []
                for symbol in positions_df['symbol']:
                    price = fetch_last_price(exchange_id, symbol, enable_futures)
                    current_prices.append(price or 0)
                
                positions_df['current_price'] = current_prices
                
                if 'entry' in positions_df.columns and 'qty' in positions_df.columns:
                    positions_df['unrealized_pnl'] = (positions_df['current_price'] - positions_df['entry']) * positions_df['qty']
                    positions_df['unrealized_pnl_pct'] = (positions_df['current_price'] - positions_df['entry']) / positions_df['entry'] * 100
                
                # Display
                display_cols = ['symbol', 'side', 'qty', 'entry', 'current_price', 'unrealized_pnl', 'unrealized_pnl_pct']
                display_cols = [c for c in display_cols if c in positions_df.columns]
                
                st.dataframe(
                    positions_df[display_cols],
                    width='stretch',
                    hide_index=True
                )
            else:
                st.info("No open positions")
        
        with col2:
            st.markdown("#### Pending Orders")
            if not st.session_state.pending_data.empty:
                display_cols = ['symbol', 'side', 'type', 'qty', 'price', 'filled_qty', 'created_dt']
                display_cols = [c for c in display_cols if c in st.session_state.pending_data.columns]
                
                st.dataframe(
                    st.session_state.pending_data[display_cols],
                    width='stretch',
                    hide_index=True
                )
            else:
                st.info("No pending orders")
        
        # Recent Trades
        st.divider()
        st.subheader("📋 Recent Trades")
        
        if not st.session_state.trades_data.empty:
            trades_df = st.session_state.trades_data.sort_values('dt', ascending=False).head(20)
            
            display_cols = ['dt', 'symbol', 'side', 'qty', 'price', 'fee', 'realized_pnl']
            display_cols = [c for c in display_cols if c in trades_df.columns]
            
            st.dataframe(
                trades_df[display_cols],
                width='stretch',
                hide_index=True
            )
            
            # Download button
            csv = trades_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Trades CSV",
                data=csv,
                file_name=f"trades_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
        else:
            st.info("No trades recorded")
    
    # ----------------------------
    # Tab 2: Charts
    # ----------------------------
    with tab2:
        st.subheader("📈 Price Charts")
        
        # Chart mode selection
        chart_mode = st.radio(
            "Chart Mode",
            ["Open Positions", "Manual Symbol"],
            horizontal=True,
            index=0
        )
        
        # Get symbol based on mode
        if chart_mode == "Open Positions" and not st.session_state.positions_data.empty:
            symbols = st.session_state.positions_data['symbol'].unique().tolist()
            selected_symbol = st.selectbox("Select Position", symbols)
            
            # Get position data
            position_row = st.session_state.positions_data[
                st.session_state.positions_data['symbol'] == selected_symbol
            ].iloc[0] if not st.session_state.positions_data.empty else None
            
            entry_price = position_row.get('entry') if position_row is not None else None
            stop_price = position_row.get('stop') if position_row is not None else None
            take_profit = position_row.get('tp') if position_row is not None else None
            
        else:
            selected_symbol = st.session_state.manual_symbol
            entry_price = stop_price = take_profit = None
        
        if selected_symbol:
            # Fetch OHLCV data
            exchange_id = st.session_state.api_status.get('exchange', 'binance')
            enable_futures = st.session_state.api_status.get('enable_futures', False)
            
            ohlcv_df, last_price = fetch_ohlcv_data(
                exchange_id=exchange_id,
                symbol=selected_symbol,
                enable_futures=enable_futures,
                timeframe=st.session_state.chart_tf,
                limit=st.session_state.candle_limit
            )
            
            if ohlcv_df is not None and not ohlcv_df.empty:
                # Create chart
                fig = create_price_chart(
                    ohlcv_df=ohlcv_df,
                    positions=st.session_state.positions_data,
                    symbol=selected_symbol,
                    entry_price=entry_price,
                    stop_price=stop_price,
                    take_profit=take_profit
                )
                
                # Display chart - FIXED: use width='stretch' instead of use_container_width
                st.plotly_chart(fig, width='stretch')
                
                # Price info
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Last Price", format_float(last_price, 6))
                with col2:
                    st.metric("High", format_float(ohlcv_df['high'].max(), 6))
                with col3:
                    st.metric("Low", format_float(ohlcv_df['low'].min(), 6))
                with col4:
                    change = ((last_price - ohlcv_df['close'].iloc[0]) / ohlcv_df['close'].iloc[0] * 100) if last_price else 0
                    st.metric("Change", f"{format_float(change, 2)}%")
            else:
                st.error(f"Could not fetch data for {selected_symbol}")
        else:
            st.info("Select a symbol to display chart")
    
    # ----------------------------
    # Tab 3: Logs
    # ----------------------------
    with tab3:
        st.subheader("📋 Bot Logs & Trace")
        
        if st.session_state.trace_data:
            # Convert trace data to DataFrame
            trace_rows = []
            for event in st.session_state.trace_data:
                if isinstance(event, dict):
                    trace_rows.append({
                        'timestamp': event.get('ts'),
                        'level': event.get('level', 'info'),
                        'message': event.get('msg', ''),
                        'component': event.get('ctx', {}).get('component', ''),
                        'symbol': event.get('ctx', {}).get('symbol', ''),
                        'details': str(event.get('ctx', {}))
                    })
            
            if trace_rows:
                trace_df = pd.DataFrame(trace_rows)
                trace_df['datetime'] = pd.to_datetime(trace_df['timestamp'], unit='s', utc=True)
                
                # Filter by level
                level_order = ['error', 'warning', 'info', 'debug']
                current_level_index = level_order.index(st.session_state.trace_level)
                visible_levels = level_order[current_level_index:]
                
                filtered_df = trace_df[trace_df['level'].isin(visible_levels)].copy()
                
                # Display filters
                col1, col2, col3 = st.columns(3)
                with col1:
                    show_components = st.multiselect(
                        "Filter Components",
                        options=filtered_df['component'].unique(),
                        default=[]
                    )
                with col2:
                    show_symbols = st.multiselect(
                        "Filter Symbols",
                        options=filtered_df['symbol'].unique(),
                        default=[]
                    )
                with col3:
                    show_levels = st.multiselect(
                        "Filter Levels",
                        options=filtered_df['level'].unique(),
                        default=filtered_df['level'].unique()
                    )
                
                # Apply filters
                if show_components:
                    filtered_df = filtered_df[filtered_df['component'].isin(show_components)]
                if show_symbols:
                    filtered_df = filtered_df[filtered_df['symbol'].isin(show_symbols)]
                if show_levels:
                    filtered_df = filtered_df[filtered_df['level'].isin(show_levels)]
                
                # Display logs
                st.dataframe(
                    filtered_df[['datetime', 'level', 'component', 'symbol', 'message']],
                    width='stretch',
                    hide_index=True,
                    column_config={
                        'level': st.column_config.TextColumn(
                            'Level',
                            help='Log level'
                        ),
                        'datetime': st.column_config.DatetimeColumn(
                            'Time',
                            format='YYYY-MM-DD HH:mm:ss'
                        ),
                        'message': st.column_config.TextColumn(
                            'Message',
                            width='large'
                        )
                    }
                )
                
                # Statistics
                st.divider()
                st.subheader("📊 Log Statistics")
                
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Total Events", len(trace_df))
                with col2:
                    st.metric("Errors", len(trace_df[trace_df['level'] == 'error']))
                with col3:
                    st.metric("Warnings", len(trace_df[trace_df['level'] == 'warning']))
                with col4:
                    st.metric("Info", len(trace_df[trace_df['level'] == 'info']))
        else:
            st.info("No trace data available. Make sure trace endpoint is enabled.")
    
    # ----------------------------
    # Tab 4: Database
    # ----------------------------
    with tab4:
        st.subheader("💾 Database Explorer")
        
        if st.session_state.use_sqlite:
            db_path = os.path.join(os.getcwd(), "bot.db")
            
            if os.path.exists(db_path):
                try:
                    conn = get_db_connection(db_path)
                    tables = list_tables(conn)
                    
                    st.metric("Database Size", f"{os.path.getsize(db_path) / 1_000_000:.2f} MB")
                    st.metric("Tables Count", len(tables))
                    
                    if tables:
                        selected_table = st.selectbox("Select Table", tables)
                        
                        if selected_table:
                            df = read_table(conn, selected_table, st.session_state.table_limit)
                            
                            if not df.empty:
                                # Display table info
                                st.write(f"**Table:** {selected_table}")
                                st.write(f"**Rows:** {len(df)}")
                                st.write(f"**Columns:** {', '.join(df.columns)}")
                                
                                # Display data
                                st.dataframe(df, width='stretch')
                                
                                # Basic analytics for numeric columns
                                numeric_cols = df.select_dtypes(include=[np.number]).columns
                                if not numeric_cols.empty:
                                    st.subheader("📈 Numeric Columns Summary")
                                    summary = df[numeric_cols].describe()
                                    st.dataframe(summary, width='stretch')
                            else:
                                st.info(f"Table '{selected_table}' is empty")
                    else:
                        st.warning("No tables found in database")
                        
                except Exception as e:
                    st.error(f"Database error: {e}")
            else:
                st.error(f"Database file not found: {db_path}")
        else:
            st.info("Enable SQLite in sidebar to explore database")
    
    # ----------------------------
    # Auto Refresh
    # ----------------------------
    if st.session_state.auto_refresh:
        st_autorefresh(
            interval=st.session_state.refresh_sec * 1000,
            key="auto_refresh"
        )
    
    # ----------------------------
    # Footer
    # ----------------------------
    st.divider()
    
    if st.session_state.last_update:
        st.caption(f"Last update: {st.session_state.last_update.strftime('%Y-%m-%d %H:%M:%S')}")
    
    st.caption("Crypto Trading Bot Dashboard v3 | Made with Streamlit")


if __name__ == "__main__":
    main()
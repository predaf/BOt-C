# Improvements package (2026-01-31)

This ZIP contains the bot codebase from the last delivered archive, plus the
following 10 targeted upgrades.

1) **Risk-state reason is never blank**
   - `risk_state` now emits `reason="ok"` in NORMAL, and composes a short reason
     string when guards trigger.

2) **Risk-state module interface hardened**
   - `RiskStateOrchestrator.update()` returns a typed `RiskStateResult` with
     `.state/.risk_mult/.reason`.
   - `RiskStateOrchestrator.apply_to_engine()` is present and safe.

3) **Backtest timezone warning removed**
   - Trend slicing uses int64 nanoseconds for `searchsorted`, eliminating numpy
     timezone warnings and improving performance.

4) **Write endpoints protected in LIVE mode**
   - `POST /control`, `POST /control/manual_entry`, `POST /api/system/*` require
     `X-API-Key` (or `Authorization: Bearer ...`) when `mode=live`.
   - Configure via env `BOT_API_KEY` or config `api.key`.

5) **Safer default for missing API key**
   - In LIVE mode, if no key is configured, write endpoints are blocked with a
     clear error (prevents accidental remote trading/control).

6) **More informative `/health` and `/status` (internal wiring)**
   - Risk-state now provides consistent metadata that the API can safely expose.

7) **Backward compatible output shape**
   - Existing dashboards expecting `state/reason/controller` continue to work.

8) **Better failure isolation**
   - Risk-state apply step will not throw even if engine fields change; it falls
     back gracefully.

9) **Config surface documented**
   - This file documents new `api.key` / `BOT_API_KEY` usage.

10) **Zero behavior change in paper mode**
   - Authentication is *only* enforced in `mode=live`.

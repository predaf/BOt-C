import os, json, logging
import ccxt

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("debug")

def as_bool(x, default=False):
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    return str(x).strip().lower() in ("1", "true", "yes", "y", "on")

def default_type(exchange_id: str, enable_futures: bool) -> str:
    if not enable_futures:
        return "spot"
    return "swap" if exchange_id.lower() == "bybit" else "future"

# 1) load config.json if present
cfg = {}
cfg_path = os.path.join(os.path.dirname(__file__), "config.json")
if os.path.exists(cfg_path):
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

# 2) read key values from config or env
exchange_id = (cfg.get("exchange") or os.getenv("BOT_EXCHANGE") or "binance").strip().lower()
enable_futures = as_bool(cfg.get("enable_futures", None), as_bool(os.getenv("ENABLE_FUTURES", "false")))
dtype = default_type(exchange_id, enable_futures)

api_key = os.getenv(f"{exchange_id.upper()}_API_KEY", "") or os.getenv("BINANCE_API_KEY", "") or os.getenv("BYBIT_API_KEY", "")
secret = os.getenv(f"{exchange_id.upper()}_SECRET", "") or os.getenv("BINANCE_SECRET", "") or os.getenv("BYBIT_SECRET", "")

log.info(f"exchange={exchange_id} enable_futures={enable_futures} defaultType={dtype} has_keys={bool(api_key and secret)}")

# 3) init ccxt
ex_class = getattr(ccxt, exchange_id)
params = {"enableRateLimit": True, "options": {"defaultType": dtype}}
if api_key and secret:
    params["apiKey"] = api_key
    params["secret"] = secret

ex = ex_class(params)

# 4) load markets and print futures USDT samples
mk = ex.load_markets()
print("defaultType =", ex.options.get("defaultType"))
print("markets =", len(mk))

# futures-like (swap/future/contract) and USDT in symbol
f = []
for s, m in mk.items():
    if ("USDT" in s) and (m.get("swap") or m.get("future") or m.get("contract")):
        f.append(s)

print("sample futures:", f[:30])
print("count futures USDT:", len(f))

# 5) also print a few spot USDT symbols for sanity
spot = []
for s, m in mk.items():
    if ("/USDT" in s) and m.get("spot"):
        spot.append(s)
print("sample spot:", spot[:20])
print("count spot USDT:", len(spot))

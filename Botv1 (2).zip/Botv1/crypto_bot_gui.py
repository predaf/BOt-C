from __future__ import annotations
import os, threading, time, json, shutil, datetime, socket, csv
from typing import Optional, Tuple, List, Dict, Any

from dotenv import load_dotenv
load_dotenv()
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from app.config import load_config, save_config, apply_env_overrides
from app.utils import UILogger, CompositeLogger, setup_file_logger
from app.records import TradeRecorder
from app.engine import TradingEngine
from app.exchange import ExchangeClient
from app.backtest import simulate, walk_forward_optimize

# Optional local API
try:
    import uvicorn
    from app.api import create_app
except Exception:
    uvicorn = None
    create_app = None

DEFAULT_CONFIG = {
    "mode": "paper",
    "exchange": "binance",
    "api_key": "",
    "api_secret": "",
    "sandbox": False,
    "bybit_testnet": False,
    "quote_asset": "USDT",
    "signal_timeframe": "5m",
    "trend_timeframe": "1h",
    "ohlcv_limit": 500,
    "max_pairs": 12,
    "pair_refresh_sec": 900,
    "scan_interval_sec": 15,
    "pair_filters": {
        "min_quote_volume_usd": 5000000,
        "min_price_usd": 0.01,
        "max_spread_bps": 25,
        "exclude_leveraged_tokens": True,
        "whitelist": [],
        "blacklist": []
    },
    "execution": {
        "type": "maker_limit",
        "post_only": True,
        "maker_offset_bps": 2.0,
        "repost_sec": 15,
        "max_reposts": 8,
        "allow_market_fallback": True,
        "retry": {
            "enabled": True,
            "max_retries": 6,
            "base_delay_ms": 250,
            "max_delay_ms": 5000,
            "jitter_ms": 250
        },
        "idempotency": {
            "enabled": True,
            "prefix": "bot"
        },
        "smart_limit": {
            "edge_bps": 6,
            "max_move_bps": 25,
            "max_wait_sec": 15
        }
    },
    "micro_model": {
        "enabled": True,
        "orderbook_depth": 20,
        "max_spread_bps_for_maker": 35.0,
        "min_p_fill_for_maker": 0.25,
        "dynamic_offset": True,
        "offset_min_bps": 1.0,
        "offset_max_bps": 14.0,
        "k_distance": 0.22,
        "k_vol": 8.0,
        "use_imbalance": True
    },
    "websocket": {
        "enabled": True,
        "provider": "native",
        "symbols_max": 60,
        "reconnect_sec": 5
    },
    "paper": {
        "initial_cash_quote": 2000.0,
        "taker_fee_rate": 0.001,
        "maker_fee_rate": 0.0008,
        "market_slippage_bps": 8.0,
        "limit_slippage_bps": 0.0,
        "limit_fill_model": {
            "near_bps": 6.0,
            "p_near": 0.35,
            "timeout_sec": 240,
            "timeout_action": "cancel"
        }
    },
    "risk": {
        "risk_per_trade": 0.005,
        "max_position_pct": 0.15,
        "max_open_positions": 3,
        "cooldown_sec": 120,
        "atr_period": 14,
        "stop_atr_mult": 2.5,
        "tp_atr_mult": 3.5,
        "use_trailing": True,
        "trail_atr_mult": 2.0,
        "volatility_pause_atr_pct": 0.03,
        "scale_out": {
            "enabled": True,
            "tp1_atr_mult": 2.0,
            "tp1_pct": 0.5,
            "move_stop_to_be": True
        },
        "kill_switch": {
            "max_daily_loss_pct": 0.03,
            "max_drawdown_pct": 0.08,
            "max_trades_per_day": 50,
            "close_all_on_halt": False,
            "intraday_shock": {
                "enabled": True,
                "window_min": 30,
                "drop_pct": 0.015
            }
        },
        "portfolio": {
            "correlation_filter": {
                "enabled": True,
                "lookback": 120,
                "max_corr": 0.8
            },
            "sector_limit": {
                "enabled": False,
                "max_per_tag": 2,
                "tags": {}
            }
        }
    },
    "strategies": {
        "ema_cross": {
            "enabled": True,
            "fast": 12,
            "slow": 26
        },
        "rsi_reversion": {
            "enabled": True,
            "period": 14,
            "buy_below": 30,
            "sell_above": 70
        },
        "donchian_breakout": {
            "enabled": True,
            "lookback": 20
        },
        "momentum_filter": {
            "enabled": True,
            "lookback": 20,
            "min_return": 0.003
        },
        "mtf_confirm": {
            "enabled": True,
            "require_trend_agree": True
        },
        "regime": {
            "enabled": True,
            "mode": "auto"
        }
    },
    "auto_opt": {
        "enabled": False,
        "interval_hours": 12,
        "walk_forward": {
            "train_frac": 0.7,
            "candidates": {
                "ema_fast": [8, 12, 16],
                "ema_slow": [21, 26, 34],
                "rsi_buy": [28, 30, 32],
                "rsi_sell": [68, 70, 72]
            }
        }
    },
    "metrics": {
        "enabled": True,
        "prometheus": {
            "enabled": True,
            "port": 9108
        }
    },
    "state": {
        "enable_persistence": True,
        "resume_on_start": False,
        "save_interval_sec": 30,
        "path": "state.json"
    },
    "watchdog": {
        "enabled": True,
        "max_consecutive_errors": 8,
        "pause_sec": 120,
        "backoff_factor": 1.7,
        "max_pause_sec": 1800,
        "auto_resume": True
    },
    "paths": {
        "log_file": "logs/bot.log",
        "trades_csv": "trades.csv"
    },
    "quote_assets": ["USDT", "USDC"],
    "api": {
        "enabled": False,
        "host": "127.0.0.1",
        "port": 8000,
        "auto_port": True,
        "max_port_tries": 50
    },
    "approvals": {
        "enabled": True,
        "timeout_sec": 300,
        "require_for_live": True,
        "require_for_paper": False
    },
    "sqlite": {
        "enabled": True,
        "path": "bot.db"
    },
    "notifier": {
        "enabled": False,
        "telegram": {
            "enabled": False,
            "bot_token": "",
            "chat_id": ""
        },
        "email": {
            "enabled": False,
            "smtp_host": "",
            "smtp_port": 587,
            "username": "",
            "password": "",
            "to": "",
            "use_tls": True
        }
    },
    "market_guard": {
        "enabled": True,
        "timeframe": "5m",
        "symbols": ["BTC/USDT", "ETH/USDT"],
        "atr_period": 14,
        "atr_pct_halt": 0.02,
        "cooldown_sec": 300,
        "breadth_universe_max": 40,
        "breadth_drop_pct": 0.65,
        "breadth_lookback_bars": 6
    },
    "signal_thresholds": {
        "buy": 1.0,
        "sell": -1.0
    },
    "signals": {
        "history_max": 2000,
        "record_hold": False,
        "snapshot_interval_sec": 10
    }
}


def safe_load_config(path: str, default_cfg: dict) -> Tuple[dict, Optional[str]]:
    """Load config.json safely. Returns (config, warning_message or None)."""
    try:
        config = load_config(path, default_cfg)
        return config, None
    except json.JSONDecodeError as e:
        # Backup broken file
        try:
            ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            bak = f"{path}.broken_{ts}"
            shutil.copy2(path, bak)
        except Exception:
            bak = None
        
        # Restore defaults
        try:
            save_config(path, default_cfg)
        except Exception:
            pass
            
        msg = f"Config JSON invalid: {e}. Reset to defaults."
        if bak:
            msg += f" Backup: {bak}"
        return json.loads(json.dumps(default_cfg)), msg
    except Exception as e:
        return json.loads(json.dumps(default_cfg)), f"Config load failed: {e}. Using defaults."


def _parse_list(text: str) -> List[str]:
    """Parse comma or newline separated list to unique uppercase items."""
    items = []
    for line in text.replace(",", "\n").splitlines():
        s = line.strip().upper()
        if s:
            items.append(s)
    
    # Remove duplicates while preserving order
    seen = set()
    out = []
    for s in items:
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


class BotGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Crypto Bot — V8.2 (Binance + Bybit)")
        self.geometry("1600x950")
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        
        # Control flags
        self._shutdown = False
        self._api_running = False
        self._bt_running = False
        self._bt_cancel_flag = False
        self._bt_mode = "run"
        self._bt_thread: Optional[threading.Thread] = None
        self._bt_results: List[Dict[str, Any]] = []
        self._signals_cache: List[Dict[str, Any]] = []
        
        # Paths and config
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.cfg_path = os.path.join(self.base_dir, "config.json")
        
        # Load config
        loaded = safe_load_config(self.cfg_path, DEFAULT_CONFIG)
        if isinstance(loaded, tuple):
            self.cfg, self._cfg_warn = loaded
        else:
            self.cfg, self._cfg_warn = loaded, None
        self.cfg = apply_env_overrides(self.cfg)
        
        # Logging
        self.ui = UILogger()
        log_file_path = os.path.join(self.base_dir, self.cfg["paths"]["log_file"])
        self.log = CompositeLogger(self.ui, setup_file_logger(log_file_path))
        
        # Trade recorder
        self.rec = TradeRecorder()
        
        # Engine and API
        self.engine: Optional[TradingEngine] = None
        self.t_engine: Optional[threading.Thread] = None
        self.api_server = None
        self.t_api: Optional[threading.Thread] = None
        
        # GUI Variables
        self._init_gui_variables()
        
        # Build GUI
        self._build()
        
        # Load config to UI
        self._load_to_ui()
        
        # Show config warning if any
        if self._cfg_warn:
            try:
                messagebox.showwarning('Config reset', self._cfg_warn)
            except Exception:
                pass
            try:
                self.log.warn(self._cfg_warn)
            except Exception:
                pass
        
        # Start periodic tasks
        self.after(250, self._pump_logs)
        self.after(900, self._refresh)
        self.after(1500, self._refresh_signals)
    
    def _init_gui_variables(self):
        """Initialize all GUI tkinter variables."""
        # Main controls
        self.var_mode = tk.StringVar(value="paper")
        self.var_exchange = tk.StringVar(value="binance")
        self.var_scan = tk.IntVar(value=15)
        self.var_exec = tk.StringVar(value="smart_limit")
        self.var_post = tk.BooleanVar(value=True)
        self.var_allow_fb = tk.BooleanVar(value=True)
        self.var_require_appr = tk.BooleanVar(value=True)
        self.var_api = tk.BooleanVar(value=False)
        self.var_profile = tk.StringVar(value="(none)")
        
        # Backtest variables
        self.var_bt_symbols = tk.StringVar(value=self._default_bt_symbols())
        self.var_bt_bars = tk.IntVar(value=1500)
        self.var_bt_tf = tk.StringVar(value="5m")
        self.var_bt_trend_tf = tk.StringVar(value="15m")
        self.var_bt_use_wfo = tk.BooleanVar(value=False)
        
        # GUI widgets (initialized as None)
        self.txt = None
        self.txt_w = None
        self.txt_b = None
        self.ent_key = None
        self.ent_secret = None
        
        self.tree_pos = None
        self.tree_ord = None
        self.tree_app = None
        self.sig_tree = None
        self.sig_explain = None
        self.bt_tree = None
        
        self.lbl_run = None
        self.lbl_eq = None
        self.lbl_halt = None
        self.lbl_pause = None
        self.lbl_sig = None
        self.lbl_bt = None
        
        self.btn_start = None
        self.btn_stop = None
        self.btn_bt_run = None
        self.btn_bt_opt = None
        self.btn_bt_cancel = None
        
        self.t_backtest = None
        self.tab_control = None
    
    def _default_bt_symbols(self) -> str:
        """Get default symbols for backtest."""
        wl = (self.cfg.get("pair_filters", {}) or {}).get("whitelist", []) or []
        if wl:
            return ",".join(wl[:12])
        # Sensible defaults
        return "BTC/USDT,ETH/USDT,BNB/USDT,SOL/USDT,XRP/USDT,ADA/USDT,DOGE/USDT"
    
    def _build(self):
        """Build the main GUI interface."""
        # Try to use external tabs module
        try:
            from gui_tabs import build_tabs
            build_tabs(self)
        except ImportError:
            # Fallback: build minimal interface
            self._build_minimal_interface()
    
    def _build_minimal_interface(self):
        """Build minimal interface if gui_tabs is not available."""
        self.tab_control = ttk.Notebook(self)
        
        # Control Tab
        control_frame = ttk.Frame(self.tab_control)
        self.tab_control.add(control_frame, text='Control')
        self._build_control_tab(control_frame)
        
        # Positions Tab
        pos_frame = ttk.Frame(self.tab_control)
        self.tab_control.add(pos_frame, text='Positions')
        self._build_positions_tab(pos_frame)
        
        # Signals Tab
        sig_frame = ttk.Frame(self.tab_control)
        self.tab_control.add(sig_frame, text='Signals')
        self._build_signals_tab(sig_frame)
        
        # Backtest Tab
        self.t_backtest = ttk.Frame(self.tab_control)
        self.tab_control.add(self.t_backtest, text='Backtest')
        self._build_backtest()
        
        # Log Tab
        log_frame = ttk.Frame(self.tab_control)
        self.tab_control.add(log_frame, text='Log')
        self._build_log_tab(log_frame)
        
        self.tab_control.pack(expand=1, fill="both")
    
    def _build_control_tab(self, parent):
        """Build control tab."""
        # Mode and exchange
        top_frame = ttk.Frame(parent)
        top_frame.pack(fill="x", padx=10, pady=10)
        
        ttk.Label(top_frame, text="Mode:").pack(side="left")
        ttk.Combobox(top_frame, textvariable=self.var_mode, 
                    values=["paper", "live"], width=10, state="readonly").pack(side="left", padx=5)
        
        ttk.Label(top_frame, text="Exchange:").pack(side="left", padx=(20, 0))
        ttk.Combobox(top_frame, textvariable=self.var_exchange, 
                    values=["binance", "bybit"], width=10, state="readonly").pack(side="left", padx=5)
        
        # API Keys
        key_frame = ttk.LabelFrame(parent, text="API Credentials")
        key_frame.pack(fill="x", padx=10, pady=10)
        
        ttk.Label(key_frame, text="Key:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.ent_key = ttk.Entry(key_frame, width=60, show="*")
        self.ent_key.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(key_frame, text="Secret:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.ent_secret = ttk.Entry(key_frame, width=60, show="*")
        self.ent_secret.grid(row=1, column=1, padx=5, pady=5)
        
        # Control buttons
        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill="x", padx=10, pady=10)
        
        self.btn_start = ttk.Button(btn_frame, text="Start Engine", command=self._start)
        self.btn_start.pack(side="left", padx=5)
        
        self.btn_stop = ttk.Button(btn_frame, text="Stop Engine", command=self._stop, state="disabled")
        self.btn_stop.pack(side="left", padx=5)
        
        ttk.Button(btn_frame, text="Close All", command=self._close_all).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Pause Entries", command=self._pause_entries).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Resume Entries", command=self._resume_entries).pack(side="left", padx=5)
        
        # Status labels
        status_frame = ttk.Frame(parent)
        status_frame.pack(fill="x", padx=10, pady=10)
        
        self.lbl_run = ttk.Label(status_frame, text="Running: NO")
        self.lbl_run.pack(side="left", padx=10)
        
        self.lbl_eq = ttk.Label(status_frame, text="Equity: 0.00")
        self.lbl_eq.pack(side="left", padx=10)
        
        self.lbl_halt = ttk.Label(status_frame, text="Halted: NO")
        self.lbl_halt.pack(side="left", padx=10)
        
        self.lbl_pause = ttk.Label(status_frame, text="Entries paused: NO")
        self.lbl_pause.pack(side="left", padx=10)
    
    def _build_positions_tab(self, parent):
        """Build positions and orders tab."""
        # Positions
        pos_frame = ttk.LabelFrame(parent, text="Open Positions")
        pos_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        columns = ("symbol", "qty", "entry", "stop", "tp")
        self.tree_pos = ttk.Treeview(pos_frame, columns=columns, show="headings", height=8)
        
        for col in columns:
            self.tree_pos.heading(col, text=col)
            self.tree_pos.column(col, width=120)
        
        ysb = ttk.Scrollbar(pos_frame, orient="vertical", command=self.tree_pos.yview)
        self.tree_pos.configure(yscroll=ysb.set)
        self.tree_pos.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        
        # Orders
        ord_frame = ttk.LabelFrame(parent, text="Pending Orders")
        ord_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        columns = ("id", "symbol", "side", "type", "qty", "price", "status")
        self.tree_ord = ttk.Treeview(ord_frame, columns=columns, show="headings", height=8)
        
        for col in columns:
            self.tree_ord.heading(col, text=col)
            self.tree_ord.column(col, width=100)
        
        ysb = ttk.Scrollbar(ord_frame, orient="vertical", command=self.tree_ord.yview)
        self.tree_ord.configure(yscroll=ysb.set)
        self.tree_ord.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
    
    def _build_signals_tab(self, parent):
        """Build signals tab."""
        # Signals tree
        sig_tree_frame = ttk.Frame(parent)
        sig_tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        columns = ("ts", "symbol", "action", "strength", "price", "reason")
        self.sig_tree = ttk.Treeview(sig_tree_frame, columns=columns, show="headings", height=12)
        
        for col in columns:
            self.sig_tree.heading(col, text=col)
            self.sig_tree.column(col, width=120)
        
        ysb = ttk.Scrollbar(sig_tree_frame, orient="vertical", command=self.sig_tree.yview)
        xsb = ttk.Scrollbar(sig_tree_frame, orient="horizontal", command=self.sig_tree.xview)
        self.sig_tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        
        self.sig_tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        
        sig_tree_frame.grid_rowconfigure(0, weight=1)
        sig_tree_frame.grid_columnconfigure(0, weight=1)
        
        # Signal explanation
        exp_frame = ttk.LabelFrame(parent, text="Signal Details")
        exp_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.sig_explain = tk.Text(exp_frame, height=10, wrap="word")
        ysb = ttk.Scrollbar(exp_frame, orient="vertical", command=self.sig_explain.yview)
        self.sig_explain.configure(yscrollcommand=ysb.set)
        
        self.sig_explain.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
        
        # Signal label
        self.lbl_sig = ttk.Label(parent, text="Signals: 0")
        self.lbl_sig.pack(pady=5)
        
        # Bind selection
        self.sig_tree.bind('<<TreeviewSelect>>', self._on_select_signal)
    
    def _build_log_tab(self, parent):
        """Build log viewer tab."""
        self.txt = tk.Text(parent, wrap="word", height=25)
        ysb = ttk.Scrollbar(parent, orient="vertical", command=self.txt.yview)
        xsb = ttk.Scrollbar(parent, orient="horizontal", command=self.txt.xview)
        self.txt.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        
        self.txt.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
        
        self.txt.configure(state="disabled")
    

    def _on_select_signal(self, _evt=None):
        """Handle signal selection."""
        try:
            sel = self.sig_tree.selection()
            if not sel:
                return

            iid = sel[0]
            tags = self.sig_tree.item(iid, "tags") or ()
            idx = int(tags[0]) if tags else -1
            if 0 <= idx < len(self._signals_cache):
                row = self._signals_cache[idx]
                details = row.get("details") if isinstance(row, dict) else row
                if details is None:
                    details = row
                self.sig_explain.delete("1.0", "end")
                self.sig_explain.insert("end", json.dumps(details, indent=2, default=str))
        except Exception as e:
            self.log.error(f"Error selecting signal: {e}")
    def _normalize_signal_items(self, items: Any) -> List[Dict[str, Any]]:
        """Normalize signals payload into a list of dict rows.

        Engine implementations vary: can return list[dict], dict[symbol->dict], or other.
        This keeps the GUI stable and prevents Treeview crashes.
        """
        out: List[Dict[str, Any]] = []
        if items is None:
            return out

        # dict: assume {symbol: row} or {k: v}
        if isinstance(items, dict):
            vals = list(items.values())
            for v in vals:
                if isinstance(v, dict):
                    out.append(v)
            return out

        # list/tuple: keep only dict rows
        if isinstance(items, (list, tuple)):
            for v in items:
                if isinstance(v, dict):
                    out.append(v)
            return out

        return out

    def _coerce_signal_row(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Backfill legacy keys expected by GUI (action/strength/price/reason/ts)."""
        if not isinstance(row, dict):
            return {}
        r = dict(row)

        # action: prefer explicit, else map from 'signal'
        if not r.get("action"):
            sig = r.get("signal") or r.get("sig")
            if isinstance(sig, str) and sig:
                r["action"] = sig.lower()
        # strength: prefer explicit, else map from 'score'
        if r.get("strength") is None:
            sc = r.get("score")
            if sc is not None:
                r["strength"] = sc
        # price
        if r.get("price") is None:
            # common alternates
            r["price"] = r.get("last") if r.get("last") is not None else r.get("close")
        # reason
        if not r.get("reason"):
            r["reason"] = r.get("why") or r.get("comment") or ""
        # ts
        if r.get("ts") is None:
            r["ts"] = r.get("timestamp") or r.get("time") or ""
        # details: if missing, provide whole row
        if "details" not in r:
            r["details"] = dict(r)
        return r


    def _refresh_signals(self):
        """Refresh signals display."""
        try:
            if not self.engine:
                self.lbl_sig.config(text="Signals: engine not running")
                return

            raw = []
            try:
                # Newer engines should expose get_last_signals(limit=...)
                if hasattr(self.engine, "get_last_signals") and callable(getattr(self.engine, "get_last_signals")):
                    raw = self.engine.get_last_signals(limit=200)
                elif hasattr(self.engine, "get_signals_latest") and callable(getattr(self.engine, "get_signals_latest")):
                    raw = self.engine.get_signals_latest()
                elif hasattr(self.engine, "last_signals"):
                    raw = getattr(self.engine, "last_signals")
                else:
                    raw = []
            except Exception as e:
                self.log.error(f"Error fetching signals: {e}")
                raw = []

            items = [self._coerce_signal_row(r) for r in self._normalize_signal_items(raw)]
            self._signals_cache = items

            # Refresh tree
            if hasattr(self, "sig_tree"):
                for x in self.sig_tree.get_children():
                    self.sig_tree.delete(x)

                for i, row in enumerate(items):
                    ts = row.get("ts", "")
                    sym = row.get("symbol", "")
                    act = row.get("action", "")
                    try:
                        st = float(row.get("strength", 0.0) or 0.0)
                    except Exception:
                        st = 0.0
                    pr = row.get("price", "")
                    rs = row.get("reason", "")

                    self.sig_tree.insert(
                        "",
                        "end",
                        values=(ts, sym, act, f"{st:.2f}", f"{pr}", rs),
                        tags=(str(i),),
                    )

            self.lbl_sig.config(text=f"Signals: {len(items)}")
        finally:
            if not self._shutdown and self.winfo_exists():
                self.after(1500, self._refresh_signals)

    def _export_signals_csv(self):
        """Export signals to CSV."""
        path = filedialog.asksaveasfilename(defaultextension=".csv", 
                                           filetypes=[("CSV", "*.csv")])
        if not path:
            return
        
        # Try SQLite export first
        try:
            if self.engine and getattr(self.engine, "store", None):
                self.engine.store.export_signals_csv(path)
                self.log.info(f"Signals exported to {path}")
                return
        except Exception as e:
            self.log.warn(f"SQLite export failed: {e}")
        
        # Fallback: export from cache
        try:
            rows = self._signals_cache
            cols = ["ts", "symbol", "action", "strength", "price", "reason"]
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=cols)
                w.writeheader()
                for r in rows:
                    w.writerow({k: r.get(k, "") for k in cols})
            self.log.info(f"Signals exported to {path}")
        except Exception as e:
            messagebox.showerror("Export", f"Failed to export: {e}")
    
    def _build_backtest(self):
        """Build backtest tab."""
        frm = self.t_backtest
        
        # Top controls
        top = ttk.Frame(frm)
        top.pack(fill="x", padx=10, pady=8)
        
        # Symbols
        ttk.Label(top, text="Symbols:").pack(side="left")
        ent = ttk.Entry(top, textvariable=self.var_bt_symbols, width=55)
        ent.pack(side="left", padx=6)
        
        # Bars
        ttk.Label(top, text="Bars:").pack(side="left", padx=(10, 0))
        ttk.Entry(top, textvariable=self.var_bt_bars, width=8).pack(side="left", padx=6)
        
        # Timeframes
        ttk.Label(top, text="Signal TF:").pack(side="left", padx=(10, 0))
        ttk.Combobox(top, textvariable=self.var_bt_tf, width=6,
                    values=("1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "1d"),
                    state="readonly").pack(side="left", padx=6)
        
        ttk.Label(top, text="Trend TF:").pack(side="left", padx=(10, 0))
        ttk.Combobox(top, textvariable=self.var_bt_trend_tf, width=6,
                    values=("5m", "15m", "30m", "1h", "2h", "4h", "1d"),
                    state="readonly").pack(side="left", padx=6)
        
        # WFO checkbox
        ttk.Checkbutton(top, text="Walk-forward optimize",
                       variable=self.var_bt_use_wfo).pack(side="left", padx=(12, 0))
        
        # Buttons
        btns = ttk.Frame(frm)
        btns.pack(fill="x", padx=10, pady=(0, 8))
        
        self.btn_bt_run = ttk.Button(btns, text="Run Backtest", command=self._bt_start_run)
        self.btn_bt_run.pack(side="left")
        
        self.btn_bt_opt = ttk.Button(btns, text="Optimize (global)", command=self._bt_start_global_opt)
        self.btn_bt_opt.pack(side="left", padx=8)
        
        self.btn_bt_cancel = ttk.Button(btns, text="Cancel", command=self._bt_cancel_run, state="disabled")
        self.btn_bt_cancel.pack(side="left", padx=8)
        
        ttk.Button(btns, text="Export CSV", command=self._bt_export_csv).pack(side="left", padx=8)
        
        self.lbl_bt = ttk.Label(btns, text="Backtest: idle")
        self.lbl_bt.pack(side="right")
        
        # Results tree
        body = ttk.Frame(frm)
        body.pack(fill="both", expand=True, padx=10, pady=8)
        
        cols = ("symbol", "trades", "win_rate", "return_pct", "max_dd", 
                "profit_factor", "equity_end", "note")
        self.bt_tree = ttk.Treeview(body, columns=cols, show="headings", height=18)
        
        for col in cols:
            self.bt_tree.heading(col, text=col)
            self.bt_tree.column(col, width=120 if col not in ("note",) else 420, anchor="w")
        
        # Adjust column widths
        self.bt_tree.column("symbol", width=120)
        self.bt_tree.column("trades", width=70, anchor="e")
        self.bt_tree.column("win_rate", width=90, anchor="e")
        self.bt_tree.column("return_pct", width=90, anchor="e")
        self.bt_tree.column("max_dd", width=90, anchor="e")
        self.bt_tree.column("profit_factor", width=90, anchor="e")
        self.bt_tree.column("equity_end", width=110, anchor="e")
        
        ysb = ttk.Scrollbar(body, orient="vertical", command=self.bt_tree.yview)
        self.bt_tree.configure(yscroll=ysb.set)
        self.bt_tree.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")
    
    def _bt_start_run(self):
        """Start backtest run."""
        if self._bt_running:
            return
        
        try:
            self._save_from_ui()
        except Exception as e:
            self.log.error(f"Save failed: {e}")
        
        self._bt_cancel_flag = False
        self._bt_running = True
        self._bt_mode = "run"
        
        self.btn_bt_run.config(state="disabled")
        self.btn_bt_opt.config(state="disabled")
        self.btn_bt_cancel.config(state="normal")
        self.lbl_bt.config(text="Backtest: running...")
        
        t = threading.Thread(target=self._bt_worker, daemon=True)
        self._bt_thread = t
        t.start()
    
    def _bt_start_global_opt(self):
        """Start global optimization."""
        if self._bt_running:
            return
        
        try:
            self._save_from_ui()
        except Exception as e:
            self.log.error(f"Save failed: {e}")
        
        self._bt_cancel_flag = False
        self._bt_running = True
        self._bt_mode = "optimize"
        
        self.btn_bt_run.config(state="disabled")
        self.btn_bt_opt.config(state="disabled")
        self.btn_bt_cancel.config(state="normal")
        self.lbl_bt.config(text="Optimizer: running...")
        
        t = threading.Thread(target=self._bt_worker, daemon=True)
        self._bt_thread = t
        t.start()
    
    def _bt_cancel_run(self):
        """Cancel backtest/optimization."""
        self._bt_cancel_flag = True
        self.lbl_bt.config(text="Cancelling...")
    
    def _tf_minutes(self, tf: str) -> int:
        """Convert timeframe string to minutes."""
        tf = str(tf).strip().lower()
        if tf.endswith('m'):
            return int(tf[:-1])
        if tf.endswith('h'):
            return int(tf[:-1]) * 60
        if tf.endswith('d'):
            return int(tf[:-1]) * 1440
        return 5
    
    def _bt_worker(self):
        """Backtest worker thread."""
        # Deep copy config
        cfg = json.loads(json.dumps(self.cfg))
        cfg["mode"] = "paper"
        
        # Get parameters
        symbols = [s.strip() for s in str(self.var_bt_symbols.get()).split(",") if s.strip()]
        bars = max(250, int(self.var_bt_bars.get() or 1500))
        tf = str(self.var_bt_tf.get() or cfg.get("signal_timeframe", "5m"))
        trend_tf = str(self.var_bt_trend_tf.get() or cfg.get("trend_timeframe", "15m"))
        use_wfo = bool(self.var_bt_use_wfo.get())
        
        # Calculate trend bars
        ratio = max(1.0, self._tf_minutes(trend_tf) / max(1.0, self._tf_minutes(tf)))
        trend_bars = int(bars / ratio) + 250
        trend_bars = max(250, min(5000, trend_bars))
        
        # Update config with selected timeframes
        cfg["signal_timeframe"] = tf
        cfg["trend_timeframe"] = trend_tf
        
        # Create exchange client
        client = ExchangeClient(cfg, self.log)
        results = []
        
        try:
            # Global optimization mode
            if self._bt_mode == "optimize":
                auto = cfg.get("auto_opt", {}) or {}
                wf = auto.get("walk_forward", {}) or {}
                train_frac = float(wf.get("train_frac", 0.7))
                cand = wf.get("candidates", {}) or {}
                
                # Pre-fetch data
                data = []
                for sym in symbols:
                    if self._bt_cancel_flag:
                        break
                    try:
                        df_sym = client.fetch_ohlcv_df(sym, tf, bars)
                        df_tr_sym = client.fetch_ohlcv_df(sym, trend_tf, trend_bars)
                        data.append((sym, df_sym, df_tr_sym))
                    except Exception as e:
                        data.append((sym, None, None))
                        self.log.warn(f"Optimizer fetch failed for {sym}: {e}")
                
                # Grid search
                best_score = None
                best_params = None
                
                def score_result(r):
                    pf = r.profit_factor if (r.profit_factor is not None and not pd.isna(r.profit_factor)) else 0.0
                    pf = pf if pf != float("inf") else 5.0
                    return pf + 0.02 * r.total_return_pct - 0.02 * r.max_dd_pct
                
                import pandas as pd
                
                for fast in cand.get("ema_fast", [12]):
                    for slow in cand.get("ema_slow", [26]):
                        if slow <= fast:
                            continue
                        for rb in cand.get("rsi_buy", [30]):
                            for rs in cand.get("rsi_sell", [70]):
                                if self._bt_cancel_flag:
                                    break
                                
                                # Create candidate config
                                c_try = json.loads(json.dumps(cfg))
                                c_try["strategies"]["ema_cross"]["fast"] = fast
                                c_try["strategies"]["ema_cross"]["slow"] = slow
                                c_try["strategies"]["rsi_reversion"]["buy_below"] = rb
                                c_try["strategies"]["rsi_reversion"]["sell_above"] = rs
                                
                                # Average score across symbols
                                scores = []
                                for sym, df_sym, df_tr_sym in data:
                                    if df_sym is None or df_tr_sym is None or len(df_sym) < 200:
                                        continue
                                    
                                    cut = int(len(df_sym) * train_frac)
                                    df_tr = df_sym.iloc[:cut].copy()
                                    t_end = df_tr["ts"].iloc[-1]
                                    df_trend_tr = df_tr_sym[df_tr_sym["ts"] <= t_end].copy()
                                    
                                    if len(df_trend_tr) < 120:
                                        df_trend_tr = df_tr_sym
                                    
                                    r_tr = simulate(c_try, df_tr, df_trend_tr)
                                    scores.append(score_result(r_tr))
                                
                                if not scores:
                                    continue
                                
                                s_avg = sum(scores) / len(scores)
                                if (best_score is None) or (s_avg > best_score):
                                    best_score = s_avg
                                    best_params = (fast, slow, rb, rs)
                
                if best_params:
                    fast, slow, rb, rs = best_params
                    cfg_best = json.loads(json.dumps(cfg))
                    cfg_best["strategies"]["ema_cross"]["fast"] = fast
                    cfg_best["strategies"]["ema_cross"]["slow"] = slow
                    cfg_best["strategies"]["rsi_reversion"]["buy_below"] = rb
                    cfg_best["strategies"]["rsi_reversion"]["sell_above"] = rs
                    
                    note = f"OPT: ema_fast={fast} ema_slow={slow} rsi_buy={rb} rsi_sell={rs} score={best_score:.3f}"
                    
                    # Run backtest with best params
                    for i, (sym, df_sym, df_tr_sym) in enumerate(data, start=1):
                        if self._bt_cancel_flag:
                            break
                        
                        if df_sym is None or df_tr_sym is None:
                            results.append({
                                "symbol": sym, "trades": 0, "win_rate": 0.0, 
                                "return_pct": 0.0, "max_dd": 0.0, "profit_factor": 0.0, 
                                "equity_end": 0.0, "note": "ERROR: fetch failed"
                            })
                            continue
                        
                        r = simulate(cfg_best, df_sym, df_tr_sym)
                        results.append({
                            "symbol": sym,
                            "trades": int(r.trades),
                            "win_rate": float(r.win_rate_pct),
                            "return_pct": float(r.total_return_pct),
                            "max_dd": float(r.max_dd_pct),
                            "profit_factor": float(r.profit_factor) if r.profit_factor != float("inf") else 9999.0,
                            "equity_end": float(r.equity_end),
                            "note": note
                        })
                        
                        self.after(0, lambda cur=i, total=len(data): 
                                  self.lbl_bt.config(text=f"Optimizer: {cur}/{total}"))
            
            # Regular backtest mode
            else:
                for i, sym in enumerate(symbols, start=1):
                    if self._bt_cancel_flag:
                        break
                    
                    try:
                        df = client.fetch_ohlcv_df(sym, tf, bars)
                        df_trend = client.fetch_ohlcv_df(sym, trend_tf, trend_bars)
                        
                        # Apply WFO if requested
                        c_run = cfg
                        note = ""
                        if use_wfo:
                            c_run = walk_forward_optimize(cfg, df, df_trend)
                            note = str(c_run.get("_auto_opt_note", ""))
                        
                        r = simulate(c_run, df, df_trend)
                        results.append({
                            "symbol": sym,
                            "trades": int(r.trades),
                            "win_rate": float(r.win_rate_pct),
                            "return_pct": float(r.total_return_pct),
                            "max_dd": float(r.max_dd_pct),
                            "profit_factor": float(r.profit_factor) if r.profit_factor != float("inf") else 9999.0,
                            "equity_end": float(r.equity_end),
                            "note": note
                        })
                    except Exception as e:
                        results.append({
                            "symbol": sym,
                            "trades": 0,
                            "win_rate": 0.0,
                            "return_pct": 0.0,
                            "max_dd": 0.0,
                            "profit_factor": 0.0,
                            "equity_end": 0.0,
                            "note": f"ERROR: {str(e)[:100]}"
                        })
                    
                    # Update progress
                    self.after(0, lambda cur=i, total=len(symbols): 
                              self.lbl_bt.config(text=f"Backtest: {cur}/{total}"))
        
        except Exception as e:
            self.log.error(f"Backtest error: {e}")
            results.append({
                "symbol": "ERROR",
                "trades": 0,
                "win_rate": 0.0,
                "return_pct": 0.0,
                "max_dd": 0.0,
                "profit_factor": 0.0,
                "equity_end": 0.0,
                "note": f"SYSTEM ERROR: {e}"
            })
        
        # Sort results
        results.sort(key=lambda x: (x.get("return_pct", 0.0), x.get("profit_factor", 0.0)), reverse=True)
        self._bt_results = results
        
        # Update UI
        self.after(0, self._bt_set_results)
    
    def _bt_set_results(self):
        """Set backtest results in UI."""
        self._bt_running = False
        
        # Clear tree
        for iid in self.bt_tree.get_children():
            self.bt_tree.delete(iid)
        
        # Insert results
        for row in self._bt_results:
            vals = (
                row["symbol"],
                row["trades"],
                f"{row['win_rate']:.1f}",
                f"{row['return_pct']:.2f}",
                f"{row['max_dd']:.2f}",
                f"{row['profit_factor']:.2f}",
                f"{row['equity_end']:.2f}",
                row.get("note", "")[:400],
            )
            self.bt_tree.insert("", "end", values=vals)
        
        # Update buttons and label
        self.btn_bt_run.config(state="normal")
        self.btn_bt_opt.config(state="normal")
        self.btn_bt_cancel.config(state="disabled")
        
        if self._bt_cancel_flag:
            self.lbl_bt.config(text="Backtest: cancelled")
            self._bt_cancel_flag = False
        else:
            self.lbl_bt.config(text=f"Backtest: done ({len(self._bt_results)} symbols)")
    
    def _bt_export_csv(self):
        """Export backtest results to CSV."""
        if not self._bt_results:
            messagebox.showinfo("Export", "No backtest results to export.")
            return
        
        fp = filedialog.asksaveasfilename(defaultextension=".csv", 
                                         filetypes=[("CSV", "*.csv")])
        if not fp:
            return
        
        try:
            with open(fp, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["symbol", "trades", "win_rate", 
                                                 "return_pct", "max_dd", "profit_factor", 
                                                 "equity_end", "note"])
                w.writeheader()
                for r in self._bt_results:
                    w.writerow(r)
            messagebox.showinfo("Export", f"Saved: {fp}")
        except Exception as e:
            messagebox.showerror("Export", f"Failed to export: {e}")
    
    def _pump_logs(self):
        """Pump log messages from queue to UI."""
        try:
            while True:
                msg = self.ui.q.get_nowait()
                if hasattr(self, 'txt') and self.txt:
                    self.txt.configure(state="normal")
                    self.txt.insert("end", msg + "\n")
                    self.txt.see("end")
                    self.txt.configure(state="disabled")
        except Exception:
            pass
        
        if not self._shutdown and self.winfo_exists():
            self.after(250, self._pump_logs)
    
    def _apply_profile(self):
        """Apply selected profile."""
        p = self.var_profile.get()
        if p == "(none)":
            return
        
        prof = os.path.join(self.base_dir, "profiles", f"{p}.json")
        if not os.path.exists(prof):
            messagebox.showerror("Missing profile", prof)
            return
        
        self.cfg = load_config(prof, DEFAULT_CONFIG)
        self.cfg = apply_env_overrides(self.cfg)
        self._load_to_ui()
        self.log.info(f"Applied profile: {p}")
    
    def _load_to_ui(self):
        """Load config values to UI."""
        c = self.cfg
        
        self.var_mode.set(c.get("mode", "paper"))
        self.var_exchange.set(c.get("exchange", "binance"))
        
        if hasattr(self, 'ent_key'):
            self.ent_key.delete(0, "end")
            self.ent_key.insert(0, c.get("api_key", ""))
        
        if hasattr(self, 'ent_secret'):
            self.ent_secret.delete(0, "end")
            self.ent_secret.insert(0, c.get("api_secret", ""))
        
        self.var_scan.set(int(c.get("scan_interval_sec", 15)))
        self.var_exec.set(c.get("execution", {}).get("type", "smart_limit"))
        self.var_post.set(bool(c.get("execution", {}).get("post_only", True)))
        self.var_allow_fb.set(bool(c.get("execution", {}).get("allow_market_fallback", True)))
        
        if hasattr(self, 'txt_w'):
            self.txt_w.delete("1.0", "end")
            self.txt_w.insert("end", "\n".join(c.get("pair_filters", {}).get("whitelist") or []))
        
        if hasattr(self, 'txt_b'):
            self.txt_b.delete("1.0", "end")
            self.txt_b.insert("end", "\n".join(c.get("pair_filters", {}).get("blacklist") or []))
        
        self.var_require_appr.set(bool(c.get("approvals", {}).get("require_for_live", True)))
        self.var_api.set(bool(c.get("api", {}).get("enabled", False)))
        
        # Backtest values
        self.var_bt_tf.set(str(c.get("signal_timeframe", "5m")))
        self.var_bt_trend_tf.set(str(c.get("trend_timeframe", "15m")))
    
    def _save_from_ui(self):
        """Save UI values to config."""
        c = self.cfg
        
        c["mode"] = self.var_mode.get()
        c["exchange"] = self.var_exchange.get()
        
        if hasattr(self, 'ent_key'):
            c["api_key"] = self.ent_key.get().strip()
        
        if hasattr(self, 'ent_secret'):
            c["api_secret"] = self.ent_secret.get().strip()
        
        c["scan_interval_sec"] = int(self.var_scan.get())
        c.setdefault("execution", {})["type"] = self.var_exec.get()
        c["execution"]["post_only"] = bool(self.var_post.get())
        c["execution"]["allow_market_fallback"] = bool(self.var_allow_fb.get())
        
        if hasattr(self, 'txt_w'):
            c.setdefault("pair_filters", {})["whitelist"] = _parse_list(self.txt_w.get("1.0", "end"))
        
        if hasattr(self, 'txt_b'):
            c["pair_filters"]["blacklist"] = _parse_list(self.txt_b.get("1.0", "end"))
        
        c.setdefault("approvals", {})["require_for_live"] = bool(self.var_require_appr.get())
        c.setdefault("api", {})["enabled"] = bool(self.var_api.get())
        c["api"]["host"] = "127.0.0.1"
        
        save_config(self.cfg_path, c)
        self.log.info("Config saved.")
    
    def _load_cfg(self):
        """Load config from file."""
        path = filedialog.askopenfilename(title="Select config.json", 
                                         filetypes=[("JSON", "*.json")])
        if not path:
            return
        
        self.cfg = load_config(path, DEFAULT_CONFIG)
        self.cfg = apply_env_overrides(self.cfg)
        self.cfg_path = path
        self._load_to_ui()
        self.log.info(f"Loaded config: {path}")
    
    def _export_trades(self):
        """Export trades to CSV."""
        path = filedialog.asksaveasfilename(defaultextension=".csv", 
                                           filetypes=[("CSV", "*.csv")])
        if not path:
            return
        
        # Try SQLite export first
        try:
            if self.engine and getattr(self.engine, "store", None):
                self.engine.store.export_trades_csv(path)
                self.log.info(f"Trades exported to {path}")
                return
        except Exception as e:
            self.log.warn(f"SQLite export failed: {e}")
        
        # Fallback to in-memory recorder
        try:
            self.rec.export_csv(path)
            self.log.info(f"Trades exported to {path}")
        except Exception as e:
            messagebox.showerror("Export", f"Failed to export trades: {e}")
    
    def _validate_live(self):
        """Validate config for live trading."""
        if self.cfg.get("mode") != "live":
            return
        
        r = float(self.cfg.get("risk", {}).get("risk_per_trade", 0.005))
        if r > 0.02:
            raise ValueError("risk_per_trade too high (>2%)")
        
        if not self.cfg.get("api_key") or not self.cfg.get("api_secret"):
            raise ValueError("Live requires API key+secret (or env vars).")
        
        if (self.cfg.get("approvals", {}).get("require_for_live", True) and 
            not self.cfg.get("api", {}).get("enabled", False)):
            raise ValueError("Live approvals are required but local API is disabled. Enable API in Settings.")
    
    def _is_port_free(self, host: str, port: int) -> bool:
        """Check if port is free."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, int(port)))
            s.close()
            return True
        except Exception:
            return False
    
    def _pick_free_port(self, host: str, start_port: int, tries: int = 50) -> int:
        """Find a free port."""
        port = int(start_port)
        for _ in range(max(1, int(tries))):
            if self._is_port_free(host, port):
                return port
            port += 1
        return int(start_port)
    
    def _stop_api(self):
        """Stop API server."""
        self._api_running = False
        try:
            if self.api_server:
                self.api_server.should_exit = True
            
            if self.t_api and self.t_api.is_alive():
                self.t_api.join(timeout=2.0)
        except Exception as e:
            self.log.error(f"Error stopping API: {e}")
        finally:
            self.api_server = None
            self.t_api = None
    
    def _start_api(self):
        """Start API server."""
        if not (uvicorn and create_app and self.engine):
            return
        
        api_cfg = self.cfg.get("api", {}) or {}
        if not api_cfg.get("enabled", False):
            return
        
        host = str(api_cfg.get("host", "127.0.0.1"))
        port = int(api_cfg.get("port", 8000))
        auto_port = bool(api_cfg.get("auto_port", True))
        max_tries = int(api_cfg.get("max_port_tries", 50))
        
        if auto_port:
            port = self._pick_free_port(host, port, tries=max_tries)
        
        try:
            app = create_app(self.engine)
            
            # Log API routes
            try:
                routes = []
                for r in getattr(app, "routes", []):
                    p = getattr(r, "path", None)
                    m = getattr(r, "methods", None)
                    if p:
                        routes.append({"path": p, "methods": sorted(list(m)) if m else []})
                self.log.info("API routes: " + json.dumps(routes, indent=2))
            except Exception as e:
                self.log.warn(f"Could not enumerate API routes: {e}")
            
            # Start server
            server = uvicorn.Server(
                uvicorn.Config(app, host=host, port=port, log_level="warning")
            )
            
            self.api_server = server
            self.t_api = threading.Thread(target=server.run, daemon=True)
            self.t_api.start()
            self._api_running = True
            
            self.log.info(f"Local API started: http://{host}:{port}")
        except Exception as e:
            self.log.error(f"Failed to start API: {e}")
    
    def _start(self):
        """Start trading engine."""
        self._save_from_ui()
        
        # Validate for live mode
        try:
            self._validate_live()
        except Exception as e:
            messagebox.showerror("Validation", str(e))
            return
        
        # Check if engine already running
        if self.engine and hasattr(self.engine, '_running') and self.engine._running:
            self.log.warn("Engine already running")
            return
        
        # Create new engine
        self.engine = TradingEngine(self.cfg, self.log, self.rec, base_dir=self.base_dir)
        self.t_engine = threading.Thread(target=self.engine.loop, daemon=True)
        self.t_engine.start()
        
        # Start API if enabled
        self._start_api()
        
        # Update UI
        self.btn_start.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.log.info("Engine started.")
    
    def _stop(self):
        """Stop trading engine."""
        if self.engine:
            self.engine.stop()
            time.sleep(0.5)  # Allow graceful shutdown
        
        self._stop_api()
        
        # Update UI
        self.btn_start.config(state="normal")
        self.btn_stop.config(state="disabled")
        self.log.info("Stop requested.")
    
    def _close_all(self):
        """Close all positions."""
        if self.engine:
            self.engine.close_all(reason="manual_close_all")
            self.log.info("Close all requested.")
    
    def _pause_entries(self):
        """Pause new entries."""
        if self.engine:
            self.engine.pause_entries = True
            self.log.info("Entries paused.")
    
    def _resume_entries(self):
        """Resume new entries."""
        if self.engine:
            self.engine.pause_entries = False
            self.log.info("Entries resumed.")
    
    def _refresh(self):
        """Refresh UI with current engine state."""
        # Check if engine thread is alive
        running = bool(self.t_engine and self.t_engine.is_alive())
        if hasattr(self, 'lbl_run'):
            self.lbl_run.config(text=f"Running: {'YES' if running else 'NO'}")
        
        if self.engine and running:
            # Update equity
            if hasattr(self.engine, 'metrics') and hasattr(self.engine.metrics, 'state'):
                equity = getattr(self.engine.metrics.state, 'equity', 0.0)
                asset = self.engine.cfg.get('quote_asset', 'USDT')
                if hasattr(self, 'lbl_eq'):
                    self.lbl_eq.config(text=f"Equity({asset}): {equity:.2f}")
            
            # Update status flags
            if hasattr(self, 'lbl_halt'):
                self.lbl_halt.config(text=f"Halted: {'YES' if self.engine.halted else 'NO'}")
            
            if hasattr(self, 'lbl_pause'):
                self.lbl_pause.config(text=f"Entries paused: {'YES' if self.engine.pause_entries else 'NO'}")
            
            # Refresh positions
            self._refresh_positions()
            
            # Refresh orders
            self._refresh_orders()
            
            # Refresh approvals
            self._refresh_approvals()
        
        # Schedule next refresh
        if not self._shutdown and self.winfo_exists():
            self.after(900, self._refresh)
    
    def _refresh_positions(self):
        """Refresh positions display."""
        if not hasattr(self, 'tree_pos'):
            return
        
        # Clear current positions
        for i in self.tree_pos.get_children():
            self.tree_pos.delete(i)
        
        # Get positions
        positions = []
        fn = getattr(self.engine, "get_positions_snapshot", None)
        if callable(fn):
            try:
                positions = fn() or []
            except Exception as e:
                self.log.error(f"Error getting positions snapshot: {e}")
                positions = []
        
        # Fallback to engine.positions
        if not positions:
            try:
                pos_dict = getattr(self.engine, "positions", {})
                for sym, pos in pos_dict.items():
                    if pos:
                        positions.append({
                            "symbol": sym,
                            "qty": float(getattr(pos, "qty", 0.0) or 0.0),
                            "entry": float(getattr(pos, "entry", 0.0) or 0.0),
                            "stop": float(getattr(pos, "stop", 0.0) or 0.0),
                            "tp": float(getattr(pos, "tp", 0.0) or 0.0),
                        })
            except Exception as e:
                self.log.error(f"Error reading positions: {e}")
        
        # Add to tree (deduplicate by symbol)
        seen = set()
        for p in positions:
            sym = str(p.get("symbol", "") or "")
            if not sym or sym in seen:
                continue
            
            seen.add(sym)
            self.tree_pos.insert(
                "", "end",
                values=(
                    sym,
                    f"{float(p.get('qty', 0.0) or 0.0):.8f}",
                    f"{float(p.get('entry', 0.0) or 0.0):.8f}",
                    f"{float(p.get('stop', 0.0) or 0.0):.8f}",
                    f"{float(p.get('tp', 0.0) or 0.0):.8f}",
                )
            )
    
    def _refresh_orders(self):
        """Refresh orders display."""
        if not hasattr(self, 'tree_ord'):
            return
        
        # Clear current orders
        for i in self.tree_ord.get_children():
            self.tree_ord.delete(i)
        
        # Get pending orders
        pendings = []
        fn = getattr(self.engine, "get_pending_snapshot", None)
        if callable(fn):
            try:
                pendings = fn() or []
            except Exception as e:
                self.log.error(f"Error getting pending snapshot: {e}")
        
        # Fallback to engine.pending
        if not pendings:
            try:
                pend_dict = getattr(self.engine, "pending", {})
                if isinstance(pend_dict, dict):
                    for v in pend_dict.values():
                        if isinstance(v, dict):
                            pendings.append(v)
                        else:
                            pendings.append(getattr(v, "__dict__", {"repr": str(v)}))
            except Exception as e:
                self.log.error(f"Error reading pending orders: {e}")
        
        # Fallback to engine.pending_orders
        if not pendings:
            try:
                pend_list = getattr(self.engine, "pending_orders", [])
                if isinstance(pend_list, list):
                    for v in pend_list:
                        if isinstance(v, dict):
                            pendings.append(v)
                        else:
                            pendings.append(getattr(v, "__dict__", {"repr": str(v)}))
            except Exception as e:
                self.log.error(f"Error reading pending_orders: {e}")
        
        # Add to tree
        for o in pendings:
            oid = o.get("id") or o.get("order_id") or str(o.get("client_order_id", ""))
            sym = o.get("symbol") or ""
            side = o.get("side") or ""
            
            # Determine order type
            typ = o.get("type")
            if not typ:
                typ = "limit" if bool(o.get("is_maker", True)) else "market"
            
            qty = float(o.get("qty", 0.0) or 0.0)
            price = o.get("price")
            status = o.get("status") or "pending"
            
            self.tree_ord.insert(
                "", "end",
                values=(
                    str(oid)[:20],
                    str(sym),
                    str(side),
                    str(typ),
                    f"{qty:.8f}",
                    (f"{float(price):.8f}" if price is not None else ""),
                    str(status),
                )
            )
    
    def _refresh_approvals(self):
        """Refresh approvals display."""
        if not hasattr(self, 'tree_app') or not self.engine:
            return
        
        # Check if approvals system exists
        if not hasattr(self.engine, 'approvals') or not self.engine.approvals:
            return
        
        # Clear current approvals
        for i in self.tree_app.get_children():
            self.tree_app.delete(i)
        
        # Get approvals
        try:
            approvals = self.engine.approvals.list()
            for a in approvals:
                self.tree_app.insert(
                    "", "end",
                    values=(
                        a.id,
                        int(a.created_ts),
                        a.symbol,
                        a.side,
                        f"{a.qty:.8f}",
                        f"{a.price_ref:.8f}",
                        a.status
                    )
                )
        except Exception as e:
            self.log.error(f"Error refreshing approvals: {e}")
    
    def _selected_approval(self):
        """Get selected approval ID."""
        if not hasattr(self, 'tree_app'):
            return None
        
        sel = self.tree_app.selection()
        if not sel:
            return None
        
        vals = self.tree_app.item(sel[0], "values")
        return vals[0] if vals else None
    
    def _approve(self):
        """Approve selected trade."""
        if not self.engine or not hasattr(self.engine, 'approvals'):
            return
        
        aid = self._selected_approval()
        if not aid:
            return
        
        try:
            self.engine.approvals.approve(aid, by="gui")
            self.log.info(f"Approved trade {aid}")
        except Exception as e:
            self.log.error(f"Error approving trade: {e}")
        
        self._refresh_approvals()
    
    def _reject(self):
        """Reject selected trade."""
        if not self.engine or not hasattr(self.engine, 'approvals'):
            return
        
        aid = self._selected_approval()
        if not aid:
            return
        
        try:
            self.engine.approvals.reject(aid, by="gui")
            self.log.info(f"Rejected trade {aid}")
        except Exception as e:
            self.log.error(f"Error rejecting trade: {e}")
        
        self._refresh_approvals()
    
    def _on_close(self):
        """Handle window close."""
        self._shutdown = True
        
        # Stop engine
        try:
            if self.engine:
                self.engine.stop()
                time.sleep(1)
        except Exception as e:
            self.log.error(f"Error stopping engine: {e}")
        
        # Stop API
        self._stop_api()
        
        # Wait for threads
        if self.t_engine and self.t_engine.is_alive():
            try:
                self.t_engine.join(timeout=2.0)
            except Exception:
                pass
        
        # Destroy window
        try:
            self.destroy()
        except Exception:
            pass
        
        # Force exit
        os._exit(0)


def main():
    """Main entry point."""
    cfg_path = os.path.join(os.path.dirname(__file__), "config.json")
    if not os.path.exists(cfg_path):
        save_config(cfg_path, DEFAULT_CONFIG)
        print(f"Created default config at {cfg_path}")
    
    app = BotGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
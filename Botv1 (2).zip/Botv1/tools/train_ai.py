from __future__ import annotations

import os
import sqlite3
import pandas as pd

def main():
    db_path = os.environ.get("BOT_DB_PATH", os.path.join(os.path.dirname(__file__), "..", "reports", "bot.db"))
    out_path = os.environ.get("AI_MODEL_PATH", os.path.join(os.path.dirname(__file__), "..", "models", "ai_model.pkl"))
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    if not os.path.exists(db_path):
        raise SystemExit(f"DB not found: {db_path}")

    conn = sqlite3.connect(db_path)

    trades = pd.read_sql_query("SELECT ts, symbol, side, price, qty, realized_pnl FROM trades ORDER BY rowid ASC", conn)
    signals = pd.read_sql_query("SELECT ts, symbol, action, strength FROM signals ORDER BY rowid ASC", conn)

    # Join last signal before each trade (simple, per symbol)
    signals["ts"] = signals["ts"].astype(float)
    trades["ts"] = trades["ts"].astype(float)
    trades = trades.sort_values("ts")
    signals = signals.sort_values("ts")

    feats = []
    for sym, tdf in trades.groupby("symbol"):
        sdf = signals[signals["symbol"] == sym]
        if len(sdf) < 20 or len(tdf) < 20:
            continue
        sdf = sdf.set_index("ts")
        for _, tr in tdf.iterrows():
            # nearest previous signal
            prev = sdf[sdf.index <= tr["ts"]].tail(1)
            if prev.empty:
                continue
            row = prev.iloc[0]
            feats.append(
                {
                    "strength": float(row["strength"]),
                    "action_buy": 1.0 if str(row["action"]) == "buy" else 0.0,
                    "action_sell": 1.0 if str(row["action"]) == "sell" else 0.0,
                    "label_win": 1.0 if float(tr["realized_pnl"]) > 0 else 0.0,
                }
            )

    if len(feats) < 200:
        raise SystemExit(f"Not enough training samples: {len(feats)} (need ~200+)")

    df = pd.DataFrame(feats)
    X = df[["strength", "action_buy", "action_sell"]]
    y = df["label_win"]

    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score
    import joblib

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    model = RandomForestClassifier(n_estimators=300, random_state=42, class_weight="balanced")
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    acc = accuracy_score(y_test, pred)

    joblib.dump(model, out_path)
    print(f"Saved AI model -> {out_path}")
    print(f"Validation accuracy: {acc:.3f}")

if __name__ == "__main__":
    main()

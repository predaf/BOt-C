from __future__ import annotations

import numpy as np

def monte_carlo_equity_curve(pnls: np.ndarray, n_sims: int = 5000) -> dict:
    """Basic MC bootstrap on trade PnLs; returns percentiles of terminal PnL."""
    pnls = np.asarray(pnls, dtype=float)
    if pnls.size == 0:
        return {"p50": 0.0, "p05": 0.0, "p95": 0.0}

    terminals = []
    for _ in range(int(n_sims)):
        sample = np.random.choice(pnls, size=pnls.size, replace=True)
        terminals.append(float(sample.sum()))
    terminals = np.array(terminals)
    return {
        "p50": float(np.percentile(terminals, 50)),
        "p05": float(np.percentile(terminals, 5)),
        "p95": float(np.percentile(terminals, 95)),
    }

if __name__ == "__main__":
    demo = np.array([1, -0.5, 0.2, 0.8, -0.3])
    print(monte_carlo_equity_curve(demo))

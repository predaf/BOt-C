# tools/smoke_test_exchange.py
from __future__ import annotations

import os
import sys
import json
import time
import argparse
import logging
from pathlib import Path
from typing import Any, Dict, Optional


# --- Ensure project root is on PYTHONPATH so "import app.*" works ---
THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parents[1]  # .../<project_root>/tools/smoke_test_exchange.py -> parent is project root
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def _load_config(path: str) -> Dict[str, Any]:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"Config not found: {p}")

    # Try YAML if extension suggests it
    if p.suffix.lower() in (".yml", ".yaml"):
        try:
            import yaml  # type: ignore
        except Exception as e:
            raise RuntimeError(
                "Config is YAML but PyYAML is not installed. Install with: pip install pyyaml"
            ) from e
        with p.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        if not isinstance(data, dict):
            raise ValueError("YAML config must be a dict/object at top-level")
        return data

    # JSON
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError("JSON config must be a dict/object at top-level")
    return data


def _setup_logger(verbose: bool = True) -> logging.Logger:
    log = logging.getLogger("smoke_test_exchange")
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    if not log.handlers:
        h = logging.StreamHandler(sys.stdout)
        h.setLevel(logging.DEBUG if verbose else logging.INFO)
        fmt = logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s")
        h.setFormatter(fmt)
        log.addHandler(h)
    return log


def main() -> int:
    ap = argparse.ArgumentParser(description="Smoke test ExchangeClient connectivity and basic endpoints.")
    ap.add_argument("--config", default="configs/base.yaml", help="Path to config (YAML/JSON). Default: configs/base.yaml")
    ap.add_argument("--symbol", default="BTC/USDT", help="Symbol to test ticker/ohlcv. Default: BTC/USDT")
    ap.add_argument("--timeframe", default="1m", help="OHLCV timeframe. Default: 1m")
    ap.add_argument("--ohlcv", type=int, default=30, help="OHLCV limit. Default: 30")
    ap.add_argument("--verbose", action="store_true", help="Verbose logging")
    args = ap.parse_args()

    log = _setup_logger(verbose=args.verbose)

    # Import after sys.path fix
    try:
        from app.exchange import ExchangeClient
    except Exception as e:
        log.error("Failed to import app.exchange.ExchangeClient.")
        log.error("Check that you have an 'app' folder at project root and ideally app/__init__.py exists.")
        log.error(f"Import error: {type(e).__name__}: {e}")
        return 2

    # Load config
    try:
        cfg = _load_config(args.config)
    except Exception as e:
        log.error(f"Failed to load config: {type(e).__name__}: {e}")
        return 3

    # Optional: allow env override if your project uses .env
    # (keeps it non-breaking)
    if not cfg.get("api_key") and os.getenv("API_KEY"):
        cfg["api_key"] = os.getenv("API_KEY")
    if not cfg.get("api_secret") and os.getenv("API_SECRET"):
        cfg["api_secret"] = os.getenv("API_SECRET")

    log.info(f"Project root: {PROJECT_ROOT}")
    log.info(f"Config: {Path(args.config).resolve()}")
    log.info(f"Exchange: {cfg.get('exchange')} | mode={cfg.get('mode')} | enable_futures={cfg.get('enable_futures')}")

    # Create client
    try:
        client = ExchangeClient(cfg, log)
    except Exception as e:
        log.error(f"ExchangeClient init failed: {type(e).__name__}: {e}")
        return 4

    # Basic connectivity
    try:
        markets = client.load_markets()
        log.info(f"Markets loaded: {len(markets) if markets else 0}")
    except Exception as e:
        log.error(f"load_markets failed: {type(e).__name__}: {e}")
        return 5

    sym = args.symbol

    # Ticker
    try:
        t = client.fetch_ticker_cached(sym) if hasattr(client, "fetch_ticker_cached") else client.ex.fetch_ticker(sym)
        bid = t.get("bid")
        ask = t.get("ask")
        last = t.get("last")
        log.info(f"Ticker {sym}: bid={bid} ask={ask} last={last}")
    except Exception as e:
        log.error(f"fetch_ticker failed for {sym}: {type(e).__name__}: {e}")
        return 6

    # OHLCV
    try:
        df = client.fetch_ohlcv_df(sym, args.timeframe, limit=int(args.ohlcv))
        log.info(f"OHLCV {sym} {args.timeframe}: rows={len(df)} cols={list(df.columns)}")
        if len(df) > 0:
            log.info(f"OHLCV last close={float(df['close'].iloc[-1])}")
    except Exception as e:
        log.warning(f"fetch_ohlcv_df failed for {sym}: {type(e).__name__}: {e}")

    # Balance quote
    try:
        quote = cfg.get("quote_asset", "USDT")
        bq = client.fetch_balance_quote(quote)
        log.info(f"Balance quote {quote}: {bq}")
    except Exception as e:
        log.warning(f"fetch_balance_quote failed: {type(e).__name__}: {e}")

    # Futures-only checks
    if bool(cfg.get("enable_futures", False)):
        # Funding
        try:
            fr = client.fetch_funding_rate(sym) if hasattr(client, "fetch_funding_rate") else None
            log.info(f"Funding rate {sym}: {fr}")
        except Exception as e:
            log.warning(f"fetch_funding_rate failed: {type(e).__name__}: {e}")

        # Leverage set (best-effort)
        try:
            lev = int((cfg.get("futures") or {}).get("leverage", 1))
            if hasattr(client, "set_leverage"):
                client.set_leverage(sym, lev)
                log.info(f"set_leverage({sym}, {lev}) OK (best-effort)")
        except Exception as e:
            log.warning(f"set_leverage failed: {type(e).__name__}: {e}")

    log.info("Smoke test completed OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

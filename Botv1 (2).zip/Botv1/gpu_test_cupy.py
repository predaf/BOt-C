import cupy as cp
import time

print("cupy:", cp.__version__)
a = cp.random.randn(4096, 4096)
b = cp.random.randn(4096, 4096)
cp.cuda.runtime.deviceSynchronize()
t0 = time.time()
c = a @ b
cp.cuda.runtime.deviceSynchronize()
print("matmul ok, sec:", round(time.time()-t0, 3))
print("gpu:", cp.cuda.runtime.getDeviceProperties(0)["name"].decode())

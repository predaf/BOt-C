# app/capabilities.py
from __future__ import annotations

import os
import sys
import platform
import importlib.util
import socket
import subprocess
import time
import json
import pkgutil
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, List, Tuple, Set
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutureTimeoutError
from pathlib import Path


def _has_module(name: str) -> bool:
    """Return True if a Python module can be imported (installed)."""
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def _module_version(name: str) -> Optional[str]:
    """Best-effort module version, without hard dependency."""
    try:
        if not _has_module(name):
            return None
        mod = __import__(name)
        # Try multiple common version attributes
        for attr in ["__version__", "version", "VERSION", "__version"]:
            v = getattr(mod, attr, None)
            if v is not None:
                if callable(v):
                    v = v()
                return str(v)
        return None
    except Exception:
        return None


def _env_has(name: str) -> bool:
    try:
        v = os.environ.get(name)
        return bool(v and str(v).strip())
    except Exception:
        return False


@dataclass
class Capabilities:
    """Thin wrapper so callers can safely serialize and access capability flags."""
    data: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return dict(self.data or {})
    
    def as_dict(self) -> Dict[str, Any]:
        """Alias for to_dict."""
        return self.to_dict()
    
    def get(self, key: str, default: Any = None) -> Any:
        """Safe get with default."""
        try:
            return (self.data or {}).get(key, default)
        except Exception:
            return default
    
    def __getitem__(self, key: str) -> Any:
        """Dictionary-like access."""
        return (self.data or {})[key]
    
    def json(self, indent: int = 2) -> str:
        """Return as formatted JSON string."""
        return json.dumps(self.data, indent=indent, default=str)
    
    def summary(self) -> Dict[str, Any]:
        """Return a simplified summary of capabilities."""
        return {
            "mode": self.get("mode"),
            "exchange": self.get("exchange"),
            "llm_enabled": self.get("llm", {}).get("enabled", False),
            "telegram_enabled": self.get("modules", {}).get("telegram", {}).get("enabled", False),
            "health_status": self.get("health_status", "unknown")
        }


class HealthChecker:
    """Helper class for performing health checks with timeouts."""
    
    @staticmethod
    def check_http_endpoint(url: str, timeout: float = 2.0) -> Tuple[bool, Optional[str], Optional[float]]:
        """Check HTTP endpoint availability."""
        if not _has_module("requests"):
            return False, "requests module not available", None
        
        try:
            import requests
            start_time = time.time()
            response = requests.get(url, timeout=timeout)
            elapsed = time.time() - start_time
            
            if response.status_code == 200:
                return True, f"HTTP {response.status_code}", round(elapsed * 1000, 1)
            else:
                return False, f"HTTP {response.status_code}", round(elapsed * 1000, 1)
        except requests.exceptions.Timeout:
            return False, "timeout", None
        except requests.exceptions.ConnectionError:
            return False, "connection error", None
        except Exception as e:
            return False, f"{type(e).__name__}: {str(e)}", None
    
    @staticmethod
    def check_tcp_port(host: str, port: int, timeout: float = 2.0) -> Tuple[bool, Optional[str], Optional[float]]:
        """Check TCP port availability."""
        try:
            start_time = time.time()
            sock = socket.create_connection((host, port), timeout=timeout)
            sock.close()
            elapsed = time.time() - start_time
            return True, "port open", round(elapsed * 1000, 1)
        except socket.timeout:
            return False, "timeout", None
        except ConnectionRefusedError:
            return False, "connection refused", None
        except Exception as e:
            return False, f"{type(e).__name__}: {str(e)}", None
    
    @staticmethod
    def check_command(command: List[str], timeout: float = 2.0) -> Tuple[bool, Optional[str], Optional[float]]:
        """Check if a command executes successfully."""
        try:
            start_time = time.time()
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            elapsed = time.time() - start_time
            
            if result.returncode == 0:
                return True, "command executed successfully", round(elapsed * 1000, 1)
            else:
                return False, f"exit code {result.returncode}: {result.stderr[:100]}", round(elapsed * 1000, 1)
        except subprocess.TimeoutExpired:
            return False, "timeout", None
        except FileNotFoundError:
            return False, "command not found", None
        except Exception as e:
            return False, f"{type(e).__name__}: {str(e)}", None


class DependencyScanner:
    """Scan for available dependencies and their versions."""
    
    @staticmethod
    def scan_common_packages() -> Dict[str, Optional[str]]:
        """Scan for common trading/data science packages."""
        common_packages = [
            "numpy", "pandas", "scipy", "scikit-learn", "tensorflow", "torch",
            "ccxt", "websockets", "aiohttp", "requests", "sqlalchemy", 
            "plotly", "matplotlib", "seaborn", "ta", "pyti", "talib",
            "feedparser", "newspaper3k", "textblob", "vaderSentiment",
            "web3", "eth_account", "cryptography",
            "openai", "anthropic", "cohere", "google.generativeai",
            "docker", "kubernetes", "celery", "redis",
            "pytest", "pytest_asyncio", "pytest_mock",
        ]
        
        versions = {}
        for package in common_packages:
            versions[package] = _module_version(package)
        
        return versions
    
    @staticmethod
    def find_installed_packages(prefix: str = "") -> Dict[str, Optional[str]]:
        """Find all installed packages with optional prefix filter."""
        installed = {}
        for module in pkgutil.iter_modules():
            if prefix and not module.name.startswith(prefix):
                continue
            installed[module.name] = _module_version(module.name)
        return installed
    
    @staticmethod
    def check_exchange_support(exchange_name: str) -> Tuple[bool, Optional[str]]:
        """Check if an exchange is supported via CCXT."""
        if not _has_module("ccxt"):
            return False, "ccxt not installed"
        
        try:
            import ccxt
            exchange_class = getattr(ccxt, exchange_name, None)
            if exchange_class:
                return True, f"CCXT version: {_module_version('ccxt')}"
            else:
                return False, f"Exchange {exchange_name} not found in CCXT"
        except Exception as e:
            return False, f"Error checking CCXT: {str(e)}"


class CapabilityRegistry:
    """Registry for detecting and reporting system capabilities."""
    
    def __init__(self):
        self._cache: Optional[Capabilities] = None
        self._cache_time: Optional[float] = None
        self._cache_ttl: float = 60.0  # Cache for 60 seconds
        
    @staticmethod
    def detect(cfg: Dict[str, Any], base_dir: str = ".") -> Capabilities:
        """Detect system capabilities based on configuration."""
        cfg = cfg or {}
        
        # Check cache
        registry = CapabilityRegistry()
        current_time = time.time()
        if (registry._cache is not None and 
            registry._cache_time is not None and
            (current_time - registry._cache_time) < registry._cache_ttl):
            return registry._cache
        
        llm_cfg = (cfg.get("llm") or {})
        tg_cfg = (cfg.get("telegram") or {})
        ws_cfg = (cfg.get("websocket") or {})
        sqlite_cfg = (cfg.get("sqlite") or {})
        caps_cfg = (cfg.get("capabilities") or {})  # optional section
        
        enable_futures = bool(cfg.get("enable_futures", False))
        mode = str(cfg.get("mode", "paper")).lower().strip()
        
        # LLM flags
        llm_enabled = bool(llm_cfg.get("enabled", False))
        llm_mode = str(llm_cfg.get("mode", "local")).lower().strip()
        llm_provider = str(llm_cfg.get("provider", "ollama")).lower().strip()
        
        # Optional lightweight healthchecks (can be disabled from config)
        do_healthchecks = bool(caps_cfg.get("healthchecks", True))
        health_timeout_sec = float(caps_cfg.get("health_timeout_sec", 1.5))
        
        # Run health checks in parallel
        health_results = {}
        if do_healthchecks:
            health_results = CapabilityRegistry._run_health_checks(
                cfg, health_timeout_sec
            )
        
        # ---- LLM local (Ollama) ----
        ollama_cfg = (llm_cfg.get("ollama") or {})
        ollama_base_url = str(ollama_cfg.get("base_url") or ollama_cfg.get("host") or "http://127.0.0.1:11434").strip()
        ollama_cfg_enabled = bool(ollama_cfg.get("enabled", True))
        
        requests_available = _has_module("requests")
        ollama_available = requests_available and (llm_provider == "ollama")
        ollama_enabled = llm_enabled and (llm_mode in ("local", "ollama", "hybrid")) and ollama_cfg_enabled and ollama_available
        
        ollama_healthy = health_results.get("ollama", {}).get("healthy")
        ollama_detail = health_results.get("ollama", {}).get("detail")
        ollama_latency = health_results.get("ollama", {}).get("latency_ms")
        
        # ---- LLM cloud (OpenAI) ----
        openai_pkg = _has_module("openai")
        openai_key_present = bool(_env_has("OPENAI_API_KEY") or ((llm_cfg.get("cloud") or {}).get("api_key")))
        openai_available = openai_pkg and openai_key_present
        openai_enabled = llm_enabled and (llm_mode in ("cloud", "openai", "hybrid")) and (llm_provider == "openai") and openai_available
        
        # Check OpenAI connectivity if enabled
        openai_healthy = None
        openai_detail = None
        if do_healthchecks and openai_enabled and openai_available:
            openai_healthy = health_results.get("openai", {}).get("healthy")
            openai_detail = health_results.get("openai", {}).get("detail")
        
        # ---- Additional LLM providers ----
        anthropic_available = _has_module("anthropic")
        anthropic_key_present = _env_has("ANTHROPIC_API_KEY")
        anthropic_enabled = llm_enabled and (llm_provider == "anthropic") and anthropic_available and anthropic_key_present
        
        cohere_available = _has_module("cohere")
        cohere_key_present = _env_has("COHERE_API_KEY")
        cohere_enabled = llm_enabled and (llm_provider == "cohere") and cohere_available and cohere_key_present
        
        # ---- Aux data sources ----
        news_available = _has_module("feedparser") or requests_available
        sentiment_available = _has_module("textblob") or _has_module("vaderSentiment") or _has_module("nltk")
        onchain_available = _has_module("web3")
        
        # In-repo modules (assume available; you can extend this with real checks)
        micro_available = True
        
        # ---- Config toggles ----
        approvals_enabled = bool((cfg.get("approvals") or {}).get("enabled", False))
        decision_factor_enabled = bool((cfg.get("decision_factor") or {}).get("enabled", False))
        autonomy_enabled = bool((cfg.get("autonomy") or {}).get("enabled", True))
        market_guard_enabled = bool((cfg.get("market_guard") or {}).get("enabled", False))
        
        # ---- Telegram ----
        telegram_cfg_enabled = bool(tg_cfg.get("enabled", False))
        telegram_token_present = bool(_env_has("TELEGRAM_BOT_TOKEN") or tg_cfg.get("token"))
        telegram_available = telegram_cfg_enabled and telegram_token_present
        
        # ---- WebSockets ----
        ws_available = _has_module("websockets")
        ws_enabled = bool(ws_cfg.get("enabled", True)) and ws_available
        
        # ---- SQLite ----
        sqlite_enabled = bool(sqlite_cfg.get("enabled", True))
        
        # ---- Exchange support ----
        exchange_name = str(cfg.get("exchange", "")).lower()
        exchange_available, exchange_detail = DependencyScanner.check_exchange_support(exchange_name)
        
        # ---- Execution features ----
        exec_cfg = (cfg.get("execution") or {})
        twap_cfg = (exec_cfg.get("twap") or {})
        twap_enabled = bool(twap_cfg.get("enabled", True))
        
        router_cfg = (exec_cfg.get("router") or {})
        router_enabled = bool(router_cfg.get("enabled", True))
        
        iceberg_cfg = (exec_cfg.get("iceberg") or {})
        iceberg_enabled = bool(iceberg_cfg.get("enabled", False))
        
        # ---- Hardware capabilities ----
        hardware_info = CapabilityRegistry._detect_hardware()
        
        # ---- System resources ----
        system_resources = CapabilityRegistry._check_system_resources()
        
        # ---- Versions (best-effort) ----
        versions = DependencyScanner.scan_common_packages()
        
        # Add bot version if available
        try:
            bot_version = _module_version("app") or "unknown"
            versions["bot"] = bot_version
        except Exception:
            versions["bot"] = "unknown"
        
        # ---- Security checks ----
        security_info = CapabilityRegistry._check_security(cfg)
        
        # ---- Build capabilities dictionary ----
        data: Dict[str, Any] = {
            "mode": mode,
            "exchange": {
                "name": exchange_name,
                "available": exchange_available,
                "detail": exchange_detail,
                "futures_enabled": enable_futures
            },
            "sandbox": bool(cfg.get("sandbox", False)),
            "enable_futures": enable_futures,
            
            "modules": {
                "ws": {"enabled": ws_enabled, "available": ws_available},
                "sqlite": {"enabled": sqlite_enabled, "available": True},
                "approvals": {"enabled": approvals_enabled, "available": True},
                "decision_factor": {"enabled": decision_factor_enabled, "available": True},
                "micro_model": {"enabled": True, "available": micro_available},
                "autonomy": {"enabled": autonomy_enabled, "available": True},
                "market_guard": {"enabled": market_guard_enabled, "available": True},
                "news": {"enabled": bool((cfg.get("news") or {}).get("enabled", True)), "available": news_available},
                "sentiment": {"enabled": bool((cfg.get("sentiment") or {}).get("enabled", True)), "available": sentiment_available},
                "onchain": {"enabled": bool((cfg.get("onchain") or {}).get("enabled", False)), "available": onchain_available},
                "telegram": {"enabled": telegram_available, "available": telegram_token_present},
                "llm": {"enabled": llm_enabled, "available": True},
            },
            
            "llm": {
                "enabled": llm_enabled,
                "mode": llm_mode,
                "provider": llm_provider,
                "local": {
                    "ollama": {
                        "enabled": ollama_enabled,
                        "available": ollama_available,
                        "base_url": ollama_base_url,
                        "healthy": ollama_healthy,
                        "detail": ollama_detail,
                        "latency_ms": ollama_latency,
                    }
                },
                "cloud": {
                    "openai": {
                        "enabled": openai_enabled,
                        "available": openai_available,
                        "healthy": openai_healthy,
                        "detail": openai_detail,
                        "pkg": openai_pkg,
                        "key_present": openai_key_present,
                    },
                    "anthropic": {
                        "enabled": anthropic_enabled,
                        "available": anthropic_available,
                        "key_present": anthropic_key_present,
                    },
                    "cohere": {
                        "enabled": cohere_enabled,
                        "available": cohere_available,
                        "key_present": cohere_key_present,
                    }
                },
            },
            
            "execution": {
                "twap": {"enabled": twap_enabled, "available": True},
                "router": {"enabled": router_enabled, "available": True},
                "iceberg": {"enabled": iceberg_enabled, "available": True},
            },
            
            "runtime": {
                "python": sys.version.split()[0],
                "platform": platform.platform(),
                "architecture": platform.architecture()[0],
                "machine": platform.machine(),
                "processor": platform.processor(),
                "cwd": os.getcwd(),
                "pid": os.getpid(),
                "uid": os.getuid() if hasattr(os, 'getuid') else None,
                "hostname": socket.gethostname(),
                "python_path": sys.executable,
            },
            
            "hardware": hardware_info,
            
            "system_resources": system_resources,
            
            "security": security_info,
            
            "paths": {
                "base_dir": os.path.abspath(base_dir),
                "config_dir": os.path.dirname(os.path.abspath(cfg.get("_config_file", ""))) if cfg.get("_config_file") else None,
                "home_dir": str(Path.home()),
            },
            
            "healthchecks": {
                "enabled": bool(do_healthchecks),
                "timeout_sec": float(health_timeout_sec),
                "results": health_results,
            },
            
            "versions": versions,
            
            "timestamp": time.time(),
            "timestamp_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "detection_time_ms": round((time.time() - current_time) * 1000, 1),
        }
        
        # Calculate overall health status
        data["health_status"] = CapabilityRegistry._calculate_health_status(data)
        
        capabilities = Capabilities(data=data)
        
        # Update cache
        registry._cache = capabilities
        registry._cache_time = time.time()
        
        return capabilities
    
    @staticmethod
    def _run_health_checks(cfg: Dict[str, Any], timeout: float) -> Dict[str, Any]:
        """Run health checks in parallel."""
        checks = {}
        futures = {}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            # Ollama check
            ollama_cfg = (cfg.get("llm") or {}).get("ollama") or {}
            ollama_base_url = str(ollama_cfg.get("base_url") or "http://127.0.0.1:11434").strip()
            if ollama_base_url:
                futures["ollama"] = executor.submit(
                    HealthChecker.check_http_endpoint,
                    f"{ollama_base_url.rstrip('/')}/api/tags",
                    timeout
                )
            
            # OpenAI check (if key present)
            openai_key_present = _env_has("OPENAI_API_KEY") or ((cfg.get("llm") or {}).get("cloud") or {}).get("api_key")
            if openai_key_present:
                futures["openai"] = executor.submit(
                    HealthChecker.check_http_endpoint,
                    "https://api.openai.com/v1/models",
                    timeout
                )
            
            # Exchange API check
            exchange_name = str(cfg.get("exchange", "")).lower()
            if exchange_name:
                if exchange_name == "binance":
                    futures["exchange_api"] = executor.submit(
                        HealthChecker.check_tcp_port,
                        "api.binance.com",
                        443,
                        timeout
                    )
                elif exchange_name == "coinbase":
                    futures["exchange_api"] = executor.submit(
                        HealthChecker.check_tcp_port,
                        "api.coinbase.com",
                        443,
                        timeout
                    )
            
            # Internet connectivity check
            futures["internet"] = executor.submit(
                HealthChecker.check_tcp_port,
                "8.8.8.8",
                53,
                timeout
            )
            
            # Process results
            for name, future in futures.items():
                try:
                    result = future.result(timeout=timeout + 0.5)
                    checks[name] = {
                        "healthy": result[0],
                        "detail": result[1],
                        "latency_ms": result[2]
                    }
                except FutureTimeoutError:
                    checks[name] = {
                        "healthy": False,
                        "detail": "health check timeout",
                        "latency_ms": None
                    }
                except Exception as e:
                    checks[name] = {
                        "healthy": False,
                        "detail": f"{type(e).__name__}: {str(e)}",
                        "latency_ms": None
                    }
        
        return checks
    
    @staticmethod
    def _detect_hardware() -> Dict[str, Any]:
        """Detect hardware capabilities."""
        hardware = {
            "cpu_count": os.cpu_count(),
            "gpu_available": False,
            "memory_gb": None,
        }
        
        # Try to detect GPU
        try:
            import subprocess
            # Check for NVIDIA GPU
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0 and result.stdout.strip():
                hardware["gpu_available"] = True
                hardware["gpu_info"] = result.stdout.strip().split('\n')[0]
        except Exception:
            pass
        
        # Try to get memory info
        try:
            import psutil
            hardware["memory_gb"] = round(psutil.virtual_memory().total / (1024**3), 1)
            hardware["memory_available_gb"] = round(psutil.virtual_memory().available / (1024**3), 1)
        except ImportError:
            pass
        
        return hardware
    
    @staticmethod
    def _check_system_resources() -> Dict[str, Any]:
        """Check system resource utilization."""
        resources = {
            "load_avg": None,
            "disk_usage": None,
            "cpu_percent": None,
        }
        
        try:
            import psutil
            # CPU load
            resources["load_avg"] = [round(x, 2) for x in psutil.getloadavg()]
            resources["cpu_percent"] = psutil.cpu_percent(interval=0.1)
            
            # Disk usage
            disk_usage = psutil.disk_usage('/')
            resources["disk_usage"] = {
                "total_gb": round(disk_usage.total / (1024**3), 1),
                "used_gb": round(disk_usage.used / (1024**3), 1),
                "free_gb": round(disk_usage.free / (1024**3), 1),
                "percent": disk_usage.percent
            }
            
            # Memory usage
            memory = psutil.virtual_memory()
            resources["memory"] = {
                "total_gb": round(memory.total / (1024**3), 1),
                "available_gb": round(memory.available / (1024**3), 1),
                "percent": memory.percent
            }
            
        except ImportError:
            pass
        
        return resources
    
    @staticmethod
    def _check_security(cfg: Dict[str, Any]) -> Dict[str, Any]:
        """Perform basic security checks."""
        security = {
            "env_vars_secured": False,
            "config_permissions": "unknown",
            "key_storage": "unknown",
        }
        
        # Check if sensitive env vars are set
        sensitive_vars = [
            "TELEGRAM_BOT_TOKEN",
            "OPENAI_API_KEY",
            "ANTHROPIC_API_KEY",
            "COHERE_API_KEY",
            "EXCHANGE_API_KEY",
            "EXCHANGE_SECRET",
        ]
        
        exposed_vars = []
        for var in sensitive_vars:
            if _env_has(var):
                exposed_vars.append(var)
        
        security["exposed_env_vars"] = exposed_vars
        security["env_vars_secured"] = len(exposed_vars) == 0
        
        # Check config file permissions
        config_file = cfg.get("_config_file")
        if config_file and os.path.exists(config_file):
            try:
                import stat
                st = os.stat(config_file)
                if st.st_mode & stat.S_IROTH:
                    security["config_permissions"] = "world_readable"
                elif st.st_mode & stat.S_IRGRP:
                    security["config_permissions"] = "group_readable"
                else:
                    security["config_permissions"] = "owner_only"
            except Exception:
                pass
        
        return security
    
    @staticmethod
    def _calculate_health_status(data: Dict[str, Any]) -> str:
        """Calculate overall health status."""
        health_checks = data.get("healthchecks", {}).get("results", {})
        
        if not health_checks:
            return "unknown"
        
        critical_checks = ["internet", "exchange_api"]
        all_healthy = True
        any_critical_failed = False
        
        for check_name, check_result in health_checks.items():
            if not check_result.get("healthy", False):
                all_healthy = False
                if check_name in critical_checks:
                    any_critical_failed = True
        
        if any_critical_failed:
            return "critical"
        elif not all_healthy:
            return "degraded"
        else:
            return "healthy"
    
    @staticmethod
    def get_detailed_report(capabilities: Capabilities) -> str:
        """Generate a human-readable report of capabilities."""
        caps = capabilities.data
        lines = []
        
        lines.append("=" * 80)
        lines.append("SYSTEM CAPABILITIES REPORT")
        lines.append("=" * 80)
        lines.append(f"Generated: {caps.get('timestamp_iso', 'unknown')}")
        lines.append(f"Detection time: {caps.get('detection_time_ms', 0)} ms")
        lines.append("")
        
        # Health Status
        lines.append("--- HEALTH STATUS ---")
        lines.append(f"Overall Status: {caps.get('health_status', 'unknown').upper()}")
        health_results = caps.get("healthchecks", {}).get("results", {})
        for check_name, result in health_results.items():
            status = "✓" if result.get("healthy") else "✗"
            detail = result.get("detail", "N/A")
            latency = result.get("latency_ms", "N/A")
            lines.append(f"  {status} {check_name}: {detail} ({latency} ms)")
        
        # Runtime
        lines.append("\n--- RUNTIME ---")
        runtime = caps.get("runtime", {})
        lines.append(f"Python: {runtime.get('python')}")
        lines.append(f"Platform: {runtime.get('platform')}")
        lines.append(f"Architecture: {runtime.get('architecture')}")
        lines.append(f"Hostname: {runtime.get('hostname')}")
        lines.append(f"PID: {runtime.get('pid')}")
        
        # Mode and Exchange
        lines.append("\n--- TRADING CONFIG ---")
        lines.append(f"Mode: {caps.get('mode')}")
        lines.append(f"Sandbox: {caps.get('sandbox')}")
        exchange = caps.get("exchange", {})
        lines.append(f"Exchange: {exchange.get('name')} (available: {exchange.get('available')})")
        if exchange.get("detail"):
            lines.append(f"  Detail: {exchange.get('detail')}")
        
        # Modules
        lines.append("\n--- MODULES ---")
        modules = caps.get("modules", {})
        for mod_name, mod_info in modules.items():
            enabled = mod_info.get('enabled', False)
            available = mod_info.get('available', False)
            status = "✓" if enabled and available else "○" if available else "✗"
            lines.append(f"  {status} {mod_name}: enabled={enabled}, available={available}")
        
        # LLM
        lines.append("\n--- LLM ---")
        llm = caps.get("llm", {})
        lines.append(f"Enabled: {llm.get('enabled')}")
        lines.append(f"Mode: {llm.get('mode')}")
        lines.append(f"Provider: {llm.get('provider')}")
        
        # Local LLM
        ollama = llm.get("local", {}).get("ollama", {})
        if ollama.get("enabled"):
            status = "✓" if ollama.get("healthy") else "✗"
            lines.append(f"  {status} Ollama: healthy={ollama.get('healthy')}, latency={ollama.get('latency_ms')}ms")
        
        # Cloud LLMs
        cloud_providers = llm.get("cloud", {})
        for provider_name, provider_info in cloud_providers.items():
            if provider_info.get("enabled"):
                status = "✓" if provider_info.get("healthy", True) else "✗"
                lines.append(f"  {status} {provider_name.capitalize()}: available={provider_info.get('available')}")
        
        # Hardware
        lines.append("\n--- HARDWARE ---")
        hardware = caps.get("hardware", {})
        lines.append(f"CPU Cores: {hardware.get('cpu_count', 'N/A')}")
        lines.append(f"GPU Available: {hardware.get('gpu_available', False)}")
        if hardware.get("gpu_info"):
            lines.append(f"GPU Info: {hardware.get('gpu_info')}")
        if hardware.get("memory_gb"):
            lines.append(f"Memory: {hardware.get('memory_gb')} GB")
        
        # System Resources
        lines.append("\n--- SYSTEM RESOURCES ---")
        resources = caps.get("system_resources", {})
        if resources.get("load_avg"):
            lines.append(f"Load Average: {resources.get('load_avg')}")
        if resources.get("cpu_percent"):
            lines.append(f"CPU Usage: {resources.get('cpu_percent')}%")
        if resources.get("disk_usage"):
            disk = resources.get("disk_usage", {})
            lines.append(f"Disk Usage: {disk.get('used_gb')}/{disk.get('total_gb')} GB ({disk.get('percent')}%)")
        
        # Security
        lines.append("\n--- SECURITY ---")
        security = caps.get("security", {})
        lines.append(f"Env Vars Secured: {security.get('env_vars_secured')}")
        if not security.get("env_vars_secured"):
            exposed = security.get("exposed_env_vars", [])
            if exposed:
                lines.append(f"  Exposed: {', '.join(exposed)}")
        lines.append(f"Config Permissions: {security.get('config_permissions', 'unknown')}")
        
        # Key Versions
        lines.append("\n--- KEY VERSIONS ---")
        versions = caps.get("versions", {})
        important_versions = ["bot", "ccxt", "pandas", "numpy", "requests", "websockets"]
        for pkg in important_versions:
            ver = versions.get(pkg)
            if ver:
                lines.append(f"  {pkg}: {ver}")
        
        lines.append("\n" + "=" * 80)
        return "\n".join(lines)
    
    @staticmethod
    def validate_configuration(cfg: Dict[str, Any]) -> List[str]:
        """Validate configuration and return warnings/issues."""
        warnings = []
        
        # Check for required modules based on config
        if cfg.get("llm", {}).get("enabled"):
            provider = cfg.get("llm", {}).get("provider", "ollama")
            if provider == "ollama" and not _has_module("requests"):
                warnings.append("LLM provider 'ollama' requires 'requests' module")
            elif provider == "openai" and not _has_module("openai"):
                warnings.append("LLM provider 'openai' requires 'openai' module")
        
        # Check exchange support
        exchange_name = str(cfg.get("exchange", "")).lower()
        if exchange_name:
            available, detail = DependencyScanner.check_exchange_support(exchange_name)
            if not available:
                warnings.append(f"Exchange '{exchange_name}' not available: {detail}")
        
        # Check for conflicting settings
        if cfg.get("sandbox") and cfg.get("enable_futures"):
            warnings.append("Futures trading might not be available in sandbox mode")
        
        # Check telegram config
        if cfg.get("telegram", {}).get("enabled"):
            if not _env_has("TELEGRAM_BOT_TOKEN") and not cfg.get("telegram", {}).get("token"):
                warnings.append("Telegram enabled but no token found in env or config")
        
        return warnings


# Convenience functions
def get_capabilities(cfg: Dict[str, Any], base_dir: str = ".") -> Capabilities:
    """Get system capabilities (cached)."""
    return CapabilityRegistry.detect(cfg, base_dir)


def print_capabilities_report(cfg: Dict[str, Any], base_dir: str = ".") -> None:
    """Print a detailed capabilities report to console."""
    caps = get_capabilities(cfg, base_dir)
    report = CapabilityRegistry.get_detailed_report(caps)
    print(report)


def check_requirements(cfg: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Check if system meets minimum requirements."""
    warnings = CapabilityRegistry.validate_configuration(cfg)
    caps = get_capabilities(cfg)
    
    # Check critical requirements
    critical_issues = []
    
    # Internet connectivity
    health = caps.get("healthchecks", {}).get("results", {}).get("internet", {})
    if not health.get("healthy", True):
        critical_issues.append("No internet connectivity")
    
    # Exchange connectivity if enabled
    exchange = caps.get("exchange", {})
    if exchange.get("name") and not exchange.get("available"):
        critical_issues.append(f"Exchange '{exchange.get('name')}' not available")
    
    return len(critical_issues) == 0, critical_issues + warnings


# Quick test if run directly
if __name__ == "__main__":
    sample_config = {
        "mode": "paper",
        "exchange": "binance",
        "sandbox": True,
        "llm": {
            "enabled": True,
            "mode": "local",
            "provider": "ollama"
        },
        "telegram": {
            "enabled": False
        },
        "sqlite": {
            "enabled": True
        },
        "_config_file": __file__  # For testing
    }
    
    print("Testing capabilities detection...\n")
    caps = get_capabilities(sample_config)
    
    print("Summary:")
    print(json.dumps(caps.summary(), indent=2))
    
    print("\n" + "=" * 80 + "\n")
    
    print("Detailed Report:")
    print_capabilities_report(sample_config)
    
    print("\n" + "=" * 80 + "\n")
    
    print("Requirements Check:")
    ok, issues = check_requirements(sample_config)
    if ok:
        print("✓ All requirements met")
    else:
        print("✗ Issues found:")
        for issue in issues:
            print(f"  - {issue}")
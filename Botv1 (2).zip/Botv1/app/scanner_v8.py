from __future__ import annotations

from typing import List, Dict, Any, Optional, Tuple, Set
import math
import time
import logging
from dataclasses import dataclass, field
from collections import defaultdict
import threading


@dataclass
class ScanMetrics:
    """Metrics for scanner performance and results."""
    scanned_symbols: int = 0
    candidates_found: int = 0
    excluded_by_volume: int = 0
    excluded_by_spread: int = 0
    excluded_by_stable: int = 0
    excluded_by_leveraged: int = 0
    excluded_by_volatility: int = 0
    excluded_by_price: int = 0
    excluded_by_orderbook: int = 0
    execution_time_ms: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0


@dataclass
class SymbolScore:
    """Detailed score breakdown for a symbol."""
    symbol: str
    quote_volume: float
    abs_pct_change: float
    spread_bps: Optional[float]
    score: float
    volume_score: float = 0.0
    volatility_score: float = 0.0
    spread_score: float = 0.0
    liquidity_score: float = 0.0
    final_score: float = 0.0
    root_asset: str = ""
    is_futures: bool = False
    price: float = 0.0
    volume_rank: int = 0
    volatility_rank: int = 0


class MarketScanner:
    """
    Advanced market scanner with caching, multiple quote currencies,
    and comprehensive filtering options.
    """
    
    def __init__(self, exchange, log=None, config=None):
        self.exchange = exchange
        self.log = log or logging.getLogger(__name__)
        self.config = config or {}
        
        # Caching
        self._ticker_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._market_cache: Dict[str, Dict[str, Any]] = {}
        self._orderbook_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._cache_lock = threading.RLock()
        
        # Statistics
        self.metrics = ScanMetrics()
        self.scan_count = 0
        
        # Default configuration
        self.default_weights = {
            "volume": 0.60,
            "volatility": 0.25,
            "spread": 0.15,
            "liquidity": 0.10
        }
        
        # Cache TTLs (seconds)
        self.cache_ttl = {
            "ticker": 30.0,      # 30 seconds for tickers
            "orderbook": 10.0,   # 10 seconds for orderbook
            "markets": 300.0,    # 5 minutes for market info
        }
    
    def _log(self, level: str, msg: str) -> None:
        """Log message with configured logger."""
        if not self.log:
            return
        try:
            fn = getattr(self.log, level, None)
            if callable(fn):
                fn(msg)
            else:
                self.log.info(msg)
        except Exception:
            pass
    
    def _get_cache_key(self, symbol: str, cache_type: str) -> str:
        """Generate cache key for symbol and cache type."""
        return f"{cache_type}:{symbol.upper()}"
    
    def _get_cached_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get ticker from cache if not expired."""
        with self._cache_lock:
            key = self._get_cache_key(symbol, "ticker")
            if key in self._ticker_cache:
                timestamp, ticker = self._ticker_cache[key]
                if time.time() - timestamp < self.cache_ttl["ticker"]:
                    self.metrics.cache_hits += 1
                    return ticker
                else:
                    del self._ticker_cache[key]
            self.metrics.cache_misses += 1
        return None
    
    def _set_cached_ticker(self, symbol: str, ticker: Dict[str, Any]) -> None:
        """Cache ticker data."""
        with self._cache_lock:
            key = self._get_cache_key(symbol, "ticker")
            self._ticker_cache[key] = (time.time(), ticker.copy())
            
            # Clean old cache entries if too many
            if len(self._ticker_cache) > 1000:
                cutoff = time.time() - self.cache_ttl["ticker"] * 2
                expired = [k for k, (ts, _) in self._ticker_cache.items() if ts < cutoff]
                for k in expired[:100]:  # Remove up to 100 old entries
                    self._ticker_cache.pop(k, None)
    
    def _get_cached_orderbook(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get orderbook from cache if not expired."""
        with self._cache_lock:
            key = self._get_cache_key(symbol, "orderbook")
            if key in self._orderbook_cache:
                timestamp, orderbook = self._orderbook_cache[key]
                if time.time() - timestamp < self.cache_ttl["orderbook"]:
                    return orderbook
                else:
                    del self._orderbook_cache[key]
        return None
    
    def _set_cached_orderbook(self, symbol: str, orderbook: Dict[str, Any]) -> None:
        """Cache orderbook data."""
        with self._cache_lock:
            key = self._get_cache_key(symbol, "orderbook")
            self._orderbook_cache[key] = (time.time(), orderbook.copy())
    
    def _f(self, x: Any, default: float = 0.0) -> float:
        """Safe float conversion."""
        try:
            if x is None:
                return float(default)
            v = float(x)
            if math.isnan(v) or math.isinf(v):
                return float(default)
            return v
        except Exception:
            return float(default)
    
    def _is_finite(self, x: float) -> bool:
        """Check if value is finite."""
        return (x == x) and (x not in (float("inf"), float("-inf")))
    
    def _safe_abs_pct_change(self, t: Dict[str, Any]) -> float:
        """
        Best-effort: many exchanges provide `percentage` (24h %). 
        Some provide `change` or `info`.
        Returns absolute percentage (0..inf).
        """
        chg = t.get("percentage")
        if chg is None:
            chg = t.get("change")
        v = self._f(chg, 0.0)
        return abs(v) if self._is_finite(v) else 0.0
    
    def _extract_quote_volume(self, t: Dict[str, Any]) -> float:
        """
        Best-effort quote volume:
          - `quoteVolume` is ideal
          - some give `baseVolume` and we can approximate using `last`
        """
        # Try common quote volume fields
        qv_fields = ["quoteVolume", "quote_volume", "volumeQuote", "turnover", "turnover24h"]
        
        for field in qv_fields:
            qv = t.get(field)
            if qv is not None:
                v = self._f(qv, 0.0)
                if self._is_finite(v) and v > 0:
                    return v
        
        # Try baseVolume * last
        bv = t.get("baseVolume")
        last = t.get("last") or t.get("close")
        bvf = self._f(bv, 0.0)
        lastf = self._f(last, 0.0)
        if self._is_finite(bvf) and self._is_finite(lastf) and bvf > 0 and lastf > 0:
            return bvf * lastf
        
        # Sometimes in `info`
        info = t.get("info") or {}
        for k in qv_fields:
            if k in info:
                v = self._f(info.get(k), 0.0)
                if self._is_finite(v) and v > 0:
                    return v
        
        return 0.0
    
    def _extract_price(self, t: Dict[str, Any]) -> float:
        """Extract current price from ticker."""
        price_fields = ["last", "close", "lastPrice", "price"]
        
        for field in price_fields:
            price = t.get(field)
            if price is not None:
                v = self._f(price, 0.0)
                if self._is_finite(v) and v > 0:
                    return v
        
        # Fallback to bid/ask midpoint
        bid = self._f(t.get("bid"), 0.0)
        ask = self._f(t.get("ask"), 0.0)
        if self._is_finite(bid) and self._is_finite(ask) and bid > 0 and ask > 0:
            return (bid + ask) / 2.0
        
        return 0.0
    
    def _estimate_spread_bps(self, t: Dict[str, Any]) -> Optional[float]:
        """
        Estimate spread in basis points using bid/ask if present.
        Spread_bps = (ask - bid) / mid * 10_000
        Returns None if not enough data.
        """
        bid = t.get("bid")
        ask = t.get("ask")
        
        # Try info dict if bid/ask not at root
        if bid is None or ask is None:
            info = t.get("info") or {}
            bid = info.get("bid") if bid is None else bid
            ask = info.get("ask") if ask is None else ask
        
        bidf = self._f(bid, 0.0)
        askf = self._f(ask, 0.0)
        
        if not (self._is_finite(bidf) and self._is_finite(askf)):
            return None
        if bidf <= 0 or askf <= 0 or askf < bidf:
            return None
        
        mid = (askf + bidf) / 2.0
        if mid <= 0:
            return None
        
        return float((askf - bidf) / mid * 10_000.0)
    
    def _calculate_orderbook_metrics(self, symbol: str) -> Optional[Dict[str, float]]:
        """
        Calculate orderbook-based liquidity metrics.
        Returns dict with spread_bps, bid_depth, ask_depth, or None if unavailable.
        """
        try:
            # Try cache first
            cached = self._get_cached_orderbook(symbol)
            if cached:
                orderbook = cached
            else:
                # Fetch with depth (level 2 is usually sufficient)
                orderbook = self.exchange.fetch_order_book(symbol, limit=20)
                self._set_cached_orderbook(symbol, orderbook)
            
            bids = orderbook.get("bids", [])
            asks = orderbook.get("asks", [])
            
            if not bids or not asks:
                return None
            
            best_bid = float(bids[0][0]) if bids[0] else 0.0
            best_ask = float(asks[0][0]) if asks[0] else 0.0
            
            if best_bid <= 0 or best_ask <= 0 or best_ask <= best_bid:
                return None
            
            # Calculate spread
            mid = (best_bid + best_ask) / 2.0
            spread_bps = ((best_ask - best_bid) / mid) * 10000.0
            
            # Calculate depth (sum of volume in first 5 levels)
            bid_depth = sum(float(bid[1]) for bid in bids[:5])
            ask_depth = sum(float(ask[1]) for ask in asks[:5])
            
            return {
                "spread_bps": spread_bps,
                "bid_depth": bid_depth,
                "ask_depth": ask_depth,
                "depth_imbalance": abs(bid_depth - ask_depth) / max(bid_depth, ask_depth) if max(bid_depth, ask_depth) > 0 else 0.0,
            }
        except Exception as e:
            self._log("debug", f"Orderbook fetch failed for {symbol}: {e}")
            return None
    
    def _is_leveraged_token(self, symbol: str) -> bool:
        """Check if symbol is a leveraged token."""
        s = symbol.upper()
        
        # Common leveraged token suffixes/patterns
        leveraged_patterns = [
            "UP/USDT", "DOWN/USDT", "BULL/USDT", "BEAR/USDT",
            "UP:USDT", "DOWN:USDT", "BULL:USDT", "BEAR:USDT",
            "3L/USDT", "3S/USDT", "3L:USDT", "3S:USDT",
        ]
        
        for pattern in leveraged_patterns:
            if pattern in s:
                return True
        
        # Also match "ETHUP/USDT" style
        for suffix in ["UP", "DOWN", "BULL", "BEAR", "3L", "3S"]:
            if s.endswith(f"{suffix}/USDT") or s.endswith(f"{suffix}:USDT"):
                return True
        
        # Check in market info if available
        market = self._get_market_info(symbol)
        if market:
            if market.get("leveraged"):
                return True
            # Check symbol name for leveraged keywords
            symbol_lower = market.get("symbol", "").lower()
            leveraged_keywords = ["leveraged", "bull", "bear", "long", "short", "3x", "5x"]
            if any(keyword in symbol_lower for keyword in leveraged_keywords):
                return True
        
        return False
    
    def _is_stable_stable(self, symbol: str) -> bool:
        """Check if symbol is stablecoin-to-stablecoin pair."""
        s = symbol.upper()
        stables = {"USDT", "USDC", "BUSD", "DAI", "TUSD", "FDUSD", "EUR", "USD", "GBP", "AUD"}
        
        # Parse symbol format
        if "/" in s:
            base, quote = s.split("/", 1)
        elif ":" in s:
            # Futures format like BTC/USDT:USDT
            if "/" in s:
                base_part = s.split(":")[0]
                base = base_part.split("/")[0] if "/" in base_part else base_part
                quote = s.split(":")[1]
            else:
                return False
        else:
            return False
        
        return base in stables and quote in stables
    
    def _symbol_root(self, symbol: str) -> str:
        """Extract root asset from symbol."""
        s = symbol.upper()
        
        if "/USDT" in s:
            return s.split("/USDT")[0]
        if ":USDT" in s:
            left = s.split(":USDT")[0]
            if "/USDT" in left:
                return left.split("/USDT")[0]
            if "/" in left:
                return left.split("/")[0]
            return left
        
        # Generic split
        if "/" in s:
            return s.split("/")[0]
        if ":" in s:
            return s.split(":")[0]
        
        return s
    
    def _is_futures_symbol(self, symbol: str) -> bool:
        """Check if symbol is a futures contract."""
        s = symbol.upper()
        return ":USDT" in s or "PERP" in s or "-PERP" in s or s.endswith("_PERP")
    
    def _get_market_info(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get market info with caching."""
        with self._cache_lock:
            if symbol in self._market_cache:
                return self._market_cache[symbol]
        
        try:
            markets = getattr(self.exchange, "markets", {})
            market = markets.get(symbol)
            if market:
                with self._cache_lock:
                    self._market_cache[symbol] = market
            return market
        except Exception:
            return None
    
    def _chunked(self, lst: List[str], n: int) -> List[List[str]]:
        """Split list into chunks of size n."""
        return [lst[i:i + n] for i in range(0, len(lst), n)]
    
    def _fetch_tickers_batch(self, symbols: List[str]) -> Dict[str, Any]:
        """Fetch tickers in batches with error handling."""
        tickers = {}
        
        # Try bulk fetch first
        try:
            bulk_tickers = self.exchange.fetch_tickers(symbols)
            if isinstance(bulk_tickers, dict):
                tickers.update(bulk_tickers)
                return tickers
        except Exception as e:
            self._log("debug", f"Bulk ticker fetch failed: {e}")
        
        # Fallback to smaller batches
        batch_size = 50
        for chunk in self._chunked(symbols, batch_size):
            try:
                chunk_tickers = self.exchange.fetch_tickers(chunk)
                if isinstance(chunk_tickers, dict):
                    tickers.update(chunk_tickers)
            except Exception as e:
                self._log("debug", f"Chunk ticker fetch failed: {e}")
                # Try even smaller chunks
                for sym in chunk:
                    try:
                        single_ticker = self.exchange.fetch_ticker(sym)
                        if single_ticker:
                            tickers[sym] = single_ticker
                    except Exception:
                        continue
        
        return tickers
    
    def _rank_values(self, values: List[float], reverse: bool = True) -> Dict[float, float]:
        """
        Rank values and return normalized scores [0, 1].
        Higher score is better.
        """
        if not values:
            return {}
        
        # Remove NaN/Inf values
        valid_values = [v for v in values if self._is_finite(v)]
        if not valid_values:
            return {}
        
        # Sort and rank
        unique_values = sorted(set(valid_values), reverse=reverse)
        if len(unique_values) == 1:
            return {unique_values[0]: 1.0}
        
        rank_map = {}
        for i, val in enumerate(unique_values):
            # Normalize rank to [0, 1] where best gets 1.0
            rank_map[val] = 1.0 - (i / (len(unique_values) - 1))
        
        return rank_map
    
    def scan_markets(self, **kwargs) -> Tuple[List[str], List[SymbolScore], ScanMetrics]:
        """
        Advanced market scanning with comprehensive filtering and scoring.
        
        Args:
            See find_best_pairs for full parameter list
        
        Returns:
            Tuple of (selected_symbols, detailed_scores, metrics)
        """
        start_time = time.time()
        self.scan_count += 1
        
        # Extract parameters with defaults
        limit = int(kwargs.get("limit", 5))
        min_volume = float(kwargs.get("min_volume", 1_000_000.0))
        prefer_futures = bool(kwargs.get("prefer_futures", False))
        max_symbols_scan = int(kwargs.get("max_symbols_scan", 800))
        exclude_leveraged_tokens = bool(kwargs.get("exclude_leveraged_tokens", True))
        exclude_stable_pairs = bool(kwargs.get("exclude_stable_pairs", True))
        ensure_diversity = bool(kwargs.get("ensure_diversity", True))
        max_per_root = int(kwargs.get("max_per_root", 1))
        min_spread_bps = float(kwargs.get("min_spread_bps", 0.0))
        max_spread_bps = float(kwargs.get("max_spread_bps", 120.0))
        min_price = float(kwargs.get("min_price", 0.0))
        max_price = float(kwargs.get("max_price", float("inf")))
        min_volatility = float(kwargs.get("min_volatility", 0.0))
        max_volatility = float(kwargs.get("max_volatility", 100.0))
        use_orderbook = bool(kwargs.get("use_orderbook", False))
        orderbook_depth_threshold = float(kwargs.get("orderbook_depth_threshold", 0.0))
        
        weights = kwargs.get("weights", {})
        exclude_symbols = set(s.upper() for s in kwargs.get("exclude_symbols", []))
        include_symbols = set(s.upper() for s in kwargs.get("include_symbols", []))
        quote_currencies = kwargs.get("quote_currencies", ["USDT"])
        
        # Merge weights with defaults
        final_weights = self.default_weights.copy()
        for k, v in weights.items():
            if k in final_weights:
                final_weights[k] = float(v)
        
        # Load markets
        try:
            self.exchange.load_markets()
        except Exception as e:
            self._log("warning", f"Failed to load markets: {e}")
        
        all_symbols = getattr(self.exchange, "symbols", [])
        markets = getattr(self.exchange, "markets", {})
        
        # Filter candidate symbols
        candidate_symbols = []
        for symbol in all_symbols:
            symbol_upper = symbol.upper()
            
            # Check if symbol matches any quote currency
            matches_quote = False
            for quote in quote_currencies:
                if f"/{quote}" in symbol_upper or f":{quote}" in symbol_upper:
                    matches_quote = True
                    break
            
            if not matches_quote:
                continue
            
            # Check market activity
            market = markets.get(symbol, {})
            if not market.get("active", True):
                continue
            
            # Apply filters
            if symbol_upper in exclude_symbols:
                continue
            if include_symbols and symbol_upper not in include_symbols:
                continue
            
            if prefer_futures and not self._is_futures_symbol(symbol):
                continue
            
            if exclude_leveraged_tokens and self._is_leveraged_token(symbol):
                self.metrics.excluded_by_leveraged += 1
                continue
            
            if exclude_stable_pairs and self._is_stable_stable(symbol):
                self.metrics.excluded_by_stable += 1
                continue
            
            candidate_symbols.append(symbol)
        
        self.metrics.scanned_symbols = len(candidate_symbols)
        
        # Limit scan size
        if len(candidate_symbols) > max_symbols_scan:
            candidate_symbols = candidate_symbols[:max_symbols_scan]
        
        # Fetch tickers
        tickers = self._fetch_tickers_batch(candidate_symbols)
        
        # Process each symbol
        scored_symbols = []
        for symbol in candidate_symbols:
            # Try cache first
            cached_ticker = self._get_cached_ticker(symbol)
            if cached_ticker:
                ticker = cached_ticker
            else:
                ticker = tickers.get(symbol, {})
                if ticker:
                    self._set_cached_ticker(symbol, ticker)
            
            # Extract metrics
            quote_volume = self._extract_quote_volume(ticker)
            abs_pct_change = self._safe_abs_pct_change(ticker)
            spread_bps = self._estimate_spread_bps(ticker)
            price = self._extract_price(ticker)
            
            # Volume filter
            if quote_volume < min_volume:
                self.metrics.excluded_by_volume += 1
                continue
            
            # Price filter
            if price < min_price or price > max_price:
                self.metrics.excluded_by_price += 1
                continue
            
            # Volatility filter
            if abs_pct_change < min_volatility or abs_pct_change > max_volatility:
                self.metrics.excluded_by_volatility += 1
                continue
            
            # Spread filter
            if spread_bps is not None:
                if spread_bps < min_spread_bps or spread_bps > max_spread_bps:
                    self.metrics.excluded_by_spread += 1
                    continue
            
            # Orderbook filter (optional)
            liquidity_score = 0.5  # Default neutral score
            if use_orderbook:
                ob_metrics = self._calculate_orderbook_metrics(symbol)
                if ob_metrics:
                    # Check depth threshold
                    min_depth = min(ob_metrics["bid_depth"], ob_metrics["ask_depth"])
                    if min_depth < orderbook_depth_threshold:
                        self.metrics.excluded_by_orderbook += 1
                        continue
                    
                    # Calculate liquidity score based on depth and spread
                    depth_score = min(1.0, min_depth / (orderbook_depth_threshold * 10) if orderbook_depth_threshold > 0 else 0.5)
                    spread_score = 1.0 - min(1.0, ob_metrics["spread_bps"] / 100.0) if ob_metrics["spread_bps"] else 0.5
                    liquidity_score = (depth_score + spread_score) / 2.0
                else:
                    # If orderbook fetch failed, use neutral score
                    liquidity_score = 0.5
            
            # Create score object
            symbol_score = SymbolScore(
                symbol=symbol,
                quote_volume=quote_volume,
                abs_pct_change=abs_pct_change,
                spread_bps=spread_bps,
                score=0.0,  # Will be calculated later
                liquidity_score=liquidity_score,
                root_asset=self._symbol_root(symbol),
                is_futures=self._is_futures_symbol(symbol),
                price=price
            )
            
            scored_symbols.append(symbol_score)
        
        self.metrics.candidates_found = len(scored_symbols)
        
        if not scored_symbols:
            # Fallback to major symbols
            major_symbols = []
            for quote in quote_currencies:
                for major in ["BTC", "ETH", "BNB", "SOL", "XRP"]:
                    symbol = f"{major}/{quote}"
                    if symbol in all_symbols:
                        major_symbols.append(symbol)
                        if len(major_symbols) >= limit:
                            break
                if major_symbols:
                    break
            
            # Create dummy scores for major symbols
            dummy_scores = []
            for symbol in major_symbols:
                dummy_scores.append(SymbolScore(
                    symbol=symbol,
                    quote_volume=10_000_000.0,
                    abs_pct_change=1.0,
                    spread_bps=10.0,
                    score=1.0,
                    final_score=1.0
                ))
            
            self.metrics.execution_time_ms = (time.time() - start_time) * 1000.0
            return major_symbols[:limit], dummy_scores, self.metrics
        
        # Calculate ranking scores
        volumes = [s.quote_volume for s in scored_symbols]
        volatilities = [s.abs_pct_change for s in scored_symbols]
        spreads = [s.spread_bps for s in scored_symbols if s.spread_bps is not None]
        
        volume_rank = self._rank_values(volumes, reverse=True)
        volatility_rank = self._rank_values(volatilities, reverse=True)
        spread_rank = self._rank_values(spreads, reverse=False) if spreads else {}
        
        # Apply scores
        for symbol_score in scored_symbols:
            vol_score = volume_rank.get(symbol_score.quote_volume, 0.0)
            vol_score = vol_score if self._is_finite(vol_score) else 0.0
            
            vola_score = volatility_rank.get(symbol_score.abs_pct_change, 0.0)
            vola_score = vola_score if self._is_finite(vola_score) else 0.0
            
            spread_score = 0.5  # Default for unknown spread
            if symbol_score.spread_bps is not None:
                spread_score = spread_rank.get(symbol_score.spread_bps, 0.5)
                spread_score = spread_score if self._is_finite(spread_score) else 0.5
            
            # Calculate final score with weights
            final_score = (
                final_weights["volume"] * vol_score +
                final_weights["volatility"] * vola_score +
                final_weights["spread"] * spread_score +
                final_weights["liquidity"] * symbol_score.liquidity_score
            )
            
            symbol_score.volume_score = vol_score
            symbol_score.volatility_score = vola_score
            symbol_score.spread_score = spread_score
            symbol_score.final_score = final_score
        
        # Sort by final score
        scored_symbols.sort(key=lambda x: x.final_score, reverse=True)
        
        # Apply diversity filter
        selected_symbols = []
        selected_scores = []
        root_counts = defaultdict(int)
        
        for symbol_score in scored_symbols:
            if ensure_diversity:
                root = symbol_score.root_asset
                if root_counts.get(root, 0) >= max_per_root:
                    continue
                root_counts[root] += 1
            
            selected_symbols.append(symbol_score.symbol)
            selected_scores.append(symbol_score)
            
            if len(selected_symbols) >= limit:
                break
        
        # Calculate volume and volatility ranks
        for i, symbol_score in enumerate(selected_scores):
            symbol_score.volume_rank = i + 1
            symbol_score.volatility_rank = i + 1
        
        self.metrics.execution_time_ms = (time.time() - start_time) * 1000.0
        
        return selected_symbols[:limit], selected_scores[:limit], self.metrics
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of scanner metrics."""
        return {
            "total_scans": self.scan_count,
            "current_metrics": {
                "scanned_symbols": self.metrics.scanned_symbols,
                "candidates_found": self.metrics.candidates_found,
                "cache_hits": self.metrics.cache_hits,
                "cache_misses": self.metrics.cache_misses,
                "cache_hit_rate": self.metrics.cache_hits / max(1, self.metrics.cache_hits + self.metrics.cache_misses),
            },
            "exclusion_counts": {
                "volume": self.metrics.excluded_by_volume,
                "spread": self.metrics.excluded_by_spread,
                "stable_pairs": self.metrics.excluded_by_stable,
                "leveraged_tokens": self.metrics.excluded_by_leveraged,
                "volatility": self.metrics.excluded_by_volatility,
                "price": self.metrics.excluded_by_price,
                "orderbook": self.metrics.excluded_by_orderbook,
            }
        }
    
    def clear_cache(self, cache_type: Optional[str] = None) -> None:
        """Clear scanner cache."""
        with self._cache_lock:
            if cache_type is None or cache_type == "ticker":
                self._ticker_cache.clear()
            if cache_type is None or cache_type == "orderbook":
                self._orderbook_cache.clear()
            if cache_type is None or cache_type == "markets":
                self._market_cache.clear()


# Backward compatibility function
def find_best_pairs(
    exchange,
    limit: int = 5,
    min_volume: float = 1_000_000.0,
    *,
    prefer_futures: bool = False,
    max_symbols_scan: int = 800,
    exclude_leveraged_tokens: bool = True,
    exclude_stable_pairs: bool = True,
    ensure_diversity: bool = True,
    max_per_root: int = 1,
    min_spread_bps: float = 0.0,
    max_spread_bps: float = 120.0,
    weights: Optional[Dict[str, float]] = None,
    exclude_symbols: Optional[List[str]] = None,
    include_symbols: Optional[List[str]] = None,
    return_debug: bool = False,
    **kwargs  # Accept additional parameters for compatibility
) -> List[str] | Dict[str, Any]:
    """
    Improved V8 market scanner (CCXT exchange instance).
    
    Filters:
      - USDT-quoted symbols (/USDT) or futures-style (:USDT)
      - active markets only (best-effort)
      - exclude leveraged tokens (optional)
      - exclude stable-stable pairs (optional)
      - quoteVolume >= min_volume (best-effort)
      - spread filter (best-effort)
    
    Ranking:
      - by composite score from volume rank, abs(% change), and spread quality
    
    Returns:
      - list of symbols (or debug dict if return_debug=True)
    """
    # Create scanner instance
    scanner = MarketScanner(exchange)
    
    # Prepare parameters
    scan_params = {
        "limit": limit,
        "min_volume": min_volume,
        "prefer_futures": prefer_futures,
        "max_symbols_scan": max_symbols_scan,
        "exclude_leveraged_tokens": exclude_leveraged_tokens,
        "exclude_stable_pairs": exclude_stable_pairs,
        "ensure_diversity": ensure_diversity,
        "max_per_root": max_per_root,
        "min_spread_bps": min_spread_bps,
        "max_spread_bps": max_spread_bps,
        "weights": weights or {},
        "exclude_symbols": exclude_symbols or [],
        "include_symbols": include_symbols or [],
    }
    
    # Add any extra kwargs
    scan_params.update(kwargs)
    
    # Run scan
    selected_symbols, detailed_scores, metrics = scanner.scan_markets(**scan_params)
    
    if not return_debug:
        return selected_symbols
    
    # Prepare debug information
    debug_info = {
        "symbols": selected_symbols,
        "rows": [
            {
                "symbol": score.symbol,
                "quote_volume": score.quote_volume,
                "abs_pct_change": score.abs_pct_change,
                "spread_bps": score.spread_bps,
                "score": score.final_score,
                "volume_score": score.volume_score,
                "volatility_score": score.volatility_score,
                "spread_score": score.spread_score,
                "liquidity_score": score.liquidity_score,
                "root_asset": score.root_asset,
                "is_futures": score.is_futures,
                "price": score.price,
            }
            for score in detailed_scores
        ],
        "scanned": metrics.scanned_symbols,
        "candidates": metrics.candidates_found,
        "weights": scanner.default_weights,
        "elapsed_ms": metrics.execution_time_ms,
        "filters": {
            "min_volume": float(min_volume),
            "prefer_futures": bool(prefer_futures),
            "exclude_leveraged_tokens": bool(exclude_leveraged_tokens),
            "exclude_stable_pairs": bool(exclude_stable_pairs),
            "ensure_diversity": bool(ensure_diversity),
            "max_per_root": int(max_per_root),
            "min_spread_bps": float(min_spread_bps),
            "max_spread_bps": float(max_spread_bps),
        },
        "metrics": scanner.get_metrics_summary(),
    }
    
    return debug_info


# Additional utility functions for backward compatibility
def _f(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return float(default)
        return float(x)
    except Exception:
        return float(default)


def _is_finite(x: float) -> bool:
    return (x == x) and (x not in (float("inf"), float("-inf")))


def _safe_abs_pct_change(t: Dict[str, Any]) -> float:
    """
    Best-effort: many exchanges provide `percentage` (24h %). Some provide `change` or `info`.
    Returns absolute percentage (0..inf).
    """
    chg = t.get("percentage")
    if chg is None:
        chg = t.get("change")
    v = _f(chg, 0.0)
    return abs(v) if _is_finite(v) else 0.0


def _extract_quote_volume(t: Dict[str, Any]) -> float:
    """
    Best-effort quote volume:
      - `quoteVolume` is ideal
      - some give `baseVolume` and we can approximate using `last`
    """
    qv = t.get("quoteVolume")
    if qv is not None:
        v = _f(qv, 0.0)
        return v if _is_finite(v) else 0.0

    bv = t.get("baseVolume")
    last = t.get("last")
    bvf = _f(bv, 0.0)
    lastf = _f(last, 0.0)
    if _is_finite(bvf) and _is_finite(lastf) and bvf > 0 and lastf > 0:
        return bvf * lastf

    # sometimes in `info`
    info = t.get("info") or {}
    for k in ("quoteVolume", "quote_volume", "turnover", "turnover24h", "volumeQuote"):
        if k in info:
            v = _f(info.get(k), 0.0)
            if _is_finite(v):
                return v
    return 0.0


def _estimate_spread_bps(t: Dict[str, Any]) -> Optional[float]:
    """
    Estimate spread in basis points using bid/ask if present.
    Spread_bps = (ask - bid) / mid * 10_000
    Returns None if not enough data.
    """
    bid = t.get("bid")
    ask = t.get("ask")
    if bid is None or ask is None:
        # some put in info
        info = t.get("info") or {}
        bid = info.get("bid") if bid is None else bid
        ask = info.get("ask") if ask is None else ask

    bidf = _f(bid, 0.0)
    askf = _f(ask, 0.0)
    if not (_is_finite(bidf) and _is_finite(askf)):
        return None
    if bidf <= 0 or askf <= 0 or askf < bidf:
        return None
    mid = (askf + bidf) / 2.0
    if mid <= 0:
        return None
    return float((askf - bidf) / mid * 10_000.0)


def _is_leveraged_token(symbol: str) -> bool:
    s = symbol.upper()
    # common leveraged token suffixes/patterns
    bad = ("UP/USDT", "DOWN/USDT", "BULL/USDT", "BEAR/USDT", "UP:USDT", "DOWN:USDT", "BULL:USDT", "BEAR:USDT")
    if any(x in s for x in bad):
        return True
    # also match "ETHUP/USDT" style
    if s.endswith(("UP/USDT", "DOWN/USDT", "BULL/USDT", "BEAR/USDT")):
        return True
    return False


def _is_stable_stable(symbol: str) -> bool:
    # Exclude USDC/USDT, BUSD/USDT etc.
    s = symbol.upper()
    stables = ("USDT", "USDC", "BUSD", "DAI", "TUSD", "FDUSD", "EUR", "USD")
    # quick check for "/USDT" quoted and base stable
    if "/USDT" in s:
        base = s.split("/USDT")[0]
        return base in stables
    if ":USDT" in s:
        base = s.split(":USDT")[0]
        # futures might be like BTC/USDT:USDT; keep BTC
        base = base.split("/")[0]
        return base in stables
    return False


def _symbol_root(symbol: str) -> str:
    # Root asset for diversity: "BTC" from "BTC/USDT" or "BTC/USDT:USDT"
    s = symbol.upper()
    if "/USDT" in s:
        return s.split("/USDT")[0]
    if ":USDT" in s:
        left = s.split(":USDT")[0]
        if "/USDT" in left:
            return left.split("/USDT")[0]
        if "/" in left:
            return left.split("/")[0]
        return left
    # fallback
    return s.split("/")[0]


def _chunked(lst: List[str], n: int) -> List[List[str]]:
    return [lst[i : i + n] for i in range(0, len(lst), n)]
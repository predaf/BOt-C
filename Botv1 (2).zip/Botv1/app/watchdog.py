from __future__ import annotations
import time
from typing import Any
try:
    import ccxt  # type: ignore
except Exception:  # pragma: no cover
    ccxt = None  # type: ignore

class ErrorWatchdog:
    def __init__(self, cfg: dict, log: Any):
        self.cfg = cfg
        self.log = log
        self.enabled = bool(cfg.get("watchdog", {}).get("enabled", True))
        self.consecutive = 0
        self.pause_until = 0.0
        self.pause_level = 0

    def is_paused(self) -> bool:
        return self.enabled and time.time() < self.pause_until

    def seconds_left(self) -> int:
        return max(0, int(self.pause_until - time.time())) if self.is_paused() else 0

    def record_success(self) -> None:
        if self.consecutive > 0:
            self.consecutive = 0
            self.pause_level = max(0, self.pause_level - 1)

    def _watchworthy(self, e: BaseException) -> bool:
        watch_types = (
            getattr(ccxt, "NetworkError", Exception),
            getattr(ccxt, "DDoSProtection", Exception),
            getattr(ccxt, "RateLimitExceeded", Exception),
            getattr(ccxt, "RequestTimeout", Exception),
            getattr(ccxt, "ExchangeNotAvailable", Exception),
        )
        return isinstance(e, watch_types)

    def record_error(self, e: BaseException) -> None:
        if not self.enabled or (not self._watchworthy(e)):
            return
        self.consecutive += 1
        mx = int(self.cfg["watchdog"]["max_consecutive_errors"])
        if self.consecutive >= mx:
            base = float(self.cfg["watchdog"]["pause_sec"])
            backoff = float(self.cfg["watchdog"]["backoff_factor"])
            cap = float(self.cfg["watchdog"]["max_pause_sec"])
            self.pause_level += 1
            pause = min(cap, base * (backoff ** max(0, self.pause_level - 1)))
            self.pause_until = time.time() + pause
            self.log.warn(f"WATCHDOG: Pausing NEW trading actions for {int(pause)}s after {mx} consecutive API errors. (level={self.pause_level})")
            self.consecutive = 0

    def force_resume(self) -> None:
        self.pause_until = 0.0
        self.consecutive = 0
        self.log.info("WATCHDOG: Manual resume executed.")

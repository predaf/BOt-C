# test_risk_advisor.py
import math
import statistics
from typing import List, Dict, Any
import pytest
import numpy as np

from risk_advisor import (
    RiskAdvisor,
    _f, _clamp, _isfinite, _norm_ppf, _quantile, _merge_returns_from_positions
)


# Test helper functions
def test_f():
    """Test safe float conversion."""
    assert _f("3.14") == 3.14
    assert _f(42) == 42.0
    assert _f(None) == 0.0
    assert _f("invalid", default=1.0) == 1.0
    assert _f(float('nan'), default=0.0) == 0.0
    assert _f(float('inf'), default=0.0) == 0.0
    assert _f(None, default=5.0) == 5.0


def test_clamp():
    """Test clamping function."""
    assert _clamp(1.5, 0.0, 1.0) == 1.0
    assert _clamp(-0.5, 0.0, 1.0) == 0.0
    assert _clamp(0.3, 0.0, 1.0) == 0.3
    assert _clamp(100.0, 0.0, 1.0) == 1.0
    assert _clamp(-100.0, 0.0, 1.0) == 0.0
    
    # Test with equal bounds
    assert _clamp(5.0, 5.0, 5.0) == 5.0
    assert _clamp(10.0, 5.0, 5.0) == 5.0


def test_isfinite():
    """Test finite number check."""
    assert _isfinite(3.14) is True
    assert _isfinite(-100.0) is True
    assert _isfinite(0.0) is True
    assert _isfinite(float('nan')) is False
    assert _isfinite(float('inf')) is False
    assert _isfinite(float('-inf')) is False


def test_norm_ppf():
    """Test normal distribution percent point function approximation."""
    # Test extreme values
    assert _norm_ppf(0.0) == float('-inf')
    assert _norm_ppf(1.0) == float('inf')
    
    # Test symmetric property
    for p in [0.1, 0.2, 0.3, 0.4]:
        assert abs(_norm_ppf(p) + _norm_ppf(1 - p)) < 0.01
    
    # Test known values (approximate)
    assert abs(_norm_ppf(0.5) - 0.0) < 0.001
    assert abs(_norm_ppf(0.9) - 1.2816) < 0.01
    assert abs(_norm_ppf(0.95) - 1.6449) < 0.01
    assert abs(_norm_ppf(0.975) - 1.96) < 0.02
    assert abs(_norm_ppf(0.99) - 2.3263) < 0.02
    
    # Test bounds
    assert _norm_ppf(0.02425) < -2.0  # Should be below -2
    assert _norm_ppf(0.97575) > 2.0   # Should be above 2
    
    # Test with scipy if available (for comparison)
    try:
        import scipy.stats as stats
        test_points = [0.01, 0.05, 0.1, 0.3, 0.5, 0.7, 0.9, 0.95, 0.99]
        for p in test_points:
            approx = _norm_ppf(p)
            exact = stats.norm.ppf(p)
            # Our approximation should be close to scipy's implementation
            assert abs(approx - exact) < 0.01, f"Failed for p={p}: approx={approx}, exact={exact}"
    except ImportError:
        pass  # scipy not available, skip comparison


def test_quantile():
    """Test quantile calculation with linear interpolation."""
    # Test with empty list
    assert _quantile([], 0.5) == 0.0
    
    # Test with single element
    assert _quantile([5.0], 0.5) == 5.0
    assert _quantile([5.0], 0.1) == 5.0
    assert _quantile([5.0], 0.9) == 5.0
    
    # Test with two elements
    xs = [1.0, 3.0]
    assert _quantile(xs, 0.0) == 1.0
    assert _quantile(xs, 1.0) == 3.0
    assert _quantile(xs, 0.5) == 2.0  # Average of 1 and 3
    
    # Test with multiple elements
    xs = [1.0, 2.0, 3.0, 4.0, 5.0]
    assert _quantile(xs, 0.0) == 1.0
    assert _quantile(xs, 0.25) == 2.0  # 25th percentile
    assert _quantile(xs, 0.5) == 3.0   # Median
    assert _quantile(xs, 0.75) == 4.0  # 75th percentile
    assert _quantile(xs, 1.0) == 5.0
    
    # Test with non-sorted list
    xs = [5.0, 1.0, 3.0, 4.0, 2.0]
    assert _quantile(xs, 0.5) == 3.0  # Should sort internally
    
    # Test with NaN/infinite values (should be filtered)
    xs = [1.0, float('nan'), 2.0, float('inf'), 3.0, float('-inf'), 4.0]
    assert _quantile(xs, 0.5) == 2.5  # Average of 2.0 and 3.0
    
    # Test edge cases
    assert _quantile(xs, -0.1) == 1.0  # Clamped to 0.0
    assert _quantile(xs, 1.1) == 4.0   # Clamped to 1.0


def test_merge_returns_from_positions():
    """Test merging returns from position data."""
    # Test empty positions
    assert _merge_returns_from_positions([]) == []
    assert _merge_returns_from_positions(None) == []
    
    # Test with returns field
    positions = [
        {"returns": [0.01, -0.02, 0.03]},
        {"returns": [-0.01, 0.005]}
    ]
    merged = _merge_returns_from_positions(positions)
    assert len(merged) == 5
    assert 0.01 in merged
    assert -0.02 in merged
    assert 0.03 in merged
    assert -0.01 in merged
    assert 0.005 in merged
    
    # Test with pnl_series and equity
    positions2 = [
        {"pnl_series": [10.0, -20.0, 30.0], "equity": 1000.0},
        {"pnl_series": [-10.0, 5.0], "equity": 500.0}
    ]
    merged2 = _merge_returns_from_positions(positions2)
    assert len(merged2) == 5
    assert 0.01 in merged2  # 10/1000
    assert -0.02 in merged2  # -20/1000
    assert 0.03 in merged2  # 30/1000
    assert -0.02 in merged2  # -10/500
    assert 0.01 in merged2  # 5/500
    
    # Test mixed positions
    positions3 = [
        {"returns": [0.01, -0.02]},
        {"pnl_series": [30.0], "equity": 1000.0},
        {"some_other_field": [1, 2, 3]},  # Should be ignored
        "not_a_dict",  # Should be ignored
        None  # Should be ignored
    ]
    merged3 = _merge_returns_from_positions(positions3)
    assert len(merged3) == 3
    assert 0.01 in merged3
    assert -0.02 in merged3
    assert 0.03 in merged3  # 30/1000
    
    # Test with non-finite values (should be filtered)
    positions4 = [
        {"returns": [0.01, float('nan'), float('inf'), -0.02]},
        {"pnl_series": [float('-inf'), 10.0], "equity": 1000.0}
    ]
    merged4 = _merge_returns_from_positions(positions4)
    assert len(merged4) == 2  # Only 0.01, -0.02, and 0.01 (10/1000)
    assert 0.01 in merged4
    assert -0.02 in merged4


class TestRiskAdvisor:
    """Test the RiskAdvisor class."""
    
    @pytest.fixture
    def advisor(self):
        return RiskAdvisor()
    
    @pytest.fixture
    def sample_trades(self):
        """Sample trade returns for testing."""
        return [0.02, -0.01, 0.03, -0.005, 0.015, -0.02, 0.01, 0.005]
    
    @pytest.fixture
    def sample_positions(self):
        """Sample position data for VaR/CVaR testing."""
        return [
            {"returns": [0.01, -0.02, 0.015, -0.01, 0.005]},
            {"returns": [-0.015, 0.02, -0.005, 0.01, -0.03]},
            {"pnl_series": [50.0, -100.0, 75.0], "equity": 5000.0}
        ]
    
    def test_calculate_kelly_criterion_basic(self, advisor):
        """Test basic Kelly criterion calculation."""
        # Positive edge
        f = advisor.calculate_kelly_criterion(
            win_rate=0.6,  # 60% win rate
            avg_win=0.02,  # 2% average win
            avg_loss=0.01,  # 1% average loss
            kelly_fraction=1.0,
            cap=1.0
        )
        
        # Manual calculation:
        # b = avg_win / avg_loss = 2
        # f* = (0.6*(2+1) - 1) / 2 = (0.6*3 - 1)/2 = (1.8 - 1)/2 = 0.8/2 = 0.4
        assert abs(f - 0.4) < 0.001
        
        # Test with fractional Kelly (half-Kelly)
        f_half = advisor.calculate_kelly_criterion(
            win_rate=0.6,
            avg_win=0.02,
            avg_loss=0.01,
            kelly_fraction=0.5,  # Half Kelly
            cap=1.0
        )
        assert abs(f_half - 0.2) < 0.001  # 0.4 * 0.5 = 0.2
        
        # Test with cap
        f_capped = advisor.calculate_kelly_criterion(
            win_rate=0.6,
            avg_win=0.02,
            avg_loss=0.01,
            kelly_fraction=1.0,
            cap=0.3  # Cap at 30%
        )
        assert abs(f_capped - 0.3) < 0.001  # Should be capped at 0.3
    
    def test_calculate_kelly_criterion_edge_cases(self, advisor):
        """Test Kelly criterion with edge cases."""
        # No edge (win rate too low)
        f_no_edge = advisor.calculate_kelly_criterion(
            win_rate=0.3,  # Low win rate
            avg_win=0.02,
            avg_loss=0.01
        )
        # b = 2, f* = (0.3*3 - 1)/2 = (0.9 - 1)/2 = -0.1/2 = -0.05 -> clamped to 0
        assert abs(f_no_edge - 0.0) < 0.001
        
        # Perfect win rate
        f_perfect = advisor.calculate_kelly_criterion(
            win_rate=1.0,
            avg_win=0.02,
            avg_loss=0.01
        )
        # b = 2, f* = (1.0*3 - 1)/2 = (3-1)/2 = 2/2 = 1.0
        assert abs(f_perfect - 1.0) < 0.001
        
        # Zero avg_win
        f_zero_win = advisor.calculate_kelly_criterion(
            win_rate=0.6,
            avg_win=0.0,
            avg_loss=0.01
        )
        assert abs(f_zero_win - 0.0) < 0.001
        
        # Zero avg_loss (should be protected by max(1e-12, ...))
        f_zero_loss = advisor.calculate_kelly_criterion(
            win_rate=0.6,
            avg_win=0.02,
            avg_loss=0.0
        )
        # Should handle division by zero gracefully
        
        # Test with invalid inputs
        f_invalid = advisor.calculate_kelly_criterion(
            win_rate="invalid",
            avg_win=None,
            avg_loss="also invalid"
        )
        # Should return 0.0 due to default values
        assert abs(f_invalid - 0.0) < 0.001
    
    def test_calculate_optimal_f_basic(self, advisor, sample_trades):
        """Test optimal-f calculation."""
        f = advisor.calculate_optimal_f(
            trades_series=sample_trades,
            f_min=0.01,
            f_max=0.5,
            steps=60,
            refine_rounds=2,
            refine_steps=25
        )
        
        # f should be between 0 and 1
        assert 0.0 <= f <= 1.0
        # With sample trades, optimal f should be > 0
        assert f > 0.0
        
        # Test with different parameters
        f2 = advisor.calculate_optimal_f(
            trades_series=sample_trades,
            f_min=0.0,
            f_max=1.0,
            steps=100
        )
        assert 0.0 <= f2 <= 1.0
    
    def test_calculate_optimal_f_edge_cases(self, advisor):
        """Test optimal-f with edge cases."""
        # Empty trades series
        f_empty = advisor.calculate_optimal_f([])
        assert f_empty == 0.0
        
        # All zero returns
        f_zeros = advisor.calculate_optimal_f([0.0, 0.0, 0.0, 0.0])
        assert f_zeros == 0.0
        
        # All positive returns (no risk)
        f_all_positive = advisor.calculate_optimal_f([0.01, 0.02, 0.005])
        # With all positive returns, optimal f would be at max (but bounded)
        assert f_all_positive > 0.0
        
        # All negative returns (always losing)
        f_all_negative = advisor.calculate_optimal_f([-0.01, -0.02, -0.005])
        # With all negative returns, optimal f should be 0 (don't bet)
        assert abs(f_all_negative - 0.0) < 0.001
        
        # Test with extreme values
        extreme_trades = [0.5, -0.4, 0.6, -0.3]  # Large swings
        f_extreme = advisor.calculate_optimal_f(
            trades_series=extreme_trades,
            f_min=0.0,
            f_max=1.0
        )
        assert 0.0 <= f_extreme <= 1.0
        
        # Test with non-finite values (should be filtered)
        trades_with_nan = [0.01, float('nan'), -0.02, float('inf'), 0.03]
        f_nan = advisor.calculate_optimal_f(trades_with_nan)
        # Should only process finite values (0.01, -0.02, 0.03)
        assert 0.0 <= f_nan <= 1.0
        
        # Test refinement
        f_refined = advisor.calculate_optimal_f(
            trades_series=[0.02, -0.01, 0.015, -0.005],
            refine_rounds=3,
            refine_steps=50
        )
        assert 0.0 <= f_refined <= 1.0
    
    def test_calculate_var_historical(self, advisor, sample_positions):
        """Test historical VaR calculation."""
        var_95 = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.95,
            method="historical"
        )
        
        # VaR should be >= 0 (positive loss magnitude)
        assert var_95 >= 0.0
        
        # For 95% confidence, VaR should be less than worst loss
        all_returns = _merge_returns_from_positions(sample_positions)
        worst_loss = min(all_returns)
        assert var_95 <= abs(worst_loss) + 0.01  # Allow small tolerance
        
        # Test with different confidence levels
        var_90 = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.90,
            method="historical"
        )
        var_99 = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.99,
            method="historical"
        )
        
        # Higher confidence should give larger VaR (or equal)
        assert var_99 >= var_95 >= var_90
        
        # Test with explicit returns_series
        returns = [0.01, -0.02, 0.015, -0.01, 0.005, -0.03, 0.02, -0.015]
        var_explicit = advisor.calculate_var(
            positions=[],
            confidence_level=0.95,
            method="historical",
            returns_series=returns
        )
        assert var_explicit >= 0.0
    
    def test_calculate_var_gaussian(self, advisor, sample_positions):
        """Test Gaussian VaR calculation."""
        var_gaussian = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.95,
            method="gaussian"
        )
        
        # VaR should be >= 0
        assert var_gaussian >= 0.0
        
        # Compare with historical VaR
        var_historical = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.95,
            method="historical"
        )
        
        # Gaussian and historical VaR might differ, but both should be reasonable
        # For normal-ish distributions, they should be similar
        
        # Test with insufficient data
        var_small = advisor.calculate_var(
            positions=[{"returns": [0.01, -0.02]}],  # Only 2 returns
            confidence_level=0.95,
            method="gaussian"
        )
        assert var_small == 0.0  # Should return 0.0 for < 10 data points
        
        # Test with invalid method (should default to historical)
        var_default = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.95,
            method="invalid_method"
        )
        assert var_default >= 0.0
    
    def test_calculate_var_edge_cases(self, advisor):
        """Test VaR calculation with edge cases."""
        # Empty positions
        var_empty = advisor.calculate_var([], confidence_level=0.95)
        assert var_empty == 0.0
        
        # Positions with non-finite returns
        positions_nan = [
            {"returns": [0.01, float('nan'), -0.02, float('inf')]}
        ]
        var_nan = advisor.calculate_var(positions_nan, confidence_level=0.95)
        # Should filter out non-finite values and have < 10 points -> return 0
        assert var_nan == 0.0
        
        # Test confidence level bounds
        var_low_cl = advisor.calculate_var(
            positions=[{"returns": [-0.01, -0.02, -0.03, 0.01, 0.02, 0.03]}],
            confidence_level=0.0  # Should be clamped to 0.5
        )
        assert var_low_cl >= 0.0
        
        var_high_cl = advisor.calculate_var(
            positions=[{"returns": [-0.01, -0.02, -0.03, 0.01, 0.02, 0.03]}],
            confidence_level=1.0  # Should be clamped to 0.999
        )
        assert var_high_cl >= 0.0
    
    def test_calculate_cvar(self, advisor, sample_positions):
        """Test CVaR (Expected Shortfall) calculation."""
        cvar_95 = advisor.calculate_cvar(
            positions=sample_positions,
            confidence_level=0.95
        )
        
        # CVaR should be >= 0
        assert cvar_95 >= 0.0
        
        # CVaR should be >= VaR at same confidence level
        var_95 = advisor.calculate_var(
            positions=sample_positions,
            confidence_level=0.95,
            method="historical"
        )
        assert cvar_95 >= var_95 - 0.001  # Allow small tolerance
        
        # Test with different confidence levels
        cvar_90 = advisor.calculate_cvar(
            positions=sample_positions,
            confidence_level=0.90
        )
        cvar_99 = advisor.calculate_cvar(
            positions=sample_positions,
            confidence_level=0.99
        )
        
        # For the same data, higher confidence might give larger CVaR
        # (but not strictly due to tail averaging)
        
        # Test with explicit returns_series
        returns = [0.01, -0.02, 0.015, -0.01, 0.005, -0.03, 0.02, -0.015]
        cvar_explicit = advisor.calculate_cvar(
            positions=[],
            confidence_level=0.95,
            returns_series=returns
        )
        assert cvar_explicit >= 0.0
    
    def test_calculate_cvar_edge_cases(self, advisor):
        """Test CVaR calculation with edge cases."""
        # Empty positions
        cvar_empty = advisor.calculate_cvar([], confidence_level=0.95)
        assert cvar_empty == 0.0
        
        # Insufficient data
        cvar_small = advisor.calculate_cvar(
            [{"returns": [0.01, -0.02]}],
            confidence_level=0.95
        )
        assert cvar_small == 0.0
        
        # All positive returns (no tail losses)
        positions_all_positive = [
            {"returns": [0.01, 0.02, 0.015, 0.005, 0.01]}
        ]
        cvar_positive = advisor.calculate_cvar(
            positions_all_positive,
            confidence_level=0.95
        )
        # With all positive returns, tail at 95% might be positive -> CVaR = 0
        assert cvar_positive >= 0.0
        
        # All negative returns
        positions_all_negative = [
            {"returns": [-0.01, -0.02, -0.015, -0.005, -0.01]}
        ]
        cvar_negative = advisor.calculate_cvar(
            positions_all_negative,
            confidence_level=0.95
        )
        # Should be positive (loss magnitude)
        assert cvar_negative > 0.0


# Integration tests
def test_integration_scenario():
    """Test integrated risk assessment scenario."""
    advisor = RiskAdvisor()
    
    # Simulate trading history
    trade_returns = [
        0.02, -0.01, 0.03, -0.005, 0.015, -0.02,
        0.01, 0.005, -0.015, 0.025, -0.01, 0.005
    ]
    
    # Calculate optimal position size
    optimal_f = advisor.calculate_optimal_f(
        trades_series=trade_returns,
        f_min=0.01,
        f_max=0.5,
        steps=100,
        refine_rounds=2
    )
    
    assert 0.0 <= optimal_f <= 1.0
    print(f"Optimal-F: {optimal_f:.3f}")
    
    # Calculate Kelly for comparison (using win rate from history)
    wins = [r for r in trade_returns if r > 0]
    losses = [r for r in trade_returns if r < 0]
    
    if wins and losses:
        win_rate = len(wins) / len(trade_returns)
        avg_win = sum(wins) / len(wins)
        avg_loss = abs(sum(losses) / len(losses))  # Losses are negative
        
        kelly_f = advisor.calculate_kelly_criterion(
            win_rate=win_rate,
            avg_win=avg_win,
            avg_loss=avg_loss,
            kelly_fraction=0.5,  # Half-Kelly for conservatism
            cap=0.25  # Cap at 25%
        )
        
        print(f"Half-Kelly: {kelly_f:.3f} (win_rate={win_rate:.2f}, avg_win={avg_win:.3f}, avg_loss={avg_loss:.3f})")
    
    # Calculate risk metrics from positions
    positions = [
        {"returns": trade_returns},
        {"pnl_series": [50, -30, 20, -10, 40], "equity": 1000}
    ]
    
    # VaR at 95% confidence
    var_95 = advisor.calculate_var(
        positions=positions,
        confidence_level=0.95,
        method="historical"
    )
    
    # CVaR at 95% confidence
    cvar_95 = advisor.calculate_cvar(
        positions=positions,
        confidence_level=0.95
    )
    
    print(f"VaR 95%: {var_95:.3%}")
    print(f"CVaR 95%: {cvar_95:.3%}")
    
    assert var_95 >= 0.0
    assert cvar_95 >= var_95 - 0.001  # CVaR >= VaR


def test_risk_management_pipeline():
    """Test a complete risk management pipeline."""
    advisor = RiskAdvisor()
    
    # Step 1: Analyze historical performance
    historical_trades = [
        0.015, -0.008, 0.022, -0.012, 0.018,
        -0.005, 0.025, -0.015, 0.012, -0.008
    ]
    
    # Step 2: Calculate optimal position size
    position_size = advisor.calculate_optimal_f(
        trades_series=historical_trades,
        f_min=0.01,
        f_max=0.3,  # Conservative max
        steps=80,
        refine_rounds=1
    )
    
    # Step 3: Calculate risk metrics
    positions = [{"returns": historical_trades}]
    
    # Daily risk metrics
    daily_var_95 = advisor.calculate_var(
        positions=positions,
        confidence_level=0.95,
        method="historical"
    )
    
    daily_cvar_95 = advisor.calculate_cvar(
        positions=positions,
        confidence_level=0.95
    )
    
    # Step 4: Make risk-aware decision
    max_daily_loss_tolerance = 0.02  # 2% max daily loss
    
    risk_metrics = {
        "optimal_position_size": position_size,
        "daily_var_95": daily_var_95,
        "daily_cvar_95": daily_cvar_95,
        "within_risk_limits": daily_cvar_95 <= max_daily_loss_tolerance,
        "suggested_position_cap": min(position_size, max_daily_loss_tolerance / max(daily_cvar_95, 1e-6))
    }
    
    print("\n=== Risk Management Report ===")
    for key, value in risk_metrics.items():
        if isinstance(value, float):
            print(f"{key}: {value:.4f}")
        else:
            print(f"{key}: {value}")
    
    # Verify calculations
    assert 0.0 <= risk_metrics["optimal_position_size"] <= 1.0
    assert risk_metrics["daily_var_95"] >= 0.0
    assert risk_metrics["daily_cvar_95"] >= risk_metrics["daily_var_95"] - 0.001


# Performance tests
def test_performance():
    """Test performance with large datasets."""
    advisor = RiskAdvisor()
    
    # Generate large dataset
    import numpy as np
    np.random.seed(42)
    n_trades = 10000
    trade_returns = np.random.normal(0.001, 0.02, n_trades).tolist()  # Mean 0.1%, std 2%
    
    # Time optimal-f calculation
    import time
    start = time.time()
    
    optimal_f = advisor.calculate_optimal_f(
        trades_series=trade_returns,
        f_min=0.0,
        f_max=0.5,
        steps=100,
        refine_rounds=1
    )
    
    elapsed = time.time() - start
    print(f"\nOptimal-F calculation for {n_trades} trades: {elapsed:.3f}s")
    
    assert 0.0 <= optimal_f <= 1.0
    assert elapsed < 1.0  # Should be fast
    
    # Time VaR calculation
    positions = [{"returns": trade_returns}]
    
    start = time.time()
    var_95 = advisor.calculate_var(
        positions=positions,
        confidence_level=0.95,
        method="historical"
    )
    elapsed_var = time.time() - start
    
    print(f"VaR calculation: {elapsed_var:.3f}s")
    assert var_95 >= 0.0
    assert elapsed_var < 0.5  # Should be fast


# Property-based tests
def test_properties():
    """Test mathematical properties of risk calculations."""
    advisor = RiskAdvisor()
    
    # Property 1: Kelly should be 0 when win_rate <= 1/(b+1)
    # For b = 1 (avg_win = avg_loss), Kelly is 0 when win_rate <= 0.5
    kelly = advisor.calculate_kelly_criterion(
        win_rate=0.5,
        avg_win=0.01,
        avg_loss=0.01
    )
    assert abs(kelly - 0.0) < 0.001
    
    # Property 2: With all positive returns, optimal-f should be at max
    positive_returns = [0.01, 0.02, 0.005, 0.015]
    optimal_f = advisor.calculate_optimal_f(
        trades_series=positive_returns,
        f_min=0.0,
        f_max=0.5
    )
    # Actually, with all positive returns, growth is monotonic in f
    # So optimal f would be at max (0.5)
    assert abs(optimal_f - 0.5) < 0.01
    
    # Property 3: With all negative returns, optimal-f should be 0
    negative_returns = [-0.01, -0.02, -0.005, -0.015]
    optimal_f_neg = advisor.calculate_optimal_f(
        trades_series=negative_returns,
        f_min=0.0,
        f_max=0.5
    )
    assert abs(optimal_f_neg - 0.0) < 0.01
    
    # Property 4: VaR should be monotonic in confidence level
    returns = [-0.03, -0.02, -0.01, 0.0, 0.01, 0.02, 0.03]
    positions = [{"returns": returns}]
    
    var_90 = advisor.calculate_var(positions, confidence_level=0.90)
    var_95 = advisor.calculate_var(positions, confidence_level=0.95)
    var_99 = advisor.calculate_var(positions, confidence_level=0.99)
    
    assert var_99 >= var_95 >= var_90
    
    # Property 5: CVaR >= VaR at same confidence level
    cvar_95 = advisor.calculate_cvar(positions, confidence_level=0.95)
    assert cvar_95 >= var_95 - 0.001


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
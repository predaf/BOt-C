"""
Configuration management module with environment variable support.
Features:
- Deep merging of configs
- Environment variable overrides
- Atomic file operations
- Type-safe conversions
- Schema validation with Pydantic
"""

from __future__ import annotations

import os
import json
import copy
import tempfile
import logging
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional, List, Union, TypeVar, Generic
from contextlib import contextmanager
from dataclasses import dataclass, asdict

try:
    from pydantic import BaseModel, ValidationError, Field, validator
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False
    BaseModel = object  # Fallback

# Setup logging
logger = logging.getLogger(__name__)

# Type variables
T = TypeVar('T')
ConfigDict = Dict[str, Any]

class ListStrategy(str, Enum):
    """Strategies for merging lists in configuration."""
    REPLACE = "replace"  # User list replaces default list
    APPEND = "append"    # User list appended to default list
    UNIQUE_APPEND = "unique_append"  # Append with deduplication


@dataclass
class ConfigMetadata:
    """Metadata about configuration loading."""
    source_file: Optional[Path] = None
    env_vars_used: List[str] = None
    merge_strategy: ListStrategy = ListStrategy.REPLACE
    loaded_at: Optional[float] = None
    checksum: Optional[str] = None
    
    def __post_init__(self):
        if self.env_vars_used is None:
            self.env_vars_used = []


class ConfigSchema(BaseModel):
    """Base Pydantic schema for configuration validation."""
    class Config:
        extra = "ignore"  # Ignore extra fields
        validate_assignment = True
        anystr_strip_whitespace = True
    
    @classmethod
    def validate_config(cls, config_dict: ConfigDict) -> tuple[ConfigDict, List[str]]:
        """
        Validate configuration against schema.
        
        Returns:
            Tuple of (validated_config, list_of_warnings)
        """
        warnings = []
        
        if not PYDANTIC_AVAILABLE:
            warnings.append("Pydantic not available, skipping validation")
            return config_dict, warnings
        
        try:
            # Create instance for validation
            instance = cls(**config_dict)
            validated = instance.dict(exclude_none=True)
            return validated, warnings
        except ValidationError as e:
            warnings.append(f"Configuration validation errors: {e}")
            # Return original but log warnings
            return config_dict, warnings


class AppConfigSchema(ConfigSchema):
    """Example application configuration schema."""
    api_key: Optional[str] = Field(None, description="Exchange API key")
    api_secret: Optional[str] = Field(None, description="Exchange API secret")
    exchange: str = Field("binance", description="Exchange ID")
    mode: str = Field("paper", description="Trading mode: paper or live")
    enable_futures: bool = Field(False, description="Enable futures trading")
    
    class ApiConfig(ConfigSchema):
        key: Optional[str] = None
        secret: Optional[str] = None
        timeout: int = 30
        retries: int = 3
    
    api: ApiConfig = Field(default_factory=ApiConfig)
    
    @validator('mode')
    def validate_mode(cls, v):
        if v.lower() not in ('paper', 'live'):
            raise ValueError('mode must be "paper" or "live"')
        return v.lower()
    
    @validator('exchange')
    def validate_exchange(cls, v):
        # Could add exchange validation here
        return v.lower()


def _clone(obj: Any) -> Any:
    """
    Safely deep clone an object.
    
    Args:
        obj: Object to clone
        
    Returns:
        Deep copy of the object
    """
    try:
        return copy.deepcopy(obj)
    except Exception as e:
        logger.debug(f"Deep copy failed, using JSON fallback: {e}")
        try:
            return json.loads(json.dumps(obj, default=str))
        except Exception as json_e:
            logger.error(f"JSON fallback also failed: {json_e}")
            raise ValueError(f"Cannot clone object: {e}")


class TypeConverter:
    """Utility class for type conversions with logging."""
    
    @staticmethod
    def as_bool(value: Any) -> Optional[bool]:
        """Convert value to boolean with intelligent parsing."""
        if value is None:
            return None
        
        if isinstance(value, bool):
            return value
        
        str_value = str(value).strip().lower()
        
        truthy = {"1", "true", "yes", "y", "on", "enabled", "enable"}
        falsy = {"0", "false", "no", "n", "off", "disabled", "disable"}
        
        if str_value in truthy:
            return True
        if str_value in falsy:
            return False
        
        # Try numeric
        try:
            num = float(str_value)
            return bool(num)
        except ValueError:
            pass
        
        logger.debug(f"Cannot convert '{value}' to boolean")
        return None
    
    @staticmethod
    def as_int(value: Any) -> Optional[int]:
        """Convert value to integer."""
        try:
            return int(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            return None
    
    @staticmethod
    def as_float(value: Any) -> Optional[float]:
        """Convert value to float."""
        try:
            return float(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            return None
    
    @staticmethod
    def as_json(value: Any) -> Optional[Any]:
        """Parse JSON string."""
        if value is None:
            return None
        
        # If already a dict/list, return as is
        if isinstance(value, (dict, list)):
            return value
        
        try:
            return json.loads(str(value))
        except (json.JSONDecodeError, TypeError, AttributeError):
            return None


def deep_merge(
    user_config: ConfigDict,
    default_config: ConfigDict,
    *,
    list_strategy: Union[str, ListStrategy] = ListStrategy.REPLACE,
    path: str = "",
) -> ConfigDict:
    """
    Deep merge user configuration over default configuration.
    
    Args:
        user_config: User configuration (higher priority)
        default_config: Default configuration (lower priority)
        list_strategy: How to merge lists
        path: Current path for logging (internal use)
        
    Returns:
        Merged configuration dictionary
    """
    # Convert string to enum if needed
    if isinstance(list_strategy, str):
        try:
            list_strategy = ListStrategy(list_strategy)
        except ValueError:
            logger.warning(f"Invalid list strategy '{list_strategy}', using REPLACE")
            list_strategy = ListStrategy.REPLACE
    
    result = _clone(default_config or {})
    user_config = user_config or {}
    
    for key, user_value in user_config.items():
        current_path = f"{path}.{key}" if path else key
        
        # Both values are dictionaries -> recurse
        if (isinstance(user_value, dict) and 
            isinstance(result.get(key), dict)):
            result[key] = deep_merge(
                user_value,
                result[key],
                list_strategy=list_strategy,
                path=current_path
            )
        
        # Both values are lists -> apply list strategy
        elif (isinstance(user_value, list) and 
              isinstance(result.get(key), list)):
            
            default_list = result.get(key, [])
            
            if list_strategy == ListStrategy.REPLACE:
                result[key] = user_value
                
            elif list_strategy == ListStrategy.APPEND:
                result[key] = default_list + user_value
                
            elif list_strategy == ListStrategy.UNIQUE_APPEND:
                seen = set()
                merged = []
                
                for item in default_list + user_value:
                    # Create a hashable representation
                    if isinstance(item, (dict, list)):
                        try:
                            item_key = json.dumps(item, sort_keys=True)
                        except (TypeError, ValueError):
                            item_key = str(item)
                    else:
                        item_key = str(item)
                    
                    if item_key not in seen:
                        seen.add(item_key)
                        merged.append(item)
                
                result[key] = merged
                
            else:
                logger.warning(f"Unknown list strategy: {list_strategy}")
                result[key] = user_value
        
        # Replace with user value
        else:
            result[key] = user_value
    
    return result


class ConfigurationError(Exception):
    """Configuration-related exceptions."""
    pass


class ConfigManager:
    """
    Main configuration manager with file and environment support.
    """
    
    def __init__(
        self,
        default_config: Optional[ConfigDict] = None,
        schema_class: Optional[type[ConfigSchema]] = None,
        env_prefix: str = "BOT_"
    ):
        """
        Initialize configuration manager.
        
        Args:
            default_config: Default configuration dictionary
            schema_class: Pydantic schema class for validation
            env_prefix: Prefix for environment variables
        """
        self.default_config = _clone(default_config or {})
        self.schema_class = schema_class
        self.env_prefix = env_prefix
        self.metadata = ConfigMetadata()
        self._converter = TypeConverter()
        
        # Store validated config
        self._config: Optional[ConfigDict] = None
        self._warnings: List[str] = []
    
    def load(
        self,
        config_path: Union[str, Path, None] = None,
        *,
        list_strategy: Union[str, ListStrategy] = ListStrategy.REPLACE,
        validate: bool = True,
        apply_env: bool = True
    ) -> ConfigDict:
        """
        Load configuration from file and environment.
        
        Args:
            config_path: Path to configuration file
            list_strategy: Strategy for merging lists
            validate: Validate against schema if available
            apply_env: Apply environment variable overrides
            
        Returns:
            Configuration dictionary
        """
        self._warnings.clear()
        
        # Load from file if path provided
        file_config = {}
        if config_path:
            file_config = self._load_from_file(config_path, list_strategy)
        
        # Merge file config over defaults
        merged = deep_merge(
            file_config,
            self.default_config,
            list_strategy=list_strategy
        )
        
        # Apply environment variables
        if apply_env:
            merged = self._apply_environment_overrides(merged)
        
        # Apply special handling for API keys
        merged = self._normalize_api_keys(merged)
        
        # Validate if requested and schema available
        if validate and self.schema_class:
            merged, warnings = self.schema_class.validate_config(merged)
            self._warnings.extend(warnings)
        
        self._config = merged
        return merged
    
    def _load_from_file(
        self,
        config_path: Union[str, Path],
        list_strategy: Union[str, ListStrategy]
    ) -> ConfigDict:
        """Load configuration from JSON file."""
        path = Path(config_path)
        
        if not path.exists():
            logger.info(f"Config file not found: {path}, using defaults")
            return {}
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, dict):
                logger.warning(f"Config file {path} does not contain a dictionary")
                return {}
            
            self.metadata.source_file = path
            logger.info(f"Loaded configuration from {path}")
            return data
            
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config file {path}: {e}")
            raise ConfigurationError(f"Invalid JSON in config file: {e}")
        except Exception as e:
            logger.error(f"Error reading config file {path}: {e}")
            raise ConfigurationError(f"Error reading config file: {e}")
    
    def _apply_environment_overrides(self, config: ConfigDict) -> ConfigDict:
        """Apply environment variable overrides to configuration."""
        env_vars_used = []
        config = _clone(config)
        
        # Helper to get env var and track usage
        def get_env(name: str, default: Any = None) -> Optional[str]:
            value = os.getenv(name)
            if value is not None:
                env_vars_used.append(name)
            return value if value is not None else default
        
        # Generic API keys
        api_key = get_env(f"{self.env_prefix}API_KEY")
        api_secret = get_env(f"{self.env_prefix}API_SECRET")
        
        if api_key:
            config["api_key"] = api_key
        if api_secret:
            config["api_secret"] = api_secret
        
        # Exchange selection
        exchange = (get_env(f"{self.env_prefix}EXCHANGE") or 
                   get_env("EXCHANGE"))
        if exchange:
            config["exchange"] = exchange.lower()
        
        # Mode selection
        mode = get_env(f"{self.env_prefix}MODE")
        if mode:
            config["mode"] = mode.lower()
        
        trading_mode = get_env("TRADING_MODE")
        if trading_mode:
            tm_upper = trading_mode.upper()
            if tm_upper in ("PAPER", "LIVE"):
                config["mode"] = "paper" if tm_upper == "PAPER" else "live"
        
        # Futures flag
        futures = get_env("ENABLE_FUTURES")
        if futures is not None:
            bool_val = self._converter.as_bool(futures)
            if bool_val is not None:
                config["enable_futures"] = bool_val
        
        # Exchange-specific keys
        exchange_id = config.get("exchange", "").upper()
        if exchange_id:
            ex_key = get_env(f"{exchange_id}_API_KEY")
            ex_secret = get_env(f"{exchange_id}_SECRET") or get_env(f"{exchange_id}_API_SECRET")
            
            if ex_key:
                config["api_key"] = ex_key
            if ex_secret:
                config["api_secret"] = ex_secret
        
        # JSON overrides
        json_override = get_env("CFG_SET_JSON")
        if json_override:
            try:
                override_dict = json.loads(json_override)
                if isinstance(override_dict, dict):
                    config.update(override_dict)
            except json.JSONDecodeError as e:
                logger.warning(f"Invalid JSON in CFG_SET_JSON: {e}")
        
        # Dotted overrides
        dotted_override = get_env("CFG_SET")
        if dotted_override:
            self._apply_dotted_overrides(config, dotted_override)
        
        # Update metadata
        self.metadata.env_vars_used = env_vars_used
        
        if env_vars_used:
            logger.debug(f"Used environment variables: {env_vars_used}")
        
        return config
    
    def _apply_dotted_overrides(self, config: ConfigDict, dotted_string: str) -> None:
        """Apply dotted path overrides (key.path=value;key2=value2)."""
        pairs = [p.strip() for p in dotted_string.split(';') if p.strip()]
        
        for pair in pairs:
            if '=' not in pair:
                continue
            
            key_path, value = pair.split('=', 1)
            key_path = key_path.strip()
            value = value.strip()
            
            # Try different type conversions
            typed_value = None
            
            # Boolean
            bool_val = self._converter.as_bool(value)
            if bool_val is not None:
                typed_value = bool_val
            
            # Integer
            if typed_value is None:
                int_val = self._converter.as_int(value)
                if int_val is not None and str(int_val) == value:
                    typed_value = int_val
            
            # Float
            if typed_value is None:
                float_val = self._converter.as_float(value)
                if float_val is not None:
                    typed_value = float_val
            
            # JSON
            if typed_value is None:
                json_val = self._converter.as_json(value)
                if json_val is not None:
                    typed_value = json_val
            
            # String fallback
            if typed_value is None:
                typed_value = value
            
            # Set the value
            self._set_nested(config, key_path, typed_value)
    
    def _set_nested(self, config: ConfigDict, dotted_path: str, value: Any) -> None:
        """Set nested value using dotted path."""
        keys = [k for k in dotted_path.split('.') if k]
        current = config
        
        for key in keys[:-1]:
            if key not in current or not isinstance(current.get(key), dict):
                current[key] = {}
            current = current[key]
        
        current[keys[-1]] = value
    
    def _normalize_api_keys(self, config: ConfigDict) -> ConfigDict:
        """Normalize API key structure in configuration."""
        config = _clone(config)
        
        # Ensure api section exists
        if "api" not in config or not isinstance(config["api"], dict):
            config["api"] = {}
        
        # Move root-level api_key/api_secret to api section
        if "api_key" in config and not config["api"].get("key"):
            config["api"]["key"] = config["api_key"]
        
        if "api_secret" in config and not config["api"].get("secret"):
            config["api"]["secret"] = config["api_secret"]
        
        return config
    
    def save(
        self,
        config_path: Union[str, Path],
        config: Optional[ConfigDict] = None,
        *,
        atomic: bool = True,
        create_backup: bool = False
    ) -> None:
        """
        Save configuration to file.
        
        Args:
            config_path: Path to save configuration
            config: Configuration to save (uses current if None)
            atomic: Use atomic write (temp file + replace)
            create_backup: Create backup of existing file
        """
        config = config or self._config or {}
        path = Path(config_path)
        
        # Create backup if requested and file exists
        if create_backup and path.exists():
            backup_path = path.with_suffix(f"{path.suffix}.bak")
            try:
                path.replace(backup_path)
                logger.info(f"Created backup at {backup_path}")
            except Exception as e:
                logger.warning(f"Failed to create backup: {e}")
        
        # Ensure parent directory exists
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if atomic:
            self._atomic_write(path, config)
        else:
            self._direct_write(path, config)
    
    def _atomic_write(self, path: Path, config: ConfigDict) -> None:
        """Write configuration atomically."""
        fd, temp_path_str = tempfile.mkstemp(
            prefix=f"{path.name}.",
            suffix=".tmp",
            dir=path.parent or None
        )
        temp_path = Path(temp_path_str)
        
        try:
            # Write to temp file
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            
            # Replace original with temp
            temp_path.replace(path)
            
            # Set secure permissions on POSIX
            self._set_secure_permissions(path)
            
            logger.info(f"Configuration saved atomically to {path}")
            
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
            # Clean up temp file
            try:
                temp_path.unlink(missing_ok=True)
            except Exception:
                pass
            raise ConfigurationError(f"Failed to save configuration: {e}")
    
    def _direct_write(self, path: Path, config: ConfigDict) -> None:
        """Write configuration directly."""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            
            self._set_secure_permissions(path)
            logger.info(f"Configuration saved to {path}")
            
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
            raise ConfigurationError(f"Failed to save configuration: {e}")
    
    def _set_secure_permissions(self, path: Path) -> None:
        """Set secure file permissions (600 on POSIX)."""
        try:
            if os.name == 'posix':
                os.chmod(path, 0o600)
        except Exception as e:
            logger.warning(f"Could not set file permissions: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by dotted key."""
        if self._config is None:
            raise ConfigurationError("Configuration not loaded")
        
        return self._get_nested(self._config, key, default)
    
    def _get_nested(self, config: ConfigDict, dotted_path: str, default: Any = None) -> Any:
        """Get nested value using dotted path."""
        keys = [k for k in dotted_path.split('.') if k]
        current = config
        
        for key in keys:
            if not isinstance(current, dict):
                return default
            current = current.get(key)
            if current is None:
                return default
        
        return current if current is not None else default
    
    @property
    def warnings(self) -> List[str]:
        """Get configuration warnings."""
        return self._warnings.copy()
    
    @property
    def is_valid(self) -> bool:
        """Check if configuration is valid (no critical warnings)."""
        return len(self._warnings) == 0 or all(
            "warning" in w.lower() for w in self._warnings
        )


# Legacy functions for backward compatibility
def load_config(
    path: str,
    default_cfg: ConfigDict,
    *,
    list_strategy: str = "replace",
    tolerate_invalid_json: bool = True,
) -> ConfigDict:
    """
    Legacy function for loading configuration.
    
    Args:
        path: Path to configuration file
        default_cfg: Default configuration
        list_strategy: Strategy for merging lists
        tolerate_invalid_json: Return default on JSON error
        
    Returns:
        Merged configuration
    """
    manager = ConfigManager(default_cfg)
    
    if not Path(path).exists():
        return _clone(default_cfg)
    
    if tolerate_invalid_json:
        try:
            return manager.load(path, list_strategy=list_strategy)
        except Exception:
            logger.warning(f"Invalid config at {path}, returning default")
            return _clone(default_cfg)
    else:
        return manager.load(path, list_strategy=list_strategy)


def save_config(path: str, cfg: ConfigDict, *, atomic: bool = True) -> None:
    """Legacy function for saving configuration."""
    manager = ConfigManager()
    manager.save(path, cfg, atomic=atomic)


def apply_env_overrides(cfg: ConfigDict) -> ConfigDict:
    """Legacy function for applying environment overrides."""
    manager = ConfigManager(cfg)
    return manager.load(apply_env=True)


# Context manager for temporary configuration
@contextmanager
def temp_config(config_dict: ConfigDict, path: Union[str, Path]):
    """
    Context manager for temporary configuration file.
    
    Example:
        with temp_config({"key": "value"}, "temp.json"):
            # config file exists here
            pass
        # config file deleted here
    """
    path_obj = Path(path)
    
    try:
        # Save config
        manager = ConfigManager()
        manager.save(path_obj, config_dict)
        
        yield path_obj
        
    finally:
        # Clean up
        try:
            path_obj.unlink(missing_ok=True)
        except Exception as e:
            logger.warning(f"Failed to remove temp config {path_obj}: {e}")


# Example usage
if __name__ == "__main__":
    # Example default configuration
    DEFAULT_CONFIG = {
        "exchange": "binance",
        "mode": "paper",
        "enable_futures": False,
        "api": {
            "timeout": 30,
            "retries": 3
        },
        "logging": {
            "level": "INFO",
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        }
    }
    
    # Create config manager
    manager = ConfigManager(
        default_config=DEFAULT_CONFIG,
        schema_class=AppConfigSchema if PYDANTIC_AVAILABLE else None
    )
    
    # Load configuration
    try:
        config = manager.load("config.json")
        print("Configuration loaded successfully")
        print(f"Exchange: {config.get('exchange')}")
        print(f"Mode: {config.get('mode')}")
        
        if manager.warnings:
            print("\nWarnings:")
            for warning in manager.warnings:
                print(f"  - {warning}")
                
    except ConfigurationError as e:
        print(f"Configuration error: {e}")
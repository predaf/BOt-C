from __future__ import annotations

from typing import Any, Dict, Optional, List, Tuple, Callable
import time
import hashlib
import random
from contextlib import contextmanager
from dataclasses import dataclass, asdict, field
import json
from datetime import datetime


# ============================================================
# Data Models for Order Tracking
# ============================================================

@dataclass
class OrderLeg:
    """Represents a single leg of a complex order (OCO, Bracket)"""
    leg_id: str
    order_id: str
    leg_type: str  # "entry", "stop_loss", "take_profit", "stop_entry", "limit_entry"
    symbol: str
    side: str
    qty: float
    price: Optional[float] = None
    trigger_price: Optional[float] = None
    status: str = "pending"  # pending, filled, cancelled, rejected, expired
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    fees: float = 0.0
    filled_qty: float = 0.0
    avg_fill_price: Optional[float] = None
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # Convert timestamps to ISO format for JSON serialization
        d['created_at_iso'] = datetime.fromtimestamp(self.created_at).isoformat()
        d['updated_at_iso'] = datetime.fromtimestamp(self.updated_at).isoformat()
        return d

    def update_status(self, status: str, **kwargs):
        """Update leg status and optional fields"""
        self.status = status
        self.updated_at = time.time()
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)


@dataclass
class ComplexOrder:
    """Represents a complex order (OCO, Bracket, Grid) with multiple legs"""
    order_id: str
    order_type: str  # "oco", "bracket", "grid", "simple"
    symbol: str
    side: str  # entry side
    qty: float
    status: str = "pending"  # pending, active, partially_filled, filled, cancelled, error
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    legs: Dict[str, OrderLeg] = field(default_factory=dict)  # leg_id -> OrderLeg
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    def add_leg(self, leg: OrderLeg):
        """Add a leg to the complex order"""
        self.legs[leg.leg_id] = leg
        self.updated_at = time.time()
    
    def remove_leg(self, leg_id: str):
        """Remove a leg from the complex order"""
        if leg_id in self.legs:
            del self.legs[leg_id]
            self.updated_at = time.time()
    
    def update_status(self, status: str):
        """Update overall order status"""
        self.status = status
        self.updated_at = time.time()
    
    def get_active_legs(self) -> List[OrderLeg]:
        """Get all legs that are still active (not filled or cancelled)"""
        active_statuses = {"pending", "partially_filled"}
        return [leg for leg in self.legs.values() if leg.status in active_statuses]
    
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['legs'] = {leg_id: leg.to_dict() for leg_id, leg in self.legs.items()}
        d['created_at_iso'] = datetime.fromtimestamp(self.created_at).isoformat()
        d['updated_at_iso'] = datetime.fromtimestamp(self.updated_at).isoformat()
        d['active_legs_count'] = len(self.get_active_legs())
        return d


# ============================================================
# Main OrderManager Class
# ============================================================

class OrderManager:
    """Advanced order helpers (OCO/Bracket/Grid) - best-effort wrappers over ExchangeClient.

    Enhanced with:
      - Circuit breaker pattern for order failure protection
      - Exponential backoff retry logic
      - Comprehensive order tracking and history
      - Performance monitoring
      - Graceful degradation
    """

    def __init__(self, client: Any, log: Any):
        self.client = client
        self.log = log
        
        # Order tracking
        self.active_orders: Dict[str, ComplexOrder] = {}  # order_id -> ComplexOrder
        self.order_history: List[Dict[str, Any]] = []  # Full history for analysis
        self.max_history_size = 1000
        
        # Circuit breaker configuration
        self._circuit_breaker = {
            "open": False,
            "failures": 0,
            "last_failure": 0.0,
            "cooldown_until": 0.0
        }
        self.max_failures = 5
        self.cooldown_sec = 60.0
        
        # Performance tracking
        self.metrics = {
            "total_orders": 0,
            "successful_orders": 0,
            "failed_orders": 0,
            "retry_count": 0,
            "avg_order_time_ms": 0.0,
            "last_order_time": 0.0
        }
        
        # Monkey-patching protection
        self._initialized = True
        
        # Default configuration
        self.config = {
            "default_retries": 3,
            "default_backoff": True,
            "max_backoff_sec": 5.0,
            "min_notional": 5.0,
            "slippage_bps": 2.0,
            "track_orders": True,
            "auto_cancel_stale_seconds": 3600
        }

    # -------------------------
    # Monkey-patching Protection
    # -------------------------
    def __setattr__(self, name: str, value: Any) -> None:
        if hasattr(self, '_initialized') and not hasattr(self, name):
            raise AttributeError(f"Cannot add new attribute '{name}' to {self.__class__.__name__}")
        super().__setattr__(name, value)

    # -------------------------
    # Context Managers
    # -------------------------
    @contextmanager
    def temp_override(self, **kwargs):
        """Temporarily override configuration attributes"""
        old_values = {}
        try:
            for key, value in kwargs.items():
                if hasattr(self, key):
                    old_values[key] = getattr(self, key)
                    setattr(self, key, value)
                elif hasattr(self.config, key):
                    old_values[key] = self.config.get(key)
                    self.config[key] = value
            yield
        finally:
            for key, value in old_values.items():
                if hasattr(self, key):
                    setattr(self, key, value)
                else:
                    self.config[key] = value

    # -------------------------
    # Small utilities
    # -------------------------
    @staticmethod
    def _s(x: Any, d: str = "") -> str:
        try:
            if x is None:
                return d
            return str(x)
        except Exception:
            return d

    @staticmethod
    def _f(x: Any, d: float = 0.0) -> float:
        try:
            return float(x)
        except Exception:
            return float(d)

    @staticmethod
    def generate_id(prefix: str = "ord") -> str:
        """Generate a unique order ID"""
        timestamp = int(time.time() * 1000)
        random_part = hashlib.md5(str(random.random()).encode()).hexdigest()[:8]
        return f"{prefix}_{timestamp}_{random_part}"

    def _norm_side(self, side: str) -> str:
        s = self._s(side).lower().strip()
        if s in ("buy", "long"):
            return "buy"
        if s in ("sell", "short"):
            return "sell"
        return s  # keep as-is, but may fail later

    def _close_side(self, entry_side: str) -> str:
        s = self._norm_side(entry_side)
        return "sell" if s == "buy" else "buy"

    def _pos_side_to_ccxt(self, pos_side: Optional[str]) -> Optional[str]:
        """CCXT hedge-mode positionSide (Binance/Bybit style)."""
        if not pos_side:
            return None
        ps = self._s(pos_side).lower().strip()
        if ps in ("long", "buy"):
            return "LONG"
        if ps in ("short", "sell"):
            return "SHORT"
        return None

    def _trigger_params(self, trigger_price: float) -> Dict[str, Any]:
        """
        Exchanges differ: some use stopPrice, some triggerPrice.
        We set both (harmless if ignored).
        """
        tp = float(trigger_price)
        return {"stopPrice": tp, "triggerPrice": tp}

    def _maybe_position_side(self, pos_side: Optional[str]) -> Dict[str, Any]:
        ps = self._pos_side_to_ccxt(pos_side)
        return {"positionSide": ps} if ps else {}

    def _log_warn(self, msg: str) -> None:
        try:
            if hasattr(self.log, "warning"):
                self.log.warning(msg)
            elif hasattr(self.log, "info"):
                self.log.info(msg)
        except Exception:
            pass

    def _log_info(self, msg: str) -> None:
        try:
            if hasattr(self.log, "info"):
                self.log.info(msg)
        except Exception:
            pass

    def _log_error(self, msg: str) -> None:
        try:
            if hasattr(self.log, "error"):
                self.log.error(msg)
            elif hasattr(self.log, "warning"):
                self.log.warning(msg)
        except Exception:
            pass

    # -------------------------
    # Circuit Breaker
    # -------------------------
    def _check_circuit_breaker(self) -> bool:
        """Check if circuit breaker is open, raise exception if cooldown active"""
        now = time.time()
        cb = self._circuit_breaker
        
        if cb["open"]:
            if now < cb["cooldown_until"]:
                remaining = cb["cooldown_until"] - now
                raise Exception(
                    f"Circuit breaker open - too many order failures. "
                    f"Cooldown for {remaining:.1f} seconds"
                )
            else:
                # Cooldown expired, reset circuit breaker
                cb["open"] = False
                cb["failures"] = 0
                self._log_info("Circuit breaker reset after cooldown")
        
        return True

    def _record_failure(self) -> None:
        """Record a failure and potentially open circuit breaker"""
        cb = self._circuit_breaker
        cb["failures"] += 1
        cb["last_failure"] = time.time()
        
        if cb["failures"] >= self.max_failures:
            cb["open"] = True
            cb["cooldown_until"] = time.time() + self.cooldown_sec
            self._log_error(
                f"Circuit breaker opened after {cb['failures']} failures. "
                f"Cooldown for {self.cooldown_sec} seconds"
            )

    def _record_success(self) -> None:
        """Record success - reset failure count"""
        self._circuit_breaker["failures"] = 0
        self._circuit_breaker["open"] = False

    def get_circuit_breaker_status(self) -> Dict[str, Any]:
        """Get current circuit breaker status"""
        cb = self._circuit_breaker
        now = time.time()
        status = {
            "open": cb["open"],
            "failures": cb["failures"],
            "max_failures": self.max_failures,
            "last_failure_ago": now - cb["last_failure"] if cb["last_failure"] > 0 else None,
        }
        
        if cb["open"]:
            status["cooldown_remaining"] = max(0, cb["cooldown_until"] - now)
            status["cooldown_until"] = cb["cooldown_until"]
        
        return status

    # -------------------------
    # Retry Logic with Exponential Backoff
    # -------------------------
    def _retry_call(
        self, 
        fn: Callable, 
        *args, 
        retries: Optional[int] = None,
        sleep_sec: float = 0.2, 
        exponential_backoff: Optional[bool] = None,
        **kwargs
    ) -> Any:
        """
        Lightweight retry for transient errors with exponential backoff.
        We DO NOT aggressively retry to avoid duplicate orders.
        """
        retries = retries if retries is not None else self.config["default_retries"]
        exponential_backoff = exponential_backoff if exponential_backoff is not None else self.config["default_backoff"]
        
        last_exception = None
        start_time = time.time()
        
        for attempt in range(max(1, int(retries) + 1)):
            try:
                result = fn(*args, **kwargs)
                elapsed = (time.time() - start_time) * 1000
                self.metrics["avg_order_time_ms"] = (
                    self.metrics["avg_order_time_ms"] * self.metrics["total_orders"] + elapsed
                ) / (self.metrics["total_orders"] + 1) if self.metrics["total_orders"] > 0 else elapsed
                self.metrics["last_order_time"] = time.time()
                return result
                
            except Exception as e:
                last_exception = e
                msg = str(e).lower()
                
                # Check if error is transient
                transient_keywords = ["rate", "timeout", "tempor", "network", "busy", "too many requests", "connection"]
                is_transient = any(k in msg for k in transient_keywords)
                
                # Update retry metrics
                self.metrics["retry_count"] += 1
                
                if attempt < retries and is_transient:
                    if exponential_backoff:
                        # Exponential backoff with jitter
                        backoff_time = sleep_sec * (2 ** attempt) * (0.8 + 0.4 * random.random())
                        backoff_time = min(backoff_time, self.config["max_backoff_sec"])
                    else:
                        backoff_time = sleep_sec
                    
                    self._log_warn(
                        f"Retry {attempt + 1}/{retries} for {fn.__name__} after {backoff_time:.2f}s: {type(e).__name__}"
                    )
                    time.sleep(backoff_time)
                    continue
                
                # Non-transient error or max retries reached
                break
        
        # Record failure in circuit breaker
        self._record_failure()
        raise last_exception  # type: ignore

    # -------------------------
    # Order Tracking & Management
    # -------------------------
    def _create_complex_order(
        self,
        order_type: str,
        symbol: str,
        side: str,
        qty: float,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None
    ) -> ComplexOrder:
        """Create a new complex order and add it to tracking"""
        order_id = self.generate_id(order_type[:3])
        order = ComplexOrder(
            order_id=order_id,
            order_type=order_type,
            symbol=symbol,
            side=side,
            qty=qty,
            metadata=metadata or {},
            tags=tags or []
        )
        
        self.active_orders[order_id] = order
        self.metrics["total_orders"] += 1
        
        return order

    def _add_order_to_history(self, order: ComplexOrder, result: Dict[str, Any]):
        """Add order to history with result"""
        history_entry = {
            **order.to_dict(),
            "result": result,
            "completed_at": time.time(),
            "completed_at_iso": datetime.now().isoformat()
        }
        
        self.order_history.append(history_entry)
        
        # Trim history if too large
        if len(self.order_history) > self.max_history_size:
            self.order_history = self.order_history[-self.max_history_size:]
    
    def get_active_orders_summary(self) -> List[Dict[str, Any]]:
        """Get summary of all active orders"""
        return [order.to_dict() for order in self.active_orders.values()]

    def get_order_by_id(self, order_id: str) -> Optional[ComplexOrder]:
        """Get an order by its ID"""
        return self.active_orders.get(order_id)

    def cancel_all_active_orders(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Cancel all active orders, optionally filtered by symbol"""
        cancelled = []
        failed = []
        
        for order_id, order in list(self.active_orders.items()):
            if symbol and order.symbol != symbol:
                continue
            
            # Cancel all active legs
            for leg in order.get_active_legs():
                try:
                    if self.cancel_order_safe(order.symbol, leg.order_id):
                        leg.update_status("cancelled")
                    else:
                        failed.append(leg.order_id)
                except Exception as e:
                    failed.append(leg.order_id)
                    self._log_error(f"Failed to cancel leg {leg.order_id}: {e}")
            
            order.update_status("cancelled")
            cancelled.append(order_id)
        
        return {
            "cancelled": cancelled,
            "failed": failed,
            "cancelled_count": len(cancelled),
            "failed_count": len(failed)
        }

    def cleanup_stale_orders(self, max_age_seconds: Optional[float] = None) -> Dict[str, Any]:
        """Remove stale orders from tracking"""
        if max_age_seconds is None:
            max_age_seconds = self.config["auto_cancel_stale_seconds"]
        
        now = time.time()
        removed = []
        
        for order_id, order in list(self.active_orders.items()):
            # Check if all legs are completed (filled or cancelled)
            active_legs = order.get_active_legs()
            if not active_legs:
                # All legs completed, move to history if not already
                if order_id in self.active_orders:
                    del self.active_orders[order_id]
                    removed.append(order_id)
            
            # Check if order is too old
            elif now - order.created_at > max_age_seconds:
                self._log_warn(f"Auto-cancelling stale order {order_id} after {max_age_seconds}s")
                self.cancel_all_active_orders(order.symbol)
                removed.append(order_id)
        
        return {
            "removed_orders": removed,
            "removed_count": len(removed),
            "remaining_active": len(self.active_orders)
        }

    # -------------------------
    # Cancel helpers
    # -------------------------
    def cancel_order_safe(self, symbol: str, order_id: Optional[str]) -> bool:
        if not order_id:
            return False
        
        try:
            self._check_circuit_breaker()
            
            if hasattr(self.client, "cancel_order"):
                result = self._retry_call(
                    self.client.cancel_order, 
                    order_id, 
                    symbol, 
                    retries=1,  # Minimal retries for cancellation
                    exponential_backoff=False
                )
                
                # Update order tracking if this order is tracked
                for order in self.active_orders.values():
                    for leg in order.legs.values():
                        if leg.order_id == order_id:
                            leg.update_status("cancelled")
                            self._log_info(f"{symbol}: Cancelled tracked order {order_id}")
                
                self._record_success()
                return True
                
        except Exception as e:
            self._record_failure()
            self._log_warn(f"{symbol}: cancel failed for {order_id}: {type(e).__name__}: {e}")
        
        return False

    def cancel_many_safe(self, symbol: str, order_ids: List[str]) -> Dict[str, Any]:
        """Cancel multiple orders with detailed results"""
        results = {
            "successful": [],
            "failed": [],
            "success_count": 0,
            "fail_count": 0
        }
        
        for oid in order_ids or []:
            if self.cancel_order_safe(symbol, oid):
                results["successful"].append(oid)
                results["success_count"] += 1
            else:
                results["failed"].append(oid)
                results["fail_count"] += 1
        
        return results

    # -------------------------
    # OCO / Bracket Orders (Enhanced)
    # -------------------------
    def create_oco_order(
        self,
        symbol: str,
        side: str,
        qty: float,
        stop_price: float,
        tp_price: float,
        pos_side: Optional[str] = None,
        *,
        rollback_on_partial: bool = True,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Emulate OCO using two reduce-only trigger orders (futures-safe best-effort)."""
        try:
            self._check_circuit_breaker()
            
            sym = self._s(symbol).strip()
            entry_side = self._norm_side(side)
            close_side = self._close_side(entry_side)
            
            # Create tracking order
            order = self._create_complex_order(
                order_type="oco",
                symbol=sym,
                side=entry_side,
                qty=float(qty),
                tags=tags or [],
                metadata=metadata or {}
            )
            
            position_side = self._maybe_position_side(pos_side)
            created_legs: List[OrderLeg] = []
            result_legs = {}
            
            out: Dict[str, Any] = {
                "ok": True,
                "kind": "oco",
                "order_id": order.order_id,
                "symbol": sym,
                "entry_side": entry_side,
                "close_side": close_side,
                "qty": float(qty),
                "stop_price": float(stop_price),
                "tp_price": float(tp_price),
                "legs": {},
                "errors": [],
            }
            
            # 1) Stop Loss Leg
            try:
                sl = self._retry_call(
                    self.client.create_order,
                    sym,
                    "STOP_MARKET",
                    close_side,
                    float(qty),
                    None,
                    params={
                        "reduceOnly": True,
                        **self._trigger_params(float(stop_price)),
                        **position_side,
                    },
                    retries=1,
                )
                
                sid = (sl or {}).get("id")
                if sid:
                    leg = OrderLeg(
                        leg_id="stop_loss",
                        order_id=str(sid),
                        leg_type="stop_loss",
                        symbol=sym,
                        side=close_side,
                        qty=float(qty),
                        trigger_price=float(stop_price)
                    )
                    order.add_leg(leg)
                    created_legs.append(leg)
                    result_legs["stop_id"] = sid
                    out["legs"]["stop_loss"] = leg.to_dict()
            except Exception as e:
                out["ok"] = False
                out["errors"].append(f"SL:{type(e).__name__}:{e}")
                self._log_warn(f"{sym}: OCO SL failed: {type(e).__name__}: {e}")
            
            # 2) Take Profit Leg
            try:
                tp = self._retry_call(
                    self.client.create_order,
                    sym,
                    "TAKE_PROFIT_MARKET",
                    close_side,
                    float(qty),
                    None,
                    params={
                        "reduceOnly": True,
                        **self._trigger_params(float(tp_price)),
                        **position_side,
                    },
                    retries=1,
                )
                
                tid = (tp or {}).get("id")
                if tid:
                    leg = OrderLeg(
                        leg_id="take_profit",
                        order_id=str(tid),
                        leg_type="take_profit",
                        symbol=sym,
                        side=close_side,
                        qty=float(qty),
                        trigger_price=float(tp_price)
                    )
                    order.add_leg(leg)
                    created_legs.append(leg)
                    result_legs["tp_id"] = tid
                    out["legs"]["take_profit"] = leg.to_dict()
            except Exception as e:
                out["ok"] = False
                out["errors"].append(f"TP:{type(e).__name__}:{e}")
                self._log_warn(f"{sym}: OCO TP failed: {type(e).__name__}: {e}")
            
            # 3) Check for partial creation and rollback if needed
            has_stop = "stop_loss" in out["legs"]
            has_tp = "take_profit" in out["legs"]
            
            if rollback_on_partial and (has_stop ^ has_tp):  # XOR: one created, other failed
                self._log_warn(f"{sym}: OCO partial; attempting rollback of created triggers")
                
                # Cancel created legs
                for leg in created_legs:
                    self.cancel_order_safe(sym, leg.order_id)
                
                # Remove from active orders
                if order.order_id in self.active_orders:
                    del self.active_orders[order.order_id]
                
                out["errors"].append("rollback_partial_oco")
                out["ok"] = False
                out["rollback_performed"] = True
            else:
                # Update order status
                if has_stop and has_tp:
                    order.update_status("active")
                    self.metrics["successful_orders"] += 1
                    self._record_success()
                else:
                    order.update_status("error")
                    self.metrics["failed_orders"] += 1
            
            # Add to history if completed or errored
            if not out["ok"] or order.status in ["error", "cancelled"]:
                self._add_order_to_history(order, out)
                if order.order_id in self.active_orders:
                    del self.active_orders[order.order_id]
            
            return out
            
        except Exception as e:
            self._record_failure()
            self.metrics["failed_orders"] += 1
            return {
                "ok": False,
                "kind": "oco",
                "symbol": symbol,
                "error": f"Circuit breaker or unexpected error: {type(e).__name__}: {e}",
                "errors": [f"INIT:{type(e).__name__}:{e}"]
            }

    def create_bracket_order(
        self,
        symbol: str,
        side: str,
        qty: float,
        entry_price: float,
        sl_price: float,
        tp_price: float,
        pos_side: Optional[str] = None,
        *,
        entry_type: str = "limit",
        rollback_on_partial: bool = True,
        cancel_entry_if_protection_fails: bool = True,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Entry + protective SL/TP (best-effort)."""
        try:
            self._check_circuit_breaker()
            
            sym = self._s(symbol).strip()
            entry_side = self._norm_side(side)
            close_side = self._close_side(entry_side)
            
            # Create tracking order
            order = self._create_complex_order(
                order_type="bracket",
                symbol=sym,
                side=entry_side,
                qty=float(qty),
                tags=tags or [],
                metadata=metadata or {}
            )
            
            position_side = self._maybe_position_side(pos_side)
            created_triggers: List[OrderLeg] = []
            
            out: Dict[str, Any] = {
                "ok": True,
                "kind": "bracket",
                "order_id": order.order_id,
                "symbol": sym,
                "entry_side": entry_side,
                "close_side": close_side,
                "qty": float(qty),
                "entry_price": float(entry_price),
                "sl_price": float(sl_price),
                "tp_price": float(tp_price),
                "legs": {},
                "errors": [],
            }
            
            # 1) Entry Leg
            entry_leg: Optional[OrderLeg] = None
            try:
                entry = self._retry_call(
                    self.client.create_order,
                    sym,
                    str(entry_type),
                    entry_side,
                    float(qty),
                    float(entry_price),
                    params={},
                    retries=1,
                )
                
                entry_id = (entry or {}).get("id")
                if entry_id:
                    entry_leg = OrderLeg(
                        leg_id="entry",
                        order_id=str(entry_id),
                        leg_type="entry",
                        symbol=sym,
                        side=entry_side,
                        qty=float(qty),
                        price=float(entry_price)
                    )
                    order.add_leg(entry_leg)
                    out["legs"]["entry"] = entry_leg.to_dict()
                else:
                    raise Exception("No order ID returned for entry")
                    
            except Exception as e:
                out["ok"] = False
                out["errors"].append(f"ENTRY:{type(e).__name__}:{e}")
                self._log_warn(f"{sym}: entry failed: {type(e).__name__}: {e}")
                order.update_status("error")
                self._add_order_to_history(order, out)
                self.metrics["failed_orders"] += 1
                return out
            
            # 2) Stop Loss Leg
            try:
                sl = self._retry_call(
                    self.client.create_order,
                    sym,
                    "STOP_MARKET",
                    close_side,
                    float(qty),
                    None,
                    params={
                        "reduceOnly": True,
                        **self._trigger_params(float(sl_price)),
                        **position_side,
                    },
                    retries=1,
                )
                
                sid = (sl or {}).get("id")
                if sid:
                    sl_leg = OrderLeg(
                        leg_id="stop_loss",
                        order_id=str(sid),
                        leg_type="stop_loss",
                        symbol=sym,
                        side=close_side,
                        qty=float(qty),
                        trigger_price=float(sl_price)
                    )
                    order.add_leg(sl_leg)
                    created_triggers.append(sl_leg)
                    out["legs"]["stop_loss"] = sl_leg.to_dict()
            except Exception as e:
                out["ok"] = False
                out["errors"].append(f"SL:{type(e).__name__}:{e}")
                self._log_warn(f"{sym}: SL failed: {type(e).__name__}: {e}")
            
            # 3) Take Profit Leg
            try:
                tp = self._retry_call(
                    self.client.create_order,
                    sym,
                    "TAKE_PROFIT_MARKET",
                    close_side,
                    float(qty),
                    None,
                    params={
                        "reduceOnly": True,
                        **self._trigger_params(float(tp_price)),
                        **position_side,
                    },
                    retries=1,
                )
                
                tid = (tp or {}).get("id")
                if tid:
                    tp_leg = OrderLeg(
                        leg_id="take_profit",
                        order_id=str(tid),
                        leg_type="take_profit",
                        symbol=sym,
                        side=close_side,
                        qty=float(qty),
                        trigger_price=float(tp_price)
                    )
                    order.add_leg(tp_leg)
                    created_triggers.append(tp_leg)
                    out["legs"]["take_profit"] = tp_leg.to_dict()
            except Exception as e:
                out["ok"] = False
                out["errors"].append(f"TP:{type(e).__name__}:{e}")
                self._log_warn(f"{sym}: TP failed: {type(e).__name__}: {e}")
            
            # 4) Check protection legs and handle partial creation
            has_sl = "stop_loss" in out["legs"]
            has_tp = "take_profit" in out["legs"]
            protection_ok = has_sl and has_tp
            
            if rollback_on_partial and not protection_ok:
                self._log_warn(f"{sym}: bracket protection partial; attempting rollback triggers")
                
                # Cancel created triggers
                for leg in created_triggers:
                    self.cancel_order_safe(sym, leg.order_id)
                    order.remove_leg(leg.leg_id)
                
                out["errors"].append("rollback_partial_bracket")
                out["ok"] = False
                
                if cancel_entry_if_protection_fails and entry_leg:
                    self._log_warn(f"{sym}: cancelling entry due to missing protection")
                    if self.cancel_order_safe(sym, entry_leg.order_id):
                        order.remove_leg(entry_leg.leg_id)
                    out["errors"].append("cancelled_entry_due_to_protection_failure")
                    order.update_status("cancelled")
                else:
                    order.update_status("partial")
            
            # Update order status and metrics
            if out["ok"]:
                order.update_status("active")
                self.metrics["successful_orders"] += 1
                self._record_success()
            else:
                order.update_status("error")
                self.metrics["failed_orders"] += 1
                # Move errored orders to history
                self._add_order_to_history(order, out)
                if order.order_id in self.active_orders:
                    del self.active_orders[order.order_id]
            
            return out
            
        except Exception as e:
            self._record_failure()
            self.metrics["failed_orders"] += 1
            return {
                "ok": False,
                "kind": "bracket",
                "symbol": symbol,
                "error": f"Circuit breaker or unexpected error: {type(e).__name__}: {e}",
                "errors": [f"INIT:{type(e).__name__}:{e}"]
            }

    # -------------------------
    # Grid Orders (Enhanced)
    # -------------------------
    def create_grid_orders(
        self,
        symbol: str,
        side: str,
        qty: float,
        levels: int,
        spacing_pct: float,
        mid_price: Optional[float] = None,
        *,
        order_type: str = "limit",
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a grid of orders.
        Returns detailed information about created grid.
        """
        try:
            self._check_circuit_breaker()
            
            sym = self._s(symbol).strip()
            entry_side = self._norm_side(side)
            lv = max(1, int(levels))
            sp = float(spacing_pct)
            
            # Get mid price if not provided
            if mid_price is None or float(mid_price) <= 0:
                try:
                    if hasattr(self.client, "fetch_ticker"):
                        t = self.client.fetch_ticker(sym)
                        mid_price = float((t or {}).get("last") or (t or {}).get("close") or 0.0)
                except Exception:
                    mid_price = 0.0
            
            mp = float(mid_price or 0.0)
            
            if mp <= 0:
                return {
                    "ok": False,
                    "kind": "grid",
                    "symbol": sym,
                    "error": "Could not determine mid price for grid",
                    "errors": ["NO_MID_PRICE"]
                }
            
            # Create tracking order
            order = self._create_complex_order(
                order_type="grid",
                symbol=sym,
                side=entry_side,
                qty=float(qty) * lv,  # Total qty across all levels
                tags=tags or [],
                metadata={
                    **(metadata or {}),
                    "levels": lv,
                    "spacing_pct": sp,
                    "mid_price": mp
                }
            )
            
            # Calculate price ladder
            ladder: List[Dict[str, Any]] = []
            created_orders: List[OrderLeg] = []
            errors: List[str] = []
            
            for i in range(1, lv + 1):
                # Calculate price for this level
                off = (sp / 100.0) * float(i)
                if entry_side == "buy":
                    px = mp * (1.0 - off)
                else:
                    px = mp * (1.0 + off)
                
                # Create order for this level
                try:
                    order_result = self._retry_call(
                        self.client.create_order,
                        sym,
                        order_type,
                        entry_side,
                        float(qty),
                        float(px),
                        params={},
                        retries=1,
                    )
                    
                    order_id = (order_result or {}).get("id")
                    if order_id:
                        leg = OrderLeg(
                            leg_id=f"grid_{i}",
                            order_id=str(order_id),
                            leg_type="grid_level",
                            symbol=sym,
                            side=entry_side,
                            qty=float(qty),
                            price=float(px),
                            params={"level": i, "spacing_pct": sp}
                        )
                        order.add_leg(leg)
                        created_orders.append(leg)
                        ladder.append({
                            "level": i,
                            "price": float(px),
                            "side": entry_side,
                            "order_id": order_id,
                            "status": "created"
                        })
                    else:
                        errors.append(f"Level {i}: No order ID returned")
                        
                except Exception as e:
                    errors.append(f"Level {i}: {type(e).__name__}: {e}")
                    ladder.append({
                        "level": i,
                        "price": float(px),
                        "side": entry_side,
                        "error": f"{type(e).__name__}: {str(e)[:100]}",
                        "status": "failed"
                    })
            
            # Determine overall success
            success_count = len(created_orders)
            out = {
                "ok": success_count > 0,
                "kind": "grid",
                "order_id": order.order_id,
                "symbol": sym,
                "side": entry_side,
                "levels": int(lv),
                "spacing_pct": float(sp),
                "mid_price": float(mp),
                "created": success_count,
                "failed": lv - success_count,
                "ladder": ladder,
                "errors": errors,
            }
            
            # Update order status and metrics
            if success_count > 0:
                if success_count == lv:
                    order.update_status("active")
                    self.metrics["successful_orders"] += 1
                    self._record_success()
                else:
                    order.update_status("partial")
                    out["partial"] = True
                    self.metrics["successful_orders"] += 1
            else:
                order.update_status("error")
                self.metrics["failed_orders"] += 1
                # Remove from active orders if complete failure
                if order.order_id in self.active_orders:
                    del self.active_orders[order.order_id]
            
            return out
            
        except Exception as e:
            self._record_failure()
            self.metrics["failed_orders"] += 1
            return {
                "ok": False,
                "kind": "grid",
                "symbol": symbol,
                "error": f"Circuit breaker or unexpected error: {type(e).__name__}: {e}",
                "errors": [f"INIT:{type(e).__name__}:{e}"]
            }

    def manage_grid_orders(self, symbol: str, side: str, levels: int, spacing_pct: float, mid_price: Optional[float] = None) -> Dict[str, Any]:
        """
        Placeholder grid scaffold (does NOT auto-place orders by default).
        Returns proposed price ladder for UI / strategy planner.
        """
        sym = self._s(symbol).strip()
        entry_side = self._norm_side(side)
        lv = max(1, int(levels))
        sp = float(spacing_pct)

        if mid_price is None or float(mid_price) <= 0:
            # Try best-effort last price fetch if client exposes it
            try:
                if hasattr(self.client, "fetch_ticker"):
                    t = self.client.fetch_ticker(sym)
                    mid_price = float((t or {}).get("last") or (t or {}).get("close") or 0.0)
            except Exception:
                mid_price = 0.0

        mp = float(mid_price or 0.0)

        ladder: List[Dict[str, Any]] = []
        if mp > 0 and sp > 0:
            for i in range(1, lv + 1):
                off = (sp / 100.0) * float(i)
                if entry_side == "buy":
                    px = mp * (1.0 - off)
                else:
                    px = mp * (1.0 + off)
                ladder.append({"level": i, "price": float(px), "side": entry_side})

        return {
            "ok": True,
            "kind": "grid_scaffold",
            "symbol": sym,
            "side": entry_side,
            "levels": int(lv),
            "spacing_pct": float(sp),
            "mid_price": float(mp) if mp > 0 else None,
            "ladder": ladder,
            "note": "Grid scaffold only (no orders placed).",
        }

    # -------------------------
    # Simple Order Wrapper (Enhanced)
    # -------------------------
    def create_simple_order(
        self,
        symbol: str,
        side: str,
        qty: float,
        price: Optional[float] = None,
        order_type: str = "market",
        *,
        reduce_only: bool = False,
        pos_side: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a simple order with enhanced tracking and error handling.
        """
        try:
            self._check_circuit_breaker()
            
            sym = self._s(symbol).strip()
            order_side = self._norm_side(side)
            
            # Create tracking order
            order = self._create_complex_order(
                order_type="simple",
                symbol=sym,
                side=order_side,
                qty=float(qty),
                tags=tags or [],
                metadata={
                    **(metadata or {}),
                    "order_type": order_type,
                    "reduce_only": reduce_only
                }
            )
            
            # Prepare parameters
            params = {}
            if reduce_only:
                params["reduceOnly"] = True
            
            position_side = self._maybe_position_side(pos_side)
            if position_side:
                params.update(position_side)
            
            # Create the order
            try:
                result = self._retry_call(
                    self.client.create_order,
                    sym,
                    order_type,
                    order_side,
                    float(qty),
                    float(price) if price is not None else None,
                    params=params,
                    retries=2
                )
                
                order_id = (result or {}).get("id")
                if order_id:
                    # Create leg for this simple order
                    leg = OrderLeg(
                        leg_id="main",
                        order_id=str(order_id),
                        leg_type=order_type,
                        symbol=sym,
                        side=order_side,
                        qty=float(qty),
                        price=float(price) if price is not None else None,
                        params=params
                    )
                    order.add_leg(leg)
                    
                    out = {
                        "ok": True,
                        "kind": "simple",
                        "order_id": order.order_id,
                        "leg_id": leg.leg_id,
                        "exchange_order_id": order_id,
                        "symbol": sym,
                        "side": order_side,
                        "qty": float(qty),
                        "price": float(price) if price is not None else None,
                        "order_type": order_type,
                        "result": result,
                    }
                    
                    order.update_status("active")
                    self.metrics["successful_orders"] += 1
                    self._record_success()
                    
                    return out
                else:
                    raise Exception("No order ID returned from exchange")
                    
            except Exception as e:
                order.update_status("error")
                self.metrics["failed_orders"] += 1
                self._record_failure()
                
                return {
                    "ok": False,
                    "kind": "simple",
                    "order_id": order.order_id,
                    "symbol": sym,
                    "error": f"Order creation failed: {type(e).__name__}: {e}",
                    "errors": [f"CREATE:{type(e).__name__}:{e}"]
                }
                
        except Exception as e:
            self._record_failure()
            self.metrics["failed_orders"] += 1
            
            return {
                "ok": False,
                "kind": "simple",
                "symbol": symbol,
                "error": f"Circuit breaker or unexpected error: {type(e).__name__}: {e}",
                "errors": [f"INIT:{type(e).__name__}:{e}"]
            }

    # -------------------------
    # Order Status & Sync
    # -------------------------
    def sync_order_status(self, symbol: str, order_id: str) -> Optional[Dict[str, Any]]:
        """
        Sync order status from exchange and update local tracking.
        """
        try:
            if hasattr(self.client, "fetch_order"):
                order_info = self._retry_call(
                    self.client.fetch_order,
                    order_id,
                    symbol,
                    retries=1,
                    exponential_backoff=False
                )
                
                # Update local tracking if this order is tracked
                for order in self.active_orders.values():
                    for leg in order.legs.values():
                        if leg.order_id == order_id:
                            # Update leg status
                            status = (order_info or {}).get("status", "").lower()
                            leg.update_status(
                                status,
                                filled_qty=float((order_info or {}).get("filled", 0.0)),
                                avg_fill_price=float((order_info or {}).get("average", 0.0)) or None,
                                fees=float((order_info or {}).get("fee", {}).get("cost", 0.0))
                            )
                            
                            # Update overall order status
                            active_legs = order.get_active_legs()
                            if not active_legs:
                                order.update_status("filled" if status == "closed" else status)
                            
                            return {
                                "ok": True,
                                "order_id": order_id,
                                "symbol": symbol,
                                "status": status,
                                "filled": float((order_info or {}).get("filled", 0.0)),
                                "remaining": float((order_info or {}).get("remaining", 0.0)),
                                "average": float((order_info or {}).get("average", 0.0)),
                                "leg_updated": leg.leg_id,
                                "order_updated": order.order_id
                            }
                
                return {
                    "ok": True,
                    "order_id": order_id,
                    "symbol": symbol,
                    "status": (order_info or {}).get("status", "unknown"),
                    "note": "Order not tracked locally"
                }
                
        except Exception as e:
            return {
                "ok": False,
                "order_id": order_id,
                "symbol": symbol,
                "error": f"Failed to sync order: {type(e).__name__}: {e}"
            }
        
        return None

    def sync_all_active_orders(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Sync status of all active orders from exchange.
        """
        synced = []
        failed = []
        
        for order in self.active_orders.values():
            if symbol and order.symbol != symbol:
                continue
            
            for leg in order.legs.values():
                result = self.sync_order_status(order.symbol, leg.order_id)
                if result and result.get("ok"):
                    synced.append({
                        "order_id": order.order_id,
                        "leg_id": leg.leg_id,
                        "exchange_order_id": leg.order_id,
                        "status": result.get("status")
                    })
                else:
                    failed.append({
                        "order_id": order.order_id,
                        "leg_id": leg.leg_id,
                        "exchange_order_id": leg.order_id,
                        "error": result.get("error") if result else "Unknown error"
                    })
        
        return {
            "synced": synced,
            "failed": failed,
            "synced_count": len(synced),
            "failed_count": len(failed)
        }

    # -------------------------
    # Metrics & Reporting
    # -------------------------
    def get_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics"""
        now = time.time()
        metrics = self.metrics.copy()
        
        # Calculate additional metrics
        if metrics["total_orders"] > 0:
            metrics["success_rate"] = metrics["successful_orders"] / metrics["total_orders"]
            metrics["failure_rate"] = metrics["failed_orders"] / metrics["total_orders"]
            metrics["avg_retries_per_order"] = metrics["retry_count"] / metrics["total_orders"]
        else:
            metrics["success_rate"] = 0.0
            metrics["failure_rate"] = 0.0
            metrics["avg_retries_per_order"] = 0.0
        
        metrics["active_orders_count"] = len(self.active_orders)
        metrics["history_size"] = len(self.order_history)
        metrics["circuit_breaker"] = self.get_circuit_breaker_status()
        metrics["uptime"] = now - self.metrics.get("init_time", now)
        
        return metrics

    def get_detailed_report(self) -> Dict[str, Any]:
        """Get detailed report of order manager state"""
        now = time.time()
        
        # Categorize active orders by type and status
        order_summary = {}
        for order in self.active_orders.values():
            order_type = order.order_type
            if order_type not in order_summary:
                order_summary[order_type] = {
                    "count": 0,
                    "by_status": {},
                    "total_qty": 0.0
                }
            
            summary = order_summary[order_type]
            summary["count"] += 1
            summary["total_qty"] += order.qty
            
            status = order.status
            if status not in summary["by_status"]:
                summary["by_status"][status] = 0
            summary["by_status"][status] += 1
        
        # Analyze recent history for patterns
        recent_errors = []
        if self.order_history:
            recent = self.order_history[-50:]  # Last 50 orders
            for entry in recent:
                if not entry.get("result", {}).get("ok", True):
                    recent_errors.append({
                        "order_id": entry.get("order_id"),
                        "kind": entry.get("order_type"),
                        "error": entry.get("result", {}).get("errors", ["Unknown"])[0],
                        "time": entry.get("completed_at_iso")
                    })
        
        return {
            "timestamp": now,
            "timestamp_iso": datetime.now().isoformat(),
            "metrics": self.get_metrics(),
            "order_summary": order_summary,
            "active_orders_count": len(self.active_orders),
            "recent_errors": recent_errors[-10:],  # Last 10 errors
            "config": self.config,
            "circuit_breaker": self.get_circuit_breaker_status()
        }

    # -------------------------
    # Serialization & Persistence
    # -------------------------
    def to_dict(self, include_history: bool = False) -> Dict[str, Any]:
        """Serialize order manager state to dict"""
        state = {
            "active_orders": {oid: order.to_dict() for oid, order in self.active_orders.items()},
            "metrics": self.metrics.copy(),
            "circuit_breaker": self._circuit_breaker.copy(),
            "config": self.config.copy(),
            "timestamp": time.time(),
            "timestamp_iso": datetime.now().isoformat()
        }
        
        if include_history and self.order_history:
            state["recent_history"] = self.order_history[-100:]  # Last 100 entries
        
        return state

    @classmethod
    def from_dict(cls, client: Any, log: Any, state: Dict[str, Any]) -> "OrderManager":
        """Deserialize order manager from dict"""
        manager = cls(client, log)
        
        # Restore active orders
        active_orders_data = state.get("active_orders", {})
        for order_id, order_data in active_orders_data.items():
            # Reconstruct ComplexOrder from data
            order = ComplexOrder(
                order_id=order_data["order_id"],
                order_type=order_data["order_type"],
                symbol=order_data["symbol"],
                side=order_data["side"],
                qty=order_data["qty"],
                status=order_data["status"],
                created_at=order_data["created_at"],
                updated_at=order_data["updated_at"],
                metadata=order_data.get("metadata", {}),
                tags=order_data.get("tags", [])
            )
            
            # Reconstruct legs
            legs_data = order_data.get("legs", {})
            for leg_id, leg_data in legs_data.items():
                leg = OrderLeg(
                    leg_id=leg_data["leg_id"],
                    order_id=leg_data["order_id"],
                    leg_type=leg_data["leg_type"],
                    symbol=leg_data["symbol"],
                    side=leg_data["side"],
                    qty=leg_data["qty"],
                    price=leg_data.get("price"),
                    trigger_price=leg_data.get("trigger_price"),
                    status=leg_data["status"],
                    created_at=leg_data["created_at"],
                    updated_at=leg_data["updated_at"],
                    fees=leg_data.get("fees", 0.0),
                    filled_qty=leg_data.get("filled_qty", 0.0),
                    avg_fill_price=leg_data.get("avg_fill_price"),
                    params=leg_data.get("params", {})
                )
                order.legs[leg_id] = leg
            
            manager.active_orders[order_id] = order
        
        # Restore metrics
        manager.metrics.update(state.get("metrics", {}))
        
        # Restore circuit breaker
        manager._circuit_breaker.update(state.get("circuit_breaker", {}))
        
        # Restore config (safely)
        for key, value in state.get("config", {}).items():
            if key in manager.config:
                manager.config[key] = value
        
        return manager

    def save_state(self, filepath: str) -> bool:
        """Save order manager state to file"""
        try:
            import pickle
            state = self.to_dict(include_history=True)
            with open(filepath, 'wb') as f:
                pickle.dump(state, f)
            return True
        except Exception as e:
            self._log_error(f"Failed to save state to {filepath}: {e}")
            return False

    @classmethod
    def load_state(cls, client: Any, log: Any, filepath: str) -> Optional["OrderManager"]:
        """Load order manager state from file"""
        try:
            import pickle
            with open(filepath, 'rb') as f:
                state = pickle.load(f)
            return cls.from_dict(client, log, state)
        except Exception as e:
            log.error(f"Failed to load state from {filepath}: {e}")
            return None
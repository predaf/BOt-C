from __future__ import annotations

import time
import traceback
import inspect
import threading
import json
import sys
import statistics
from dataclasses import dataclass, asdict, field
from typing import Any, Callable, Dict, Optional, Tuple, Deque, List, Union, Set, Type
from collections import deque, defaultdict
from functools import wraps
from contextlib import contextmanager
from enum import Enum, auto
import uuid


class MetricType(Enum):
    """Types of metrics supported."""
    COUNTER = auto()
    GAUGE = auto()
    HISTOGRAM = auto()
    TIMER = auto()
    CIRCUIT_BREAKER = auto()


class TelemetryLevel(Enum):
    """Logging levels for telemetry."""
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50


@dataclass
class Tag:
    """Tag for metric classification."""
    key: str
    value: str


@dataclass
class Metric:
    """Base metric class."""
    name: str
    type: MetricType
    tags: List[Tag] = field(default_factory=list)
    description: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class CounterMetric(Metric):
    """Counter metric (increments only)."""
    value: int = 0


@dataclass
class GaugeMetric(Metric):
    """Gauge metric (can go up and down)."""
    value: float = 0.0


@dataclass
class HistogramMetric(Metric):
    """Histogram metric with statistical summaries."""
    values: Deque[float] = field(default_factory=lambda: deque(maxlen=1000))
    count: int = 0
    sum: float = 0.0
    min: float = float('inf')
    max: float = float('-inf')
    
    def add_value(self, value: float):
        """Add a value to the histogram."""
        self.values.append(value)
        self.count += 1
        self.sum += value
        self.min = min(self.min, value)
        self.max = max(self.max, value)
    
    @property
    def mean(self) -> float:
        """Calculate mean of values."""
        return self.sum / max(1, self.count)
    
    @property
    def median(self) -> float:
        """Calculate median of values."""
        if not self.values:
            return 0.0
        return float(statistics.median(self.values))
    
    @property
    def stddev(self) -> float:
        """Calculate standard deviation."""
        if len(self.values) < 2:
            return 0.0
        try:
            return float(statistics.stdev(self.values))
        except Exception:
            return 0.0


@dataclass
class TimerMetric(HistogramMetric):
    """Timer metric specialized for timing measurements."""
    unit: str = "ms"


@dataclass
class CircuitBreakerMetric(Metric):
    """Circuit breaker metric."""
    state: str = "closed"
    failures: int = 0
    successes: int = 0
    consecutive_failures: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    opened_time: float = 0.0
    half_open_attempts: int = 0


class TelemetryBackend:
    """Base class for telemetry backends."""
    
    def emit(self, metric: Metric, metadata: Dict[str, Any] = None):
        """Emit a metric to the backend."""
        pass
    
    def flush(self):
        """Flush any buffered metrics."""
        pass


class ConsoleBackend(TelemetryBackend):
    """Console output backend."""
    
    def __init__(self, format: str = "text", level: TelemetryLevel = TelemetryLevel.INFO):
        self.format = format
        self.level = level
    
    def emit(self, metric: Metric, metadata: Dict[str, Any] = None):
        if metric.type == MetricType.TIMER and isinstance(metric, TimerMetric):
            if self.format == "json":
                print(json.dumps({
                    "name": metric.name,
                    "type": metric.type.name,
                    "value": metric.mean,
                    "unit": metric.unit,
                    "count": metric.count,
                    "min": metric.min,
                    "max": metric.max,
                    "stddev": metric.stddev,
                    "timestamp": metric.timestamp,
                    "tags": [{"key": t.key, "value": t.value} for t in metric.tags]
                }))
            else:
                print(f"[TELEMETRY] {metric.name}: {metric.mean:.2f}{metric.unit} "
                      f"(count={metric.count}, min={metric.min:.2f}, max={metric.max:.2f})")


class FileBackend(TelemetryBackend):
    """File output backend."""
    
    def __init__(self, filename: str, format: str = "json"):
        self.filename = filename
        self.format = format
        self._file = None
    
    def _get_file(self):
        if self._file is None or self._file.closed:
            self._file = open(self.filename, 'a')
        return self._file
    
    def emit(self, metric: Metric, metadata: Dict[str, Any] = None):
        file = self._get_file()
        if self.format == "json":
            data = {
                "name": metric.name,
                "type": metric.type.name,
                "timestamp": metric.timestamp,
                "tags": [{"key": t.key, "value": t.value} for t in metric.tags]
            }
            
            if isinstance(metric, CounterMetric):
                data["value"] = metric.value
            elif isinstance(metric, GaugeMetric):
                data["value"] = metric.value
            elif isinstance(metric, (HistogramMetric, TimerMetric)):
                data.update({
                    "count": metric.count,
                    "mean": metric.mean,
                    "min": metric.min,
                    "max": metric.max,
                    "stddev": metric.stddev,
                    "median": metric.median
                })
                if isinstance(metric, TimerMetric):
                    data["unit"] = metric.unit
            
            file.write(json.dumps(data) + "\n")
    
    def flush(self):
        if self._file and not self._file.closed:
            self._file.flush()
    
    def close(self):
        if self._file and not self._file.closed:
            self._file.close()
            self._file = None


class HTTPBackend(TelemetryBackend):
    """HTTP backend for telemetry data."""
    
    def __init__(self, url: str, api_key: str = None, timeout: int = 5):
        self.url = url
        self.api_key = api_key
        self.timeout = timeout
        self._buffer = []
        self._max_buffer_size = 100
    
    def emit(self, metric: Metric, metadata: Dict[str, Any] = None):
        # Buffer metrics and send in batches
        self._buffer.append(metric)
        if len(self._buffer) >= self._max_buffer_size:
            self.flush()
    
    def flush(self):
        if not self._buffer:
            return
        
        try:
            import requests
            payload = {
                "metrics": [self._metric_to_dict(m) for m in self._buffer],
                "timestamp": time.time()
            }
            
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            response = requests.post(
                self.url,
                json=payload,
                headers=headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            self._buffer.clear()
            
        except ImportError:
            print("WARNING: requests library not installed, cannot send HTTP telemetry")
            self._buffer.clear()
        except Exception as e:
            print(f"WARNING: Failed to send telemetry to {self.url}: {e}")
            # Keep buffer for retry, but clear if too large
            if len(self._buffer) > self._max_buffer_size * 2:
                self._buffer.clear()
    
    def _metric_to_dict(self, metric: Metric) -> Dict[str, Any]:
        """Convert metric to dictionary."""
        data = {
            "name": metric.name,
            "type": metric.type.name,
            "timestamp": metric.timestamp,
            "tags": [{"key": t.key, "value": t.value} for t in metric.tags]
        }
        
        if isinstance(metric, CounterMetric):
            data["value"] = metric.value
        elif isinstance(metric, GaugeMetric):
            data["value"] = metric.value
        
        return data


def _safe_log(log: Any, level: str, msg: str, **kwargs) -> None:
    """Safely log a message with optional structured logging."""
    try:
        # Try structured logging first
        if hasattr(log, "log") and callable(log.log):
            log.log(getattr(logging, level.upper(), logging.INFO), msg, **kwargs)
            return
            
        # Fallback to direct method
        fn = getattr(log, level, None)
        if callable(fn):
            if kwargs:
                # Try to include extra kwargs
                try:
                    fn(f"{msg} | {kwargs}")
                except:
                    fn(msg)
            else:
                fn(msg)
            return
            
        # Last resort
        fn2 = getattr(log, "info", None)
        if callable(fn2):
            fn2(msg)
    except Exception:
        pass


def _now_ts() -> float:
    return time.time()


def _dur_ms(t0_perf: float) -> int:
    return int((time.perf_counter() - t0_perf) * 1000)


def _redact_dict(d: Dict[str, Any], redact_keys: Tuple[str, ...]) -> Dict[str, Any]:
    """Best-effort redaction for ctx/kwargs logs."""
    try:
        out: Dict[str, Any] = {}
        for k, v in (d or {}).items():
            kk = str(k).lower()
            if any(rk in kk for rk in redact_keys if rk):
                out[str(k)] = "***"
            else:
                # Handle nested dictionaries
                if isinstance(v, dict):
                    out[str(k)] = _redact_dict(v, redact_keys)
                elif isinstance(v, list):
                    # Redact lists if they might contain sensitive data
                    out[str(k)] = ["***" if isinstance(item, str) and any(rk in item.lower() for rk in redact_keys if rk) else item for item in v]
                else:
                    out[str(k)] = v
        return out
    except Exception:
        return {}


def _percentile(values: Deque[int], p: float) -> int:
    """Compute percentile on a small deque without numpy."""
    if not values:
        return 0
    try:
        xs = sorted(list(values))
        if len(xs) == 1:
            return int(xs[0])
        # p in [0..100]
        p = max(0.0, min(100.0, float(p)))
        k = (len(xs) - 1) * (p / 100.0)
        lo = int(k)
        hi = min(len(xs) - 1, lo + 1)
        if hi == lo:
            return int(xs[lo])
        frac = k - lo
        return int(xs[lo] * (1.0 - frac) + xs[hi] * frac)
    except Exception:
        return int(values[-1] if values else 0)


class CircuitBreakerState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker."""
    failure_threshold: int = 5
    reset_timeout: int = 60
    half_open_max_attempts: int = 3
    half_open_success_threshold: int = 2
    backoff_factor: float = 1.5
    max_reset_timeout: int = 300


class CircuitBreaker:
    """Circuit breaker implementation with exponential backoff."""
    
    def __init__(self, name: str, config: CircuitBreakerConfig = None):
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.consecutive_failures = 0
        self.last_failure_time = 0.0
        self.last_success_time = 0.0
        self.state_change_time = 0.0
        self.half_open_attempts = 0
        self.half_open_successes = 0
        self._lock = threading.RLock()
    
    def record_success(self):
        """Record a successful operation."""
        with self._lock:
            self.success_count += 1
            self.last_success_time = time.time()
            self.consecutive_failures = 0
            
            if self.state == CircuitBreakerState.HALF_OPEN:
                self.half_open_successes += 1
                if self.half_open_successes >= self.config.half_open_success_threshold:
                    self._close()
            elif self.state == CircuitBreakerState.OPEN:
                # Check if reset timeout has passed
                if time.time() - self.state_change_time > self._get_reset_timeout():
                    self._half_open()
    
    def record_failure(self):
        """Record a failed operation."""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            self.consecutive_failures += 1
            
            if self.state == CircuitBreakerState.CLOSED:
                if self.consecutive_failures >= self.config.failure_threshold:
                    self._open()
            elif self.state == CircuitBreakerState.HALF_OPEN:
                self._open()
    
    def is_available(self) -> bool:
        """Check if circuit breaker allows operations."""
        with self._lock:
            if self.state == CircuitBreakerState.CLOSED:
                return True
            elif self.state == CircuitBreakerState.OPEN:
                # Check if we should transition to half-open
                if time.time() - self.state_change_time > self._get_reset_timeout():
                    self._half_open()
                    return True
                return False
            elif self.state == CircuitBreakerState.HALF_OPEN:
                if self.half_open_attempts < self.config.half_open_max_attempts:
                    self.half_open_attempts += 1
                    return True
                return False
            return False
    
    def _open(self):
        """Open the circuit breaker."""
        self.state = CircuitBreakerState.OPEN
        self.state_change_time = time.time()
        self.half_open_attempts = 0
        self.half_open_successes = 0
    
    def _close(self):
        """Close the circuit breaker."""
        self.state = CircuitBreakerState.CLOSED
        self.state_change_time = time.time()
        self.consecutive_failures = 0
        self.half_open_attempts = 0
        self.half_open_successes = 0
    
    def _half_open(self):
        """Transition to half-open state."""
        self.state = CircuitBreakerState.HALF_OPEN
        self.state_change_time = time.time()
        self.half_open_attempts = 0
        self.half_open_successes = 0
    
    def _get_reset_timeout(self) -> int:
        """Calculate reset timeout with exponential backoff."""
        if self.consecutive_failures <= 1:
            return self.config.reset_timeout
        
        timeout = self.config.reset_timeout * (self.config.backoff_factor ** (self.consecutive_failures - 1))
        return min(timeout, self.config.max_reset_timeout)
    
    def get_metrics(self) -> CircuitBreakerMetric:
        """Get circuit breaker metrics."""
        return CircuitBreakerMetric(
            name=self.name,
            type=MetricType.CIRCUIT_BREAKER,
            state=self.state.value,
            failures=self.failure_count,
            successes=self.success_count,
            consecutive_failures=self.consecutive_failures,
            last_failure_time=self.last_failure_time,
            last_success_time=self.last_success_time,
            opened_time=self.state_change_time if self.state == CircuitBreakerState.OPEN else 0.0,
            half_open_attempts=self.half_open_attempts
        )


@dataclass
class TelemetryStat:
    calls: int = 0
    ok: int = 0
    err: int = 0

    last_ms: int = 0
    avg_ms: float = 0.0           # running avg over ok calls (legacy)
    ewma_ms: float = 0.0          # smoother latency estimate
    max_ms: int = 0

    p95_ms: int = 0
    p99_ms: int = 0
    _lat_hist: Deque[int] = field(default_factory=lambda: deque(maxlen=256))

    last_err: str = ""
    last_err_ts: float = 0.0
    consec_err: int = 0

    disabled_until: float = 0.0
    disabled_reason: str = ""
    disable_count: int = 0

    # Additional metrics
    total_duration_ms: float = 0.0
    qps: float = 0.0  # queries per second
    last_qps_update: float = field(default_factory=time.time)
    call_count_since_update: int = 0

    # lock per stat for fine-grained contention
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # internal fields
        d.pop("_lat_hist", None)
        d.pop("_lock", None)
        d.pop("last_qps_update", None)
        d.pop("call_count_since_update", None)
        return d


class Telemetry:
    """
    Advanced in-process telemetry with circuit-breakers, metrics, and exporters.
    
    Features:
      - Counters per 'name'
      - Duration stats (avg, ewma, max, p95/p99)
      - Consecutive error tracking
      - Temporary disable per name after repeated errors (optional backoff)
      - Thread-safe
      - Multiple export backends
      - Custom metrics (counters, gauges, histograms)
      - Circuit breakers with exponential backoff
      - Health checks and alerts
    """
    
    def __init__(self, log: Any = None, enable_heartbeat: bool = True):
        self.log = log
        self._stats: Dict[str, TelemetryStat] = {}
        self._metrics: Dict[str, Metric] = {}
        self._circuit_breakers: Dict[str, CircuitBreaker] = {}
        self._backends: List[TelemetryBackend] = []
        self._default_tags: List[Tag] = []
        self._enabled: bool = True
        self._lock = threading.RLock()
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._stop_heartbeat = threading.Event()
        
        # Add console backend by default
        self.add_backend(ConsoleBackend(format="text"))
        
        if enable_heartbeat:
            self._start_heartbeat()
    
    def _start_heartbeat(self):
        """Start heartbeat thread for periodic metric collection."""
        def heartbeat():
            while not self._stop_heartbeat.is_set():
                try:
                    self.emit_heartbeat()
                    time.sleep(60)  # Emit heartbeat every minute
                except Exception as e:
                    _safe_log(self.log, "error", f"Heartbeat error: {e}")
        
        self._heartbeat_thread = threading.Thread(target=heartbeat, daemon=True, name="telemetry-heartbeat")
        self._heartbeat_thread.start()
    
    def stop(self):
        """Stop telemetry system."""
        self._stop_heartbeat.set()
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=5)
        
        # Flush all backends
        for backend in self._backends:
            try:
                backend.flush()
                if isinstance(backend, FileBackend):
                    backend.close()
            except Exception as e:
                _safe_log(self.log, "error", f"Error closing backend: {e}")
    
    def add_backend(self, backend: TelemetryBackend):
        """Add a telemetry backend."""
        with self._lock:
            self._backends.append(backend)
    
    def remove_backend(self, backend: TelemetryBackend):
        """Remove a telemetry backend."""
        with self._lock:
            if backend in self._backends:
                self._backends.remove(backend)
    
    def add_tag(self, key: str, value: str):
        """Add a default tag to all metrics."""
        with self._lock:
            self._default_tags.append(Tag(key=key, value=value))
    
    def set_enabled(self, enabled: bool):
        """Enable or disable telemetry collection."""
        with self._lock:
            self._enabled = enabled
    
    def _get(self, name: str) -> TelemetryStat:
        with self._lock:
            st = self._stats.get(name)
            if st is None:
                st = TelemetryStat()
                self._stats[name] = st
            return st
    
    def get_circuit_breaker(self, name: str, config: CircuitBreakerConfig = None) -> CircuitBreaker:
        """Get or create a circuit breaker."""
        with self._lock:
            if name not in self._circuit_breakers:
                self._circuit_breakers[name] = CircuitBreaker(name, config)
            return self._circuit_breakers[name]
    
    def create_counter(self, name: str, description: str = "", tags: List[Tag] = None) -> CounterMetric:
        """Create a counter metric."""
        with self._lock:
            metric = CounterMetric(
                name=name,
                type=MetricType.COUNTER,
                description=description,
                tags=(tags or []) + self._default_tags
            )
            self._metrics[name] = metric
            return metric
    
    def create_gauge(self, name: str, description: str = "", tags: List[Tag] = None) -> GaugeMetric:
        """Create a gauge metric."""
        with self._lock:
            metric = GaugeMetric(
                name=name,
                type=MetricType.GAUGE,
                description=description,
                tags=(tags or []) + self._default_tags
            )
            self._metrics[name] = metric
            return metric
    
    def create_timer(self, name: str, description: str = "", tags: List[Tag] = None) -> TimerMetric:
        """Create a timer metric."""
        with self._lock:
            metric = TimerMetric(
                name=name,
                type=MetricType.TIMER,
                description=description,
                tags=(tags or []) + self._default_tags
            )
            self._metrics[name] = metric
            return metric
    
    def increment_counter(self, name: str, value: int = 1, tags: List[Tag] = None):
        """Increment a counter metric."""
        if not self._enabled:
            return
        
        with self._lock:
            if name not in self._metrics or not isinstance(self._metrics[name], CounterMetric):
                self.create_counter(name, tags=tags)
            
            metric = self._metrics[name]
            if isinstance(metric, CounterMetric):
                metric.value += value
                metric.timestamp = time.time()
                self._emit_metric(metric)
    
    def set_gauge(self, name: str, value: float, tags: List[Tag] = None):
        """Set a gauge metric value."""
        if not self._enabled:
            return
        
        with self._lock:
            if name not in self._metrics or not isinstance(self._metrics[name], GaugeMetric):
                self.create_gauge(name, tags=tags)
            
            metric = self._metrics[name]
            if isinstance(metric, GaugeMetric):
                metric.value = value
                metric.timestamp = time.time()
                self._emit_metric(metric)
    
    def record_timer(self, name: str, value_ms: float, tags: List[Tag] = None):
        """Record a timer metric value."""
        if not self._enabled:
            return
        
        with self._lock:
            if name not in self._metrics or not isinstance(self._metrics[name], TimerMetric):
                self.create_timer(name, tags=tags)
            
            metric = self._metrics[name]
            if isinstance(metric, TimerMetric):
                metric.add_value(value_ms)
                metric.timestamp = time.time()
                self._emit_metric(metric)
    
    def _emit_metric(self, metric: Metric, metadata: Dict[str, Any] = None):
        """Emit metric to all backends."""
        if not self._enabled:
            return
        
        for backend in self._backends:
            try:
                backend.emit(metric, metadata)
            except Exception as e:
                _safe_log(self.log, "error", f"Failed to emit metric to backend: {e}")
    
    def flush(self):
        """Flush all backends."""
        for backend in self._backends:
            try:
                backend.flush()
            except Exception as e:
                _safe_log(self.log, "error", f"Failed to flush backend: {e}")
    
    def clear(self, name: Optional[str] = None) -> None:
        """Clear one stat bucket or all."""
        with self._lock:
            if name is None:
                self._stats.clear()
                self._metrics.clear()
                self._circuit_breakers.clear()
            else:
                self._stats.pop(name, None)
                self._metrics.pop(name, None)
                self._circuit_breakers.pop(name, None)
    
    def is_disabled(self, name: str) -> Tuple[bool, float, str]:
        st = self._get(name)
        now = _now_ts()
        with st._lock:
            if st.disabled_until and now < st.disabled_until:
                return True, float(st.disabled_until), str(st.disabled_reason)
            # auto re-enable
            if st.disabled_until and now >= st.disabled_until:
                st.disabled_until = 0.0
                st.disabled_reason = ""
            return False, 0.0, ""
    
    def disable_for(self, name: str, sec: int, reason: str = "") -> None:
        st = self._get(name)
        until = _now_ts() + float(sec)
        with st._lock:
            st.disabled_until = until
            st.disabled_reason = str(reason)[:400]
            st.disable_count += 1
        
        # Also emit a gauge metric for disabled state
        self.set_gauge(f"{name}_disabled", 1.0, tags=[Tag("reason", reason[:100])])
        
        if self.log:
            _safe_log(self.log, "warning", f"[telemetry] DISABLE {name} for {sec}s reason={st.disabled_reason}")
    
    def enable(self, name: str) -> None:
        """Explicitly enable a disabled component."""
        st = self._get(name)
        with st._lock:
            st.disabled_until = 0.0
            st.disabled_reason = ""
        
        # Emit gauge metric for enabled state
        self.set_gauge(f"{name}_disabled", 0.0)
        
        if self.log:
            _safe_log(self.log, "info", f"[telemetry] ENABLED {name}")
    
    def snapshot(self) -> Dict[str, Dict[str, Any]]:
        """Thread-safe snapshot for API/UI."""
        out: Dict[str, Dict[str, Any]] = {}
        with self._lock:
            items = list(self._stats.items())
        for k, st in items:
            with st._lock:
                out[k] = st.to_dict()
        return out
    
    def get_metrics_snapshot(self) -> Dict[str, Any]:
        """Get snapshot of all metrics."""
        with self._lock:
            metrics_data = {}
            for name, metric in self._metrics.items():
                metrics_data[name] = self._metric_to_dict(metric)
            
            # Add circuit breaker metrics
            for name, cb in self._circuit_breakers.items():
                metrics_data[f"circuit_breaker_{name}"] = self._metric_to_dict(cb.get_metrics())
            
            return metrics_data
    
    def _metric_to_dict(self, metric: Metric) -> Dict[str, Any]:
        """Convert any metric to dictionary."""
        data = {
            "name": metric.name,
            "type": metric.type.name,
            "timestamp": metric.timestamp,
            "tags": [{"key": t.key, "value": t.value} for t in metric.tags]
        }
        
        if isinstance(metric, CounterMetric):
            data["value"] = metric.value
        elif isinstance(metric, GaugeMetric):
            data["value"] = metric.value
        elif isinstance(metric, HistogramMetric):
            data.update({
                "count": metric.count,
                "mean": metric.mean,
                "min": metric.min,
                "max": metric.max,
                "stddev": metric.stddev,
                "median": metric.median
            })
            if isinstance(metric, TimerMetric):
                data["unit"] = metric.unit
        elif isinstance(metric, CircuitBreakerMetric):
            data.update({
                "state": metric.state,
                "failures": metric.failures,
                "successes": metric.successes,
                "consecutive_failures": metric.consecutive_failures,
                "half_open_attempts": metric.half_open_attempts
            })
        
        return data
    
    def emit_heartbeat(self):
        """Emit heartbeat metrics."""
        if not self._enabled:
            return
        
        # Emit system metrics
        try:
            import psutil
            self.set_gauge("system.cpu_percent", psutil.cpu_percent())
            self.set_gauge("system.memory_percent", psutil.virtual_memory().percent)
            self.set_gauge("system.disk_usage", psutil.disk_usage('/').percent)
        except ImportError:
            pass  # psutil not available
        
        # Emit Python runtime metrics
        import gc
        self.set_gauge("python.gc_objects", len(gc.get_objects()))
        self.set_gauge("python.memory_allocated", sys.getsizeof({}))
        
        # Emit thread count
        self.set_gauge("system.thread_count", threading.active_count())
    
    def health_check(self) -> Dict[str, Any]:
        """Perform health check of telemetry system."""
        health = {
            "status": "healthy",
            "timestamp": time.time(),
            "components": {
                "enabled": self._enabled,
                "backends_count": len(self._backends),
                "metrics_count": len(self._metrics),
                "circuit_breakers_count": len(self._circuit_breakers),
                "stats_count": len(self._stats),
            },
            "issues": []
        }
        
        # Check for disabled components
        disabled_components = []
        for name, stat in list(self._stats.items()):
            with stat._lock:
                if stat.disabled_until and time.time() < stat.disabled_until:
                    disabled_components.append({
                        "name": name,
                        "until": stat.disabled_until,
                        "reason": stat.disabled_reason
                    })
        
        if disabled_components:
            health["status"] = "degraded"
            health["disabled_components"] = disabled_components
            health["issues"].append(f"{len(disabled_components)} components are disabled")
        
        # Check circuit breakers
        open_circuit_breakers = []
        for name, cb in self._circuit_breakers.items():
            if cb.state == CircuitBreakerState.OPEN:
                open_circuit_breakers.append(name)
        
        if open_circuit_breakers:
            health["status"] = "degraded"
            health["open_circuit_breakers"] = open_circuit_breakers
            health["issues"].append(f"{len(open_circuit_breakers)} circuit breakers are open")
        
        return health


def instrument(
    name: str,
    *,
    degrade: Optional[Callable[..., Any]] = None,
    disable_after: int = 5,
    disable_sec: int = 60,
    backoff: bool = True,
    backoff_cap_sec: int = 15 * 60,
    ewma_alpha: float = 0.25,
    log_args: bool = False,
    ctx_builder: Optional[Callable[..., Dict[str, Any]]] = None,
    redact_keys: Tuple[str, ...] = ("key", "secret", "token", "password", "pass", "api_key", "apikey"),
    tags: List[Tag] = None,
    use_circuit_breaker: bool = False,
    circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
):
    """
    Decorator to instrument a method/function.
    
    Expectations:
      - Preferably first positional arg is `self` and it has `self.telemetry: Telemetry`.
      - Alternatively you can pass telemetry=Telemetry(...) in kwargs.
    
    Behavior:
      - rate stats recorded on success and error
      - circuit-breaker: disable name after N consecutive errors
      - degrade() is optional fallback; if used, it receives same args/kwargs.
        Additionally it may inspect kwargs["_telemetry_exc"] for the exception object.
    
    Supports async functions too.
    """
    
    disable_after = max(1, int(disable_after))
    disable_sec = max(1, int(disable_sec))
    backoff_cap_sec = max(disable_sec, int(backoff_cap_sec))
    ewma_alpha = max(0.01, min(0.99, float(ewma_alpha)))
    
    def _compute_disable_sec(st: TelemetryStat) -> int:
        if not backoff:
            return int(disable_sec)
        # exponential-ish: base * 2^(disable_count-1), capped
        try:
            mul = 2 ** max(0, int(st.disable_count))
            return int(min(backoff_cap_sec, int(disable_sec) * mul))
        except Exception:
            return int(disable_sec)
    
    def _get_tel(args, kwargs) -> Optional[Telemetry]:
        tel: Optional[Telemetry] = None
        if args:
            tel = getattr(args[0], "telemetry", None)
        if tel is None:
            tel = kwargs.get("telemetry", None)
        return tel
    
    def _update_qps(st: TelemetryStat):
        """Update queries per second metric."""
        now = time.time()
        time_diff = now - st.last_qps_update
        if time_diff >= 1.0:  # Update QPS every second
            st.qps = st.call_count_since_update / time_diff
            st.last_qps_update = now
            st.call_count_since_update = 0
    
    def _on_ok(tel: Telemetry, st: TelemetryStat, ms: int) -> None:
        with st._lock:
            st.ok += 1
            st.last_ms = int(ms)
            st.max_ms = max(int(st.max_ms), int(ms))
            st.total_duration_ms += ms
            # running avg over ok
            st.avg_ms = st.total_duration_ms / max(1, st.ok)
            # ewma
            st.ewma_ms = (st.ewma_ms * (1.0 - ewma_alpha)) + (ms * ewma_alpha) if st.ewma_ms > 0 else float(ms)
            # percentiles
            st._lat_hist.append(int(ms))
            st.p95_ms = _percentile(st._lat_hist, 95.0)
            st.p99_ms = _percentile(st._lat_hist, 99.0)
            # reset consecutive errors
            st.consec_err = 0
            # update QPS
            st.call_count_since_update += 1
            _update_qps(st)
        
        # Record timer metric if telemetry supports it
        if tel:
            tel.record_timer(f"{name}_duration", ms, tags=tags)
            tel.increment_counter(f"{name}_success", 1, tags=tags)
    
    def _on_err(tel: Telemetry, st: TelemetryStat, ms: int, e: Exception, ctx: Dict[str, Any], args, kwargs) -> None:
        now = _now_ts()
        with st._lock:
            st.err += 1
            st.last_ms = int(ms)
            st.max_ms = max(int(st.max_ms), int(ms))
            st.last_err = f"{type(e).__name__}: {e}"
            st.last_err_ts = float(now)
            st.consec_err += 1
            consec = int(st.consec_err)
            # update QPS
            st.call_count_since_update += 1
            _update_qps(st)
        
        # Record error metric
        if tel:
            tel.increment_counter(f"{name}_error", 1, tags=tags + [Tag("error_type", type(e).__name__)] if tags else [Tag("error_type", type(e).__name__)])
        
        if consec >= int(disable_after):
            sec = _compute_disable_sec(st)
            tel.disable_for(name, sec, reason=st.last_err)
        
        if tel and tel.log:
            try:
                extra = ""
                if log_args:
                    # redact possibly sensitive content
                    safe_kwargs = _redact_dict(dict(kwargs or {}), redact_keys)
                    extra += f" kwargs={safe_kwargs}"
                if ctx:
                    extra += f" ctx={_redact_dict(ctx, redact_keys)}"
                _safe_log(tel.log, "error", f"[telemetry] {name} failed ({ms}ms): {st.last_err}{extra}")
                _safe_log(tel.log, "debug", traceback.format_exc())
            except Exception:
                pass
    
    def deco(fn: Callable[..., Any]):
        is_async = inspect.iscoroutinefunction(fn)
        
        if is_async:
            @wraps(fn)
            async def awrapper(*args, **kwargs):
                tel = _get_tel(args, kwargs)
                if tel is None:
                    return await fn(*args, **kwargs)
                
                # Check circuit breaker if enabled
                if use_circuit_breaker:
                    cb = tel.get_circuit_breaker(name, circuit_breaker_config)
                    if not cb.is_available():
                        if degrade is not None:
                            kwargs["_telemetry_exc"] = RuntimeError(f"Circuit breaker open for {name}")
                            return degrade(*args, **kwargs)
                        raise RuntimeError(f"Circuit breaker open for {name}")
                
                disabled, until, reason = tel.is_disabled(name)
                if disabled:
                    if degrade is not None:
                        kwargs["_telemetry_exc"] = RuntimeError(f"{name} disabled until {until}: {reason}")
                        return degrade(*args, **kwargs)
                    raise RuntimeError(f"{name} disabled until {until}: {reason}")
                
                st = tel._get(name)
                t0 = time.perf_counter()
                
                with st._lock:
                    st.calls += 1
                
                ctx: Dict[str, Any] = {}
                if ctx_builder is not None:
                    try:
                        ctx = ctx_builder(*args, **kwargs) or {}
                    except Exception:
                        ctx = {}
                
                try:
                    out = await fn(*args, **kwargs)
                    ms = _dur_ms(t0)
                    _on_ok(tel, st, ms)
                    
                    # Record circuit breaker success
                    if use_circuit_breaker:
                        cb = tel.get_circuit_breaker(name, circuit_breaker_config)
                        cb.record_success()
                    
                    return out
                except Exception as e:
                    ms = _dur_ms(t0)
                    _on_err(tel, st, ms, e, ctx, args, kwargs)
                    
                    # Record circuit breaker failure
                    if use_circuit_breaker:
                        cb = tel.get_circuit_breaker(name, circuit_breaker_config)
                        cb.record_failure()
                    
                    if degrade is not None:
                        kwargs["_telemetry_exc"] = e
                        return degrade(*args, **kwargs)
                    raise
            
            return awrapper
        
        @wraps(fn)
        def swrapper(*args, **kwargs):
            tel = _get_tel(args, kwargs)
            if tel is None:
                return fn(*args, **kwargs)
            
            # Check circuit breaker if enabled
            if use_circuit_breaker:
                cb = tel.get_circuit_breaker(name, circuit_breaker_config)
                if not cb.is_available():
                    if degrade is not None:
                        kwargs["_telemetry_exc"] = RuntimeError(f"Circuit breaker open for {name}")
                        return degrade(*args, **kwargs)
                    raise RuntimeError(f"Circuit breaker open for {name}")
            
            disabled, until, reason = tel.is_disabled(name)
            if disabled:
                if degrade is not None:
                    kwargs["_telemetry_exc"] = RuntimeError(f"{name} disabled until {until}: {reason}")
                    return degrade(*args, **kwargs)
                raise RuntimeError(f"{name} disabled until {until}: {reason}")
            
            st = tel._get(name)
            t0 = time.perf_counter()
            
            with st._lock:
                st.calls += 1
            
            ctx: Dict[str, Any] = {}
            if ctx_builder is not None:
                try:
                    ctx = ctx_builder(*args, **kwargs) or {}
                except Exception:
                    ctx = {}
            
            try:
                out = fn(*args, **kwargs)
                ms = _dur_ms(t0)
                _on_ok(tel, st, ms)
                
                # Record circuit breaker success
                if use_circuit_breaker:
                    cb = tel.get_circuit_breaker(name, circuit_breaker_config)
                    cb.record_success()
                
                return out
            except Exception as e:
                ms = _dur_ms(t0)
                _on_err(tel, st, ms, e, ctx, args, kwargs)
                
                # Record circuit breaker failure
                if use_circuit_breaker:
                    cb = tel.get_circuit_breaker(name, circuit_breaker_config)
                    cb.record_failure()
                
                if degrade is not None:
                    kwargs["_telemetry_exc"] = e
                    return degrade(*args, **kwargs)
                raise
        
        return swrapper
    
    return deco


@contextmanager
def timed_section(name: str, telemetry: Telemetry = None, tags: List[Tag] = None):
    """
    Context manager for timing a code section.
    
    Example:
        with timed_section("database_query", telemetry):
            result = db.query(...)
    """
    start_time = time.perf_counter()
    try:
        yield
    finally:
        duration_ms = (time.perf_counter() - start_time) * 1000
        if telemetry:
            telemetry.record_timer(f"{name}_duration", duration_ms, tags=tags)


class TelemetryMiddleware:
    """Middleware for HTTP/RPC frameworks."""
    
    def __init__(self, telemetry: Telemetry, service_name: str = "api"):
        self.telemetry = telemetry
        self.service_name = service_name
    
    def http_middleware(self, request_handler):
        """Middleware for HTTP request handling."""
        def wrapper(request, *args, **kwargs):
            start_time = time.perf_counter()
            request_id = request.headers.get('X-Request-ID', str(uuid.uuid4()))
            
            tags = [
                Tag("service", self.service_name),
                Tag("request_id", request_id),
                Tag("method", getattr(request, 'method', 'UNKNOWN')),
                Tag("path", getattr(request, 'path', 'UNKNOWN'))
            ]
            
            self.telemetry.increment_counter(f"{self.service_name}.requests", 1, tags=tags)
            
            try:
                response = request_handler(request, *args, **kwargs)
                duration_ms = (time.perf_counter() - start_time) * 1000
                
                status_code = getattr(response, 'status_code', 200)
                tags.append(Tag("status_code", str(status_code)))
                
                self.telemetry.record_timer(f"{self.service_name}.request_duration", duration_ms, tags=tags)
                self.telemetry.increment_counter(f"{self.service_name}.responses", 1, tags=tags)
                
                if 500 <= status_code <= 599:
                    self.telemetry.increment_counter(f"{self.service_name}.errors", 1, tags=tags)
                
                return response
            except Exception as e:
                duration_ms = (time.perf_counter() - start_time) * 1000
                tags.append(Tag("error_type", type(e).__name__))
                
                self.telemetry.record_timer(f"{self.service_name}.request_duration", duration_ms, tags=tags)
                self.telemetry.increment_counter(f"{self.service_name}.errors", 1, tags=tags)
                raise
        
        return wrapper


# Example usage and test
if __name__ == "__main__":
    # Create telemetry with file backend
    telemetry = Telemetry(log=print)
    telemetry.add_backend(FileBackend("telemetry.log", format="json"))
    
    # Add some default tags
    telemetry.add_tag("environment", "test")
    telemetry.add_tag("version", "1.0.0")
    
    # Create some metrics
    request_counter = telemetry.create_counter("http_requests", "Total HTTP requests")
    response_time = telemetry.create_timer("http_response_time", "HTTP response times")
    
    # Use the decorator
    @instrument("fetch_data", disable_after=3, disable_sec=30, use_circuit_breaker=True)
    def fetch_data(url):
        # Simulate API call
        time.sleep(0.1)
        if "fail" in url:
            raise ValueError("Failed to fetch data")
        return {"data": "success"}
    
    # Test the function
    try:
        result = fetch_data("https://api.example.com/data", telemetry=telemetry)
        print(f"Success: {result}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test with failure
    try:
        result = fetch_data("https://api.example.com/fail", telemetry=telemetry)
    except Exception as e:
        print(f"Expected error: {e}")
    
    # Use context manager
    with timed_section("database_query", telemetry):
        time.sleep(0.05)
    
    # Get health check
    health = telemetry.health_check()
    print(f"Health: {health}")
    
    # Get metrics snapshot
    metrics = telemetry.get_metrics_snapshot()
    print(f"Metrics count: {len(metrics)}")
    
    # Cleanup
    telemetry.stop()
from __future__ import annotations

import time
import math
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple, List
from enum import Enum
import statistics
import hashlib


# ============================================================================
# TYPES AND ENUMS
# ============================================================================

class ExecutionType(Enum):
    """Tipuri de execuție"""
    MAKER = "maker"
    MARKET = "market"
    TWAP = "twap"
    ICEBERG = "iceberg"


class IntentType(Enum):
    """Tipuri de intenție"""
    ENTRY = "entry"
    EXIT = "exit"
    PROTECT = "protect"
    REBALANCE = "rebalance"
    HEDGE = "hedge"


class OrderSide(Enum):
    """Părțile ordinelor"""
    BUY = "buy"
    SELL = "sell"


class ExecutionConfidence(Enum):
    """Nivele de încredere pentru execuție"""
    HIGH = "high"      # > 0.8
    MEDIUM = "medium"  # 0.5 - 0.8
    LOW = "low"        # < 0.5
    UNKNOWN = "unknown"


@dataclass
class ExecutionPlan:
    """Plan de execuție generat de router"""
    kind: ExecutionType
    params: Dict[str, Any]
    reasons: Dict[str, Any]
    confidence: float = 1.0
    confidence_level: ExecutionConfidence = ExecutionConfidence.HIGH
    timestamp: float = field(default_factory=time.time)
    version: str = "1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire la dicționar"""
        return {
            "kind": self.kind.value,
            "params": self.params,
            "reasons": self.reasons,
            "confidence": self.confidence,
            "confidence_level": self.confidence_level.value,
            "timestamp": self.timestamp,
            "version": self.version
        }
    
    def calculate_hash(self) -> str:
        """Calculează hash-ul planului pentru comparații"""
        plan_str = f"{self.kind.value}_{self.confidence}_{self.timestamp}"
        return hashlib.md5(plan_str.encode()).hexdigest()[:8]


@dataclass
class MarketMetrics:
    """Metrici de piață calculate"""
    symbol: str
    side: OrderSide
    spread_bps: float
    slippage_bps: float
    fill_probability: float
    imbalance: float
    notional_usd: float
    atr_pct: float
    mid_price: float
    orderbook_depth: int
    bid_price: float
    ask_price: float
    last_price: float
    timestamp: float = field(default_factory=time.time)
    source: str = "orderbook"  # "orderbook" sau "fallback"
    
    def is_valid(self) -> bool:
        """Verifică dacă metricile sunt valide"""
        return all([
            math.isfinite(self.spread_bps),
            math.isfinite(self.slippage_bps),
            math.isfinite(self.fill_probability),
            self.mid_price > 0,
            self.notional_usd > 0
        ])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire la dicționar"""
        return {
            "symbol": self.symbol,
            "side": self.side.value,
            "spread_bps": self.spread_bps,
            "slippage_bps": self.slippage_bps,
            "fill_probability": self.fill_probability,
            "imbalance": self.imbalance,
            "notional_usd": self.notional_usd,
            "atr_pct": self.atr_pct,
            "mid_price": self.mid_price,
            "orderbook_depth": self.orderbook_depth,
            "bid_price": self.bid_price,
            "ask_price": self.ask_price,
            "last_price": self.last_price,
            "timestamp": self.timestamp,
            "source": self.source,
            "valid": self.is_valid()
        }


@dataclass
class ExecutionContext:
    """Context complet pentru execuție"""
    symbol: str
    side: OrderSide
    quantity: float
    intent: IntentType
    reason: str
    engine: Any
    metrics: MarketMetrics
    config: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    
    def get_key(self) -> str:
        """Generează o cheie unică pentru context"""
        key_parts = [
            self.symbol,
            self.side.value,
            str(round(self.quantity, 4)),
            self.intent.value,
            self.reason,
            str(int(self.timestamp))
        ]
        return hashlib.md5("_".join(key_parts).encode()).hexdigest()[:12]


# ============================================================================
# EXECUTION HISTORY AND ANALYTICS
# ============================================================================

class ExecutionAnalytics:
    """Analitică pentru deciziile de execuție"""
    
    def __init__(self, max_history: int = 1000):
        self.max_history = max_history
        self.history: List[Dict[str, Any]] = []
        self._lock = threading.RLock()
        self.metrics = {
            "total_decisions": 0,
            "by_type": {et.value: 0 for et in ExecutionType},
            "by_intent": {it.value: 0 for it in IntentType},
            "fallback_count": 0,
            "avg_decision_time_ms": 0.0,
            "success_rates": {},
            "confidence_distribution": {c.value: 0 for c in ExecutionConfidence}
        }
    
    def record_decision(
        self, 
        context: ExecutionContext, 
        plan: ExecutionPlan,
        decision_time_ms: float
    ) -> None:
        """Înregistrează o decizie de execuție"""
        with self._lock:
            entry = {
                "timestamp": time.time(),
                "context_key": context.get_key(),
                "symbol": context.symbol,
                "side": context.side.value,
                "intent": context.intent.value,
                "reason": context.reason,
                "execution_type": plan.kind.value,
                "confidence": plan.confidence,
                "confidence_level": plan.confidence_level.value,
                "decision_time_ms": decision_time_ms,
                "metrics": context.metrics.to_dict(),
                "plan_hash": plan.calculate_hash(),
                "notional_usd": context.metrics.notional_usd
            }
            
            self.history.append(entry)
            
            # Actualizează metrici
            self.metrics["total_decisions"] += 1
            self.metrics["by_type"][plan.kind.value] += 1
            self.metrics["by_intent"][context.intent.value] += 1
            self.metrics["confidence_distribution"][plan.confidence_level.value] += 1
            
            # Actualizează timpul mediu de decizie
            current_avg = self.metrics["avg_decision_time_ms"]
            n = self.metrics["total_decisions"]
            self.metrics["avg_decision_time_ms"] = (
                (current_avg * (n - 1) + decision_time_ms) / n
            )
            
            # Limitează istoricul
            if len(self.history) > self.max_history:
                self.history = self.history[-self.max_history:]
    
    def record_fallback(self) -> None:
        """Înregistrează utilizarea fallback-ului"""
        with self._lock:
            self.metrics["fallback_count"] += 1
    
    def get_stats(self, symbol: Optional[str] = None, 
                  time_window_sec: Optional[float] = None) -> Dict[str, Any]:
        """Obține statistici"""
        with self._lock:
            if not self.history:
                return {"total": 0}
            
            cutoff = time.time() - time_window_sec if time_window_sec else 0
            filtered = [
                h for h in self.history 
                if h["timestamp"] > cutoff and (symbol is None or h["symbol"] == symbol)
            ]
            
            if not filtered:
                return {"total": 0, "filtered": 0}
            
            # Calcul statistici
            decision_times = [h["decision_time_ms"] for h in filtered]
            confidences = [h["confidence"] for h in filtered]
            notionals = [h["notional_usd"] for h in filtered]
            
            stats = {
                "total": len(self.history),
                "filtered": len(filtered),
                "time_window_sec": time_window_sec,
                "symbol": symbol or "all",
                "by_type": {},
                "by_intent": {},
                "decision_time_ms": {
                    "avg": statistics.mean(decision_times) if decision_times else 0,
                    "median": statistics.median(decision_times) if decision_times else 0,
                    "min": min(decision_times) if decision_times else 0,
                    "max": max(decision_times) if decision_times else 0,
                    "std": statistics.stdev(decision_times) if len(decision_times) > 1 else 0
                },
                "confidence": {
                    "avg": statistics.mean(confidences) if confidences else 0,
                    "median": statistics.median(confidences) if confidences else 0,
                    "min": min(confidences) if confidences else 0,
                    "max": max(confidences) if confidences else 0
                },
                "notional_usd": {
                    "avg": statistics.mean(notionals) if notionals else 0,
                    "total": sum(notionals) if notionals else 0,
                    "min": min(notionals) if notionals else 0,
                    "max": max(notionals) if notionals else 0
                }
            }
            
            # Calculează distribuții
            for entry in filtered:
                ex_type = entry["execution_type"]
                intent = entry["intent"]
                
                stats["by_type"][ex_type] = stats["by_type"].get(ex_type, 0) + 1
                stats["by_intent"][intent] = stats["by_intent"].get(intent, 0) + 1
            
            # Convert to percentages
            total_filtered = len(filtered)
            if total_filtered > 0:
                stats["by_type_pct"] = {
                    k: (v / total_filtered * 100) 
                    for k, v in stats["by_type"].items()
                }
                stats["by_intent_pct"] = {
                    k: (v / total_filtered * 100) 
                    for k, v in stats["by_intent"].items()
                }
            
            return stats
    
    def clear_history(self) -> None:
        """Șterge istoricul"""
        with self._lock:
            self.history.clear()
            self.metrics = {
                "total_decisions": 0,
                "by_type": {et.value: 0 for et in ExecutionType},
                "by_intent": {it.value: 0 for it in IntentType},
                "fallback_count": 0,
                "avg_decision_time_ms": 0.0,
                "success_rates": {},
                "confidence_distribution": {c.value: 0 for c in ExecutionConfidence}
            }


# ============================================================================
# EXECUTION POLICY ENGINE
# ============================================================================

class ExecutionPolicy:
    """Motor de politică pentru decizii de execuție"""
    
    def __init__(self, config: Dict[str, Any], log: Any):
        self.config = config or {}
        self.log = log
        
        # Configurații
        self.router_cfg = self.config.get("router", {})
        self.twap_cfg = self.config.get("twap", {})
        
        # Praguri
        self.max_spread = float(self.router_cfg.get("max_spread_bps", 18.0))
        self.max_slip = float(self.router_cfg.get("max_slippage_bps", 25.0))
        self.min_fill = float(self.router_cfg.get("min_maker_fill_prob", 0.55))
        self.twap_auto_bps = float(self.twap_cfg.get("auto_slippage_bps", 30.0))
        self.twap_enabled = bool(self.twap_cfg.get("enabled", True))
        
        # Politici per intenție
        self.intent_policies = {
            IntentType.ENTRY: self._policy_entry,
            IntentType.EXIT: self._policy_exit,
            IntentType.PROTECT: self._policy_protect,
            IntentType.REBALANCE: self._policy_rebalance,
            IntentType.HEDGE: self._policy_hedge
        }
        
        # Override-uri
        self.force_market_reasons = set(self.router_cfg.get("force_market_reasons", []))
        self.force_kind_reasons = self.router_cfg.get("force_kind_reasons", {})
    
    def evaluate(
        self, 
        context: ExecutionContext, 
        prev_plan: Optional[ExecutionPlan] = None
    ) -> ExecutionPlan:
        """Evaluează contextul și returnează un plan de execuție"""
        
        # 1. Aplică override-uri bazate pe reason
        forced_plan = self._apply_reason_overrides(context)
        if forced_plan:
            return forced_plan
        
        # 2. Aplică politica pentru intenție
        policy_fn = self.intent_policies.get(context.intent, self._policy_default)
        base_plan = policy_fn(context)
        
        # 3. Aplică anti flip-flop dacă există plan anterior
        if prev_plan:
            base_plan = self._apply_anti_flip_flop(base_plan, prev_plan)
        
        # 4. Calculează încrederea
        base_plan.confidence = self._calculate_confidence(context, base_plan)
        base_plan.confidence_level = self._get_confidence_level(base_plan.confidence)
        
        return base_plan
    
    def _policy_entry(self, context: ExecutionContext) -> ExecutionPlan:
        """Politică pentru intenția de entry"""
        metrics = context.metrics
        
        reasons = {
            "policy": "entry_optimization",
            "rationale": "Optimizing for entry with minimal market impact"
        }
        
        # Verifică condiții pentru TWAP
        if (self.twap_enabled and 
            math.isfinite(metrics.slippage_bps) and 
            metrics.slippage_bps >= self.twap_auto_bps):
            
            reasons["decision"] = "high_slippage_twap"
            reasons["slippage_bps"] = metrics.slippage_bps
            reasons["threshold"] = self.twap_auto_bps
            
            return ExecutionPlan(
                kind=ExecutionType.TWAP,
                params={},
                reasons=reasons
            )
        
        # Verifică spread
        if math.isfinite(metrics.spread_bps) and metrics.spread_bps > self.max_spread:
            reasons["decision"] = "wide_spread_market"
            reasons["spread_bps"] = metrics.spread_bps
            reasons["threshold"] = self.max_spread
            
            return ExecutionPlan(
                kind=ExecutionType.MARKET,
                params={},
                reasons=reasons
            )
        
        # Verifică fill probability
        if math.isfinite(metrics.fill_probability) and metrics.fill_probability < self.min_fill:
            reasons["decision"] = "low_fill_probability_market"
            reasons["fill_probability"] = metrics.fill_probability
            reasons["threshold"] = self.min_fill
            
            return ExecutionPlan(
                kind=ExecutionType.MARKET,
                params={},
                reasons=reasons
            )
        
        # Verifică slippage
        if math.isfinite(metrics.slippage_bps) and metrics.slippage_bps > self.max_slip:
            if self.twap_enabled:
                reasons["decision"] = "high_impact_twap"
                reasons["slippage_bps"] = metrics.slippage_bps
                reasons["threshold"] = self.max_slip
                
                return ExecutionPlan(
                    kind=ExecutionType.TWAP,
                    params={},
                    reasons=reasons
                )
            else:
                reasons["decision"] = "high_impact_market"
                reasons["slippage_bps"] = metrics.slippage_bps
                reasons["threshold"] = self.max_slip
                
                return ExecutionPlan(
                    kind=ExecutionType.MARKET,
                    params={},
                    reasons=reasons
                )
        
        # Condiții optime pentru maker
        reasons["decision"] = "optimal_maker_conditions"
        reasons["conditions"] = {
            "spread_ok": metrics.spread_bps <= self.max_spread,
            "slippage_ok": metrics.slippage_bps <= self.max_slip,
            "fill_probability_ok": metrics.fill_probability >= self.min_fill
        }
        
        return ExecutionPlan(
            kind=ExecutionType.MAKER,
            params={},
            reasons=reasons
        )
    
    def _policy_exit(self, context: ExecutionContext) -> ExecutionPlan:
        """Politică pentru intenția de exit"""
        prefer = str(self.router_cfg.get("exit_prefer", "market")).lower().strip()
        
        reasons = {
            "policy": "exit_priority",
            "intent": "exit",
            "preference": prefer
        }
        
        if prefer == "twap" and self.twap_enabled:
            reasons["decision"] = "exit_preference_twap"
            return ExecutionPlan(
                kind=ExecutionType.TWAP,
                params={},
                reasons=reasons
            )
        else:
            reasons["decision"] = "exit_preference_market"
            return ExecutionPlan(
                kind=ExecutionType.MARKET,
                params={},
                reasons=reasons
            )
    
    def _policy_protect(self, context: ExecutionContext) -> ExecutionPlan:
        """Politică pentru intenția de protect (stop loss, etc.)"""
        reasons = {
            "policy": "protection_priority",
            "intent": "protect",
            "rationale": "Priority on execution certainty for protection orders"
        }
        
        # Pentru protecție, preferăm market orders pentru viteză
        reasons["decision"] = "protection_market_priority"
        
        return ExecutionPlan(
            kind=ExecutionType.MARKET,
            params={},
            reasons=reasons
        )
    
    def _policy_rebalance(self, context: ExecutionContext) -> ExecutionPlan:
        """Politică pentru rebalanțare"""
        reasons = {
            "policy": "rebalance_priority",
            "intent": "rebalance",
            "rationale": "Minimizing market impact for rebalancing"
        }
        
        # Pentru rebalanțare, folosim TWAP pentru impact minim
        if self.twap_enabled:
            reasons["decision"] = "rebalance_twap_priority"
            return ExecutionPlan(
                kind=ExecutionType.TWAP,
                params={},
                reasons=reasons
            )
        else:
            reasons["decision"] = "rebalance_market_fallback"
            return ExecutionPlan(
                kind=ExecutionType.MARKET,
                params={},
                reasons=reasons
            )
    
    def _policy_hedge(self, context: ExecutionContext) -> ExecutionPlan:
        """Politică pentru hedging"""
        reasons = {
            "policy": "hedge_priority",
            "intent": "hedge",
            "rationale": "Balancing speed and cost for hedging"
        }
        
        # Pentru hedging, evaluăm condițiile de piață
        if context.metrics.spread_bps > self.max_spread * 1.5:
            reasons["decision"] = "wide_spread_market_hedge"
            return ExecutionPlan(
                kind=ExecutionType.MARKET,
                params={},
                reasons=reasons
            )
        elif self.twap_enabled and context.metrics.slippage_bps > self.twap_auto_bps:
            reasons["decision"] = "high_slippage_twap_hedge"
            return ExecutionPlan(
                kind=ExecutionType.TWAP,
                params={},
                reasons=reasons
            )
        else:
            reasons["decision"] = "optimal_maker_hedge"
            return ExecutionPlan(
                kind=ExecutionType.MAKER,
                params={},
                reasons=reasons
            )
    
    def _policy_default(self, context: ExecutionContext) -> ExecutionPlan:
        """Politică implicită"""
        return ExecutionPlan(
            kind=ExecutionType.MAKER,
            params={},
            reasons={"policy": "default", "intent": context.intent.value}
        )
    
    def _apply_reason_overrides(self, context: ExecutionContext) -> Optional[ExecutionPlan]:
        """Aplică override-uri bazate pe reason"""
        reason_lower = context.reason.lower().strip()
        
        # Force market reasons
        if reason_lower in self.force_market_reasons:
            return ExecutionPlan(
                kind=ExecutionType.MARKET,
                params={},
                reasons={
                    "policy": "force_market_reason",
                    "reason": context.reason,
                    "override": True
                },
                confidence=1.0
            )
        
        # Force specific kind
        if reason_lower in self.force_kind_reasons:
            forced_kind = str(self.force_kind_reasons[reason_lower]).lower().strip()
            
            valid_kinds = [e.value for e in ExecutionType]
            if forced_kind in valid_kinds:
                # Verifică dacă tipul forțat este disponibil
                if forced_kind == "twap" and not self.twap_enabled:
                    forced_kind = "market"
                
                return ExecutionPlan(
                    kind=ExecutionType(forced_kind),
                    params={},
                    reasons={
                        "policy": "force_kind_reason",
                        "reason": context.reason,
                        "forced_kind": forced_kind,
                        "override": True
                    },
                    confidence=1.0
                )
        
        return None
    
    def _apply_anti_flip_flop(
        self, 
        new_plan: ExecutionPlan, 
        prev_plan: ExecutionPlan
    ) -> ExecutionPlan:
        """Aplică anti flip-flop logic"""
        hold_sec = float(self.router_cfg.get("min_plan_hold_sec", 3.0))
        
        try:
            time_since_prev = time.time() - prev_plan.timestamp
            
            if time_since_prev < hold_sec and new_plan.kind != prev_plan.kind:
                # Păstrează planul anterior
                reasons = dict(new_plan.reasons)
                reasons["policy"] = "hold_previous_plan"
                reasons["previous_plan"] = prev_plan.kind.value
                reasons["hold_time_remaining"] = hold_sec - time_since_prev
                reasons["anti_flip_flop"] = True
                
                return ExecutionPlan(
                    kind=prev_plan.kind,
                    params=prev_plan.params,
                    reasons=reasons,
                    confidence=prev_plan.confidence * 0.8,
                    timestamp=new_plan.timestamp
                )
        except Exception as e:
            self.log.debug(f"Anti flip-flop error: {e}")
        
        return new_plan
    
    def _calculate_confidence(self, context: ExecutionContext, plan: ExecutionPlan) -> float:
        """Calculează încrederea în plan"""
        metrics = context.metrics
        confidence = 0.7  # Bază
        
        # Ajustări bazate pe metrici
        if plan.kind == ExecutionType.MAKER:
            if metrics.fill_probability > 0.7:
                confidence += 0.2
            if metrics.spread_bps < self.max_spread * 0.5:
                confidence += 0.1
            if metrics.source == "fallback":
                confidence -= 0.1
        
        elif plan.kind == ExecutionType.MARKET:
            if metrics.spread_bps > self.max_spread * 1.5:
                confidence += 0.1
            if metrics.slippage_bps < self.max_slip * 0.5:
                confidence += 0.1
        
        elif plan.kind == ExecutionType.TWAP:
            if metrics.slippage_bps > self.twap_auto_bps * 1.2:
                confidence += 0.2
            if metrics.notional_usd > 10000:  # Marje mari beneficiază de TWAP
                confidence += 0.1
        
        # Ajustări bazate pe intenție
        if context.intent in [IntentType.PROTECT, IntentType.EXIT]:
            confidence += 0.1  # Decizii mai clare pentru exit/protecție
        
        # Limitează între 0.1 și 1.0
        return max(0.1, min(1.0, confidence))
    
    def _get_confidence_level(self, confidence: float) -> ExecutionConfidence:
        """Determină nivelul de încredere"""
        if confidence > 0.8:
            return ExecutionConfidence.HIGH
        elif confidence > 0.5:
            return ExecutionConfidence.MEDIUM
        elif confidence > 0.2:
            return ExecutionConfidence.LOW
        else:
            return ExecutionConfidence.UNKNOWN


# ============================================================================
# EXECUTION ROUTER MAIN CLASS
# ============================================================================

class ExecutionRouter:
    """
    Router pentru execuție: convertește intenția într-un plan de execuție.
    
    Caracteristici:
      - Politică bazată pe intenție (entry, exit, protect, rebalance, hedge)
      - Fallback robust în caz de eșec al orderbook-ului
      - Anti flip-flop prin hold time
      - Metrice avansate de piață
      - Istoric și analiză a deciziilor
      - Încredere calculată pentru fiecare decizie
    """
    
    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log
        
        # Configurare
        self.execution_cfg = self.cfg.get("execution", {})
        self.router_cfg = self.execution_cfg.get("router", {})
        self.micro_model_cfg = self.cfg.get("micro_model", {})
        self.twap_cfg = self.execution_cfg.get("twap", {})
        
        # Componente
        self.policy_engine = ExecutionPolicy(self.execution_cfg, log)
        self.analytics = ExecutionAnalytics(
            max_history=int(self.router_cfg.get("history_size", 1000))
        )
        
        # Cache pentru ultimele planuri
        self._last_plans: Dict[str, ExecutionPlan] = {}
        self._plan_cache: Dict[str, Tuple[float, ExecutionPlan]] = {}
        self._cache_ttl = float(self.router_cfg.get("cache_ttl_sec", 2.0))
        
        # Metrici de performanță
        self.metrics = {
            "total_routes": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "avg_decision_time_ms": 0.0,
            "last_route_time": 0.0
        }
        
        # Lock pentru thread safety
        self._lock = threading.RLock()
        
        self.log.info(
            f"ExecutionRouter initializat cu {len(self.policy_engine.intent_policies)} politici"
        )
    
    # ============================================================================
    # METODE PUBLICE
    # ============================================================================
    
    def last(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Returnează ultimul plan pentru un simbol"""
        plan = self._last_plans.get(symbol)
        return plan.to_dict() if plan else None
    
    def get_stats(self) -> Dict[str, Any]:
        """Returnează statistici ale router-ului"""
        with self._lock:
            return {
                **self.metrics,
                **self.analytics.get_stats(),
                "cache_ttl_sec": self._cache_ttl,
                "last_plan_count": len(self._last_plans)
            }
    
    def get_symbol_stats(self, symbol: str, 
                         time_window_sec: Optional[float] = 3600) -> Dict[str, Any]:
        """Returnează statistici pentru un simbol specific"""
        return self.analytics.get_stats(symbol=symbol, time_window_sec=time_window_sec)
    
    def clear_cache(self) -> None:
        """Șterge cache-ul și istoricul"""
        with self._lock:
            self._last_plans.clear()
            self._plan_cache.clear()
            self.analytics.clear_history()
            self.metrics["cache_hits"] = 0
            self.metrics["cache_misses"] = 0
            self.log.info("Execution cache cleared")
    
    def route(
        self,
        engine: Any,
        symbol: str,
        side: str,
        qty: float,
        bid: float,
        ask: float,
        last: float,
        atr_pct: float,
        reason: str,
        intent: str = "entry",
    ) -> ExecutionPlan:
        """
        Determină planul optim de execuție.
        
        Args:
            engine: Motorul de trading
            symbol: Simbolul trading
            side: 'buy' sau 'sell'
            qty: Cantitatea
            bid: Prețul bid curent
            ask: Prețul ask curent
            last: Ultimul preț
            atr_pct: ATR ca procent
            reason: Motivul ordinului
            intent: Intenția ('entry', 'exit', 'protect', 'rebalance', 'hedge')
        
        Returns:
            ExecutionPlan: Planul de execuție recomandat
        """
        start_time = time.time()
        self.metrics["total_routes"] += 1
        self.metrics["last_route_time"] = time.time()
        
        # Verifică dacă router-ul este dezactivat
        if not bool(self.router_cfg.get("enabled", True)):
            default_type = self.execution_cfg.get("type", "limit").lower()
            default_kind = ExecutionType(default_type) if default_type in [e.value for e in ExecutionType] else ExecutionType.MAKER
            
            plan = ExecutionPlan(
                kind=default_kind,
                params={},
                reasons={"router": "disabled"},
                confidence=0.5,
                confidence_level=ExecutionConfidence.LOW
            )
            
            self._update_metrics(plan, start_time, False)
            return plan
        
        # Normalizează input-urile
        side_enum = self._normalize_side(side)
        intent_enum = self._normalize_intent(intent)
        
        # Verifică cache
        cache_key = self._generate_cache_key(symbol, side_enum, qty, intent_enum, reason)
        cached_plan = self._get_cached_plan(cache_key)
        
        if cached_plan:
            self.metrics["cache_hits"] += 1
            self.log.debug(f"Cache hit for {symbol}: {cached_plan.kind.value}")
            return cached_plan
        
        self.metrics["cache_misses"] += 1
        
        # Obține metricile de piață
        market_metrics = self._get_market_metrics(
            engine, symbol, side_enum, qty, bid, ask, last, atr_pct
        )
        
        # Creează contextul de execuție
        context = ExecutionContext(
            symbol=symbol,
            side=side_enum,
            quantity=qty,
            intent=intent_enum,
            reason=reason,
            engine=engine,
            metrics=market_metrics,
            config=self.execution_cfg
        )
        
        # Obține planul anterior
        prev_plan = self._last_plans.get(symbol)
        
        # Determină planul folosind motorul de politică
        plan = self.policy_engine.evaluate(context, prev_plan)
        
        # Completează parametrii planului
        plan = self._enrich_plan_params(plan, market_metrics)
        
        # Salvează în cache
        self._cache_plan(cache_key, plan)
        self._last_plans[symbol] = plan
        
        # Înregistrează decizia
        decision_time = (time.time() - start_time) * 1000
        self.analytics.record_decision(context, plan, decision_time)
        
        # Actualizează metrici
        self._update_metrics(plan, start_time, market_metrics.source == "fallback")
        
        # Log detalii
        if plan.confidence_level == ExecutionConfidence.LOW:
            self.log.warning(
                f"Low confidence plan for {symbol}: {plan.kind.value} "
                f"(confidence: {plan.confidence:.2f}, reason: {reason})"
            )
        
        return plan
    
    # ============================================================================
    # METODE PRIVATE - HELPERS
    # ============================================================================
    
    def _normalize_side(self, side: str) -> OrderSide:
        """Normalizează partea ordinului"""
        side_lower = str(side).lower().strip()
        if side_lower in ("buy", "b", "long"):
            return OrderSide.BUY
        elif side_lower in ("sell", "s", "short"):
            return OrderSide.SELL
        else:
            self.log.warning(f"Side necunoscut '{side}', folosesc 'buy'")
            return OrderSide.BUY
    
    def _normalize_intent(self, intent: str) -> IntentType:
        """Normalizează intenția"""
        intent_lower = str(intent).lower().strip()
        
        intent_map = {
            "entry": IntentType.ENTRY,
            "exit": IntentType.EXIT,
            "protect": IntentType.PROTECT,
            "rebalance": IntentType.REBALANCE,
            "hedge": IntentType.HEDGE,
            "stop_loss": IntentType.PROTECT,
            "take_profit": IntentType.EXIT,
            "liquidation": IntentType.EXIT
        }
        
        return intent_map.get(intent_lower, IntentType.ENTRY)
    
    def _generate_cache_key(
        self, 
        symbol: str, 
        side: OrderSide, 
        qty: float, 
        intent: IntentType, 
        reason: str
    ) -> str:
        """Generează cheie de cache"""
        key_parts = [
            symbol,
            side.value,
            str(round(qty, 6)),
            intent.value,
            reason.lower(),
            str(int(time.time() / 10))  # Schimbă la fiecare 10 secunde
        ]
        return hashlib.md5("_".join(key_parts).encode()).hexdigest()[:16]
    
    def _get_cached_plan(self, cache_key: str) -> Optional[ExecutionPlan]:
        """Obține plan din cache"""
        with self._lock:
            if cache_key in self._plan_cache:
                timestamp, plan = self._plan_cache[cache_key]
                if time.time() - timestamp < self._cache_ttl:
                    return plan
        
        return None
    
    def _cache_plan(self, cache_key: str, plan: ExecutionPlan) -> None:
        """Salvează plan în cache"""
        with self._lock:
            self._plan_cache[cache_key] = (time.time(), plan)
            
            # Cleanup cache vechi
            current_time = time.time()
            expired_keys = [
                k for k, (ts, _) in self._plan_cache.items()
                if current_time - ts > self._cache_ttl * 2
            ]
            
            for key in expired_keys:
                del self._plan_cache[key]
    
    def _get_market_metrics(
        self,
        engine: Any,
        symbol: str,
        side: OrderSide,
        qty: float,
        bid: float,
        ask: float,
        last: float,
        atr_pct: float
    ) -> MarketMetrics:
        """Obține metricile de piață pentru simbol"""
        # Configurații
        depth = int(self.router_cfg.get(
            "orderbook_depth", 
            self.micro_model_cfg.get("orderbook_depth", 20)
        ))
        
        min_notional = float(self.router_cfg.get("min_notional_usd", 50.0))
        mid_price = self._calculate_mid_price(bid, ask, last)
        notional_usd = max(min_notional, float(qty) * float(mid_price if mid_price > 0 else (last or 0.0)))
        
        # Încearcă să obțineți metrici din orderbook
        try:
            ob = engine.client.fetch_order_book(symbol, limit=depth)
            met = orderbook_metrics(ob, depth=depth)
            
            spread_bps = float(met.get("spread_bps", float("nan")))
            imbalance = float(met.get("imbalance", 0.0) or 0.0)
            
            # Calcul slippage
            slip_bps = float(expected_market_slippage_bps(
                ob, side=side.value, qty=float(qty), depth=depth
            ))
            
            # Calcul fill probability
            maker_distance = self._calculate_maker_distance(spread_bps)
            fill_prob = float(maker_fill_probability(
                self.micro_model_cfg,
                side=side.value,
                distance_bps=maker_distance,
                atr_pct=float(atr_pct),
                imbalance=imbalance,
            ))
            
            return MarketMetrics(
                symbol=symbol,
                side=side,
                spread_bps=spread_bps,
                slippage_bps=slip_bps,
                fill_probability=fill_prob,
                imbalance=imbalance,
                notional_usd=notional_usd,
                atr_pct=float(atr_pct),
                mid_price=mid_price,
                orderbook_depth=depth,
                bid_price=float(bid),
                ask_price=float(ask),
                last_price=float(last),
                source="orderbook"
            )
            
        except Exception as e:
            # Fallback la metrici bazate pe quotes
            self.analytics.record_fallback()
            self.log.warning(f"Orderbook fetch failed for {symbol}, using fallback: {e}")
            
            return self._get_fallback_metrics(
                symbol, side, bid, ask, last, atr_pct, notional_usd, depth, str(e)
            )
    
    def _calculate_mid_price(self, bid: float, ask: float, last: float) -> float:
        """Calculează prețul mid"""
        try:
            b = float(bid)
            a = float(ask)
            if b > 0 and a > 0:
                return (b + a) / 2.0
        except Exception:
            pass
        
        try:
            l = float(last)
            return l if l > 0 else 0.0
        except Exception:
            return 0.0
    
    def _calculate_maker_distance(self, spread_bps: float) -> float:
        """Calculează distanța pentru ordinul maker"""
        if not math.isfinite(spread_bps):
            return 10.0  # Default
        
        # Distanța default este jumătate din spread
        dist_default = max(1.0, float(spread_bps) / 2.0)
        
        # Aplică configurații
        dist = float(self.router_cfg.get("maker_distance_bps", dist_default))
        min_dist = float(self.router_cfg.get("maker_distance_min_bps", 0.5))
        max_dist = float(self.router_cfg.get("maker_distance_max_bps", 25.0))
        
        return max(min_dist, min(max_dist, dist))
    
    def _get_fallback_metrics(
        self,
        symbol: str,
        side: OrderSide,
        bid: float,
        ask: float,
        last: float,
        atr_pct: float,
        notional_usd: float,
        depth: int,
        error_msg: str
    ) -> MarketMetrics:
        """Obține metrici fallback când orderbook-ul eșuează"""
        # Calcul spread din quotes
        spread_bps = self._calculate_spread_from_quotes(bid, ask)
        
        # Estimare conservatoare pentru slippage
        base_slip = spread_bps if math.isfinite(spread_bps) else 12.0
        vol_impact = 2.0 + 0.02 * float(atr_pct or 0.0) * 10_000.0
        size_impact = min(20.0, max(0.0, (notional_usd - 100.0) / 2000.0))
        slip_bps = float(base_slip + vol_impact + size_impact)
        
        # Fill probability fallback
        fill_prob = float(self.router_cfg.get("fallback_fill_prob", 0.6))
        
        return MarketMetrics(
            symbol=symbol,
            side=side,
            spread_bps=spread_bps,
            slippage_bps=slip_bps,
            fill_probability=fill_prob,
            imbalance=0.0,
            notional_usd=notional_usd,
            atr_pct=float(atr_pct),
            mid_price=self._calculate_mid_price(bid, ask, last),
            orderbook_depth=depth,
            bid_price=float(bid),
            ask_price=float(ask),
            last_price=float(last),
            source="fallback"
        )
    
    def _calculate_spread_from_quotes(self, bid: float, ask: float) -> float:
        """Calculează spread-ul din quotes"""
        try:
            b = float(bid)
            a = float(ask)
            if b <= 0 or a <= 0:
                return float("nan")
            
            mid = (a + b) / 2.0
            if mid <= 0:
                return float("nan")
            
            return (a - b) / mid * 10_000.0
        except Exception:
            return float("nan")
    
    def _enrich_plan_params(
        self, 
        plan: ExecutionPlan, 
        metrics: MarketMetrics
    ) -> ExecutionPlan:
        """Completează parametrii planului"""
        params = dict(plan.params)
        
        if plan.kind == ExecutionType.TWAP:
            params = self._get_twap_params(metrics)
        elif plan.kind == ExecutionType.MAKER:
            params = self._get_maker_params(metrics)
        elif plan.kind == ExecutionType.MARKET:
            params = self._get_market_params(metrics)
        
        return ExecutionPlan(
            kind=plan.kind,
            params=params,
            reasons=plan.reasons,
            confidence=plan.confidence,
            confidence_level=plan.confidence_level,
            timestamp=plan.timestamp,
            version=plan.version
        )
    
    def _get_twap_params(self, metrics: MarketMetrics) -> Dict[str, Any]:
        """Obține parametrii pentru TWAP"""
        # Configurații default
        duration = int(self.twap_cfg.get("duration_sec", 60))
        slices = int(self.twap_cfg.get("slices", 10))
        
        # Sizing dinamic bazat pe impact și notional
        if bool(self.twap_cfg.get("dynamic", True)):
            twap_auto_bps = float(self.twap_cfg.get("auto_slippage_bps", 30.0))
            
            # Ajustare pentru slippage mare
            if metrics.slippage_bps >= twap_auto_bps + 10:
                duration = max(duration, int(self.twap_cfg.get("duration_high_sec", 120)))
                slices = max(slices, int(self.twap_cfg.get("slices_high", 16)))
            
            # Ajustare pentru notional mare
            big_notional = float(self.twap_cfg.get("big_notional_usd", 2500.0))
            if metrics.notional_usd >= big_notional:
                duration = max(duration, int(self.twap_cfg.get("duration_big_sec", 180)))
                slices = max(slices, int(self.twap_cfg.get("slices_big", 20)))
        
        return {
            "duration_sec": duration,
            "slices": slices,
            "slice_notional_usd": metrics.notional_usd / slices,
            "estimated_slippage_bps": metrics.slippage_bps,
            "start_time": time.time(),
            "end_time": time.time() + duration,
            "slice_interval_sec": duration / slices
        }
    
    def _get_maker_params(self, metrics: MarketMetrics) -> Dict[str, Any]:
        """Obține parametrii pentru ordinul maker"""
        maker_distance = self._calculate_maker_distance(metrics.spread_bps)
        
        return {
            "distance_bps": maker_distance,
            "estimated_fill_probability": metrics.fill_probability,
            "timeout_sec": float(self.router_cfg.get("maker_timeout_sec", 30.0)),
            "post_only": bool(self.router_cfg.get("maker_post_only", True)),
            "reduce_only": False
        }
    
    def _get_market_params(self, metrics: MarketMetrics) -> Dict[str, Any]:
        """Obține parametrii pentru ordinul market"""
        return {
            "estimated_slippage_bps": metrics.slippage_bps,
            "time_in_force": "IOC",  # Immediate or Cancel
            "reduce_only": False
        }
    
    def _update_metrics(
        self, 
        plan: ExecutionPlan, 
        start_time: float,
        fallback_used: bool
    ) -> None:
        """Actualizează metricile de performanță"""
        decision_time = (time.time() - start_time) * 1000
        
        # Actualizează timpul mediu de decizie (moving average)
        current_avg = self.metrics["avg_decision_time_ms"]
        n = self.metrics["total_routes"]
        self.metrics["avg_decision_time_ms"] = (
            (current_avg * (n - 1) + decision_time) / n
        )
        
        # Înregistrează fallback dacă s-a folosit
        if fallback_used:
            self.analytics.record_fallback()


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def create_execution_router(cfg: Dict[str, Any], log: Any) -> ExecutionRouter:
    """Factory function pentru a crea un ExecutionRouter"""
    return ExecutionRouter(cfg, log)
# onchain_test.py
import pytest
import json
import time
from unittest.mock import Mock, patch, MagicMock
from onchain import OnChainTracker, OnChainSignal, _s, _f, _clamp
import urllib.request
import urllib.error


class TestHelperFunctions:
    """Test the helper utility functions"""
    
    def test_safe_string_conversion(self):
        """Test _s function for safe string conversion"""
        assert _s("hello") == "hello"
        assert _s(123) == "123"
        assert _s(3.14) == "3.14"
        assert _s(None) == ""
        assert _s(None, "default") == "default"
        assert _s({"a": 1}) == "{'a': 1}"
        
    def test_safe_float_conversion(self):
        """Test _f function for safe float conversion"""
        assert _f("123") == 123.0
        assert _f(123) == 123.0
        assert _f(3.14) == 3.14
        assert _f(None) == 0.0
        assert _f(None, 99.0) == 99.0
        assert _f("not a number") == 0.0
        
    def test_clamp_function(self):
        """Test _clamp function"""
        assert _clamp(5, 0, 10) == 5.0
        assert _clamp(-5, 0, 10) == 0.0
        assert _clamp(15, 0, 10) == 10.0
        assert _clamp(3.14, 0.0, 1.0) == 1.0
        assert _clamp(-3.14, -5.0, 5.0) == -3.14


class TestOnChainSignal:
    """Test the OnChainSignal dataclass"""
    
    def test_onchain_signal_creation(self):
        """Test creating OnChainSignal instance"""
        signal = OnChainSignal(
            ts=1234567890.0,
            symbol="BTC/USDT",
            score=0.75,
            reason="whale accumulation",
            details={"whales": 5, "volume": 1000000}
        )
        
        assert signal.ts == 1234567890.0
        assert signal.symbol == "BTC/USDT"
        assert signal.score == 0.75
        assert signal.reason == "whale accumulation"
        assert signal.details == {"whales": 5, "volume": 1000000}
        
    def test_onchain_signal_to_dict(self):
        """Test converting OnChainSignal to dictionary"""
        signal = OnChainSignal(
            ts=1234567890.0,
            symbol="ETH/USDT",
            score=-0.25,
            reason="large transfers to exchange"
        )
        
        signal_dict = signal.to_dict()
        assert signal_dict["ts"] == 1234567890.0
        assert signal_dict["symbol"] == "ETH/USDT"
        assert signal_dict["score"] == -0.25
        assert signal_dict["reason"] == "large transfers to exchange"
        assert signal_dict["details"] == {}  # Default empty dict
        
    def test_onchain_signal_score_clamping(self):
        """Test that scores are automatically clamped in ingestion"""
        # Note: The actual clamping happens in _ingest_payload
        # These are just to verify the dataclass itself doesn't clamp
        signal = OnChainSignal(
            ts=1234567890.0,
            symbol="BTC/USDT",
            score=2.5,  # Above 1.0, but dataclass doesn't validate
            reason="test"
        )
        assert signal.score == 2.5  # No automatic clamping in dataclass


class TestOnChainTracker:
    """Test the OnChainTracker class"""
    
    @pytest.fixture
    def mock_log(self):
        """Create a mock logger"""
        return Mock()
    
    @pytest.fixture
    def tracker_disabled(self, mock_log):
        """Create a disabled OnChainTracker instance"""
        config = {
            "onchain": {
                "enabled": False,
                "mode": "disabled"
            }
        }
        return OnChainTracker(config, mock_log)
    
    @pytest.fixture
    def tracker_http_json(self, mock_log):
        """Create an HTTP JSON mode OnChainTracker instance"""
        config = {
            "onchain": {
                "enabled": True,
                "mode": "http_json",
                "endpoint_url": "http://localhost:8080/api/signals",
                "refresh_sec": 10,
                "cache_ttl_sec": 30,
                "timeout_sec": 2.0,
                "api_key": "test-api-key"
            }
        }
        return OnChainTracker(config, mock_log)
    
    @pytest.fixture
    def tracker_web3(self, mock_log):
        """Create a web3 mode OnChainTracker instance"""
        config = {
            "onchain": {
                "enabled": True,
                "mode": "web3",
                "provider_url": "https://mainnet.infura.io/v3/test",
                "refresh_sec": 60,
                "cache_ttl_sec": 120
            }
        }
        return OnChainTracker(config, mock_log)
    
    def test_initialization_disabled(self, mock_log):
        """Test initialization with disabled mode"""
        config = {}
        tracker = OnChainTracker(config, mock_log)
        
        assert tracker.enabled is False
        assert tracker.mode == "disabled"
        assert tracker.endpoint_url == ""
        assert tracker._cache == {}
        assert tracker._last_fetch_ts == 0.0
        
    def test_initialization_without_onchain_section(self, mock_log):
        """Test initialization when config doesn't have onchain section"""
        config = {"other_key": "value"}
        tracker = OnChainTracker(config, mock_log)
        
        assert tracker.enabled is False
        assert tracker.mode == "disabled"
        
    def test_status_disabled(self, tracker_disabled):
        """Test status reporting for disabled tracker"""
        status = tracker_disabled.status()
        
        assert status["enabled"] is False
        assert status["mode"] == "disabled"
        assert status["cache_size"] == 0
        assert status["last_fetch_ts"] == 0.0
        assert status["last_error"] == ""
        
    def test_status_enabled(self, tracker_http_json):
        """Test status reporting for enabled tracker"""
        status = tracker_http_json.status()
        
        assert status["enabled"] is True
        assert status["mode"] == "http_json"
        assert status["endpoint_url"] == "http://localhost:8080/api/signals"
        assert status["refresh_sec"] == 10.0
        assert status["cache_ttl_sec"] == 30.0
        
    def test_score_for_symbol_disabled(self, tracker_disabled):
        """Test getting score when tracker is disabled"""
        score = tracker_disabled.score_for_symbol("BTC/USDT")
        assert score == 0.0  # Neutral when disabled
        
    def test_score_for_symbol_no_cache(self, tracker_http_json):
        """Test getting score with empty cache"""
        tracker_http_json._last_fetch_ts = 0  # Force refresh
        score = tracker_http_json.score_for_symbol("BTC/USDT")
        assert score == 0.0  # Neutral when no data
        
    def test_tick_disabled(self, tracker_disabled):
        """Test tick method when disabled"""
        # Should not do anything
        tracker_disabled.tick()
        assert tracker_disabled._last_fetch_ts == 0.0
        
    def test_tick_not_time_for_refresh(self, tracker_http_json):
        """Test tick when not enough time has passed for refresh"""
        tracker_http_json._last_fetch_ts = time.time() - 5  # 5 seconds ago
        tracker_http_json.refresh_sec = 10
        
        # Mock the _refresh_remote to ensure it's not called
        with patch.object(tracker_http_json, '_refresh_remote') as mock_refresh:
            tracker_http_json.tick()
            mock_refresh.assert_not_called()
            
    def test_tick_time_for_refresh(self, tracker_http_json):
        """Test tick when it's time to refresh"""
        tracker_http_json._last_fetch_ts = time.time() - 15  # 15 seconds ago
        tracker_http_json.refresh_sec = 10
        
        with patch.object(tracker_http_json, '_refresh_remote') as mock_refresh:
            tracker_http_json.tick()
            mock_refresh.assert_called_once()
            
    def test_last_details_empty(self, tracker_http_json):
        """Test getting last details for unknown symbol"""
        details = tracker_http_json.last_details("BTC/USDT")
        assert details == {}
        
    def test_last_details_with_signal(self, tracker_http_json):
        """Test getting last details for cached symbol"""
        signal = OnChainSignal(
            ts=time.time(),
            symbol="BTC/USDT",
            score=0.5,
            reason="test",
            details={"key": "value"}
        )
        tracker_http_json._cache["BTC/USDT"] = signal
        
        details = tracker_http_json.last_details("BTC/USDT")
        assert details["symbol"] == "BTC/USDT"
        assert details["score"] == 0.5
        assert details["details"]["key"] == "value"
    
    def test_ingest_payload_option_a(self, tracker_http_json):
        """Test ingesting payload format A: {"scores": {...}}"""
        payload = {
            "scores": {
                "BTC/USDT": 0.75,
                "ETH/USDT": -0.25
            },
            "meta": {"source": "test", "timestamp": 1234567890}
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        assert "BTC/USDT" in tracker_http_json._cache
        assert "ETH/USDT" in tracker_http_json._cache
        assert tracker_http_json._cache["BTC/USDT"].score == 0.75
        assert tracker_http_json._cache["ETH/USDT"].score == -0.25
        assert tracker_http_json._last_meta == {"source": "test", "timestamp": 1234567890}
        
    def test_ingest_payload_option_b(self, tracker_http_json):
        """Test ingesting payload format B: {"BTC/USDT": {...}}"""
        payload = {
            "BTC/USDT": {
                "score": 0.8,
                "reason": "whale buying",
                "details": {"transactions": 5, "volume": 1000000}
            },
            "ETH/USDT": {
                "score": -0.3,
                "reason": "exchange inflow"
            },
            "meta": {"version": "1.0"}
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        assert "BTC/USDT" in tracker_http_json._cache
        assert "ETH/USDT" in tracker_http_json._cache
        
        btc_signal = tracker_http_json._cache["BTC/USDT"]
        assert btc_signal.score == 0.8
        assert btc_signal.reason == "whale buying"
        assert btc_signal.details == {"transactions": 5, "volume": 1000000}
        
        eth_signal = tracker_http_json._cache["ETH/USDT"]
        assert eth_signal.score == -0.3
        assert eth_signal.reason == "exchange inflow"
        
        assert tracker_http_json._last_meta == {"version": "1.0"}
        
    def test_ingest_payload_option_c(self, tracker_http_json):
        """Test ingesting payload format C: single symbol dict"""
        payload = {
            "symbol": "BTC/USDT",
            "score": 0.9,
            "s": 0.9,  # Alternative field
            "reason": "test reason",
            "details": {"key": "value"},
            "meta": {"source": "single"}
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        assert "BTC/USDT" in tracker_http_json._cache
        signal = tracker_http_json._cache["BTC/USDT"]
        assert signal.score == 0.9
        assert signal.reason == "test reason"
        assert signal.details == {"key": "value"}
        assert tracker_http_json._last_meta == {"source": "single"}
        
    def test_ingest_payload_clamping(self, tracker_http_json):
        """Test that scores are clamped to [-1, 1]"""
        payload = {
            "scores": {
                "BTC/USDT": 2.5,  # Above 1.0
                "ETH/USDT": -1.5  # Below -1.0
            }
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        assert tracker_http_json._cache["BTC/USDT"].score == 1.0  # Clamped
        assert tracker_http_json._cache["ETH/USDT"].score == -1.0  # Clamped
        
    def test_ingest_payload_alternative_score_field(self, tracker_http_json):
        """Test using alternative 's' field for score"""
        payload = {
            "BTC/USDT": {
                "s": 0.7,  # Alternative to "score"
                "reason": "test"
            }
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        assert tracker_http_json._cache["BTC/USDT"].score == 0.7
        
    def test_ingest_payload_value_only(self, tracker_http_json):
        """Test payload with just values (not dicts)"""
        payload = {
            "BTC/USDT": 0.6,
            "ETH/USDT": -0.4
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        assert tracker_http_json._cache["BTC/USDT"].score == 0.6
        assert tracker_http_json._cache["BTC/USDT"].reason == "http_json:value"
        
        assert tracker_http_json._cache["ETH/USDT"].score == -0.4
        assert tracker_http_json._cache["ETH/USDT"].reason == "http_json:value"
        
    def test_ingest_payload_invalid(self, tracker_http_json):
        """Test ingesting invalid payload"""
        # None payload
        tracker_http_json._ingest_payload(None, ts=time.time())
        assert len(tracker_http_json._cache) == 0
        
        # Empty dict
        tracker_http_json._ingest_payload({}, ts=time.time())
        assert len(tracker_http_json._cache) == 0
        
        # List payload (unsupported)
        tracker_http_json._ingest_payload([1, 2, 3], ts=time.time())
        assert len(tracker_http_json._cache) == 0
        
    def test_score_for_symbol_with_cache(self, tracker_http_json):
        """Test getting score from cache"""
        now = time.time()
        signal = OnChainSignal(
            ts=now - 15,  # 15 seconds ago
            symbol="BTC/USDT",
            score=0.8,
            reason="cached"
        )
        tracker_http_json._cache["BTC/USDT"] = signal
        tracker_http_json.cache_ttl_sec = 30
        
        score = tracker_http_json.score_for_symbol("BTC/USDT")
        assert score == 0.8  # From cache
        
    def test_score_for_symbol_cache_expired(self, tracker_http_json):
        """Test getting score when cache is expired"""
        now = time.time()
        signal = OnChainSignal(
            ts=now - 45,  # 45 seconds ago
            symbol="BTC/USDT",
            score=0.8,
            reason="expired"
        )
        tracker_http_json._cache["BTC/USDT"] = signal
        tracker_http_json.cache_ttl_sec = 30
        tracker_http_json._last_fetch_ts = now - 35  # Can refresh
        
        with patch.object(tracker_http_json, '_refresh_remote') as mock_refresh:
            score = tracker_http_json.score_for_symbol("BTC/USDT")
            mock_refresh.assert_called_once()
            # Since refresh doesn't actually update in this test, returns 0.0
            assert score == 0.0
            
    def test_refresh_remote_http_json_success(self, tracker_http_json):
        """Test successful HTTP JSON refresh"""
        mock_response = {
            "scores": {
                "BTC/USDT": 0.7,
                "ETH/USDT": -0.2
            }
        }
        
        with patch.object(tracker_http_json, '_http_get_json') as mock_http:
            mock_http.return_value = mock_response
            tracker_http_json._refresh_remote()
            
            mock_http.assert_called_once_with(
                tracker_http_json.endpoint_url,
                timeout=tracker_http_json.timeout_sec,
                api_key=tracker_http_json.api_key
            )
            
        assert "BTC/USDT" in tracker_http_json._cache
        assert "ETH/USDT" in tracker_http_json._cache
        assert tracker_http_json._last_error == ""
        
    def test_refresh_remote_http_json_missing_url(self, tracker_http_json):
        """Test HTTP JSON refresh with missing endpoint URL"""
        tracker_http_json.endpoint_url = ""
        tracker_http_json._refresh_remote()
        
        assert tracker_http_json._last_error == "http_json: endpoint_url missing"
        assert len(tracker_http_json._cache) == 0
        
    def test_refresh_remote_http_json_exception(self, tracker_http_json):
        """Test HTTP JSON refresh with exception"""
        with patch.object(tracker_http_json, '_http_get_json') as mock_http:
            mock_http.side_effect = Exception("Connection failed")
            tracker_http_json._refresh_remote()
            
        assert "Connection failed" in tracker_http_json._last_error
        # Cache should remain unchanged
        assert len(tracker_http_json._cache) == 0
        
    def test_refresh_remote_web3_mode(self, tracker_web3):
        """Test web3 mode refresh (not implemented)"""
        tracker_web3._refresh_remote()
        
        assert "web3: not implemented" in tracker_web3._last_error
        
    def test_refresh_remote_web3_missing_provider(self, tracker_web3):
        """Test web3 mode refresh with missing provider URL"""
        tracker_web3.provider_url = ""
        tracker_web3._refresh_remote()
        
        assert tracker_web3._last_error == "web3: provider_url missing"
        
    def test_refresh_remote_unknown_mode(self, mock_log):
        """Test refresh with unknown mode"""
        config = {
            "onchain": {
                "enabled": True,
                "mode": "unknown_mode"
            }
        }
        tracker = OnChainTracker(config, mock_log)
        tracker._refresh_remote()
        
        assert "unknown mode" in tracker._last_error
        
    def test_http_get_json_success(self, tracker_http_json):
        """Test successful HTTP GET JSON"""
        mock_response_data = {"scores": {"BTC/USDT": 0.5}}
        
        mock_response = Mock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode('utf-8')
        
        with patch('urllib.request.urlopen') as mock_urlopen:
            mock_urlopen.return_value.__enter__.return_value = mock_response
            result = tracker_http_json._http_get_json(
                "http://example.com",
                timeout=5.0,
                api_key="test-key"
            )
            
            # Check headers were set
            call_args = mock_urlopen.call_args[0][0]
            assert call_args.headers["Accept"] == "application/json"
            assert call_args.headers["X-API-Key"] == "test-key"
            
        assert result == mock_response_data
        
    def test_http_get_json_invalid_json(self, tracker_http_json):
        """Test HTTP GET with invalid JSON response"""
        mock_response = Mock()
        mock_response.read.return_value = b"not json"
        
        with patch('urllib.request.urlopen') as mock_urlopen:
            mock_urlopen.return_value.__enter__.return_value = mock_response
            result = tracker_http_json._http_get_json("http://example.com", timeout=5.0)
            
        assert result == {}  # Returns empty dict on JSON parse error
        
    def test_http_get_json_network_error(self, tracker_http_json):
        """Test HTTP GET with network error"""
        with patch('urllib.request.urlopen') as mock_urlopen:
            mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
            
            with pytest.raises(urllib.error.URLError):
                tracker_http_json._http_get_json("http://example.com", timeout=5.0)
                
    def test_http_get_json_timeout(self, tracker_http_json):
        """Test HTTP GET with timeout"""
        with patch('urllib.request.urlopen') as mock_urlopen:
            mock_urlopen.side_effect = TimeoutError("Request timed out")
            
            with pytest.raises(TimeoutError):
                tracker_http_json._http_get_json("http://example.com", timeout=5.0)
                
    def test_score_for_symbol_with_refresh(self, tracker_http_json):
        """Test score_for_symbol triggers refresh and uses new data"""
        # Set up initial state
        tracker_http_json._last_fetch_ts = time.time() - 20  # 20 seconds ago
        tracker_http_json.refresh_sec = 10  # Can refresh
        
        # Mock the refresh to add data to cache
        def mock_refresh():
            signal = OnChainSignal(
                ts=time.time(),
                symbol="BTC/USDT",
                score=0.9,
                reason="refreshed"
            )
            tracker_http_json._cache["BTC/USDT"] = signal
            
        with patch.object(tracker_http_json, '_refresh_remote', side_effect=mock_refresh):
            score = tracker_http_json.score_for_symbol("BTC/USDT")
            
        assert score == 0.9  # From refreshed data
        
    def test_caching_behavior(self, tracker_http_json):
        """Test caching TTL behavior"""
        now = time.time()
        
        # Add a signal to cache
        signal = OnChainSignal(
            ts=now - 20,  # 20 seconds old
            symbol="BTC/USDT",
            score=0.8
        )
        tracker_http_json._cache["BTC/USDT"] = signal
        
        # Test with TTL of 30 seconds (signal is still valid)
        tracker_http_json.cache_ttl_sec = 30
        score = tracker_http_json.score_for_symbol("BTC/USDT")
        assert score == 0.8  # From cache
        
        # Test with TTL of 10 seconds (signal is expired)
        tracker_http_json.cache_ttl_sec = 10
        score = tracker_http_json.score_for_symbol("BTC/USDT")
        assert score == 0.0  # Cache expired, no refresh set up
        
    def test_symbol_normalization(self, tracker_http_json):
        """Test that symbols are normalized (stripped)"""
        payload = {
            "scores": {
                "  BTC/USDT  ": 0.5,  # With spaces
                "ETH/USDT\n": -0.3     # With newline
            }
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        # Should be stored with normalized (stripped) keys
        assert "BTC/USDT" in tracker_http_json._cache
        assert "ETH/USDT" in tracker_http_json._cache
        assert "  BTC/USDT  " not in tracker_http_json._cache
        
    def test_empty_reason_and_details(self, tracker_http_json):
        """Test handling of missing reason and details"""
        payload = {
            "BTC/USDT": {
                "score": 0.5
                # No reason or details
            }
        }
        
        tracker_http_json._ingest_payload(payload, ts=time.time())
        
        signal = tracker_http_json._cache["BTC/USDT"]
        assert signal.reason == "http_json:dict"  # Default
        assert signal.details == {}  # Empty dict
        
    def test_logging_methods(self, mock_log):
        """Test that logging methods handle errors gracefully"""
        config = {"onchain": {"enabled": True}}
        
        # Test with log that has no info method
        bad_log = object()
        tracker = OnChainTracker(config, bad_log)
        
        # Should not raise exception
        tracker._log_info("test info")
        tracker._log_warn("test warning")
        
        # Test with log that raises exception
        raising_log = Mock()
        raising_log.info.side_effect = Exception("Log error")
        tracker2 = OnChainTracker(config, raising_log)
        
        # Should not raise exception
        tracker2._log_info("test")


class TestIntegrationScenarios:
    """Test integration scenarios and real-world use cases"""
    
    @pytest.fixture
    def tracker(self):
        mock_log = Mock()
        config = {
            "onchain": {
                "enabled": True,
                "mode": "http_json",
                "endpoint_url": "http://localhost:8080/signals",
                "refresh_sec": 5,
                "cache_ttl_sec": 10,
                "timeout_sec": 2.0
            }
        }
        return OnChainTracker(config, mock_log)
    
    def test_full_workflow(self, tracker):
        """Test a complete workflow: refresh, cache, retrieve"""
        # Mock HTTP response
        mock_response = {
            "scores": {
                "BTC/USDT": 0.8,
                "ETH/USDT": 0.2,
                "SOL/USDT": -0.4
            },
            "meta": {"updated": time.time()}
        }
        
        # Initial state
        assert tracker.score_for_symbol("BTC/USDT") == 0.0
        assert len(tracker._cache) == 0
        
        # Trigger refresh
        with patch.object(tracker, '_http_get_json') as mock_http:
            mock_http.return_value = mock_response
            tracker._refresh_remote()
            
        # Check cache
        assert len(tracker._cache) == 3
        assert tracker._cache["BTC/USDT"].score == 0.8
        assert tracker._cache["ETH/USDT"].score == 0.2
        assert tracker._cache["SOL/USDT"].score == -0.4
        
        # Retrieve from cache
        assert tracker.score_for_symbol("BTC/USDT") == 0.8
        assert tracker.score_for_symbol("ETH/USDT") == 0.2
        assert tracker.score_for_symbol("SOL/USDT") == -0.4
        
        # Check status
        status = tracker.status()
        assert status["cache_size"] == 3
        assert status["last_error"] == ""
        
    def test_error_recovery(self, tracker):
        """Test error recovery scenario"""
        # First, succeed and populate cache
        success_response = {"scores": {"BTC/USDT": 0.7}}
        
        with patch.object(tracker, '_http_get_json') as mock_http:
            mock_http.return_value = success_response
            tracker._refresh_remote()
            
        assert tracker.score_for_symbol("BTC/USDT") == 0.7
        assert tracker._last_error == ""
        
        # Now fail
        with patch.object(tracker, '_http_get_json') as mock_http:
            mock_http.side_effect = Exception("Network error")
            tracker._refresh_remote()
            
        assert "Network error" in tracker._last_error
        
        # Cache should still have old data (within TTL)
        tracker.cache_ttl_sec = 60
        assert tracker.score_for_symbol("BTC/USDT") == 0.7
        
        # After TTL expires, should return 0.0
        tracker.cache_ttl_sec = 0.1
        time.sleep(0.2)
        assert tracker.score_for_symbol("BTC/USDT") == 0.0
        
    def test_multiple_symbol_formats(self, tracker):
        """Test handling various symbol formats"""
        payload = {
            "BTC-USD": 0.5,  # Dash separator
            "BTC.USD": 0.3,  # Dot separator
            "BTC_USD": 0.1,  # Underscore separator
            "BTCUSD": -0.2,   # No separator
        }
        
        tracker._ingest_payload(payload, ts=time.time())
        
        for symbol in ["BTC-USD", "BTC.USD", "BTC_USD", "BTCUSD"]:
            assert symbol in tracker._cache
            assert tracker.score_for_symbol(symbol) == payload[symbol]


def test_onchain_tracker_without_log():
    """Test OnChainTracker can be created without a proper logger"""
    # Should not raise exception
    tracker = OnChainTracker({}, None)
    assert tracker.enabled is False
    
    # Methods should not crash
    tracker.tick()
    assert tracker.score_for_symbol("BTC/USDT") == 0.0
    assert tracker.status() is not None


if __name__ == "__main__":
    # Run tests
    pytest.main(["-v", __file__])
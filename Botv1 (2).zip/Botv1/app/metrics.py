# app/metrics.py
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional


@dataclass
class MetricsState:
    equity: float = 0.0
    open_positions: int = 0
    pending_orders: int = 0
    last_update_ts: float = 0.0


class Metrics:
    """
    Minimal metrics collector used by engine.py and exposed via /metrics.
    Designed to be JSON-serializable via snapshot().
    """

    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log
        self._lock = threading.RLock()
        self.state = MetricsState()
        self.counters: Dict[str, int] = {
            "errors": 0,
            "trades": 0,
        }
        # entry_skip codes are dynamic, stored as counters['entry_skip:<code>[:<side>]']
        self.gauges: Dict[str, Any] = {}

    def update(self, **gauges: Any) -> None:
        """Update gauge values (equity/open_positions/pending_orders, etc.)."""
        with self._lock:
            now = time.time()
            self.state.last_update_ts = now
            # common gauges that engine expects
            if "equity" in gauges:
                try:
                    self.state.equity = float(gauges["equity"])
                except Exception:
                    pass
            if "open_positions" in gauges:
                try:
                    self.state.open_positions = int(gauges["open_positions"])
                except Exception:
                    pass
            if "pending_orders" in gauges:
                try:
                    self.state.pending_orders = int(gauges["pending_orders"])
                except Exception:
                    pass
            for k, v in gauges.items():
                if k in ("equity","open_positions","pending_orders"):
                    continue
                self.gauges[k] = v

    def inc_error(self) -> None:
        with self._lock:
            self.counters["errors"] = int(self.counters.get("errors", 0)) + 1

    def inc_trade(self) -> None:
        with self._lock:
            self.counters["trades"] = int(self.counters.get("trades", 0)) + 1

    def inc_entry_skip(self, code: str, side: str = "") -> None:
        code = str(code or "unknown").strip()
        side = str(side or "").strip().lower()
        key = f"entry_skip:{code}" + (f":{side}" if side else "")
        with self._lock:
            self.counters[key] = int(self.counters.get(key, 0)) + 1

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "state": asdict(self.state),
                "counters": dict(self.counters),
                "gauges": dict(self.gauges),
            }

from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable
from enum import Enum
from abc import ABC, abstractmethod
import statistics


# ============================================================================
# TYPES AND ENUMS
# ============================================================================

class HealthStatus(Enum):
    """Statusuri pentru componentele de sănătate"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    UNKNOWN = "unknown"


class AlertSeverity(Enum):
    """Severități pentru alerte"""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class HealthComponent:
    """Starea unei componente individuale de sănătate"""
    name: str
    status: HealthStatus
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    latency_ms: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire la dicționar"""
        return {
            "name": self.name,
            "status": self.status.value,
            "message": self.message,
            "details": self.details,
            "timestamp": self.timestamp,
            "latency_ms": self.latency_ms
        }


@dataclass
class HealthState:
    """Starea completă a sistemului"""
    ok: bool
    status: HealthStatus
    components: Dict[str, HealthComponent]
    timestamp: float
    latency_ms: Optional[float] = None
    score: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire la dicționar"""
        return {
            "ok": self.ok,
            "status": self.status.value,
            "components": {k: v.to_dict() for k, v in self.components.items()},
            "timestamp": self.timestamp,
            "latency_ms": self.latency_ms,
            "score": self.score
        }


@dataclass
class Alert:
    """Structură pentru alerte"""
    id: str
    title: str
    message: str
    severity: AlertSeverity
    component: str
    timestamp: float = field(default_factory=time.time)
    acknowledged: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire la dicționar"""
        return {
            "id": self.id,
            "title": self.title,
            "message": self.message,
            "severity": self.severity.value,
            "component": self.component,
            "timestamp": self.timestamp,
            "acknowledged": self.acknowledged,
            "metadata": self.metadata
        }


# ============================================================================
# HEALTH CHECK PROTOCOL
# ============================================================================

@runtime_checkable
class HealthCheck(Protocol):
    """Protocol pentru verificări de sănătate"""
    
    @property
    def name(self) -> str:
        """Numele verificării"""
        pass
    
    @property
    def description(self) -> str:
        """Descrierea verificării"""
        pass
    
    @property
    def critical(self) -> bool:
        """Dacă verificarea este critică pentru sănătatea generală"""
        pass
    
    def run(self, engine: Any) -> HealthComponent:
        """Execută verificarea"""
        pass


# ============================================================================
# IMPLEMENTĂRI HEALTH CHECKS
# ============================================================================

class WSStaleCheck:
    """Verifică dacă WebSocket-urile sunt staled"""
    
    def __init__(self, stale_threshold_sec: float = 10.0, sample_size: int = 10):
        self._name = "websocket_stale"
        self._description = "Verifică dacă WebSocket-urile primesc date în timp util"
        self._critical = False
        self.stale_threshold = stale_threshold_sec
        self.sample_size = sample_size
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def critical(self) -> bool:
        return self._critical
    
    def run(self, engine: Any) -> HealthComponent:
        start_time = time.time()
        
        try:
            ws = getattr(engine, "ws", None)
            
            if not ws or not getattr(ws, "enabled", False):
                return HealthComponent(
                    name=self.name,
                    status=HealthStatus.HEALTHY,
                    message="WebSocket disabled",
                    details={"enabled": False}
                )
            
            # Obține perechile pentru eșantionare
            pairs = list(getattr(engine, "pairs", []) or [])[:self.sample_size]
            stale_symbols = []
            latest_age = 0.0
            
            for sym in pairs:
                data = ws.get(sym) or {}
                ts = float(data.get("ts") or 0.0)
                
                if ts > 0:
                    age = time.time() - ts
                    latest_age = max(latest_age, age)
                    
                    if age > self.stale_threshold:
                        stale_symbols.append({
                            "symbol": sym,
                            "age_sec": round(age, 1),
                            "last_update": ts
                        })
            
            status = HealthStatus.HEALTHY
            message = "WebSocket active"
            
            if stale_symbols:
                if len(stale_symbols) == len(pairs):
                    status = HealthStatus.CRITICAL
                    message = f"All WebSocket connections stale ({len(stale_symbols)} symbols)"
                else:
                    status = HealthStatus.WARNING
                    message = f"Partial WebSocket stale ({len(stale_symbols)}/{len(pairs)} symbols)"
            
            return HealthComponent(
                name=self.name,
                status=status,
                message=message,
                details={
                    "enabled": True,
                    "stale_symbols": stale_symbols,
                    "total_monitored": len(pairs),
                    "stale_threshold_sec": self.stale_threshold,
                    "latest_age_sec": round(latest_age, 1)
                },
                latency_ms=(time.time() - start_time) * 1000
            )
            
        except Exception as e:
            return HealthComponent(
                name=self.name,
                status=HealthStatus.CRITICAL,
                message=f"WebSocket check failed: {str(e)}",
                details={"error": str(e), "error_type": type(e).__name__},
                latency_ms=(time.time() - start_time) * 1000
            )


class ExchangeConnectivityCheck:
    """Verifică conectivitatea la exchange"""
    
    def __init__(self):
        self._name = "exchange_connectivity"
        self._description = "Verifică conectivitatea la exchange"
        self._critical = True  # Acesta este critic pentru sistem
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def critical(self) -> bool:
        return self._critical
    
    def run(self, engine: Any) -> HealthComponent:
        start_time = time.time()
        
        try:
            client = getattr(engine, "client", None)
            
            if not client:
                return HealthComponent(
                    name=self.name,
                    status=HealthStatus.CRITICAL,
                    message="Client not found",
                    details={"error": "No client available"}
                )
            
            # Încercăm să obținem un ticker pentru o pereche
            pairs = list(getattr(engine, "pairs", []) or [])
            test_symbol = pairs[0] if pairs else None
            
            if test_symbol:
                ticker = client.fetch_ticker_cached(test_symbol)
                
                if ticker and "last" in ticker:
                    return HealthComponent(
                        name=self.name,
                        status=HealthStatus.HEALTHY,
                        message="Exchange connectivity OK",
                        details={
                            "test_symbol": test_symbol,
                            "last_price": ticker.get("last"),
                            "timestamp": ticker.get("timestamp")
                        },
                        latency_ms=(time.time() - start_time) * 1000
                    )
                else:
                    return HealthComponent(
                        name=self.name,
                        status=HealthStatus.WARNING,
                        message="Exchange connectivity partial",
                        details={
                            "test_symbol": test_symbol,
                            "ticker_data": bool(ticker)
                        },
                        latency_ms=(time.time() - start_time) * 1000
                    )
            
            # Dacă nu avem perechi, încercăm altă metodă
            try:
                # Încercăm să obținem timpul serverului
                server_time = client.ex.fetch_time()
                return HealthComponent(
                    name=self.name,
                    status=HealthStatus.HEALTHY,
                    message="Exchange connectivity OK (server time)",
                    details={"server_time": server_time},
                    latency_ms=(time.time() - start_time) * 1000
                )
            except Exception as e:
                return HealthComponent(
                    name=self.name,
                    status=HealthStatus.CRITICAL,
                    message=f"Exchange connectivity failed: {str(e)}",
                    details={"error": str(e), "error_type": type(e).__name__},
                    latency_ms=(time.time() - start_time) * 1000
                )
                
        except Exception as e:
            return HealthComponent(
                name=self.name,
                status=HealthStatus.CRITICAL,
                message=f"Exchange check failed: {str(e)}",
                details={"error": str(e), "error_type": type(e).__name__},
                latency_ms=(time.time() - start_time) * 1000
            )


class OrderLifecycleCheck:
    """Verifică starea ciclului de ordine"""
    
    def __init__(self, stuck_threshold_sec: float = 120.0):
        self._name = "order_lifecycle"
        self._description = "Verifică ciclul de ordine pentru ordine blocate"
        self._critical = True
        self.stuck_threshold = stuck_threshold_sec
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def critical(self) -> bool:
        return self._critical
    
    def run(self, engine: Any) -> HealthComponent:
        start_time = time.time()
        
        try:
            # Sincronizează starea ordinelor
            olm = getattr(engine, "order_lifecycle", None)
            
            if olm:
                try:
                    olm.sync(engine)
                except Exception as sync_error:
                    # Log error dar continuăm
                    engine.log.warning(f"Order sync failed: {sync_error}")
            
            # Detectează ordine blocate
            stuck_orders = []
            if olm:
                stuck_orders = olm.detect_stuck(max_age_sec=self.stuck_threshold)
            
            if stuck_orders:
                status = HealthStatus.CRITICAL if len(stuck_orders) > 2 else HealthStatus.WARNING
                message = f"Found {len(stuck_orders)} stuck orders"
                
                order_details = []
                for order in stuck_orders:
                    order_details.append({
                        "order_id": getattr(order, "id", "unknown"),
                        "symbol": getattr(order, "symbol", "unknown"),
                        "status": getattr(order, "status", "unknown"),
                        "age_sec": round(time.time() - float(getattr(order, "created_at", time.time())), 1)
                    })
                
                return HealthComponent(
                    name=self.name,
                    status=status,
                    message=message,
                    details={
                        "stuck_orders": order_details,
                        "total_stuck": len(stuck_orders),
                        "stuck_threshold_sec": self.stuck_threshold
                    },
                    latency_ms=(time.time() - start_time) * 1000
                )
            else:
                return HealthComponent(
                    name=self.name,
                    status=HealthStatus.HEALTHY,
                    message="No stuck orders",
                    details={"stuck_orders": [], "stuck_threshold_sec": self.stuck_threshold},
                    latency_ms=(time.time() - start_time) * 1000
                )
                
        except Exception as e:
            return HealthComponent(
                name=self.name,
                status=HealthStatus.CRITICAL,
                message=f"Order lifecycle check failed: {str(e)}",
                details={"error": str(e), "error_type": type(e).__name__},
                latency_ms=(time.time() - start_time) * 1000
            )


class ReconciliationCheck:
    """Verifică starea reconcilierei"""
    
    def __init__(self, max_age_sec: float = 300.0):
        self._name = "reconciliation"
        self._description = "Verifică ultima reconciliere"
        self._critical = False
        self.max_age_sec = max_age_sec
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def critical(self) -> bool:
        return self._critical
    
    def run(self, engine: Any) -> HealthComponent:
        start_time = time.time()
        
        try:
            last_reconcile = getattr(engine, "_last_reconcile", None)
            
            if last_reconcile is None:
                return HealthComponent(
                    name=self.name,
                    status=HealthStatus.WARNING,
                    message="No reconciliation data",
                    details={"last_reconcile": None},
                    latency_ms=(time.time() - start_time) * 1000
                )
            
            # Dacă e un dicționar cu timestamp
            if isinstance(last_reconcile, dict):
                reconcile_ts = last_reconcile.get("timestamp", 0)
                reconcile_age = time.time() - reconcile_ts if reconcile_ts > 0 else float('inf')
                
                if reconcile_age > self.max_age_sec:
                    status = HealthStatus.WARNING
                    message = f"Reconciliation stale ({round(reconcile_age)}s old)"
                else:
                    status = HealthStatus.HEALTHY
                    message = f"Reconciliation recent ({round(reconcile_age)}s ago)"
                
                return HealthComponent(
                    name=self.name,
                    status=status,
                    message=message,
                    details={
                        "last_reconcile": last_reconcile,
                        "age_sec": round(reconcile_age, 1),
                        "max_age_sec": self.max_age_sec
                    },
                    latency_ms=(time.time() - start_time) * 1000
                )
            else:
                # Dacă e doar un timestamp
                reconcile_age = time.time() - float(last_reconcile) if last_reconcile > 0 else float('inf')
                
                if reconcile_age > self.max_age_sec:
                    status = HealthStatus.WARNING
                    message = f"Reconciliation stale ({round(reconcile_age)}s old)"
                else:
                    status = HealthStatus.HEALTHY
                    message = f"Reconciliation recent ({round(reconcile_age)}s ago)"
                
                return HealthComponent(
                    name=self.name,
                    status=status,
                    message=message,
                    details={
                        "last_reconcile": last_reconcile,
                        "age_sec": round(reconcile_age, 1),
                        "max_age_sec": self.max_age_sec
                    },
                    latency_ms=(time.time() - start_time) * 1000
                )
                
        except Exception as e:
            return HealthComponent(
                name=self.name,
                status=HealthStatus.WARNING,
                message=f"Reconciliation check failed: {str(e)}",
                details={"error": str(e), "error_type": type(e).__name__},
                latency_ms=(time.time() - start_time) * 1000
            )


class SystemResourcesCheck:
    """Verifică resursele sistemului"""
    
    def __init__(self):
        self._name = "system_resources"
        self._description = "Verifică utilizarea resurselor sistemului"
        self._critical = False
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def critical(self) -> bool:
        return self._critical
    
    def run(self, engine: Any) -> HealthComponent:
        start_time = time.time()
        
        try:
            import psutil
            import os
            
            process = psutil.Process(os.getpid())
            
            # Memorie
            memory_info = process.memory_info()
            memory_percent = process.memory_percent()
            
            # CPU
            cpu_percent = process.cpu_percent(interval=0.1)
            
            # Threads
            num_threads = process.num_threads()
            
            # Disk I/O (dacă este disponibil)
            io_counters = process.io_counters()
            
            details = {
                "memory_rss_mb": round(memory_info.rss / 1024 / 1024, 1),
                "memory_percent": round(memory_percent, 1),
                "cpu_percent": round(cpu_percent, 1),
                "threads": num_threads,
                "read_bytes_mb": round(io_counters.read_bytes / 1024 / 1024, 1) if io_counters else 0,
                "write_bytes_mb": round(io_counters.write_bytes / 1024 / 1024, 1) if io_counters else 0,
                "create_time": process.create_time()
            }
            
            # Determină statusul
            if memory_percent > 90 or cpu_percent > 90:
                status = HealthStatus.WARNING
                message = "High resource usage"
            elif memory_percent > 70 or cpu_percent > 70:
                status = HealthStatus.WARNING
                message = "Moderate resource usage"
            else:
                status = HealthStatus.HEALTHY
                message = "Resources normal"
            
            return HealthComponent(
                name=self.name,
                status=status,
                message=message,
                details=details,
                latency_ms=(time.time() - start_time) * 1000
            )
            
        except ImportError:
            return HealthComponent(
                name=self.name,
                status=HealthStatus.UNKNOWN,
                message="psutil not available",
                details={"error": "psutil package required for system checks"},
                latency_ms=(time.time() - start_time) * 1000
            )
        except Exception as e:
            return HealthComponent(
                name=self.name,
                status=HealthStatus.UNKNOWN,
                message=f"System check failed: {str(e)}",
                details={"error": str(e), "error_type": type(e).__name__},
                latency_ms=(time.time() - start_time) * 1000
            )


# ============================================================================
# HEALTH MONITOR
# ============================================================================

class HealthMonitor:
    """
    Monitor periodic pentru sănătatea runtime.
    
    Verificări incluse:
      - Stale WebSocket cache
      - Conectivitatea la exchange
      - Sincronizarea stării / reconciliere
      - Ordine blocate
      - Resurse sistem
    """
    
    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log

        # Lock pentru thread safety.
        # IMPORTANT: trebuie inițializat înainte de orice folosire a property-ului last_state
        self._lock = threading.RLock()
        
        # Configurație
        health_cfg = self.cfg.get("health", {})
        self.interval_sec = float(health_cfg.get("interval_sec", 15.0))
        self.alerts_enabled = bool(health_cfg.get("alerts", True))
        self.alert_cooldown_sec = float(health_cfg.get("alert_cooldown_sec", 120.0))
        
        # Stare (backing field; property last_state folosește _lock)
        self._last_state: Optional[HealthState] = None
        self.history: List[HealthState] = []
        self.max_history = int(health_cfg.get("history_size", 100))
        
        # Alerte
        self.active_alerts: Dict[str, Alert] = {}
        self.alert_history: List[Alert] = []
        self.max_alert_history = int(health_cfg.get("alert_history_size", 1000))
        self._last_alert_sent: Dict[str, float] = {}
        
        # Verificări
        self.checks: List[HealthCheck] = []
        self._setup_checks(health_cfg)
        
        # Metrici
        self.metrics = {
            "total_checks": 0,
            "failed_checks": 0,
            "total_alerts": 0,
            "last_check_time": 0.0,
            "avg_check_latency": 0.0,
            "latency_history": []
        }
        
        self.log.info(f"HealthMonitor initializat cu {len(self.checks)} verificări, interval: {self.interval_sec}s")
    
    def _setup_checks(self, health_cfg: Dict[str, Any]) -> None:
        """Configurează verificările de sănătate"""
        # Verificări standard
        ws_stale_sec = float(health_cfg.get("ws_stale_sec", 10.0))
        ws_sample = int(health_cfg.get("ws_sample", 10))
        orders_stuck_sec = float(health_cfg.get("orders_stuck_sec", 120.0))
        reconcile_max_age = float(health_cfg.get("reconcile_max_age_sec", 300.0))
        
        self.checks.extend([
            WSStaleCheck(stale_threshold_sec=ws_stale_sec, sample_size=ws_sample),
            ExchangeConnectivityCheck(),
            OrderLifecycleCheck(stuck_threshold_sec=orders_stuck_sec),
            ReconciliationCheck(max_age_sec=reconcile_max_age),
            SystemResourcesCheck()
        ])
        
        # Verificări personalizate din config
        custom_checks = health_cfg.get("custom_checks", [])
        for check_cfg in custom_checks:
            try:
                check = self._create_custom_check(check_cfg)
                if check:
                    self.checks.append(check)
            except Exception as e:
                self.log.error(f"Failed to create custom check: {e}")
    
    def _create_custom_check(self, check_cfg: Dict[str, Any]) -> Optional[HealthCheck]:
        """Creează o verificare personalizată din configurație"""
        # Aceasta ar putea fi extinsă pentru a încărca verificări din module
        # Pentru moment, returnăm None
        return None
    
    def add_check(self, check: HealthCheck) -> None:
        """Adaugă o verificare personalizată"""
        with self._lock:
            self.checks.append(check)
            self.log.info(f"Added health check: {check.name}")
    
    def remove_check(self, check_name: str) -> bool:
        """Elimină o verificare după nume"""
        with self._lock:
            initial_count = len(self.checks)
            self.checks = [c for c in self.checks if c.name != check_name]
            removed = len(self.checks) < initial_count
            
            if removed:
                self.log.info(f"Removed health check: {check_name}")
            
            return removed
    
    @property
    def last_state(self) -> Optional[HealthState]:
        """Returnează ultima stare"""
        with self._lock:
            return self._last_state if hasattr(self, '_last_state') else None
    
    @last_state.setter
    def last_state(self, value: Optional[HealthState]):
        with self._lock:
            self._last_state = value
    
    def check_now(self, engine: Any) -> HealthState:
        """Execută verificările imediat"""
        return self.run_once(engine)
    
    def tick(self, engine: Any) -> Optional[HealthState]:
        """
        Execută verificările la intervalul configurat.
        Returnează noua stare dacă s-a executat o verificare.
        """
        now = time.time()
        last_check = self.metrics.get("last_check_time", 0.0)
        
        if (now - last_check) >= max(1.0, self.interval_sec):
            return self.run_once(engine)
        
        return None
    
    def run_once(self, engine: Any) -> HealthState:
        """Execută toate verificările o dată"""
        start_time = time.time()
        
        with self._lock:
            components: Dict[str, HealthComponent] = {}
            latencies = []
            
            # Execută fiecare verificare
            for check in self.checks:
                try:
                    component = check.run(engine)
                    components[check.name] = component
                    
                    if component.latency_ms:
                        latencies.append(component.latency_ms)
                        
                except Exception as e:
                    self.log.error(f"Health check {check.name} failed: {e}")
                    
                    components[check.name] = HealthComponent(
                        name=check.name,
                        status=HealthStatus.CRITICAL,
                        message=f"Check execution failed: {str(e)}",
                        details={"error": str(e), "error_type": type(e).__name__}
                    )
            
            # Calculează sănătatea generală
            ok = True
            critical_failures = 0
            warnings = 0
            
            for component in components.values():
                if component.status == HealthStatus.CRITICAL:
                    critical_failures += 1
                    # Verifică dacă componenta este critică pentru sistem
                    check = next((c for c in self.checks if c.name == component.name), None)
                    if check and check.critical:
                        ok = False
                elif component.status == HealthStatus.WARNING:
                    warnings += 1
            
            # Determină statusul general
            if critical_failures > 0:
                overall_status = HealthStatus.CRITICAL
            elif warnings > 0:
                overall_status = HealthStatus.WARNING
            else:
                overall_status = HealthStatus.HEALTHY
            
            # Calculează scor (0-100)
            total_checks = len(components)
            healthy_checks = sum(1 for c in components.values() if c.status == HealthStatus.HEALTHY)
            score = (healthy_checks / total_checks * 100) if total_checks > 0 else 100.0
            
            # Creează starea
            latency_ms = (time.time() - start_time) * 1000
            state = HealthState(
                ok=ok,
                status=overall_status,
                components=components,
                timestamp=time.time(),
                latency_ms=round(latency_ms, 1),
                score=round(score, 1)
            )
            
            # Actualizează istoric
            self.last_state = state
            self.history.append(state)
            
            # Limitează istoricul
            if len(self.history) > self.max_history:
                self.history = self.history[-self.max_history:]
            
            # Actualizează metrici
            self.metrics["total_checks"] += total_checks
            self.metrics["failed_checks"] += sum(1 for c in components.values() 
                                                if c.status in [HealthStatus.CRITICAL, HealthStatus.WARNING])
            self.metrics["last_check_time"] = time.time()
            
            if latencies:
                avg_latency = statistics.mean(latencies)
                self.metrics["avg_check_latency"] = round(avg_latency, 1)
                self.metrics["latency_history"].append(avg_latency)
                if len(self.metrics["latency_history"]) > 100:
                    self.metrics["latency_history"] = self.metrics["latency_history"][-100:]
            
            # Gestionează alerte
            if not ok and self.alerts_enabled:
                self._handle_alerts(engine, state)
            
            # Logging
            if overall_status == HealthStatus.CRITICAL:
                self.log.error(f"Health critical: {critical_failures} critical, {warnings} warnings")
            elif overall_status == HealthStatus.WARNING:
                self.log.warning(f"Health warning: {warnings} warnings")
            else:
                self.log.debug(f"Health OK: score={score}%, latency={latency_ms:.1f}ms")
            
            return state
    
    def _handle_alerts(self, engine: Any, state: HealthState) -> None:
        """Gestionează alertele pentru starea curentă"""
        now = time.time()
        
        for component_name, component in state.components.items():
            if component.status not in [HealthStatus.CRITICAL, HealthStatus.WARNING]:
                continue
            
            # Generează ID unic pentru alertă
            alert_id = f"{component_name}_{int(now)}"
            
            # Verifică dacă avem deja această alertă activă
            if alert_id in self.active_alerts:
                continue
            
            # Rate limiting per componentă
            last_alert = self._last_alert_sent.get(component_name, 0)
            if (now - last_alert) < self.alert_cooldown_sec:
                continue
            
            # Creează alerta
            severity = AlertSeverity.CRITICAL if component.status == HealthStatus.CRITICAL else AlertSeverity.WARNING
            title = f"Health {component.status.value}: {component_name}"
            
            alert = Alert(
                id=alert_id,
                title=title,
                message=component.message,
                severity=severity,
                component=component_name,
                metadata=component.details
            )
            
            # Salvează alerta
            self.active_alerts[alert_id] = alert
            self.alert_history.append(alert)
            
            # Limitează istoricul alerțelor
            if len(self.alert_history) > self.max_alert_history:
                self.alert_history = self.alert_history[-self.max_alert_history:]
            
            # Trimite notificare
            self._send_alert(engine, alert)
            
            # Actualizează timestamp-ul ultimei alerte
            self._last_alert_sent[component_name] = now
            self.metrics["total_alerts"] += 1
    
    def _send_alert(self, engine: Any, alert: Alert) -> None:
        """Trimite o alertă prin sistemul de notificări"""
        try:
            notifier = getattr(engine, "notifier", None)
            if notifier:
                # Formatează mesajul
                message = f"[{alert.severity.value.upper()}] {alert.title}: {alert.message}"
                
                # Adaugă detalii
                if alert.metadata:
                    details_str = ", ".join(f"{k}={v}" for k, v in alert.metadata.items() if k != "error")
                    if details_str:
                        message += f" ({details_str})"
                
                notifier.send(message)
                
                self.log.warning(f"Alert sent: {alert.title}")
        except Exception as e:
            self.log.error(f"Failed to send alert: {e}")
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """Marchează o alertă ca fiind recunoscută"""
        with self._lock:
            if alert_id in self.active_alerts:
                self.active_alerts[alert_id].acknowledged = True
                return True
            return False
    
    def clear_alert(self, alert_id: str) -> bool:
        """Șterge o alertă activă"""
        with self._lock:
            if alert_id in self.active_alerts:
                del self.active_alerts[alert_id]
                return True
            return False
    
    def clear_all_alerts(self) -> int:
        """Șterge toate alertele active și returnează numărul șters"""
        with self._lock:
            count = len(self.active_alerts)
            self.active_alerts.clear()
            return count
    
    def get_status(self) -> Dict[str, Any]:
        """Returnează statusul curent al monitorului"""
        with self._lock:
            last_state_dict = self.last_state.to_dict() if self.last_state else None
            
            return {
                "enabled": True,
                "interval_sec": self.interval_sec,
                "checks_count": len(self.checks),
                "last_check": self.metrics.get("last_check_time", 0),
                "active_alerts": len(self.active_alerts),
                "last_state": last_state_dict,
                "metrics": self.metrics.copy()
            }
    
    def get_checks_info(self) -> List[Dict[str, Any]]:
        """Returnează informații despre toate verificările"""
        with self._lock:
            return [
                {
                    "name": check.name,
                    "description": check.description,
                    "critical": check.critical
                }
                for check in self.checks
            ]
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """Returnează alertele active"""
        with self._lock:
            return [alert.to_dict() for alert in self.active_alerts.values()]
    
    def get_alert_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Returnează istoricul alerțelor"""
        with self._lock:
            recent = self.alert_history[-limit:] if self.alert_history else []
            return [alert.to_dict() for alert in recent]
    
    def get_health_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Returnează istoricul stărilor de sănătate"""
        with self._lock:
            recent = self.history[-limit:] if self.history else []
            return [state.to_dict() for state in recent]
    
    def reset_metrics(self) -> None:
        """Resetează metricile"""
        with self._lock:
            self.metrics = {
                "total_checks": 0,
                "failed_checks": 0,
                "total_alerts": 0,
                "last_check_time": 0.0,
                "avg_check_latency": 0.0,
                "latency_history": []
            }


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def create_health_monitor(cfg: Dict[str, Any], log: Any) -> HealthMonitor:
    """Factory function pentru a crea un HealthMonitor"""
    return HealthMonitor(cfg, log)
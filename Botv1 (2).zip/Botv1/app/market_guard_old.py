from __future__ import annotations
import time
from typing import Any, List, Optional
from .indicators import atr

class MarketGuard:
    """Simple circuit breaker:
    - trips if ATR% on key symbols exceeds threshold
    - trips if a large fraction of universe is negative over last N bars (breadth)
    """
    def __init__(self, cfg: dict, log: Any):
        self.cfg = cfg.get("market_guard", {}) or {}
        self.enabled = bool(self.cfg.get("enabled", True))
        self.log = log
        self._cooldown_until = 0.0

    def is_tripped(self) -> bool:
        return self.enabled and time.time() < self._cooldown_until

    def seconds_left(self) -> int:
        return max(0, int(self._cooldown_until - time.time())) if self.is_tripped() else 0

    def _atr_pct(self, df, period: int) -> float:
        if df is None or len(df) < period + 5:
            return 0.0
        a = float(atr(df, period).iloc[-1])
        px = float(df["close"].iloc[-1])
        return a / max(1e-12, px)

    def check(self, client, pairs: List[str]) -> Optional[str]:
        if not self.enabled or self.is_tripped():
            return None

        tf = str(self.cfg.get("timeframe", "5m"))
        period = int(self.cfg.get("atr_period", 14))
        halt_thr = float(self.cfg.get("atr_pct_halt", 0.02))
        cooldown = int(self.cfg.get("cooldown_sec", 300))

        for sym in (self.cfg.get("symbols") or []):
            try:
                df = client.fetch_ohlcv_df(sym, tf, limit=200)
                ap = self._atr_pct(df, period)
                if ap >= halt_thr:
                    self._cooldown_until = time.time() + cooldown
                    return f"{sym} ATR% {ap*100:.2f} >= {halt_thr*100:.2f}"
            except Exception:
                continue

        uni_max = int(self.cfg.get("breadth_universe_max", 40))
        drop_thr = float(self.cfg.get("breadth_drop_pct", 0.65))
        syms = list(dict.fromkeys(pairs))[:uni_max]

        neg=0; tot=0
        lookback=int(self.cfg.get("breadth_lookback_bars", 6))
        for sym in syms:
            try:
                df = client.fetch_ohlcv_df(sym, tf, limit=max(lookback+5, 30))
                if df is None or len(df) < lookback+1:
                    continue
                r = (float(df["close"].iloc[-1]) / float(df["close"].iloc[-(lookback+1)])) - 1.0
                tot += 1
                if r < 0:
                    neg += 1
            except Exception:
                continue

        if tot >= max(10, uni_max//3):
            frac = neg / tot
            if frac >= drop_thr:
                self._cooldown_until = time.time() + cooldown
                return f"breadth negative {frac*100:.1f}% >= {drop_thr*100:.1f}%"
        return None

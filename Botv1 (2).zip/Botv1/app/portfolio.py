from __future__ import annotations

import time
import threading
from typing import Any, Dict, List, Optional, Tuple

# Optional: numpy accelerates corr; fallback exists if missing
try:
    import numpy as np  # type: ignore
except Exception:
    np = None  # type: ignore


def _now() -> float:
    return time.time()


def _f(x: Any, d: float = 0.0) -> float:
    try:
        v = float(x)
        # sanitize NaN/Inf
        if v != v or v in (float("inf"), float("-inf")):
            return float(d)
        return v
    except Exception:
        return float(d)


def _s(x: Any, d: str = "") -> str:
    try:
        if x is None:
            return d
        return str(x)
    except Exception:
        return d


def _obj_to_dict(x: Any) -> Dict[str, Any]:
    if x is None:
        return {}
    if isinstance(x, dict):
        return x
    if hasattr(x, "to_dict") and callable(getattr(x, "to_dict")):
        try:
            v = x.to_dict()
            return v if isinstance(v, dict) else {"value": v}
        except Exception:
            pass
    if hasattr(x, "__dict__"):
        try:
            return dict(x.__dict__)
        except Exception:
            pass
    return {"repr": _s(x)}


def _normalize_positions(ex_pos: Any) -> List[Dict[str, Any]]:
    """
    Accepts:
      - dict: {symbol: {side, qty, entry, ...}}
      - list: [{symbol, side, qty, entry, ...}, ...]
    Normalizes qty as absolute and side as long/short.
    """
    out: List[Dict[str, Any]] = []

    if isinstance(ex_pos, dict):
        items = list(ex_pos.items())
        for sym, p in items:
            if not isinstance(p, dict):
                continue
            qty = _f(p.get("qty") or p.get("size") or p.get("contracts") or p.get("positionAmt"), 0.0)
            side = _s(p.get("side") or p.get("positionSide") or "")
            entry = _f(p.get("entry") or p.get("avg_price") or p.get("avgPrice") or p.get("entryPrice"), 0.0)
            side_l = side.lower().strip() if side else ""
            if not side_l:
                side_l = "short" if qty < 0 else ("long" if qty > 0 else "")
            if side_l in ("buy", "long"):
                side_l = "long"
            elif side_l in ("sell", "short"):
                side_l = "short"
            out.append({"symbol": _s(sym), "side": side_l, "qty": abs(float(qty)), "entry": float(entry)})
        return out

    if isinstance(ex_pos, list):
        for p in ex_pos:
            if not isinstance(p, dict):
                p = _obj_to_dict(p)
            sym = _s(p.get("symbol") or p.get("sym") or p.get("pair") or "")
            if not sym:
                continue
            qty = _f(p.get("qty") or p.get("size") or p.get("contracts") or p.get("positionAmt"), 0.0)
            side = _s(p.get("side") or p.get("positionSide") or "")
            entry = _f(p.get("entry") or p.get("avg_price") or p.get("avgPrice") or p.get("entryPrice"), 0.0)
            side_l = side.lower().strip() if side else ""
            if not side_l:
                side_l = "short" if qty < 0 else ("long" if qty > 0 else "")
            if side_l in ("buy", "long"):
                side_l = "long"
            elif side_l in ("sell", "short"):
                side_l = "short"
            out.append({"symbol": sym, "side": side_l, "qty": abs(float(qty)), "entry": float(entry)})
        return out

    return out


# ============================================================
# Correlation gate (portfolio risk) — REQUIRED by engine.py
# Supports BOTH call styles used in project:
#   A) corr_ok(cfg, candidate, open_symbols, returns_map)
#   B) corr_ok(candidate, open_symbols, returns_map, max_corr=0.85, lookback=120)
# ============================================================

def _finite_float_list(x: Any) -> List[float]:
    """Convert array-like to list[float] while dropping NaN/Inf and None."""
    out: List[float] = []
    if x is None:
        return out
    try:
        # numpy array / list
        for v in list(x):
            try:
                fv = float(v)
                if fv != fv or fv in (float("inf"), float("-inf")):
                    continue
                out.append(fv)
            except Exception:
                continue
    except Exception:
        return out
    return out


def _corr_abs(a: List[float], b: List[float]) -> Optional[float]:
    """Return abs(Pearson corr) or None if not computable."""
    n = min(len(a), len(b))
    if n < 2:
        return None
    a2 = a[-n:]
    b2 = b[-n:]

    # If numpy is available, use it
    if np is not None:
        try:
            aa = np.asarray(a2, dtype=float)
            bb = np.asarray(b2, dtype=float)
            if aa.size < 2 or bb.size < 2:
                return None
            c = float(np.corrcoef(aa, bb)[0, 1])
            if c != c or c in (float("inf"), float("-inf")):
                return None
            return abs(c)
        except Exception:
            pass

    # Fallback: pure python corr
    try:
        mean_a = sum(a2) / n
        mean_b = sum(b2) / n
        cov = 0.0
        va = 0.0
        vb = 0.0
        for i in range(n):
            da = a2[i] - mean_a
            db = b2[i] - mean_b
            cov += da * db
            va += da * da
            vb += db * db
        denom = (va ** 0.5) * (vb ** 0.5)
        if denom <= 1e-18:
            return None
        c = cov / denom
        if c != c or c in (float("inf"), float("-inf")):
            return None
        return abs(float(c))
    except Exception:
        return None


def corr_ok(*args, **kwargs) -> bool:
    """
    Portfolio correlation filter.

    Compatible signatures:
      1) corr_ok(cfg: dict, candidate: str, open_symbols: List[str], returns_map: Dict[str, array])
      2) corr_ok(candidate: str, open_symbols: List[str], returns_map: Dict[str, array], max_corr=0.85, lookback=120)

    returns_map values are "returns" arrays (log returns), usually created by engine._compute_returns_map().
    """
    # Defaults
    max_corr_default = float(kwargs.get("max_corr", 0.85))
    lookback_default = int(kwargs.get("lookback", 120))
    min_n_default = int(kwargs.get("min_n", 20))

    cfg: Dict[str, Any] = {}
    candidate: str = ""
    open_symbols: List[str] = []
    returns_map: Dict[str, Any] = {}

    # Detect signature
    if len(args) >= 4 and isinstance(args[0], dict):
        # Signature A
        cfg = args[0] or {}
        candidate = str(args[1])
        open_symbols = list(args[2] or [])
        returns_map = args[3] or {}
        # Read filter config from cfg
        filt = ((cfg.get("risk") or {}).get("portfolio") or {}).get("correlation_filter") or {}
        enabled = bool(filt.get("enabled", True))
        max_corr = float(filt.get("max_corr", max_corr_default))
        lookback = int(filt.get("lookback", lookback_default))
        min_n = int(filt.get("min_n", min_n_default))
        if not enabled:
            return True
    else:
        # Signature B
        if len(args) < 3:
            return True
        candidate = str(args[0])
        open_symbols = list(args[1] or [])
        returns_map = args[2] or {}
        max_corr = float(kwargs.get("max_corr", max_corr_default))
        lookback = int(kwargs.get("lookback", lookback_default))
        min_n = int(kwargs.get("min_n", min_n_default))

    # If no open symbols, it's OK
    if not open_symbols:
        return True

    # Candidate returns
    r_c = _finite_float_list(returns_map.get(candidate))
    if not r_c:
        return True

    # Clip to lookback
    if lookback > 0 and len(r_c) > lookback:
        r_c = r_c[-lookback:]

    if len(r_c) < min_n:
        return True

    # Compare vs each open symbol
    for sym in open_symbols:
        if not sym or str(sym) == candidate:
            continue
        r_o = _finite_float_list(returns_map.get(sym))
        if not r_o:
            continue
        if lookback > 0 and len(r_o) > lookback:
            r_o = r_o[-lookback:]
        if len(r_o) < min_n:
            continue

        # Align last n samples
        n = min(len(r_c), len(r_o))
        if n < min_n:
            continue

        cabs = _corr_abs(r_c[-n:], r_o[-n:])
        if cabs is None:
            continue
        if cabs > float(max_corr):
            return False

    return True


# ============================================================
# PortfolioSnapshotter (existing)
# ============================================================

class PortfolioSnapshotter:
    """Source of truth portfolio snapshot.

    In LIVE mode it queries the exchange; in PAPER it returns PaperPortfolio state.
    The resulting schema is stable for dashboard usage.

    Contract (stable):
      {
        "ts": float,
        "ok": bool,
        "stale": bool,
        "mode": "paper"|"live",
        "exchange": str,
        "equity": float,
        "balances": {"free": float, "used": float, "total": float, "currency": str, "raw": optional},
        "futures": {"enabled": bool, "margin_mode": str|None, "leverage": int|None, "hedge_mode": bool|None},
        "positions": [ ... ],
        "open_orders": [ ... ],
        "pending": [ ... ],
        "risk_state": optional,
        "regime": optional,
        "errors": [str, ...]
      }
    """

    def __init__(self, engine: Any):
        self.engine = engine
        self._cache: Optional[Dict[str, Any]] = None
        self._cache_ts: float = 0.0
        self._lock = threading.RLock()

    # ---- public API ----

    def snapshot(self, ttl_sec: float = 1.0, force: bool = False) -> Dict[str, Any]:
        return self.get(ttl_sec=ttl_sec, force=force)

    def get(self, ttl_sec: float = 1.0, force: bool = False) -> Dict[str, Any]:
        now = _now()
        with self._lock:
            if (not force) and self._cache and (now - self._cache_ts) <= float(ttl_sec):
                return dict(self._cache)

        mode = str(getattr(self.engine, "cfg", {}).get("mode", "paper")).lower().strip()
        if mode == "live":
            snap = self._live_snapshot()
        else:
            snap = self._paper_snapshot()

        with self._lock:
            self._cache = snap
            self._cache_ts = now
        return dict(snap)

    # ---- helpers ----

    def _engine_equity_best_effort(self) -> float:
        eng = self.engine

        # 1) metrics.state.equity
        try:
            m = getattr(eng, "metrics", None)
            if m is not None and getattr(m, "state", None) is not None:
                v = getattr(m.state, "equity", None)
                if v is not None:
                    return float(v)
        except Exception:
            pass

        # 2) eng.equity() dacă există
        try:
            eq_fn = getattr(eng, "equity", None)
            if callable(eq_fn):
                return float(eq_fn())
        except Exception:
            pass

        # 3) paper cash/equity dacă există
        try:
            paper = getattr(eng, "paper", None) or getattr(eng, "paper_portfolio", None)
            if paper is not None:
                for name in ("equity", "cash_quote", "cash", "balance", "free_cash"):
                    v = getattr(paper, name, None)
                    if v is not None:
                        return float(v)
        except Exception:
            pass

        # 4) fallback la config paper.initial_cash_quote
        try:
            cfg = getattr(eng, "cfg", {}) or {}
            p = (cfg.get("paper", {}) or {})
            v = p.get("initial_cash_quote", None)
            if v is not None:
                return float(v)
        except Exception:
            pass

        return 0.0

    def _common_meta(self) -> Dict[str, Any]:
        eng = self.engine
        cfg = getattr(eng, "cfg", {}) or {}
        # risk_state exposure (if set by orchestrator)
        risk_state = None
        try:
            risk_state = {
                "state": _s(getattr(eng, "_risk_state_state", None)),
                "risk_mult": _f(getattr(eng, "_risk_state_risk_mult", None), 1.0),
                "reason": _s(getattr(eng, "_risk_state_reason", None)),
                "ts": _f(getattr(eng, "_risk_state_ts", None), 0.0),
            }
            if not risk_state["state"]:
                risk_state = None
        except Exception:
            risk_state = None

        # regime exposure (if present)
        regime = None
        try:
            rd = getattr(eng, "regime_detector", None)
            if rd and hasattr(rd, "get_global"):
                regime = rd.get_global()
        except Exception:
            regime = None

        return {"exchange": _s(cfg.get("exchange", "")), "risk_state": risk_state, "regime": regime}

    def _paper_snapshot(self) -> Dict[str, Any]:
        eng = self.engine
        paper = getattr(eng, "paper", None) or getattr(eng, "paper_portfolio", None)
        eq = self._engine_equity_best_effort()

        positions: List[Dict[str, Any]] = []
        if paper is not None and getattr(paper, "positions", None):
            for sym, p in (paper.positions or {}).items():
                try:
                    if isinstance(p, dict):
                        qty = float(p.get("qty") or p.get("size") or 0.0)
                        entry = float(p.get("avg_price") or p.get("entry") or p.get("price") or 0.0)
                        upnl = float(p.get("unrealized_pnl") or p.get("upl") or 0.0)
                    else:
                        qty = float(getattr(p, "qty", 0.0) or 0.0)
                        entry = float(getattr(p, "avg_price", 0.0) or getattr(p, "entry", 0.0) or 0.0)
                        upnl = float(getattr(p, "unrealized_pnl", 0.0) or 0.0)

                    if qty == 0.0:
                        continue

                    side = "long" if qty > 0 else "short"
                    positions.append(
                        {"symbol": str(sym), "side": side, "qty": abs(qty), "entry": entry, "unrealized_pnl": upnl}
                    )
                except Exception:
                    continue

        pending: List[Dict[str, Any]] = []
        try:
            pend = getattr(eng, "pending", {}) or {}
            if isinstance(pend, dict):
                for k, po in pend.items():
                    if isinstance(po, dict):
                        d = dict(po)
                        d.setdefault("key", str(k))
                        pending.append(d)
                    else:
                        pending.append(getattr(po, "__dict__", {"key": str(k), "repr": str(po)}))
            elif isinstance(pend, list):
                for po in pend:
                    pending.append(po if isinstance(po, dict) else getattr(po, "__dict__", {"repr": str(po)}))
        except Exception:
            pending = []

        quote = str(getattr(eng, "cfg", {}).get("quote_asset", "USDT")).upper()
        meta = self._common_meta()

        return {
            "ts": _now(),
            "ok": True,
            "stale": False,
            "mode": "paper",
            "exchange": meta.get("exchange", ""),
            "equity": float(eq),
            "balances": {"free": float(eq), "used": 0.0, "total": float(eq), "currency": quote},
            "futures": {
                "enabled": bool(getattr(eng, "cfg", {}).get("enable_futures", False)),
                "margin_mode": None,
                "leverage": None,
                "hedge_mode": None,
            },
            "positions": positions,
            "open_orders": [],
            "pending": pending,
            "risk_state": meta.get("risk_state"),
            "regime": meta.get("regime"),
            "errors": [],
        }

    def _live_snapshot(self) -> Dict[str, Any]:
        eng = self.engine
        client = getattr(eng, "client", None)
        meta = self._common_meta()
        errors: List[str] = []

        if not client:
            return {
                "ts": _now(),
                "ok": False,
                "stale": False,
                "mode": "live",
                "exchange": meta.get("exchange", ""),
                "error": "missing_exchange_client",
                "errors": ["missing_exchange_client"],
            }

        # Stale-while-revalidate: if live call fails, return last ok cache as stale
        def stale_fallback(err: str) -> Dict[str, Any]:
            with self._lock:
                if self._cache and bool(self._cache.get("ok", False)):
                    s = dict(self._cache)
                    s["ts"] = _now()
                    s["stale"] = True
                    s["ok"] = True
                    s.setdefault("errors", [])
                    s["errors"] = list(s["errors"]) + [err]
                    return s
            return {
                "ts": _now(),
                "ok": False,
                "stale": False,
                "mode": "live",
                "exchange": meta.get("exchange", ""),
                "errors": [err],
                "error": err,
            }

        # balance
        bal: Dict[str, Any] = {}
        try:
            if hasattr(client, "fetch_balance") and callable(getattr(client, "fetch_balance")):
                bal = client.fetch_balance() or {}
            else:
                bal = {}
        except Exception as e:
            return stale_fallback(f"fetch_balance:{type(e).__name__}:{e}")

        # positions
        positions: List[Dict[str, Any]] = []
        try:
            ex_pos = {}
            if hasattr(client, "fetch_open_positions") and callable(getattr(client, "fetch_open_positions")):
                ex_pos = client.fetch_open_positions() or {}
            positions = _normalize_positions(ex_pos)
        except Exception as e:
            errors.append(f"fetch_open_positions:{type(e).__name__}:{e}")

        # open orders
        open_orders: List[Dict[str, Any]] = []
        try:
            if hasattr(client, "fetch_open_orders") and callable(getattr(client, "fetch_open_orders")):
                open_orders = client.fetch_open_orders(limit=200) or []
            if not isinstance(open_orders, list):
                open_orders = []
        except Exception as e:
            errors.append(f"fetch_open_orders:{type(e).__name__}:{e}")

        # pending from engine (planned orders)
        pending: List[Dict[str, Any]] = []
        try:
            pend = getattr(eng, "pending", None) or getattr(eng, "pending_orders", None) or {}
            if isinstance(pend, dict):
                for k, po in pend.items():
                    if isinstance(po, dict):
                        d = dict(po)
                        d.setdefault("key", str(k))
                        pending.append(d)
                    else:
                        pending.append(getattr(po, "__dict__", {"key": str(k), "repr": str(po)}))
            elif isinstance(pend, list):
                for po in pend:
                    pending.append(po if isinstance(po, dict) else getattr(po, "__dict__", {"repr": str(po)}))
        except Exception:
            pending = []

        # Normalize balances from CCXT shape (best-effort)
        quote = str(getattr(eng, "cfg", {}).get("quote_asset", "USDT")).upper()
        free = used = total = 0.0
        try:
            if isinstance(bal, dict):
                bq = bal.get(quote)
                if isinstance(bq, dict):
                    free = float(bq.get("free") or 0.0)
                    used = float(bq.get("used") or 0.0)
                    total = float(bq.get("total") or 0.0)
                else:
                    free = float((bal.get("free") or {}).get(quote) or 0.0)
                    used = float((bal.get("used") or {}).get(quote) or 0.0)
                    total = float((bal.get("total") or {}).get(quote) or 0.0)
        except Exception:
            pass

        # Futures metadata
        fut_cfg = (getattr(eng, "cfg", {}).get("futures") or {})
        futures_meta = {
            "enabled": bool(getattr(eng, "cfg", {}).get("enable_futures", False)),
            "margin_mode": str(fut_cfg.get("margin_mode")) if fut_cfg else None,
            "leverage": int(fut_cfg.get("leverage")) if fut_cfg and fut_cfg.get("leverage") is not None else None,
            "hedge_mode": bool(fut_cfg.get("hedge_mode", False)) if fut_cfg else False,
        }

        eq_best = float(self._engine_equity_best_effort() or 0.0)
        equity = eq_best if eq_best > 0 else float(total or free)

        return {
            "ts": _now(),
            "ok": True,
            "stale": False,
            "mode": "live",
            "exchange": meta.get("exchange", ""),
            "equity": float(equity),
            "balances": {"free": float(free), "used": float(used), "total": float(total), "currency": quote, "raw": bal},
            "futures": futures_meta,
            "positions": positions,
            "open_orders": open_orders,
            "pending": pending,
            "risk_state": meta.get("risk_state"),
            "regime": meta.get("regime"),
            "errors": errors,
        }
# app/meta_strategy.py
from __future__ import annotations

import time
import json
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TypedDict, Literal
from enum import Enum, IntEnum
from abc import ABC, abstractmethod
from collections import OrderedDict, defaultdict
from functools import lru_cache
from unittest.mock import Mock


def _now() -> float:
    return time.time()


def _f(x: Any, d: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(d)


def _i(x: Any, d: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return int(d)


def _b(x: Any, d: bool = False) -> bool:
    if x is None:
        return d
    if isinstance(x, bool):
        return x
    s = str(x).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


def _clamp(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


class StrategyStyle(Enum):
    GRID = "grid"
    DCA = "dca"
    SCALP = "scalp"
    TREND = "trend"
    NONE = "none"


class LogLevel(IntEnum):
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40


class RegimeState(TypedDict, total=False):
    regime: str
    strength: float
    confidence: float


class Context(TypedDict, total=False):
    spread_bps: float
    slippage_bps: float
    vol_24h_usd: float
    atr_pct: float
    funding: float
    risk_state: str
    price: float
    volume_usd: float
    funding_rate: float


@dataclass
class StyleConfig:
    risk_mult: float = 1.0
    cooldown_mult: float = 1.0
    weight: float = 1.0
    max_positions: int = 2
    min_signal_strength: float = 1.0
    tp_mult: float = 1.0
    sl_mult: float = 1.0
    spread_limit_bps: Optional[float] = None
    slippage_limit_bps: Optional[float] = None


@dataclass
class MetaStrategyConfig:
    map: Dict[str, StrategyStyle] = field(default_factory=lambda: {
        "trend": StrategyStyle.TREND,
        "trend_up": StrategyStyle.TREND,
        "trend_down": StrategyStyle.TREND,
        "range": StrategyStyle.GRID,
        "high_vol": StrategyStyle.SCALP,
        "high_vol_event": StrategyStyle.SCALP,
        "low_vol": StrategyStyle.DCA,
        "low_liquid": StrategyStyle.NONE,
        "low_liquid_event": StrategyStyle.NONE,
        "na": StrategyStyle.NONE,
    })
    min_hold_sec: float = 90.0
    min_delta_strength: float = 0.08
    prefer_last_on_neutral: bool = True
    neutral_regimes: List[str] = field(default_factory=lambda: ["na", "low_vol"])
    
    # Guard thresholds
    max_spread_bps: float = 35.0
    max_slippage_bps: float = 60.0
    min_vol_24h_usd: float = 2_000_000.0
    max_atr_pct: float = 0.08
    
    # Style-specific configs
    scalp_config: StyleConfig = field(default_factory=lambda: StyleConfig(
        risk_mult=0.75,
        cooldown_mult=0.6,
        weight=1.05,
        max_positions=1,
        min_signal_strength=1.2,
        tp_mult=0.85,
        sl_mult=0.90
    ))
    
    grid_config: StyleConfig = field(default_factory=lambda: StyleConfig(
        risk_mult=0.80,
        cooldown_mult=1.2,
        weight=1.00,
        max_positions=2,
        min_signal_strength=1.0,
        tp_mult=1.00,
        sl_mult=1.00
    ))
    
    dca_config: StyleConfig = field(default_factory=lambda: StyleConfig(
        risk_mult=0.70,
        cooldown_mult=1.3,
        weight=0.98,
        max_positions=2,
        min_signal_strength=0.9,
        tp_mult=1.00,
        sl_mult=1.00
    ))
    
    trend_config: StyleConfig = field(default_factory=lambda: StyleConfig(
        risk_mult=1.0,
        cooldown_mult=1.0,
        weight=1.05,
        max_positions=2,
        min_signal_strength=1.1,
        tp_mult=1.15,
        sl_mult=1.10
    ))
    
    # Funding guard
    funding_guard_abs: float = 0.003
    funding_extreme_style: StrategyStyle = StrategyStyle.NONE
    
    # Limits
    risk_mult_max: float = 1.50
    cooldown_mult_max: float = 3.0
    style_weight_max: float = 2.0


@dataclass
class MetaStrategyDecision:
    style: StrategyStyle
    params_override: Dict[str, Any]
    reasons: Dict[str, Any]


@dataclass
class GuardResult:
    should_block: bool
    style_override: Optional[StrategyStyle] = None
    reason: str = ""
    risk_mult_adjustment: float = 1.0


class GuardPlugin(ABC):
    @abstractmethod
    def check(self, symbol: str, context: Dict, config: Dict) -> Optional[GuardResult]:
        pass


class FundingGuardPlugin(GuardPlugin):
    def check(self, symbol: str, context: Dict, config: Dict) -> Optional[GuardResult]:
        funding = context.get('funding', 0)
        threshold = config.get('funding_guard_abs', 0.003)
        
        if abs(funding) >= threshold:
            return GuardResult(
                should_block=True,
                style_override=StrategyStyle(config.get('funding_extreme_style', 'none')),
                reason="funding_extreme",
                risk_mult_adjustment=0.5
            )
        return None


class SpreadGuardPlugin(GuardPlugin):
    def check(self, symbol: str, context: Dict, config: Dict) -> Optional[GuardResult]:
        spread_bps = abs(context.get('spread_bps', 0.0))
        max_spread = config.get('max_spread_bps', 35.0)
        
        if spread_bps > max_spread:
            return GuardResult(
                should_block=True,
                style_override=StrategyStyle.NONE,
                reason="spread_too_wide"
            )
        elif spread_bps > (0.85 * max_spread):
            return GuardResult(
                should_block=False,
                reason="spread_near_limit",
                risk_mult_adjustment=0.92
            )
        return None


class StyleStrategy(ABC):
    @abstractmethod
    def get_overrides(self, cfg: Dict, regime_strength: float) -> Dict[str, Any]:
        pass
    
    @abstractmethod
    def should_activate(self, context: Dict, config: Dict) -> bool:
        pass


class GridStrategy(StyleStrategy):
    def get_overrides(self, cfg: Dict, regime_strength: float) -> Dict:
        config = cfg.get('grid_config', {})
        return {
            "risk_mult": _f(config.get("risk_mult"), 0.80),
            "cooldown_mult": _f(config.get("cooldown_mult"), 1.2),
            "style_weight": _f(config.get("weight"), 1.00),
            "max_positions": _i(config.get("max_positions"), 2),
            "min_signal_strength": _f(config.get("min_signal_strength"), 1.0),
            "grid_spacing_mult": _f(cfg.get("grid_spacing_mult"), 1.0),
            "tp_mult": _f(config.get("tp_mult"), 1.00),
            "sl_mult": _f(config.get("sl_mult"), 1.00),
        }
    
    def should_activate(self, context: Dict, config: Dict) -> bool:
        # Condiții specifice pentru grid
        atr_pct = context.get('atr_pct', 0)
        max_atr = config.get('max_atr_pct', 0.08)
        return atr_pct < (max_atr * 0.7)  # Doar în volatilitate relativ mică


class DecisionCache:
    def __init__(self, max_size: int = 1000, ttl_seconds: int = 3600):
        self.cache = OrderedDict()
        self.max_size = max_size
        self.ttl = ttl_seconds
        self.lock = threading.RLock()
        self.hits = 0
        self.misses = 0
        
    def get(self, symbol: str) -> Optional[Dict]:
        with self.lock:
            if symbol not in self.cache:
                self.misses += 1
                return None
            
            entry = self.cache[symbol]
            if _now() - entry.get('timestamp', 0) > self.ttl:
                del self.cache[symbol]
                self.misses += 1
                return None
            
            self.hits += 1
            self.cache.move_to_end(symbol)
            return entry['data']
    
    def set(self, symbol: str, data: Dict):
        with self.lock:
            self.cache[symbol] = {
                'data': data,
                'timestamp': _now()
            }
            if len(self.cache) > self.max_size:
                self.cache.popitem(last=False)
    
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0


class MetaStrategyMetrics:
    def __init__(self):
        self.decisions_count = 0
        self.style_changes = 0
        self.guard_triggers = defaultdict(int)
        self.avg_decision_time = 0.0
        self.last_style: Optional[StrategyStyle] = None
        self.errors = 0
        
    def record_decision(self, decision: MetaStrategyDecision, duration: float, last_style: Optional[StrategyStyle]):
        self.decisions_count += 1
        self.avg_decision_time = (
            self.avg_decision_time * (self.decisions_count - 1) + duration
        ) / self.decisions_count
        
        if last_style != decision.style:
            self.style_changes += 1
        
        self.last_style = decision.style
        
        # Record guard triggers from reasons
        reasons = decision.reasons
        if 'guard' in reasons:
            self.guard_triggers[reasons['guard']] += 1
        if 'guard_vol' in reasons:
            self.guard_triggers[reasons['guard_vol']] += 1
        if 'guard_funding' in reasons:
            self.guard_triggers[reasons['guard_funding']] += 1
    
    def record_error(self):
        self.errors += 1
        
    def get_summary(self) -> Dict:
        return {
            "total_decisions": self.decisions_count,
            "style_changes": self.style_changes,
            "avg_decision_time_ms": round(self.avg_decision_time * 1000, 2),
            "guard_triggers": dict(self.guard_triggers),
            "current_style": self.last_style.value if self.last_style else None,
            "errors": self.errors,
        }


class StructuredLogger:
    def __init__(self, min_level: LogLevel = LogLevel.INFO):
        self.min_level = min_level
        
    def log(self, level: LogLevel, event: str, data: Dict, symbol: str = None):
        if level < self.min_level:
            return
            
        log_entry = {
            "timestamp": _now(),
            "level": level.name,
            "event": event,
            "symbol": symbol,
            "data": data,
            "source": "meta_strategy"
        }
        # Log to console
        print(json.dumps(log_entry))


class ConfigManager:
    def __init__(self, initial_config: Dict):
        self.config = initial_config
        self.last_update = _now()
        self.update_callbacks = []
        self.lock = threading.RLock()
        
    def update_config(self, new_config: Dict):
        with self.lock:
            old_config = self.config.copy()
            self.config = self._merge_configs(old_config, new_config)
            self.last_update = _now()
            
            for callback in self.update_callbacks:
                try:
                    callback(old_config, self.config)
                except Exception as e:
                    print(f"Error in config update callback: {e}")
    
    def _merge_configs(self, old: Dict, new: Dict) -> Dict:
        # Merge deep, preserving unspecified values
        result = old.copy()
        for key, value in new.items():
            if isinstance(value, dict) and key in result and isinstance(result[key], dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        return result
    
    def get_config(self) -> Dict:
        with self.lock:
            return self.config.copy()
    
    def register_callback(self, callback):
        self.update_callbacks.append(callback)


class MetaStrategySelector:
    """Chooses per-symbol strategy style based on regime and optional guards.

    This module doesn't implement strategies; it outputs a decision used by other
    components to adapt thresholds, cool-downs, and risk multipliers.

    Improvements vs original:
    - hysteresis to avoid flapping
    - continuity preference (keep previous style in neutral regimes)
    - richer guardrails (liquidity/vol/funding/risk_state)
    - richer overrides with clamps
    - structured logging
    - typed configuration
    - plugin system for guards
    - decision caching
    - performance metrics
    """

    def __init__(self, cfg: Dict[str, Any], log: Any = None):
        self.config_manager = ConfigManager(cfg)
        self.cfg = cfg or {}
        self.logger = StructuredLogger() if log is None else log
        self.cache = DecisionCache()
        self.metrics = MetaStrategyMetrics()
        
        # Initialize plugins
        self.guard_plugins: List[GuardPlugin] = [
            FundingGuardPlugin(),
            SpreadGuardPlugin(),
        ]
        
        # Initialize style strategies
        self.style_strategies = {
            StrategyStyle.GRID: GridStrategy(),
            StrategyStyle.SCALP: GridStrategy(),  # Placeholder
            StrategyStyle.DCA: GridStrategy(),    # Placeholder  
            StrategyStyle.TREND: GridStrategy(),  # Placeholder
        }
        
        # Register for config updates
        self.config_manager.register_callback(self._on_config_update)
        
    def _on_config_update(self, old_config: Dict, new_config: Dict):
        self.logger.log(LogLevel.INFO, "config_updated", {
            "old": old_config.get('meta_strategy', {}),
            "new": new_config.get('meta_strategy', {})
        })

    def _emit(self, event: Dict[str, Any]) -> None:
        """Best-effort structured log; never raises."""
        try:
            if self.logger is None:
                return
            if hasattr(self.logger, "log") and callable(getattr(self.logger, "log")):
                self.logger.log(LogLevel.INFO, event.get("event", "unknown"), event)
                return
            if callable(self.logger):
                self.logger(event)
        except Exception:
            return

    def get_last(self, symbol: str) -> Dict[str, Any]:
        cached = self.cache.get(symbol)
        if cached:
            return cached.get('params_override', {})
        return {}

    def decide(
        self,
        symbol: str,
        regime_state: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> MetaStrategyDecision:
        start_time = _now()
        
        try:
            return self._decide_impl(symbol, regime_state, context or {})
        except Exception as e:
            self.metrics.record_error()
            self.logger.log(LogLevel.ERROR, "decision_error", {
                "symbol": symbol,
                "error": str(e),
                "traceback": repr(e)
            })
            
            # Fallback la o decizie safe
            return self._create_fallback_decision(symbol, str(e))
        finally:
            duration = _now() - start_time
            self.metrics.record_decision(
                self._last_decision if hasattr(self, '_last_decision') else None,
                duration,
                self._last_style if hasattr(self, '_last_style') else None
            )

    def _decide_impl(
        self,
        symbol: str,
        regime_state: Dict[str, Any],
        context: Dict[str, Any],
    ) -> MetaStrategyDecision:
        cfg = (self.cfg.get("meta_strategy") or {}) if isinstance(self.cfg, dict) else {}
        ctx = context or {}

        # Try cache first
        cache_key = f"{symbol}_{json.dumps(regime_state, sort_keys=True)[:100]}"
        cached = self.cache.get(cache_key)
        if cached and (cached.get('timestamp', 0) > _now() - 5.0):  # 5 second cache
            return MetaStrategyDecision(
                style=StrategyStyle(cached['style']),
                params_override=cached['params_override'],
                reasons=cached['reasons']
            )

        # -------- mapping regime -> style (configurable) --------
        mapping = cfg.get("map") or {
            "trend": "trend",
            "trend_up": "trend",
            "trend_down": "trend",
            "range": "grid",
            "high_vol": "scalp",
            "high_vol_event": "scalp",
            "low_vol": "dca",
            "low_liquid": "none",
            "low_liquid_event": "none",
            "na": "none",
        }

        reg = str((regime_state or {}).get("regime") or "na").lower()
        strength = _clamp(_f((regime_state or {}).get("strength"), 0.0), 0.0, 1.0)

        # candidate style based on regime name
        cand_str = str(mapping.get(reg, mapping.get(reg.split("_")[0], "none"))).lower().strip()
        try:
            cand = StrategyStyle(cand_str)
        except ValueError:
            cand = StrategyStyle.NONE

        # -------- hysteresis / continuity --------
        last_cached = self.cache.get(symbol)
        last_style = StrategyStyle(last_cached.get('style')) if last_cached and last_cached.get('style') else StrategyStyle.NONE
        last_strength = _f(last_cached.get('strength'), 0.0) if last_cached else 0.0
        last_ts = _f(last_cached.get('ts'), 0.0) if last_cached else 0.0

        min_hold_sec = _f(cfg.get("min_hold_sec"), 90.0)            # keep style at least X sec
        min_delta_strength = _f(cfg.get("min_delta_strength"), 0.08) # need this much strength delta to switch
        prefer_last_on_neutral = _b(cfg.get("prefer_last_on_neutral"), True)

        # some regimes are "neutral-ish"
        neutral_regs = set([str(x).lower() for x in (cfg.get("neutral_regimes") or ["na", "low_vol"])])
        is_neutral = reg in neutral_regs or cand == StrategyStyle.NONE

        # if neutral: optionally keep last style (unless last was none)
        if prefer_last_on_neutral and is_neutral and last_style != StrategyStyle.NONE:
            cand = last_style

        # avoid flapping: if switching too fast, keep last
        now = _now()
        if last_style and cand != last_style:
            if (now - last_ts) < float(min_hold_sec) and abs(strength - last_strength) < float(min_delta_strength):
                cand = last_style

        # -------- guardrails from context --------
        reasons: Dict[str, Any] = {
            "symbol": symbol,
            "regime": reg,
            "strength": float(strength),
            "candidate": cand.value,
            "last_style": last_style.value if last_style else "none",
        }

        # optional contextual metrics
        spread_bps = abs(_f(ctx.get("spread_bps"), 0.0))
        slip_bps = abs(_f(ctx.get("slippage_bps"), 0.0))
        vol_usd = _f(ctx.get("vol_24h_usd"), _f(ctx.get("volume_usd"), 0.0))
        atr_pct = abs(_f(ctx.get("atr_pct"), 0.0))
        funding = _f(ctx.get("funding"), _f(ctx.get("funding_rate"), 0.0))
        risk_state = str(ctx.get("risk_state") or "").lower().strip()

        reasons["ctx"] = {
            "spread_bps": spread_bps,
            "slippage_bps": slip_bps,
            "vol_24h_usd": vol_usd,
            "atr_pct": atr_pct,
            "funding": funding,
            "risk_state": risk_state,
        }

        # thresholds
        max_spread = _f(cfg.get("max_spread_bps"), 35.0)
        max_slip = _f(cfg.get("max_slippage_bps"), 60.0)
        min_vol_usd = _f(cfg.get("min_vol_24h_usd"), 2_000_000.0)
        max_atr_pct = _f(cfg.get("max_atr_pct"), 0.08)

        # style-specific tighter thresholds (optional)
        scalp_max_spread = _f(cfg.get("scalp_max_spread_bps"), max_spread)
        scalp_max_slip = _f(cfg.get("scalp_max_slippage_bps"), max_slip)

        # risk-state overrides
        # if system says RISK_OFF / HALT, prefer none
        if risk_state in ("halt", "panic", "risk_off"):
            reasons["guard"] = f"risk_state:{risk_state}"
            cand = StrategyStyle.NONE

        # Run guard plugins
        risk_mult_adjustments = []
        for plugin in self.guard_plugins:
            result = plugin.check(symbol, ctx, cfg)
            if result:
                if result.should_block:
                    reasons[f"guard_{plugin.__class__.__name__}"] = result.reason
                    cand = result.style_override or StrategyStyle.NONE
                elif result.risk_mult_adjustment != 1.0:
                    risk_mult_adjustments.append(result.risk_mult_adjustment)
                    reasons[f"soft_{plugin.__class__.__name__}"] = result.reason

        # universal hard guards
        if spread_bps and spread_bps > max_spread:
            reasons["guard"] = "spread_too_wide"
            cand = StrategyStyle.NONE
        if slip_bps and slip_bps > max_slip:
            reasons["guard"] = "slippage_too_high"
            cand = StrategyStyle.NONE
        if vol_usd and vol_usd < min_vol_usd:
            reasons["guard"] = "liquidity_low"
            cand = StrategyStyle.NONE

        # volatility guard: discourage grid in extreme vol, discourage scalp if too spiky (optional)
        if atr_pct and atr_pct > max_atr_pct:
            reasons["guard_vol"] = "atr_too_high"
            # in extreme vol, avoid grid/dca; allow trend only if you want
            if cand in (StrategyStyle.GRID, StrategyStyle.DCA, StrategyStyle.SCALP):
                cand = StrategyStyle.NONE

        # scalp-specific constraints
        if cand == StrategyStyle.SCALP:
            if spread_bps and spread_bps > scalp_max_spread:
                reasons["guard"] = "scalp_spread_too_wide"
                cand = StrategyStyle.NONE
            if slip_bps and slip_bps > scalp_max_slip:
                reasons["guard"] = "scalp_slippage_too_high"
                cand = StrategyStyle.NONE

        # funding guard: avoid trend longs when funding very positive (and shorts when very negative) if configured
        funding_guard_abs = _f(cfg.get("funding_guard_abs"), 0.003)
        if cand == StrategyStyle.TREND and abs(funding) >= funding_guard_abs:
            # Without side we can only be conservative: if funding extreme, downshift to "grid"/"dca" or "none"
            reasons["guard_funding"] = "funding_extreme"
            cand_str = str(cfg.get("funding_extreme_style", "none")).lower().strip()
            try:
                cand = StrategyStyle(cand_str)
            except ValueError:
                cand = StrategyStyle.NONE

        # -------- dynamic overrides --------
        overrides: Dict[str, Any] = {}

        # Base multipliers per style
        risk_mult = 1.0
        cooldown_mult = 1.0
        style_weight = 1.0  # can modulate score in decision_factor/selector

        if cand == StrategyStyle.SCALP:
            risk_mult = _f(cfg.get("scalp_risk_mult"), 0.75)
            cooldown_mult = _f(cfg.get("scalp_cooldown_mult"), 0.6)
            style_weight = _f(cfg.get("scalp_weight"), 1.05)
            overrides["max_positions"] = _i(cfg.get("scalp_max_positions"), 1)
            overrides["min_signal_strength"] = _f(cfg.get("scalp_min_signal_strength"), 1.2)
            overrides["tp_mult"] = _f(cfg.get("scalp_tp_mult"), 0.85)
            overrides["sl_mult"] = _f(cfg.get("scalp_sl_mult"), 0.90)

        elif cand == StrategyStyle.GRID:
            risk_mult = _f(cfg.get("grid_risk_mult"), 0.80)
            cooldown_mult = _f(cfg.get("grid_cooldown_mult"), 1.2)
            style_weight = _f(cfg.get("grid_weight"), 1.00)
            overrides["max_positions"] = _i(cfg.get("grid_max_positions"), 2)
            overrides["min_signal_strength"] = _f(cfg.get("grid_min_signal_strength"), 1.0)
            overrides["grid_spacing_mult"] = _f(cfg.get("grid_spacing_mult"), 1.0)
            overrides["tp_mult"] = _f(cfg.get("grid_tp_mult"), 1.00)
            overrides["sl_mult"] = _f(cfg.get("grid_sl_mult"), 1.00)

        elif cand == StrategyStyle.DCA:
            risk_mult = _f(cfg.get("dca_risk_mult"), 0.70)
            cooldown_mult = _f(cfg.get("dca_cooldown_mult"), 1.3)
            style_weight = _f(cfg.get("dca_weight"), 0.98)
            overrides["max_positions"] = _i(cfg.get("dca_max_positions"), 2)
            overrides["min_signal_strength"] = _f(cfg.get("dca_min_signal_strength"), 0.9)
            overrides["dca_step_mult"] = _f(cfg.get("dca_step_mult"), 1.0)

        elif cand == StrategyStyle.TREND:
            risk_mult = _f(cfg.get("trend_risk_mult"), 1.0)
            cooldown_mult = _f(cfg.get("trend_cooldown_mult"), 1.0)
            style_weight = _f(cfg.get("trend_weight"), 1.05)
            overrides["max_positions"] = _i(cfg.get("trend_max_positions"), 2)
            overrides["min_signal_strength"] = _f(cfg.get("trend_min_signal_strength"), 1.1)
            overrides["tp_mult"] = _f(cfg.get("trend_tp_mult"), 1.15)
            overrides["sl_mult"] = _f(cfg.get("trend_sl_mult"), 1.10)

        else:
            cand = StrategyStyle.NONE
            risk_mult = 0.0
            cooldown_mult = 1.0
            style_weight = 0.0

        # scale risk by regime strength (mild)
        # original: risk_mult *= (0.85 + 0.30*strength)
        # keep but clamp to avoid weird values
        if cand != StrategyStyle.NONE:
            strength_scale = 0.85 + 0.30 * _clamp(strength, 0.0, 1.0)
            risk_mult = float(risk_mult) * float(strength_scale)

        # Apply guard plugin adjustments
        for adjustment in risk_mult_adjustments:
            risk_mult *= adjustment

        # additional derisk if near guard thresholds (soft penalties)
        if cand != StrategyStyle.NONE:
            if spread_bps and max_spread > 0 and spread_bps > (0.85 * max_spread):
                risk_mult *= 0.92
                reasons["soft"] = reasons.get("soft") or []
                reasons["soft"].append("spread_near_limit")
            if slip_bps and max_slip > 0 and slip_bps > (0.85 * max_slip):
                risk_mult *= 0.92
                reasons["soft"] = reasons.get("soft") or []
                reasons["soft"].append("slippage_near_limit")
            if vol_usd and min_vol_usd > 0 and vol_usd < (1.25 * min_vol_usd):
                risk_mult *= 0.92
                reasons["soft"] = reasons.get("soft") or []
                reasons["soft"].append("liquidity_near_min")

        # clamps
        risk_mult = _clamp(float(risk_mult), 0.0, _f(cfg.get("risk_mult_max"), 1.50))
        cooldown_mult = _clamp(float(cooldown_mult), 0.2, _f(cfg.get("cooldown_mult_max"), 3.0))
        style_weight = _clamp(float(style_weight), 0.0, _f(cfg.get("style_weight_max"), 2.0))

        overrides["risk_mult"] = float(risk_mult)
        overrides["cooldown_mult"] = float(cooldown_mult)
        overrides["style_weight"] = float(style_weight)
        overrides["regime"] = reg
        overrides["regime_strength"] = float(strength)

        # Cache the decision
        cache_entry = {
            "style": cand.value,
            "strength": float(strength),
            "ts": float(now),
            "params_override": dict(overrides),
            "reasons": dict(reasons),
            "timestamp": _now()
        }
        self.cache.set(cache_key, cache_entry)
        self.cache.set(symbol, cache_entry)  # Also cache by symbol

        dec = MetaStrategyDecision(
            style=cand,
            params_override=overrides,
            reasons=reasons
        )

        # Store for metrics
        self._last_decision = dec
        self._last_style = last_style

        # Structured log (best-effort)
        self._emit(
            {
                "event": "meta_strategy_decide",
                "symbol": symbol,
                "regime": reg,
                "strength": float(strength),
                "style": cand.value,
                "overrides": dict(overrides),
                "reasons": dict(reasons),
            }
        )

        return dec

    def _create_fallback_decision(self, symbol: str, error: str) -> MetaStrategyDecision:
        """Create a safe fallback decision when an error occurs."""
        return MetaStrategyDecision(
            style=StrategyStyle.NONE,
            params_override={
                "risk_mult": 0.0,
                "cooldown_mult": 1.0,
                "style_weight": 0.0,
                "regime": "error",
                "regime_strength": 0.0
            },
            reasons={
                "symbol": symbol,
                "error": error,
                "fallback": True
            }
        )

    def get_metrics(self) -> Dict:
        """Return current metrics."""
        summary = self.metrics.get_summary()
        summary["cache_hit_rate"] = round(self.cache.hit_rate() * 100, 2)
        summary["cache_size"] = len(self.cache.cache)
        return summary

    def update_config(self, new_config: Dict):
        """Update configuration dynamically."""
        self.config_manager.update_config(new_config)
        self.cfg = self.config_manager.get_config()

    def add_guard_plugin(self, plugin: GuardPlugin):
        """Add a custom guard plugin."""
        self.guard_plugins.append(plugin)

    def clear_cache(self):
        """Clear the decision cache."""
        self.cache.cache.clear()


# Test functions
def test_meta_strategy_selector():
    """Unit tests for MetaStrategySelector."""
    selector = MetaStrategySelector({}, Mock())
    regime = {"regime": "trend_up", "strength": 0.8}
    context = {"spread_bps": 10, "vol_24h_usd": 5_000_000}
    
    decision = selector.decide("BTCUSDT", regime, context)
    
    assert decision.style == StrategyStyle.TREND
    assert decision.params_override["risk_mult"] > 0.8
    assert "regime_strength" in decision.params_override
    
    print("Test passed!")
    return True


if __name__ == "__main__":
    # Run tests if module is executed directly
    test_passed = test_meta_strategy_selector()
    if test_passed:
        print("All tests passed!")
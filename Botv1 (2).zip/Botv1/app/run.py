from __future__ import annotations

import argparse
import os
import sys
import threading
import time
import signal
import atexit
import json
from typing import Optional, Dict, Any, List, Callable
from pathlib import Path
from datetime import datetime

import uvicorn
from dotenv import load_dotenv

# Local imports - adjusted for package structure
try:
    from .config import load_config, apply_env_overrides, ConfigValidator
    from .utils import UILogger, CompositeLogger, setup_file_logger, setup_rotating_logger, MetricsCollector
    from .records import TradeRecorder, EnhancedRecorder
    from .engine import TradingEngine, EngineManager
    from .api import create_app, create_secure_app
    from .selftest import SelfTester, SystemValidator
    from .monitor import SystemMonitor, HealthCheck
    from .telemetry import TelemetryClient
    from .scheduler import TaskScheduler
    from .backup import BackupManager
except ImportError:
    # Fallback for direct script execution
    from config import load_config, apply_env_overrides, ConfigValidator
    from utils import UILogger, CompositeLogger, setup_file_logger, setup_rotating_logger, MetricsCollector
    from records import TradeRecorder, EnhancedRecorder
    from engine import TradingEngine, EngineManager
    from api import create_app, create_secure_app
    from selftest import SelfTester, SystemValidator
    from monitor import SystemMonitor, HealthCheck
    from telemetry import TelemetryClient
    from scheduler import TaskScheduler
    from backup import BackupManager


class GracefulShutdown:
    """Manage graceful shutdown with ordered component termination."""
    
    def __init__(self, log: Optional[Any] = None):
        self.components: List[Callable] = []
        self._shutdown_in_progress = False
        self._log = log
        self._shutdown_timeout = 30  # seconds
        self._start_time: Optional[float] = None
    
    def register(self, component: Callable, name: str = "") -> None:
        """Register a component for graceful shutdown."""
        self.components.append((component, name))
    
    def shutdown(self, reason: str = "unknown") -> None:
        """Execute graceful shutdown in reverse registration order."""
        if self._shutdown_in_progress:
            return
        
        self._shutdown_in_progress = True
        self._start_time = time.time()
        
        if self._log:
            self._log.info(f"[shutdown] Starting graceful shutdown: {reason}")
        
        # Shutdown in reverse order (LIFO)
        for component, name in reversed(self.components):
            try:
                if self._log:
                    self._log.info(f"[shutdown] Stopping {name or component.__class__.__name__}")
                component()
                
                # Check timeout
                if time.time() - self._start_time > self._shutdown_timeout:
                    if self._log:
                        self._log.warning(f"[shutdown] Timeout exceeded during {name} shutdown")
                    break
                    
            except Exception as e:
                if self._log:
                    self._log.error(f"[shutdown] Error stopping {name}: {e}")
        
        elapsed = time.time() - self._start_time
        if self._log:
            self._log.info(f"[shutdown] Complete in {elapsed:.2f}s")
    
    def is_shutting_down(self) -> bool:
        """Check if shutdown is in progress."""
        return self._shutdown_in_progress


class ApplicationContext:
    """Central application context to manage all components."""
    
    def __init__(self, config: Dict[str, Any], base_dir: str, log: Any):
        self.config = config
        self.base_dir = Path(base_dir)
        self.log = log
        self.components: Dict[str, Any] = {}
        
        # Initialize shared state
        self.metrics = MetricsCollector()
        self.telemetry = None
        self.monitor = None
        self.scheduler = None
        self.backup_manager = None
        
        # Mode
        self.mode = str(config.get("mode", "paper")).lower().strip()
        self.is_live = self.mode == "live"
    
    def register_component(self, name: str, component: Any) -> None:
        """Register a component for centralized management."""
        self.components[name] = component
        self.log.debug(f"[context] Registered component: {name}")
    
    def get_component(self, name: str) -> Optional[Any]:
        """Get a registered component."""
        return self.components.get(name)
    
    def shutdown_all(self) -> None:
        """Shutdown all registered components."""
        for name, component in self.components.items():
            try:
                if hasattr(component, 'close'):
                    self.log.info(f"[context] Closing {name}")
                    component.close()
                elif hasattr(component, 'stop'):
                    self.log.info(f"[context] Stopping {name}")
                    component.stop()
            except Exception as e:
                self.log.error(f"[context] Error closing {name}: {e}")


def _safe_get(d: dict, path: str, default=None):
    """Safely get nested dictionary value using dot notation."""
    cur = d
    for part in path.split("."):
        if not isinstance(cur, dict):
            return default
        cur = cur.get(part)
    return default if cur is None else cur


def _has_api_key(cfg: dict) -> bool:
    """Check if API key is configured."""
    expected = os.getenv("BOT_API_KEY") or str((_safe_get(cfg, "api.key", "") or "")).strip()
    return bool(expected)


def _setup_logging(cfg: dict, base_dir: str, context: ApplicationContext) -> CompositeLogger:
    """Setup comprehensive logging system."""
    ui = UILogger()
    
    # Get logging configuration
    log_cfg = cfg.get("logging", {}) or {}
    log_level = log_cfg.get("level", "INFO").upper()
    
    # Setup multiple log destinations
    loggers = [ui]
    
    # File logging
    if log_cfg.get("file_enabled", True):
        log_file_rel = _safe_get(cfg, "paths.log_file", "logs/bot.log")
        log_file_abs = os.path.join(base_dir, log_file_rel)
        os.makedirs(os.path.dirname(log_file_abs), exist_ok=True)
        
        if log_cfg.get("rotating", True):
            max_size = log_cfg.get("max_size_mb", 10) * 1024 * 1024
            backup_count = log_cfg.get("backup_count", 5)
            file_logger = setup_rotating_logger(log_file_abs, max_size, backup_count, log_level)
        else:
            file_logger = setup_file_logger(log_file_abs, log_level)
        
        loggers.append(file_logger)
    
    # Console logging
    if log_cfg.get("console_enabled", True):
        # UI logger already handles console
        pass
    
    # Remote logging (if configured)
    remote_log_cfg = log_cfg.get("remote", {})
    if remote_log_cfg.get("enabled", False):
        # Could integrate with Sentry, Logstash, etc.
        pass
    
    log = CompositeLogger(*loggers)
    
    # Store logger in context
    context.register_component("logger", log)
    
    return log


def _setup_telemetry(cfg: dict, context: ApplicationContext) -> Optional[TelemetryClient]:
    """Setup telemetry and monitoring."""
    telemetry_cfg = cfg.get("telemetry", {}) or {}
    
    if not telemetry_cfg.get("enabled", False):
        return None
    
    try:
        telemetry = TelemetryClient(
            endpoint=telemetry_cfg.get("endpoint"),
            api_key=telemetry_cfg.get("api_key"),
            project_id=telemetry_cfg.get("project_id"),
            environment=context.mode,
            tags={
                "exchange": cfg.get("exchange", "unknown"),
                "mode": context.mode,
                "version": cfg.get("version", "1.0.0"),
            }
        )
        
        context.register_component("telemetry", telemetry)
        context.telemetry = telemetry
        
        return telemetry
    except Exception as e:
        context.log.warning(f"[setup] Failed to initialize telemetry: {e}")
        return None


def _setup_monitoring(cfg: dict, context: ApplicationContext) -> Optional[SystemMonitor]:
    """Setup system monitoring."""
    monitor_cfg = cfg.get("monitoring", {}) or {}
    
    if not monitor_cfg.get("enabled", True):
        return None
    
    try:
        monitor = SystemMonitor(
            check_interval=monitor_cfg.get("check_interval", 60),
            health_endpoint=monitor_cfg.get("health_endpoint"),
            metrics_collector=context.metrics,
            log=context.log,
        )
        
        # Add health checks
        monitor.add_check(HealthCheck.disk_usage("/", 90))  # 90% threshold
        monitor.add_check(HealthCheck.memory_usage(95))     # 95% threshold
        monitor.add_check(HealthCheck.cpu_usage(90))        # 90% threshold
        
        context.register_component("monitor", monitor)
        context.monitor = monitor
        
        return monitor
    except Exception as e:
        context.log.warning(f"[setup] Failed to initialize monitoring: {e}")
        return None


def _setup_scheduler(cfg: dict, context: ApplicationContext) -> Optional[TaskScheduler]:
    """Setup task scheduler for periodic jobs."""
    scheduler_cfg = cfg.get("scheduler", {}) or {}
    
    if not scheduler_cfg.get("enabled", True):
        return None
    
    try:
        scheduler = TaskScheduler(
            timezone=scheduler_cfg.get("timezone", "UTC"),
            log=context.log,
        )
        
        # Schedule regular tasks
        if scheduler_cfg.get("schedule_backups", True):
            # Daily backups at 2 AM
            scheduler.schedule_daily("backup", "02:00", lambda: context.backup_manager.backup() if context.backup_manager else None)
        
        if scheduler_cfg.get("schedule_cleanup", True):
            # Cleanup old logs/data weekly
            scheduler.schedule_weekly("cleanup", "monday", "03:00", lambda: context.log.info("[scheduler] Cleanup task executed"))
        
        context.register_component("scheduler", scheduler)
        context.scheduler = scheduler
        
        return scheduler
    except Exception as e:
        context.log.warning(f"[setup] Failed to initialize scheduler: {e}")
        return None


def _setup_backup(cfg: dict, context: ApplicationContext) -> Optional[BackupManager]:
    """Setup backup manager."""
    backup_cfg = cfg.get("backup", {}) or {}
    
    if not backup_cfg.get("enabled", True):
        return None
    
    try:
        backup_dir = Path(_safe_get(cfg, "paths.backup_dir", "backups"))
        if not backup_dir.is_absolute():
            backup_dir = context.base_dir / backup_dir
        
        backup_manager = BackupManager(
            source_paths=[
                context.base_dir / "data",
                context.base_dir / "logs",
                context.base_dir / "config.json",
            ],
            backup_dir=backup_dir,
            retention_days=backup_cfg.get("retention_days", 30),
            compression=backup_cfg.get("compression", True),
            log=context.log,
        )
        
        context.register_component("backup", backup_manager)
        context.backup_manager = backup_manager
        
        return backup_manager
    except Exception as e:
        context.log.warning(f"[setup] Failed to initialize backup manager: {e}")
        return None


def _run_selftest(
    cfg: dict, 
    context: ApplicationContext, 
    args: argparse.Namespace
) -> bool:
    """Run comprehensive self-test and return success status."""
    try:
        log = context.log
        
        # Run basic self-test
        tester = SelfTester(cfg, log=log)
        report = tester.run()
        
        if args.selftest_only:
            log.info(f"[selftest] Test complete. Overall status: {'PASS' if report.ok else 'FAIL'}")
            
            # Print detailed report
            if hasattr(report, 'to_dict'):
                log.info(f"[selftest] Detailed report: {json.dumps(report.to_dict(), indent=2)}")
            
            return report.ok
        
        # Run extended system validation in non-blocking mode
        if not args.selftest_only and _safe_get(cfg, "debug.extended_validation", False):
            validator = SystemValidator(cfg, log=log)
            validation_thread = threading.Thread(
                target=validator.run_comprehensive,
                daemon=True,
                name="system-validator"
            )
            validation_thread.start()
        
        # Check if we should halt on failure
        if not report.ok and bool(_safe_get(cfg, "debug.halt_on_selftest_fail", False)):
            log.error("[selftest] FAIL detected; halting startup because debug.halt_on_selftest_fail=true")
            return False
        
        return True
        
    except Exception as e:
        log.warning(f"[selftest] unexpected error: {type(e).__name__}: {e}")
        
        # In LIVE mode, you might want to stop on selftest exception
        if context.is_live and bool(_safe_get(cfg, "debug.halt_on_selftest_fail", False)):
            log.error("[startup] halting because selftest crashed and halt_on_selftest_fail=true")
            return False
        
        return True  # Continue despite test error (configurable)


def _create_api_server(cfg: dict, engine: Any, context: ApplicationContext) -> Optional[uvicorn.Server]:
    """Create and configure API server."""
    api_cfg = cfg.get("api", {}) or {}
    
    if not (api_cfg.get("enabled", False) or context.config.get("cli_args", {}).get("api", False)):
        return None
    
    host = str(api_cfg.get("host", "0.0.0.0"))
    port = int(api_cfg.get("port", 8000))
    workers = int(api_cfg.get("workers", 1))
    
    # Security configuration
    security_cfg = api_cfg.get("security", {})
    require_auth = security_cfg.get("require_auth", True)
    cors_origins = security_cfg.get("cors_origins", ["*"])
    
    # Check API key for live mode
    if context.is_live and not _has_api_key(cfg):
        context.log.warning("[api] LIVE mode: write endpoints will be DISABLED (set BOT_API_KEY or api.key)")
    
    # Create app with appropriate security
    if require_auth:
        app = create_secure_app(
            engine,
            api_key=os.getenv("BOT_API_KEY") or _safe_get(cfg, "api.key"),
            cors_origins=cors_origins,
            rate_limit=security_cfg.get("rate_limit", True),
        )
    else:
        app = create_app(engine, cors_origins=cors_origins)
    
    # Configure uvicorn
    server_config = uvicorn.Config(
        app,
        host=host,
        port=port,
        workers=workers,
        log_level=api_cfg.get("log_level", "warning").lower(),
        access_log=api_cfg.get("access_log", False),
        timeout_keep_alive=api_cfg.get("keep_alive_timeout", 5),
        loop="auto",
    )
    
    # Add SSL if configured
    ssl_cfg = security_cfg.get("ssl", {})
    if ssl_cfg.get("enabled", False):
        server_config.ssl_keyfile = ssl_cfg.get("keyfile")
        server_config.ssl_certfile = ssl_cfg.get("certfile")
    
    server = uvicorn.Server(server_config)
    
    context.log.info(f"[api] Server configured on http{'s' if ssl_cfg.get('enabled') else ''}://{host}:{port}")
    return server


def main():
    """Main entry point with enhanced functionality."""
    
    # Parse arguments
    ap = argparse.ArgumentParser(description="Enhanced Trading Bot System")
    ap.add_argument("--config", default="config.json", help="Path to config file (json/yaml)")
    ap.add_argument("--api", action="store_true", help="Start local API")
    ap.add_argument("--selftest-only", action="store_true", help="Run self-test and exit")
    ap.add_argument("--i-understand-live-risks", action="store_true", 
                   help="Acknowledge risks for LIVE trading mode")
    ap.add_argument("--validate-config", action="store_true", 
                   help="Validate configuration and exit")
    ap.add_argument("--version", action="store_true", help="Show version and exit")
    ap.add_argument("--verbose", "-v", action="count", default=0, 
                   help="Increase verbosity level")
    ap.add_argument("--daemon", action="store_true", help="Run as daemon")
    
    args = ap.parse_args()
    
    # Load environment
    load_dotenv()
    
    # Handle version flag
    if args.version:
        from . import __version__
        print(f"Trading Bot v{__version__}")
        return 0
    
    # Load configuration
    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Error: Config file not found: {config_path}")
        return 1
    
    try:
        cfg = load_config(str(config_path), {})
    except Exception as e:
        print(f"Error loading config: {e}")
        return 1
    
    # Apply environment overrides
    cfg = apply_env_overrides(cfg)
    
    # Store CLI args in config for later use
    cfg["cli_args"] = vars(args)
    
    # Validate configuration if requested
    if args.validate_config:
        try:
            validator = ConfigValidator(cfg)
            validation_result = validator.validate()
            if validation_result.valid:
                print("Configuration is valid")
                return 0
            else:
                print("Configuration validation failed:")
                for error in validation_result.errors:
                    print(f"  - {error}")
                return 1
        except Exception as e:
            print(f"Validation error: {e}")
            return 1
    
    # Determine mode and validate
    mode = str(cfg.get("mode", "paper")).lower().strip()
    
    # Refuse LIVE without explicit acknowledgement
    if mode == "live" and not args.i_understand_live_risks:
        print("ERROR: Refusing to start LIVE trading without --i-understand-live-risks flag")
        print("\nLive trading involves real financial risk. You must acknowledge this by:")
        print("1. Adding --i-understand-live-risks flag")
        print("2. Ensuring proper risk management is configured")
        print("3. Testing thoroughly in PAPER mode first")
        return 1
    
    # Setup base directory
    base_dir = os.path.dirname(os.path.abspath(args.config))
    
    # Initialize application context
    context = ApplicationContext(cfg, base_dir, None)
    
    # Setup logging
    log = _setup_logging(cfg, base_dir, context)
    context.log = log
    
    # Update context with proper logger
    context.register_component("logger", log)
    
    # Log startup information
    log.info("=" * 60)
    log.info(f"Trading Bot Starting - {datetime.now().isoformat()}")
    log.info(f"Mode: {mode.upper()}")
    log.info(f"Exchange: {cfg.get('exchange', 'N/A')}")
    log.info(f"Config: {os.path.abspath(args.config)}")
    log.info(f"Base Directory: {base_dir}")
    log.info("=" * 60)
    
    # Setup telemetry and monitoring
    telemetry = _setup_telemetry(cfg, context)
    monitor = _setup_monitoring(cfg, context)
    scheduler = _setup_scheduler(cfg, context)
    backup_manager = _setup_backup(cfg, context)
    
    # Send startup event to telemetry
    if telemetry:
        telemetry.event("startup", {"mode": mode, "exchange": cfg.get("exchange")})
    
    # Run self-test
    if not _run_selftest(cfg, context, args):
        log.error("[startup] Self-test failed. Exiting.")
        return 1
    
    # Setup graceful shutdown handler
    shutdown_handler = GracefulShutdown(log)
    context.register_component("shutdown_handler", shutdown_handler)
    
    # Setup atexit handler
    atexit.register(lambda: shutdown_handler.shutdown("atexit"))
    
    # ---- Engine Setup ----
    try:
        # Choose recorder based on configuration
        recorder_cfg = cfg.get("recording", {}) or {}
        if recorder_cfg.get("enhanced", True):
            rec = EnhancedRecorder(
                storage_type=recorder_cfg.get("storage", "sqlite"),
                path=Path(base_dir) / recorder_cfg.get("path", "data/trades.db"),
                auto_commit=recorder_cfg.get("auto_commit", True),
                buffer_size=recorder_cfg.get("buffer_size", 100),
                log=log,
            )
        else:
            rec = TradeRecorder()
        
        # Create engine with manager for better control
        eng = EngineManager(
            config=cfg,
            log=log,
            recorder=rec,
            base_dir=base_dir,
            metrics_collector=context.metrics,
            telemetry_client=telemetry,
        )
        
        context.register_component("engine", eng)
        
        # Register engine for graceful shutdown
        shutdown_handler.register(eng.stop, "EngineManager")
        
    except Exception as e:
        log.error(f"[engine] Failed to initialize: {type(e).__name__}: {e}")
        if telemetry:
            telemetry.error("engine_init_failed", str(e))
        return 1
    
    # ---- Start Engine Thread ----
    def _engine_thread():
        try:
            log.info("[engine] Starting main loop")
            eng.loop()
        except Exception as e:
            log.error(f"[engine] Loop crashed: {type(e).__name__}: {e}")
            if telemetry:
                telemetry.error("engine_crash", str(e))
            shutdown_handler.shutdown("engine_crash")
    
    t_engine = threading.Thread(
        target=_engine_thread, 
        daemon=True,
        name="trading-engine"
    )
    t_engine.start()
    
    # Register engine thread for monitoring
    if monitor:
        monitor.register_thread("engine", t_engine)
    
    # ---- API Server (optional) ----
    server = None
    t_api = None
    
    server = _create_api_server(cfg, eng, context)
    
    if server:
        def _api_thread():
            try:
                log.info("[api] Starting server")
                server.run()
            except Exception as e:
                log.error(f"[api] Server crashed: {type(e).__name__}: {e}")
                if telemetry:
                    telemetry.error("api_crash", str(e))
                shutdown_handler.shutdown("api_crash")
        
        t_api = threading.Thread(
            target=_api_thread, 
            daemon=True,
            name="api-server"
        )
        t_api.start()
        
        # Register for graceful shutdown
        shutdown_handler.register(lambda: setattr(server, 'should_exit', True), "APIServer")
        
        if monitor:
            monitor.register_thread("api", t_api)
    
    # ---- Start Monitoring Threads ----
    if monitor:
        def _monitor_thread():
            try:
                monitor.start()
            except Exception as e:
                log.error(f"[monitor] Failed: {type(e).__name__}: {e}")
        
        t_monitor = threading.Thread(
            target=_monitor_thread,
            daemon=True,
            name="system-monitor"
        )
        t_monitor.start()
        
        shutdown_handler.register(monitor.stop, "SystemMonitor")
    
    # ---- Start Scheduler ----
    if scheduler:
        def _scheduler_thread():
            try:
                scheduler.start()
            except Exception as e:
                log.error(f"[scheduler] Failed: {type(e).__name__}: {e}")
        
        t_scheduler = threading.Thread(
            target=_scheduler_thread,
            daemon=True,
            name="task-scheduler"
        )
        t_scheduler.start()
        
        shutdown_handler.register(scheduler.stop, "TaskScheduler")
    
    # ---- Signal Handling ----
    def _signal_handler(signum, frame):
        signal_name = {signal.SIGINT: "SIGINT", signal.SIGTERM: "SIGTERM"}.get(signum, str(signum))
        log.info(f"[signal] Received {signal_name}")
        shutdown_handler.shutdown(f"signal_{signal_name}")
    
    # Register signal handlers
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _signal_handler)
        except (AttributeError, ValueError):
            # Signals not available on this platform
            pass
    
    # Windows-specific signal
    if hasattr(signal, 'SIGBREAK'):
        try:
            signal.signal(signal.SIGBREAK, _signal_handler)
        except:
            pass
    
    # ---- Main Control Loop ----
    log.info("[main] Entering main control loop")
    
    try:
        last_heartbeat = time.time()
        
        while not shutdown_handler.is_shutting_down():
            # Check thread health
            if not t_engine.is_alive():
                log.error("[main] Engine thread died unexpectedly")
                shutdown_handler.shutdown("engine_thread_dead")
                break
            
            if t_api and not t_api.is_alive():
                log.error("[main] API thread died unexpectedly")
                shutdown_handler.shutdown("api_thread_dead")
                break
            
            # Periodic heartbeat
            if time.time() - last_heartbeat > 30:
                if telemetry:
                    telemetry.metric("heartbeat", 1)
                
                # Log status
                status = {
                    "engine_alive": t_engine.is_alive(),
                    "api_alive": t_api.is_alive() if t_api else False,
                    "uptime": time.time() - last_heartbeat,
                    "mode": mode,
                }
                log.debug(f"[heartbeat] Status: {status}")
                
                last_heartbeat = time.time()
            
            time.sleep(1.0)
            
    except KeyboardInterrupt:
        log.info("[main] Keyboard interrupt received")
        shutdown_handler.shutdown("keyboard_interrupt")
    except Exception as e:
        log.error(f"[main] Unexpected error in control loop: {type(e).__name__}: {e}")
        shutdown_handler.shutdown(f"control_loop_error: {e}")
    
    # ---- Final Cleanup ----
    log.info("[main] Starting final cleanup")
    
    # Wait for threads with timeout
    timeout = 10.0
    start_time = time.time()
    
    if t_engine.is_alive():
        log.info("[main] Waiting for engine thread...")
        t_engine.join(timeout=max(0, timeout - (time.time() - start_time)))
    
    if t_api and t_api.is_alive():
        log.info("[main] Waiting for API thread...")
        t_api.join(timeout=3.0)
    
    # Final component cleanup
    context.shutdown_all()
    
    # Final telemetry event
    if telemetry:
        telemetry.event("shutdown_complete", {"duration": time.time() - last_heartbeat})
        telemetry.close()
    
    # Final log
    log.info("[main] Shutdown complete")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
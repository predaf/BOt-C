# app/position_fsm.py
from __future__ import annotations

import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Iterable


def _s(x: Any, default: str = "") -> str:
    """Safe string conversion."""
    if x is None:
        return default
    try:
        return str(x)
    except Exception:
        return default


def _f(x: Any, default: float = 0.0) -> float:
    """Safe float conversion, rejecting NaN/Inf."""
    try:
        v = float(x)
        if v != v:  # NaN
            return float(default)
        if v == float("inf") or v == float("-inf"):
            return float(default)
        return v
    except Exception:
        return float(default)


def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Get value from dict-like or object-like."""
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _extract_pending_symbols(pending: Any) -> List[str]:
    """
    Extract symbols from pending orders snapshot.
    Supports:
      - dict keyed by symbol -> value order
      - dict keyed by order_id -> value has symbol
      - list of dicts/objects each with symbol
      - other iterables
    """
    syms: List[str] = []
    if not pending:
        return syms

    # Dict case
    if isinstance(pending, dict):
        for k, v in pending.items():
            # If key looks like symbol
            if isinstance(k, str) and ("/" in k or "-" in k):
                if k:
                    syms.append(k)
                    continue
            # Else look in the value
            sym = _s(_get(v, "symbol", ""), "").strip()
            if sym:
                syms.append(sym)
        return list(dict.fromkeys(syms))  # unique preserve order

    # List/iterable case
    if isinstance(pending, (list, tuple, set)):
        for item in pending:
            sym = _s(_get(item, "symbol", ""), "").strip()
            if sym:
                syms.append(sym)
        return list(dict.fromkeys(syms))

    # Fallback: try iterating
    try:
        for item in pending:  # type: ignore
            sym = _s(_get(item, "symbol", ""), "").strip()
            if sym:
                syms.append(sym)
        return list(dict.fromkeys(syms))
    except Exception:
        return syms


def _pending_for_symbol(pending: Any, symbol: str) -> Optional[Any]:
    """Return the pending record for a given symbol, if present."""
    if not pending or not symbol:
        return None

    if isinstance(pending, dict):
        # Most common: dict keyed by symbol
        if symbol in pending:
            return pending.get(symbol)
        # Else search values
        for _, v in pending.items():
            sym = _s(_get(v, "symbol", ""), "").strip()
            if sym == symbol:
                return v
        return None

    if isinstance(pending, (list, tuple, set)):
        for item in pending:
            sym = _s(_get(item, "symbol", ""), "").strip()
            if sym == symbol:
                return item
        return None

    # Fallback: try iterating
    try:
        for item in pending:  # type: ignore
            sym = _s(_get(item, "symbol", ""), "").strip()
            if sym == symbol:
                return item
    except Exception:
        pass
    return None


def _normalize_side(pos: Any) -> Optional[str]:
    """
    Normalize side to 'long' or 'short', derived from:
      - side field: buy/sell/long/short
      - qty sign if present
    """
    side_raw = _s(_get(pos, "side", ""), "").strip().lower()
    qty = _f(_get(pos, "qty", _get(pos, "size", _get(pos, "positionAmt", 0.0))), 0.0)

    if side_raw in ("long", "short"):
        return side_raw
    if side_raw in ("buy", "bid"):
        return "long"
    if side_raw in ("sell", "ask"):
        return "short"

    # Infer from qty sign
    if qty > 0:
        return "long"
    if qty < 0:
        return "short"
    return None


def _abs_qty(pos: Any) -> float:
    """Extract position size with common field aliases and return absolute qty."""
    # Prefer qty if exists, else size, else positionAmt
    qty = _get(pos, "qty", None)
    if qty is None:
        qty = _get(pos, "size", None)
    if qty is None:
        qty = _get(pos, "positionAmt", None)
    return abs(_f(qty, 0.0))


def _extract_entry(pos: Any) -> float:
    """Extract average entry price from common aliases."""
    for k in ("entry", "avg_price", "avgPrice", "average", "avg_entry"):
        v = _get(pos, k, None)
        if v is not None:
            vv = _f(v, 0.0)
            if vv > 0:
                return vv
    return 0.0


def _extract_stop(pos: Any) -> float:
    for k in ("stop", "sl", "stop_loss", "stopLoss"):
        v = _get(pos, k, None)
        if v is not None:
            vv = _f(v, 0.0)
            if vv > 0:
                return vv
    return 0.0


def _extract_tp(pos: Any) -> float:
    for k in ("tp", "take_profit", "takeProfit"):
        v = _get(pos, k, None)
        if v is not None:
            vv = _f(v, 0.0)
            if vv > 0:
                return vv
    return 0.0


def _extract_trailing(pos: Any) -> bool:
    v = _get(pos, "trailing", None)
    if isinstance(v, bool):
        return v
    s = _s(v, "").strip().lower()
    return s in ("1", "true", "yes", "y", "on", "enabled")


@dataclass
class PositionState:
    symbol: str
    state: str = "FLAT"          # FLAT | ENTRY_PENDING | OPEN | EXIT_PENDING
    side: Optional[str] = None   # long | short | None
    qty: float = 0.0
    entry: float = 0.0
    stop: float = 0.0
    tp: float = 0.0
    trailing: bool = False
    ts: float = 0.0             # last update timestamp


class PositionFSM:
    """
    Lightweight position finite state tracker for UI.
    Consumes engine snapshots:
      - positions snapshot (list of dict/object)
      - pending orders snapshot (list/dict)
      - optional engine.pairs list to track FLAT instruments too
    """

    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log
        self._states: Dict[str, PositionState] = {}

    def get(self, symbol: str) -> Dict[str, Any]:
        symbol = _s(symbol, "").strip()
        if not symbol:
            return asdict(PositionState(symbol=""))
        st = self._states.get(symbol)
        if st is None:
            st = PositionState(symbol=symbol, ts=0.0)
            self._states[symbol] = st
        return asdict(st)

    def snapshot(self) -> Dict[str, Dict[str, Any]]:
        return {sym: asdict(st) for sym, st in self._states.items()}

    def _safe_call(self, obj: Any, method: str, default: Any) -> Any:
        try:
            fn = getattr(obj, method, None)
            if callable(fn):
                return fn()
        except Exception:
            pass
        return default

    def update(self, engine: Any) -> None:
        """
        Update FSM with engine state.
        Must never raise.
        """
        now = time.time()

        # Gather snapshots
        positions = self._safe_call(engine, "get_positions_snapshot", None)
        if positions is None:
            positions = getattr(engine, "positions", None)

        pending = self._safe_call(engine, "get_pending_snapshot", None)
        if pending is None:
            pending = getattr(engine, "pending", None)

        # Normalize positions into iterable list
        pos_list: List[Any] = []
        if positions:
            if isinstance(positions, dict):
                # dict keyed by symbol -> position dict/object
                for sym, v in positions.items():
                    if isinstance(v, dict) and "symbol" not in v:
                        vv = dict(v)
                        vv["symbol"] = sym
                        pos_list.append(vv)
                    else:
                        # attach symbol if missing
                        if _s(_get(v, "symbol", ""), "").strip() == "" and isinstance(sym, str):
                            try:
                                if isinstance(v, dict):
                                    vv = dict(v)
                                    vv["symbol"] = sym
                                    pos_list.append(vv)
                                else:
                                    pos_list.append(v)
                            except Exception:
                                pos_list.append(v)
                        else:
                            pos_list.append(v)
            elif isinstance(positions, (list, tuple, set)):
                pos_list = list(positions)
            else:
                # single object?
                pos_list = [positions]

        # Determine universe of symbols to track
        syms: List[str] = []

        # From engine.pairs (to show FLAT symbols too)
        try:
            pairs = getattr(engine, "pairs", None)
            if isinstance(pairs, (list, tuple, set)):
                for p in pairs:
                    s = _s(p, "").strip()
                    if s:
                        syms.append(s)
        except Exception:
            pass

        # From positions
        for p in pos_list:
            s = _s(_get(p, "symbol", ""), "").strip()
            if s:
                syms.append(s)

        # From pending
        for s in _extract_pending_symbols(pending):
            ss = _s(s, "").strip()
            if ss:
                syms.append(ss)

        # Unique (preserve order)
        syms = list(dict.fromkeys(syms))

        # If nothing to do, keep empty state (do not auto-create)
        if not syms:
            return

        # Build lookup for positions by symbol
        pos_by_sym: Dict[str, Any] = {}
        for p in pos_list:
            s = _s(_get(p, "symbol", ""), "").strip()
            if s:
                pos_by_sym[s] = p

        # Update each symbol state
        for sym in syms:
            try:
                st = self._states.get(sym)
                if st is None:
                    st = PositionState(symbol=sym)
                    self._states[sym] = st

                pos = pos_by_sym.get(sym)
                pend = _pending_for_symbol(pending, sym)

                # Determine if open
                qty = _abs_qty(pos) if pos is not None else 0.0
                side = _normalize_side(pos) if pos is not None else None

                # Pending reason heuristics
                reason = _s(_get(pend, "reason", ""), "").lower()
                pside = _s(_get(pend, "side", ""), "").lower()

                # Exit markers: include real-world strings
                exit_markers = (
                    "exit", "close", "closing", "reduce",
                    "stop", "stop loss", "sl",
                    "tp", "take profit", "take-profit", "profit",
                )

                entry_markers = ("entry", "open", "buy", "sell", "enter")

                new_state = "FLAT"

                if qty <= 0.0:
                    # no position
                    if pend is not None:
                        # pending entry?
                        if any(k in reason for k in entry_markers) or pside in ("buy", "sell"):
                            new_state = "ENTRY_PENDING"
                        else:
                            # Unknown pending while flat - still treat as pending entry for UI clarity
                            new_state = "ENTRY_PENDING"
                    else:
                        new_state = "FLAT"
                else:
                    # open position
                    new_state = "OPEN"
                    if pend is not None and any(k in reason for k in exit_markers):
                        new_state = "EXIT_PENDING"

                # Fill position fields if present
                if pos is not None:
                    st.side = side
                    st.qty = qty
                    st.entry = _extract_entry(pos)
                    st.stop = _extract_stop(pos)
                    st.tp = _extract_tp(pos)
                    st.trailing = _extract_trailing(pos)
                else:
                    # flat states
                    st.side = None
                    st.qty = 0.0
                    st.entry = 0.0
                    st.stop = 0.0
                    st.tp = 0.0
                    st.trailing = False

                st.state = new_state
                st.ts = now

            except Exception as e:
                # Never break UI
                try:
                    if hasattr(self.log, "warning"):
                        self.log.warning(f"[position_fsm] update error for {sym}: {e}")
                except Exception:
                    pass

# app/selftest.py - Versiune îmbunătățită
from __future__ import annotations

import os
import sys
import time
import json
import platform
import importlib
import inspect
import glob
import py_compile
import hashlib
import pickle
import concurrent.futures
from dataclasses import dataclass, asdict, field
from typing import Any, Callable, Dict, List, Tuple, Optional, Set
from enum import Enum
from pathlib import Path
import statistics


class TestStatus(Enum):
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"
    SKIPPED = "SKIPPED"
    ERROR = "ERROR"


@dataclass
class SelfTestResult:
    name: str
    status: TestStatus
    duration_ms: int
    message: str
    metadata: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    category: str = "core"
    severity: str = "medium"  # low, medium, high, critical
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status.value,
            "duration_ms": self.duration_ms,
            "message": self.message,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
            "category": self.category,
            "severity": self.severity,
        }


@dataclass
class PerformanceMetrics:
    total_duration_ms: int = 0
    tests_per_second: float = 0.0
    avg_test_duration_ms: float = 0.0
    memory_usage_mb: float = 0.0
    cpu_percent: float = 0.0


@dataclass
class SelfTestReport:
    success: bool
    summary: Dict[str, Any]
    results: List[SelfTestResult]
    loaded_modules: List[str]
    performance: PerformanceMetrics
    recommendations: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "summary": self.summary,
            "results": [r.to_dict() for r in self.results],
            "loaded_modules": self.loaded_modules,
            "performance": asdict(self.performance),
            "recommendations": self.recommendations,
            "generated_at": time.time(),
            "version": "2.0.0"
        }
    
    def to_html(self) -> str:
        """Generate HTML report for web dashboard."""
        # Implementation for HTML report
        pass
    
    def get_failed_tests(self) -> List[SelfTestResult]:
        return [r for r in self.results if r.status in (TestStatus.FAIL, TestStatus.ERROR)]
    
    def get_critical_failures(self) -> List[SelfTestResult]:
        return [r for r in self.results if r.status in (TestStatus.FAIL, TestStatus.ERROR) 
                and r.severity in ("high", "critical")]


class TestCategory:
    CORE = "core"
    EXCHANGE = "exchange"
    STRATEGY = "strategy"
    PERFORMANCE = "performance"
    SECURITY = "security"
    INTEGRATION = "integration"


class SelfTester:
    """
    Enhanced self-test system with performance monitoring, caching,
    parallel execution, and integration with trace system.
    """
    
    def __init__(self, cfg: dict, log: Any, trace_buffer: Optional[Any] = None):
        self.cfg = cfg or {}
        self.log = log
        self.trace = trace_buffer
        self.results: List[SelfTestResult] = []
        self.cache_dir = Path(self.cfg.get("cache_dir", ".selftest_cache"))
        self.cache_enabled = self.cfg.get("selftest", {}).get("cache_enabled", True)
        self.parallel_enabled = self.cfg.get("selftest", {}).get("parallel_enabled", True)
        self.max_workers = self.cfg.get("selftest", {}).get("max_workers", 4)
        
        # Performance tracking
        self.start_time: Optional[float] = None
        self.performance_stats: Dict[str, List[float]] = {}
        
        # Initialize cache
        if self.cache_enabled:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Load test registry
        self.test_registry = self._load_test_registry()
    
    def _load_test_registry(self) -> Dict[str, Dict[str, Any]]:
        """Load test configurations from registry."""
        registry = {
            "python_env": {
                "func": self._t_python_env,
                "category": TestCategory.CORE,
                "severity": "critical",
                "timeout": 5,
            },
            "project_layout": {
                "func": self._t_project_layout,
                "category": TestCategory.CORE,
                "severity": "high",
                "timeout": 10,
            },
            # ... other tests
        }
        
        # Load custom tests from config
        custom_tests = self.cfg.get("selftest", {}).get("custom_tests", {})
        registry.update(custom_tests)
        
        return registry
    
    def _trace_event(self, level: str, message: str, metadata: Dict[str, Any]) -> None:
        """Send event to trace buffer if available."""
        if self.trace and hasattr(self.trace, 'emit'):
            self.trace.emit(message, level=level, ctx=metadata)

    # ---------------------------------------------------------------------
    # Compatibility helpers
    # ---------------------------------------------------------------------
    def _t_project_layout(self) -> Tuple[str, str, Dict[str, Any]]:
        """Basic sanity check for expected project layout."""
        try:
            root = Path(__file__).resolve().parents[1]
            expected = {
                "app_dir": (root / "app").is_dir(),
                "profiles_dir": (root / "profiles").is_dir(),
                "engine_py": (root / "app" / "engine.py").is_file(),
                "gui_py": (root / "crypto_bot_gui.py").is_file(),
            }
            missing = [k for k, ok in expected.items() if not ok]
            if missing:
                return TestStatus.WARN, f"Project layout missing: {', '.join(missing)}", {
                    "root": str(root),
                    "expected": expected,
                }
            return TestStatus.PASS, "Project layout OK", {"root": str(root), "expected": expected}
        except Exception as e:
            return TestStatus.WARN, f"Project layout check failed: {e}", {}

    def _check_dependency_conflicts(self) -> None:
        """Post-test: verify core dependencies import and record versions."""
        def _t() -> Tuple[str, str, Dict[str, Any]]:
            import importlib
            pkgs = [
                "ccxt",
                "pandas",
                "numpy",
                "fastapi",
                "uvicorn",
                "requests",
                "tqdm",
            ]
            missing = []
            versions: Dict[str, str] = {}
            for p in pkgs:
                try:
                    mod = importlib.import_module(p)
                    versions[p] = str(getattr(mod, "__version__", "?"))
                except Exception:
                    missing.append(p)
            if missing:
                return TestStatus.WARN, f"Missing deps: {', '.join(missing)}", {"missing": missing, "versions": versions}
            return TestStatus.PASS, "Core deps OK", {"versions": versions}

        self.results.append(self._run_single_test("dependency_conflicts", _t))

    def _run_security_checks(self) -> None:
        """Post-test: run lightweight security checks."""
        self.results.append(self._run_single_test("security_checks", self._t_security_checks))
    
    def run(self, mode: str = "full") -> SelfTestReport:
        """
        Run self-tests with specified mode.
        
        Modes:
          - full: All tests
          - quick: Fast tests only
          - critical: Critical tests only
          - category: Specific category
        """
        self.start_time = time.perf_counter()
        self._trace_event("info", "Starting self-test suite", {"mode": mode})
        
        # Collect tests based on mode
        tests_to_run = self._collect_tests(mode)
        
        # Run tests
        if self.parallel_enabled and len(tests_to_run) > 3:
            self._run_parallel(tests_to_run)
        else:
            self._run_sequential(tests_to_run)
        
        # Run post-tests
        self._run_post_tests()
        
        # Generate report
        report = self._generate_report()
        
        # Cache results if enabled
        if self.cache_enabled:
            self._cache_report(report)
        
        self._trace_event("info", "Self-test suite completed", 
                         {"success": report.success, "duration": report.performance.total_duration_ms})
        
        return report
    
    def _collect_tests(self, mode: str) -> List[Tuple[str, Callable]]:
        """Collect tests to run based on mode."""
        st_cfg = self.cfg.get("selftest", {})
        enabled_only = set(st_cfg.get("enabled_tests", []))
        disabled = set(st_cfg.get("disabled_tests", []))
        
        tests = []
        
        for name, config in self.test_registry.items():
            # Skip disabled
            if name in disabled:
                continue
            
            # Check if enabled
            if enabled_only and name not in enabled_only:
                continue
            
            # Check mode filter
            if mode == "quick" and config.get("category") not in [TestCategory.CORE, TestCategory.PERFORMANCE]:
                continue
            elif mode == "critical" and config.get("severity") not in ["high", "critical"]:
                continue
            
            tests.append((name, config["func"]))
        
        return tests
    
    def _run_parallel(self, tests: List[Tuple[str, Callable]]) -> None:
        """Run tests in parallel."""
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_test = {
                executor.submit(self._run_single_test, name, fn): (name, fn)
                for name, fn in tests
            }
            
            for future in concurrent.futures.as_completed(future_to_test):
                name, fn = future_to_test[future]
                try:
                    result = future.result(timeout=60)  # 60 second timeout per test
                    self.results.append(result)
                except concurrent.futures.TimeoutError:
                    self._add_timeout_result(name)
                except Exception as e:
                    self._add_error_result(name, str(e))
    
    def _run_sequential(self, tests: List[Tuple[str, Callable]]) -> None:
        """Run tests sequentially."""
        for name, fn in tests:
            result = self._run_single_test(name, fn)
            self.results.append(result)
    
    def _run_single_test(self, name: str, fn: Callable) -> SelfTestResult:
        """Run a single test with monitoring."""
        test_config = self.test_registry.get(name, {})
        category = test_config.get("category", TestCategory.CORE)
        severity = test_config.get("severity", "medium")
        timeout = test_config.get("timeout", 30)
        
        start_time = time.perf_counter()
        
        try:
            # Run test with timeout
            if timeout:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(fn)
                    status, message, metadata = future.result(timeout=timeout)
            else:
                status, message, metadata = fn()
            
            duration_ms = int((time.perf_counter() - start_time) * 1000)
            
            # Convert string status to enum
            if isinstance(status, str):
                status = TestStatus(status.upper())
            
            # Update performance stats
            self._update_performance_stats(name, duration_ms)
            
            # Trace event
            self._trace_event(
                "info" if status == TestStatus.PASS else "warning",
                f"Test {name}: {status.value}",
                {"duration_ms": duration_ms, "message": message}
            )
            
            return SelfTestResult(
                name=name,
                status=status,
                duration_ms=duration_ms,
                message=message,
                metadata=metadata,
                category=category,
                severity=severity
            )
            
        except concurrent.futures.TimeoutError:
            duration_ms = int((time.perf_counter() - start_time) * 1000)
            return SelfTestResult(
                name=name,
                status=TestStatus.ERROR,
                duration_ms=duration_ms,
                message=f"Test timeout after {timeout}s",
                metadata={"timeout": timeout},
                category=category,
                severity=severity
            )
        except Exception as e:
            duration_ms = int((time.perf_counter() - start_time) * 1000)
            return SelfTestResult(
                name=name,
                status=TestStatus.ERROR,
                duration_ms=duration_ms,
                message=f"Test error: {str(e)}",
                metadata={"error": str(e), "error_type": type(e).__name__},
                category=category,
                severity=severity
            )
    
    def _update_performance_stats(self, test_name: str, duration_ms: int) -> None:
        """Update performance statistics."""
        if test_name not in self.performance_stats:
            self.performance_stats[test_name] = []
        self.performance_stats[test_name].append(duration_ms / 1000.0)  # Convert to seconds
    
    def _run_post_tests(self) -> None:
        """Run post-test analysis and validation."""
        # Performance analysis
        self._analyze_performance()
        
        # Dependency conflict detection
        self._check_dependency_conflicts()
        
        # Security checks
        self._run_security_checks()
    
    def _analyze_performance(self) -> None:
        """Analyze test performance and detect anomalies."""
        performance_data = {}
        
        for test_name, durations in self.performance_stats.items():
            if len(durations) >= 3:  # Need at least 3 samples for statistical analysis
                avg = statistics.mean(durations)
                stdev = statistics.stdev(durations) if len(durations) > 1 else 0
                cv = (stdev / avg) * 100 if avg > 0 else 0  # Coefficient of variation
                
                performance_data[test_name] = {
                    "samples": len(durations),
                    "avg_seconds": avg,
                    "stdev_seconds": stdev,
                    "cv_percent": cv,
                    "anomaly": cv > 50  # Flag if high variation
                }
        
        # Store for reporting
        self.performance_analysis = performance_data
    
    def _generate_report(self) -> SelfTestReport:
        """Generate comprehensive test report."""
        # Calculate summary
        summary = {
            "total": len(self.results),
            "passed": sum(1 for r in self.results if r.status == TestStatus.PASS),
            "warnings": sum(1 for r in self.results if r.status == TestStatus.WARN),
            "failed": sum(1 for r in self.results if r.status == TestStatus.FAIL),
            "errors": sum(1 for r in self.results if r.status == TestStatus.ERROR),
            "skipped": sum(1 for r in self.results if r.status == TestStatus.SKIPPED),
        }
        
        # Calculate success (no failures or errors in critical tests)
        critical_failures = self._get_critical_failures()
        success = len(critical_failures) == 0
        
        # Calculate performance metrics
        total_duration = (time.perf_counter() - self.start_time) * 1000 if self.start_time else 0
        tests_per_second = summary["total"] / (total_duration / 1000) if total_duration > 0 else 0
        
        performance = PerformanceMetrics(
            total_duration_ms=int(total_duration),
            tests_per_second=tests_per_second,
            avg_test_duration_ms=total_duration / summary["total"] if summary["total"] > 0 else 0,
        )
        
        # Generate recommendations
        recommendations = self._generate_recommendations()
        
        # Get loaded modules
        loaded_modules = self._get_loaded_modules()
        
        return SelfTestReport(
            success=success,
            summary=summary,
            results=self.results,
            loaded_modules=loaded_modules,
            performance=performance,
            recommendations=recommendations
        )
    
    def _get_critical_failures(self) -> List[SelfTestResult]:
        """Get critical test failures."""
        return [
            r for r in self.results 
            if r.status in (TestStatus.FAIL, TestStatus.ERROR) 
            and r.severity in ("high", "critical")
        ]
    
    def _generate_recommendations(self) -> List[str]:
        """Generate recommendations based on test results."""
        recommendations = []
        
        # Check for slow tests
        slow_tests = [r for r in self.results if r.duration_ms > 5000]  # >5 seconds
        if slow_tests:
            recommendations.append(
                f"Consider optimizing {len(slow_tests)} slow tests (>5s): "
                f"{', '.join(r.name for r in slow_tests[:3])}"
            )
        
        # Check for flaky tests (if we have historical data)
        if hasattr(self, 'performance_analysis'):
            flaky_tests = [
                name for name, data in self.performance_analysis.items()
                if data.get('anomaly', False)
            ]
            if flaky_tests:
                recommendations.append(
                    f"Flaky tests detected (high variability): {', '.join(flaky_tests[:5])}"
                )
        
        # Check dependency issues
        if any("dependency" in r.message.lower() for r in self.results):
            recommendations.append("Review dependency versions and conflicts")
        
        # Check for missing security tests
        security_tests = [r for r in self.results if r.category == TestCategory.SECURITY]
        if not security_tests:
            recommendations.append("Add security tests for production deployment")
        
        return recommendations
    
    def _cache_report(self, report: SelfTestReport) -> None:
        """Cache test report for comparison."""
        cache_file = self.cache_dir / "last_report.json"
        
        try:
            # Load previous reports
            previous_reports = []
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    previous_reports = json.load(f)
            
            # Add current report
            report_dict = report.to_dict()
            report_dict['cached_at'] = time.time()
            
            # Keep only last 10 reports
            previous_reports.append(report_dict)
            if len(previous_reports) > 10:
                previous_reports = previous_reports[-10:]
            
            # Save
            with open(cache_file, 'w') as f:
                json.dump(previous_reports, f, indent=2)
                
        except Exception as e:
            self._trace_event("warning", f"Failed to cache report: {e}", {})
    
    def _get_loaded_modules(self) -> List[str]:
        """Get list of loaded modules for reporting."""
        modules = []
        for name, module in sys.modules.items():
            if (name.startswith('app.') or 
                name in ('ccxt', 'numpy', 'pandas', 'sqlalchemy', 'websockets')):
                try:
                    modules.append(f"{name}:{getattr(module, '__version__', 'unknown')}")
                except:
                    modules.append(name)
        return modules
    
    # ===== Enhanced Test Methods =====
    
    def _t_performance_benchmark(self) -> Tuple[str, str, Dict[str, Any]]:
        """Enhanced performance benchmarking."""
        benchmarks = {}
        
        # Test indicator calculations
        try:
            import numpy as np
            import pandas as pd
            from app.indicators import ema, rsi, atr
            
            # Generate test data
            np.random.seed(42)
            data_size = 10000
            test_data = pd.Series(np.random.randn(data_size).cumsum() + 100)
            
            # Benchmark EMA
            ema_times = []
            for _ in range(100):
                start = time.perf_counter()
                _ = ema(test_data, 20)
                ema_times.append(time.perf_counter() - start)
            
            benchmarks['ema_10k_100x'] = {
                'avg_ms': np.mean(ema_times) * 1000,
                'p95_ms': np.percentile(ema_times, 95) * 1000,
                'p99_ms': np.percentile(ema_times, 99) * 1000,
            }
            
            # Check against thresholds
            threshold_p95 = 100  # 100ms P95 threshold
            if benchmarks['ema_10k_100x']['p95_ms'] > threshold_p95:
                return TestStatus.WARN.value, f"EMA performance slow: {benchmarks['ema_10k_100x']['p95_ms']:.1f}ms P95", benchmarks
            
            return TestStatus.PASS.value, f"Performance OK: EMA avg={benchmarks['ema_10k_100x']['avg_ms']:.1f}ms", benchmarks
            
        except Exception as e:
            return TestStatus.WARN.value, f"Performance benchmark failed: {e}", {}
    
    def _t_security_checks(self) -> Tuple[str, str, Dict[str, Any]]:
        """Security-related checks."""
        checks = {
            "env_vars_exposed": False,
            "weak_crypto": False,
            "insecure_deps": False,
        }
        
        # Check for exposed secrets in environment
        sensitive_vars = ['API_KEY', 'SECRET', 'PASSWORD', 'TOKEN']
        exposed_vars = []
        for var in sensitive_vars:
            if os.getenv(var):
                exposed_vars.append(var)
        
        if exposed_vars:
            checks["env_vars_exposed"] = True
        
        # Check for weak random number generation
        try:
            import random
            if random.randint(0, 1000) == random.randint(0, 1000):
                checks["weak_crypto"] = True
        except:
            pass
        
        # Check dependencies for known vulnerabilities
        try:
            import pkg_resources
            vulnerable_deps = []
            for dist in pkg_resources.working_set:
                # This is a simplified check - in production use safety or similar
                if "0.0.1" in dist.version or "alpha" in dist.version or "beta" in dist.version:
                    vulnerable_deps.append(f"{dist.key}=={dist.version}")
            
            if vulnerable_deps:
                checks["insecure_deps"] = True
                checks["vulnerable_deps"] = vulnerable_deps
        except:
            pass
        
        # Evaluate results
        if checks["env_vars_exposed"] or checks["weak_crypto"]:
            return TestStatus.FAIL.value, "Critical security issues found", checks
        elif checks["insecure_deps"]:
            return TestStatus.WARN.value, "Potential security issues in dependencies", checks
        else:
            return TestStatus.PASS.value, "Security checks passed", checks
    
    def _t_integration_validation(self) -> Tuple[str, str, Dict[str, Any]]:
        """Validate integration between modules."""
        try:
            # Test trace + strategy integration
            from app.trace import TraceBuffer
            from app.strategy import StrategyEngine
            
            # Create instances
            trace = TraceBuffer(self.cfg, self.log)
            strategy = StrategyEngine(self.cfg, self.log)
            
            # Generate mock data
            import pandas as pd
            import numpy as np
            
            dates = pd.date_range(end=pd.Timestamp.now(), periods=50, freq='1min')
            mock_data = pd.DataFrame({
                'open': np.random.randn(50).cumsum() + 100,
                'high': np.random.randn(50).cumsum() + 105,
                'low': np.random.randn(50).cumsum() + 95,
                'close': np.random.randn(50).cumsum() + 100,
                'volume': np.random.rand(50) * 1000,
            }, index=dates)
            
            # Run strategy with tracing
            with trace as t:
                signal = strategy.compute(mock_data, None, "TEST/USDT")
                
                # Verify trace captured events
                trace_events = t.tail(10)
                strategy_events = [e for e in trace_events if "strategy" in e.get('msg', '').lower()]
                
                if len(strategy_events) == 0:
                    return TestStatus.WARN.value, "No strategy events in trace", {}
                
                return TestStatus.PASS.value, f"Integration OK: {signal.action} signal generated", {
                    "signal": signal.action,
                    "strength": signal.strength,
                    "trace_events": len(strategy_events)
                }
                
        except Exception as e:
            return TestStatus.FAIL.value, f"Integration test failed: {e}", {}
    
    # ===== Original test methods (updated) =====
    
    def _t_python_env(self) -> Tuple[str, str, Dict[str, Any]]:
        """Enhanced Python environment check."""
        v = sys.version.split()[0]
        info = {
            "python": v,
            "platform": platform.platform(),
            "executable": sys.executable,
            "architecture": platform.architecture()[0],
            "machine": platform.machine(),
            "processor": platform.processor(),
            "byte_order": sys.byteorder,
        }
        
        # Check Python version compatibility
        version_tuple = sys.version_info
        if version_tuple < (3, 8):
            return TestStatus.FAIL.value, f"Python {v} below minimum 3.8", info
        
        return TestStatus.PASS.value, f"Python {v} OK", info
    
    # ... rest of original test methods with enhancements ...


class HealthCheckService:
    """Lightweight health check service for production monitoring."""
    
    def __init__(self, tester: SelfTester, config: Dict[str, Any]):
        self.tester = tester
        self.config = config
        self.heartbeat_interval = config.get("heartbeat_interval", 60)
        self.last_heartbeat = 0
        
    def get_health_status(self) -> Dict[str, Any]:
        """Get current health status."""
        # Run quick health check
        report = self.tester.run(mode="quick")
        
        status = {
            "status": "healthy" if report.success else "unhealthy",
            "timestamp": time.time(),
            "report": report.to_dict(),
            "uptime": time.time() - self.tester.start_time if self.tester.start_time else 0,
        }
        
        # Add system metrics
        status.update(self._get_system_metrics())
        
        return status
    
    def _get_system_metrics(self) -> Dict[str, Any]:
        """Get system metrics."""
        try:
            import psutil
            return {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_usage": psutil.disk_usage("/").percent,
                "process_memory_mb": psutil.Process().memory_info().rss / 1024 / 1024,
            }
        except ImportError:
            return {"metrics": "psutil not available"}
    
    def start_monitoring(self) -> None:
        """Start continuous health monitoring."""
        import threading
        
        def monitor():
            while True:
                try:
                    status = self.get_health_status()
                    if not status["status"] == "healthy":
                        self._alert_unhealthy(status)
                    time.sleep(self.heartbeat_interval)
                except Exception as e:
                    self.tester._trace_event("error", f"Health monitor error: {e}", {})
        
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
    
    def _alert_unhealthy(self, status: Dict[str, Any]) -> None:
        """Alert on unhealthy status."""
        # Implement alerting logic (email, slack, webhook, etc.)
        self.tester._trace_event("error", "System unhealthy", status)


# Factory function for easy integration
def create_selftester(config: Dict[str, Any], logger: Any, trace_buffer: Optional[Any] = None) -> SelfTester:
    """Factory function to create SelfTester instance."""
    return SelfTester(config, logger, trace_buffer)


# Main entry point for CLI usage
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run self-tests")
    parser.add_argument("--config", "-c", default="config.json", help="Configuration file")
    parser.add_argument("--mode", "-m", default="full", choices=["full", "quick", "critical", "validate"],
                       help="Test mode")
    parser.add_argument("--output", "-o", help="Output report file")
    parser.add_argument("--format", "-f", default="json", choices=["json", "html", "text"],
                       help="Output format")
    
    args = parser.parse_args()
    
    # Load config
    import json
    with open(args.config, 'r') as f:
        config = json.load(f)
    
    # Setup logging
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("selftest")
    
    # Create and run tester
    tester = create_selftester(config, logger)
    report = tester.run(mode=args.mode)
    
    # Output results
    if args.output:
        if args.format == "json":
            with open(args.output, 'w') as f:
                json.dump(report.to_dict(), f, indent=2)
        elif args.format == "html":
            with open(args.output, 'w') as f:
                f.write(report.to_html())
        else:
            with open(args.output, 'w') as f:
                f.write(str(report))
    else:
        print(json.dumps(report.to_dict(), indent=2))
    
    # Exit code based on success
    sys.exit(0 if report.success else 1)
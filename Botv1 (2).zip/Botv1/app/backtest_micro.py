# app/backtest_micro.py
from __future__ import annotations

import time
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Optional, List, Tuple, Callable, Union
from enum import Enum
import numpy as np
import pandas as pd
from collections import defaultdict
import warnings


# ==================== Enums și Structuri de Date ====================

class Side(Enum):
    LONG = "long"
    SHORT = "short"
    
    @classmethod
    def from_string(cls, value: str) -> Side:
        value = value.lower().strip()
        if value in ("long", "buy"):
            return cls.LONG
        elif value in ("short", "sell"):
            return cls.SHORT
        raise ValueError(f"Invalid side: {value}")


class EntryMode(Enum):
    CLOSE = "close"
    NEXT_OPEN = "next_open"
    NEXT_BAR = "next_bar"  # Alias pentru next_open
    VWAP = "vwap"  # Intrare la VWAP (dacă este disponibil)
    
    @classmethod
    def from_string(cls, value: str) -> EntryMode:
        value = value.lower().strip()
        if value in ("close", "c"):
            return cls.CLOSE
        elif value in ("next_open", "next_bar", "open"):
            return cls.NEXT_OPEN
        elif value == "vwap":
            return cls.VWAP
        warnings.warn(f"Unknown entry mode: {value}, using CLOSE")
        return cls.CLOSE


class IntrabarPolicy(Enum):
    WORST = "worst"  # Stop câștigă (conservator)
    BEST = "best"   # TP câștigă (optimist)
    MID = "mid"     # Ambele (parțial TP, rest stop)
    RANDOM = "random"  # Aleatoriu (pentru Monte Carlo)
    
    @classmethod
    def from_string(cls, value: str) -> IntrabarPolicy:
        value = value.lower().strip()
        if value == "worst":
            return cls.WORST
        elif value == "best":
            return cls.BEST
        elif value == "mid":
            return cls.MID
        elif value == "random":
            return cls.RANDOM
        warnings.warn(f"Unknown intrabar policy: {value}, using WORST")
        return cls.WORST


class TacticType(Enum):
    TREND_FOLLOW = "trend_follow"
    RANGE_REVERSION = "range_reversion"
    SCALP = "scalp"
    GRID = "grid"
    BREAKOUT = "breakout"
    HIGH_VOL_EVENT = "high_vol_event"
    NONE = "none"
    MEAN_REVERSION = "mean_reversion"  # Nou
    MOMENTUM = "momentum"  # Nou
    VOLATILITY = "volatility"  # Nou
    
    @classmethod
    def default_tactics(cls) -> List[TacticType]:
        return [
            cls.TREND_FOLLOW,
            cls.RANGE_REVERSION,
            cls.SCALP,
            cls.GRID,
            cls.BREAKOUT,
            cls.HIGH_VOL_EVENT,
            cls.NONE
        ]


@dataclass
class ScaleOutLevel:
    """Nivel de scale-out cu multiplicator ATR și procent."""
    atr_multiplier: float
    percentage: float
    
    def __post_init__(self):
        self.atr_multiplier = max(0.0, float(self.atr_multiplier))
        self.percentage = max(0.0, min(1.0, float(self.percentage)))


@dataclass
class BacktestParams:
    """Parametrii pentru un backtest individual."""
    tactic_type: TacticType
    param_id: str
    stop_atr_mult: float
    tp_atr_mult: float
    timeout_bars: int
    scale_out_levels: List[ScaleOutLevel] = field(default_factory=list)
    
    # Parametrii opționali
    trailing_stop_enabled: bool = False
    trailing_stop_atr_mult: float = 0.0
    partial_exit_enabled: bool = False
    partial_exit_bars: List[int] = field(default_factory=list)
    partial_exit_pcts: List[float] = field(default_factory=list)
    
    def __post_init__(self):
        # Validare basic
        self.stop_atr_mult = max(0.1, float(self.stop_atr_mult))
        self.tp_atr_mult = max(0.1, float(self.tp_atr_mult))
        self.timeout_bars = max(1, int(self.timeout_bars))
        
        # Validare scale-out
        total_pct = sum(level.percentage for level in self.scale_out_levels)
        if total_pct > 1.0:
            # Normalizează dacă este necesar
            factor = 1.0 / total_pct
            for level in self.scale_out_levels:
                level.percentage *= factor


@dataclass
class BacktestConfig:
    """Configurația completă pentru micro-backtest."""
    enabled: bool = True
    bars: int = 600  # Numărul de bare istorice de utilizat
    horizon_bars: int = 60  # Orizont de forward testing
    max_tactics: int = 6  # Numărul maxim de tactici de testat
    windows: int = 3  # Numărul de ferestre de intrare
    
    # Praguri
    min_signal_strength: float = 1.3
    min_score_threshold: float = -0.1  # Scor minim pentru a considera tactică validă
    
    # Politici
    intrabar_policy: IntrabarPolicy = IntrabarPolicy.WORST
    entry_mode: EntryMode = EntryMode.CLOSE
    
    # Costuri (în bps)
    fee_bps: float = 8.0
    slippage_bps: float = 4.0
    
    # Limită de timp
    budget_ms: float = 50.0
    
    # Parametri default
    default_stop_atr_mult: float = 2.5
    default_tp_atr_mult: float = 4.0
    
    # Configurație scale-out
    scale_out_enabled: bool = False
    scale_out_levels: List[ScaleOutLevel] = field(default_factory=lambda: [
        ScaleOutLevel(atr_multiplier=2.0, percentage=0.25),
        ScaleOutLevel(atr_multiplier=3.0, percentage=0.25),
        ScaleOutLevel(atr_multiplier=4.0, percentage=0.50)
    ])
    
    # Alte opțiuni
    use_weighted_scoring: bool = True  # Folosește ponderi pentru diferite ferestre
    require_min_bars: int = 50  # Număr minim de bare pentru backtest
    monte_carlo_samples: int = 0  # Număr de eșantioane Monte Carlo (0 = dezactivat)


@dataclass
class TradeResult:
    """Rezultatul unei tranzacții simulate."""
    exit_price: float
    exit_bar: int
    exit_reason: str  # "stop", "tp", "scale_out", "timeout", "close"
    realized_return: float
    max_drawdown: float
    bars_held: int
    scale_out_details: List[Tuple[int, float, float]] = field(default_factory=list)  # (bar, price, pct)


@dataclass
class SimulationResult:
    """Rezultatul unei simulări complete."""
    score: float
    trade_results: List[TradeResult] = field(default_factory=list)
    avg_return: float = 0.0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    sharpe_ratio: float = 0.0  # Simplificat
    max_drawdown: float = 0.0
    total_trades: int = 0


@dataclass
class TacticResult:
    """Rezultatul evaluării unei tactici."""
    tactic_type: TacticType
    best_params: BacktestParams
    best_score: float
    all_scores: Dict[str, float] = field(default_factory=dict)  # param_id -> score
    simulation_results: Dict[str, SimulationResult] = field(default_factory=dict)  # param_id -> result
    confidence: float = 0.0
    statistics: Dict[str, float] = field(default_factory=dict)


@dataclass
class MicroBacktestResult:
    """Rezultatul final al micro-backtest-ului."""
    enabled: bool = False
    tactic_results: Dict[str, TacticResult] = field(default_factory=dict)
    best_tactic: TacticType = TacticType.NONE
    best_score: float = 0.0
    best_params: BacktestParams = field(default_factory=lambda: BacktestParams(
        tactic_type=TacticType.NONE,
        param_id="none",
        stop_atr_mult=2.5,
        tp_atr_mult=4.0,
        timeout_bars=60
    ))
    reason: str = "disabled"
    bars_used: int = 0
    horizon: int = 0
    confidence: float = 0.0
    meta: Dict[str, Any] = field(default_factory=dict)
    execution_stats: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = asdict(self)
        # Convert Enum values to strings
        result["best_tactic"] = self.best_tactic.value
        for tactic_name, tactic_result in self.tactic_results.items():
            result["tactic_results"][tactic_name]["tactic_type"] = tactic_result.tactic_type.value
        return result
    
    @property
    def is_successful(self) -> bool:
        """Return True if backtest was successful and found a viable tactic."""
        return (self.enabled and 
                self.best_tactic != TacticType.NONE and 
                self.best_score > -0.1 and 
                self.confidence > 0.1)


# ==================== Utilitare ====================

def _safe_float(x: Any, default: float = 0.0) -> float:
    """Convert safely to float."""
    if x is None:
        return default
    try:
        return float(x)
    except (ValueError, TypeError):
        return default


def _clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp value between min and max."""
    return max(min_val, min(max_val, value))


def _normalize_probabilities(probabilities: List[float]) -> List[float]:
    """Normalize probabilities to sum to 1."""
    if not probabilities:
        return []
    total = sum(probabilities)
    if total <= 0:
        return [1.0 / len(probabilities)] * len(probabilities)
    return [p / total for p in probabilities]


def _calculate_weighted_average(values: List[float], weights: Optional[List[float]] = None) -> float:
    """Calculate weighted average."""
    if not values:
        return 0.0
    if weights is None or len(weights) != len(values):
        return np.mean(values)
    return np.average(values, weights=weights)


def _calculate_sharpe_ratio(returns: List[float], risk_free_rate: float = 0.0) -> float:
    """Calculate simplified Sharpe ratio."""
    if not returns:
        return 0.0
    excess_returns = [r - risk_free_rate for r in returns]
    if len(excess_returns) < 2:
        return 0.0
    mean_return = np.mean(excess_returns)
    std_return = np.std(excess_returns)
    if std_return == 0:
        return 0.0
    return mean_return / std_return * np.sqrt(252)  # Annualized


# ==================== Simulator ====================

class TradeSimulator:
    """Simulator pentru tranzacții individuale."""
    
    def __init__(
        self,
        side: Side,
        entry_price: float,
        atr: float,
        params: BacktestParams,
        intrabar_policy: IntrabarPolicy = IntrabarPolicy.WORST,
        fee_bps: float = 0.0,
        slippage_bps: float = 0.0
    ):
        self.side = side
        self.entry_price = entry_price
        self.atr = atr
        self.params = params
        self.intrabar_policy = intrabar_policy
        self.fee_bps = fee_bps
        self.slippage_bps = slippage_bps
        
        # Calculează nivelurile stop și TP
        if side == Side.LONG:
            self.stop_price = entry_price - params.stop_atr_mult * atr
            self.tp_prices = [entry_price + level.atr_multiplier * atr 
                             for level in params.scale_out_levels]
            self.tp_percentages = [level.percentage for level in params.scale_out_levels]
            
            if not self.tp_prices:
                # Dacă nu avem scale-out, folosim TP simplu
                self.tp_prices = [entry_price + params.tp_atr_mult * atr]
                self.tp_percentages = [1.0]
        else:  # SHORT
            self.stop_price = entry_price + params.stop_atr_mult * atr
            self.tp_prices = [entry_price - level.atr_multiplier * atr 
                             for level in params.scale_out_levels]
            self.tp_percentages = [level.percentage for level in params.scale_out_levels]
            
            if not self.tp_prices:
                # Dacă nu avem scale-out, folosim TP simplu
                self.tp_prices = [entry_price - params.tp_atr_mult * atr]
                self.tp_percentages = [1.0]
        
        # Stare curentă
        self.position_pct = 1.0  # 100% din poziție rămasă
        self.realized_pnl = 0.0  # PnL realizat
        self.max_drawdown = 0.0  # Cel mai mare drawdown
        self.trade_results = []  # Rezultate parțiale (pentru scale-out)
    
    def _apply_slippage_and_fees(self, price: float, is_entry: bool = False) -> float:
        """Aplică slippage și fee-uri la un preț."""
        # Slippage (apply to all trades)
        slippage_factor = self.slippage_bps / 10000.0
        if self.side == Side.LONG:
            price_with_slip = price * (1 + slippage_factor)
        else:
            price_with_slip = price * (1 - slippage_factor)
        
        # Fee (apply once per round-trip, split between entry and exit)
        fee_factor = self.fee_bps / 10000.0 / 2  # Jumătate la intrare, jumătate la ieșire
        if is_entry:
            if self.side == Side.LONG:
                return price_with_slip * (1 + fee_factor)
            else:
                return price_with_slip * (1 - fee_factor)
        else:
            if self.side == Side.LONG:
                return price_with_slip * (1 - fee_factor)
            else:
                return price_with_slip * (1 + fee_factor)
    
    def _calculate_return(self, exit_price: float, entry_price: float) -> float:
        """Calculează return-ul pentru o tranzacție."""
        if self.side == Side.LONG:
            return (exit_price - entry_price) / entry_price
        else:
            return (entry_price - exit_price) / entry_price
    
    def simulate_bar(
        self,
        high: float,
        low: float,
        close: float,
        bar_index: int
    ) -> Tuple[bool, Optional[TradeResult]]:
        """
        Simulează un bar. Returnează (finished, trade_result).
        Dacă finished=True, poziția s-a închis complet.
        """
        # Verifică stop
        if self.side == Side.LONG:
            hit_stop = low <= self.stop_price
        else:
            hit_stop = high >= self.stop_price
        
        # Verifică TP-uri
        hit_tp_levels = []
        for tp_price in self.tp_prices:
            if self.side == Side.LONG:
                hit_tp = high >= tp_price
            else:
                hit_tp = low <= tp_price
            hit_tp_levels.append(hit_tp)
        
        # Determină ce se întâmplă conform politicii intrabar
        hit_any_tp = any(hit_tp_levels)
        resolution = self._resolve_intrabar_conflict(hit_stop, hit_any_tp)
        
        # Procesează în funcție de rezoluție
        if resolution == "stop":
            # Stop-loss hits, close entire position
            exit_price = self.stop_price
            exit_price = self._apply_slippage_and_fees(exit_price, is_entry=False)
            realized_return = self._calculate_return(exit_price, self.entry_price)
            
            # Adaugă return-ul pentru poziția rămasă
            self.realized_pnl += self.position_pct * realized_return
            self.position_pct = 0.0
            
            trade_result = TradeResult(
                exit_price=exit_price,
                exit_bar=bar_index,
                exit_reason="stop",
                realized_return=realized_return,
                max_drawdown=self.max_drawdown,
                bars_held=bar_index + 1
            )
            return True, trade_result
        
        elif resolution == "tp" or resolution == "both":
            # TP hits, process scale-outs
            for i, (tp_price, tp_pct, hit_tp) in enumerate(zip(
                self.tp_prices, self.tp_percentages, hit_tp_levels
            )):
                if hit_tp and self.position_pct > 0:
                    # Cantitatea de close la acest nivel
                    close_pct = min(self.position_pct, tp_pct)
                    
                    exit_price = tp_price
                    exit_price = self._apply_slippage_and_fees(exit_price, is_entry=False)
                    realized_return = self._calculate_return(exit_price, self.entry_price)
                    
                    self.realized_pnl += close_pct * realized_return
                    self.position_pct -= close_pct
                    
                    self.trade_results.append((
                        bar_index,
                        exit_price,
                        close_pct,
                        realized_return
                    ))
            
            # Dacă resolution == "both" și mai avem poziție, stop the rest
            if resolution == "both" and self.position_pct > 0:
                exit_price = self.stop_price
                exit_price = self._apply_slippage_and_fees(exit_price, is_entry=False)
                realized_return = self._calculate_return(exit_price, self.entry_price)
                
                self.realized_pnl += self.position_pct * realized_return
                self.position_pct = 0.0
                
                return True, TradeResult(
                    exit_price=exit_price,
                    exit_bar=bar_index,
                    exit_reason="stop",
                    realized_return=realized_return,
                    max_drawdown=self.max_drawdown,
                    bars_held=bar_index + 1
                )
            
            # Dacă mai avem poziție, continuă
            if self.position_pct <= 0:
                # Toată poziția a fost închisă
                return True, None
        
        # Actualizează drawdown-ul
        if self.side == Side.LONG:
            current_drawdown = (low - self.entry_price) / self.entry_price
        else:
            current_drawdown = (self.entry_price - high) / self.entry_price
        
        self.max_drawdown = min(self.max_drawdown, current_drawdown)
        
        return False, None
    
    def _resolve_intrabar_conflict(self, hit_stop: bool, hit_tp: bool) -> str:
        """Rezolvă conflictele intrabar conform politicii."""
        if not hit_stop and not hit_tp:
            return "none"
        if hit_stop and not hit_tp:
            return "stop"
        if hit_tp and not hit_stop:
            return "tp"
        
        # Ambii au fost atinși
        if self.intrabar_policy == IntrabarPolicy.WORST:
            return "stop"
        elif self.intrabar_policy == IntrabarPolicy.BEST:
            return "tp"
        elif self.intrabar_policy == IntrabarPolicy.MID:
            return "both"
        elif self.intrabar_policy == IntrabarPolicy.RANDOM:
            # 50/50 șansă
            return "stop" if np.random.random() < 0.5 else "tp"
        else:
            return "stop"  # Default
    
    def finalize(self, final_price: float, final_bar: int) -> TradeResult:
        """Finalizează tranzacția la timeout."""
        if self.position_pct > 0:
            exit_price = self._apply_slippage_and_fees(final_price, is_entry=False)
            realized_return = self._calculate_return(exit_price, self.entry_price)
            
            self.realized_pnl += self.position_pct * realized_return
            
            return TradeResult(
                exit_price=exit_price,
                exit_bar=final_bar,
                exit_reason="timeout",
                realized_return=realized_return,
                max_drawdown=self.max_drawdown,
                bars_held=final_bar + 1,
                scale_out_details=self.trade_results
            )
        return None


# ==================== Engine Principal ====================

class MicroBacktestEngine:
    """Motor principal pentru micro-backtest."""
    
    def __init__(self, config: Optional[BacktestConfig] = None):
        self.config = config or BacktestConfig()
        self.results_cache: Dict[str, Dict[str, SimulationResult]] = {}
        
    def run_simulation(
        self,
        df: pd.DataFrame,
        side: Side,
        atr: float,
        params: BacktestParams,
        start_idx: int
    ) -> SimulationResult:
        """Rulează o simulare individuală."""
        cache_key = f"{side.value}_{params.param_id}_{start_idx}"
        if cache_key in self.results_cache.get(params.param_id, {}):
            return self.results_cache[params.param_id][cache_key]
        
        # Extrage datele pentru simulare
        sim_data = df.iloc[start_idx:start_idx + params.timeout_bars]
        if len(sim_data) < 5:  # Minim 5 bare
            return SimulationResult(score=-1e9)
        
        # Determină prețul de intrare
        if self.config.entry_mode == EntryMode.CLOSE:
            entry_price = sim_data.iloc[0]["close"]
        elif self.config.entry_mode == EntryMode.NEXT_OPEN:
            if start_idx + 1 < len(df):
                entry_price = df.iloc[start_idx + 1]["open"]
            else:
                entry_price = sim_data.iloc[0]["close"]
        else:
            entry_price = sim_data.iloc[0]["close"]
        
        # Aplică slippage și fee la intrare
        simulator = TradeSimulator(
            side=side,
            entry_price=entry_price,
            atr=atr,
            params=params,
            intrabar_policy=self.config.intrabar_policy,
            fee_bps=self.config.fee_bps,
            slippage_bps=self.config.slippage_bps
        )
        
        # Rulează simularea bar cu bar
        trade_results = []
        for i, (_, row) in enumerate(sim_data.iterrows()):
            finished, trade_result = simulator.simulate_bar(
                high=row["high"],
                low=row["low"],
                close=row["close"],
                bar_index=i
            )
            
            if trade_result:
                trade_results.append(trade_result)
            
            if finished:
                break
        
        # Finalizează dacă mai este poziție deschisă
        if simulator.position_pct > 0:
            final_trade = simulator.finalize(
                final_price=sim_data.iloc[-1]["close"],
                final_bar=len(sim_data) - 1
            )
            if final_trade:
                trade_results.append(final_trade)
        
        # Calculează statistici
        if trade_results:
            returns = [tr.realized_return for tr in trade_results]
            avg_return = np.mean(returns)
            win_rate = sum(1 for r in returns if r > 0) / len(returns)
            
            # Profit factor
            gross_profit = sum(r for r in returns if r > 0)
            gross_loss = abs(sum(r for r in returns if r < 0))
            profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
            
            # Max drawdown
            max_drawdown = min(tr.max_drawdown for tr in trade_results)
            
            # Scor compus
            if self.config.use_weighted_scoring:
                # Ponderează după numărul de bare (simulări mai lungi sunt mai relevante)
                weights = [tr.bars_held for tr in trade_results]
                weighted_return = _calculate_weighted_average(returns, weights)
                score = weighted_return - 0.75 * abs(max_drawdown)
            else:
                score = avg_return - 0.75 * abs(max_drawdown)
        else:
            avg_return = 0.0
            win_rate = 0.0
            profit_factor = 0.0
            max_drawdown = 0.0
            score = -1e9
        
        result = SimulationResult(
            score=score,
            trade_results=trade_results,
            avg_return=avg_return,
            win_rate=win_rate,
            profit_factor=profit_factor,
            max_drawdown=max_drawdown,
            total_trades=len(trade_results)
        )
        
        # Cache
        if params.param_id not in self.results_cache:
            self.results_cache[params.param_id] = {}
        self.results_cache[params.param_id][cache_key] = result
        
        return result
    
    def generate_param_sets(
        self,
        tactic_type: TacticType,
        base_stop_mult: float,
        base_tp_mult: float
    ) -> List[BacktestParams]:
        """Generează seturi de parametri pentru o tactică."""
        if tactic_type == TacticType.NONE:
            return []
        
        param_sets = []
        
        if tactic_type == TacticType.TREND_FOLLOW:
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="tf_aggro",
                    stop_atr_mult=max(2.0, base_stop_mult * 0.8),
                    tp_atr_mult=max(base_tp_mult * 1.2, 3.5),
                    timeout_bars=self.config.horizon_bars,
                    scale_out_levels=self.config.scale_out_levels if self.config.scale_out_enabled else []
                ),
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="tf_conservative",
                    stop_atr_mult=max(2.5, base_stop_mult * 1.2),
                    tp_atr_mult=max(base_tp_mult * 0.8, 3.0),
                    timeout_bars=self.config.horizon_bars,
                    scale_out_levels=self.config.scale_out_levels if self.config.scale_out_enabled else []
                )
            ]
        elif tactic_type == TacticType.RANGE_REVERSION:
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="rr_tight",
                    stop_atr_mult=min(2.0, base_stop_mult * 0.7),
                    tp_atr_mult=min(2.5, base_tp_mult * 0.6),
                    timeout_bars=self.config.horizon_bars
                ),
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="rr_wide",
                    stop_atr_mult=min(2.5, base_stop_mult * 0.9),
                    tp_atr_mult=min(3.0, base_tp_mult * 0.75),
                    timeout_bars=self.config.horizon_bars
                )
            ]
        elif tactic_type == TacticType.SCALP:
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="scalp_fast",
                    stop_atr_mult=min(1.5, base_stop_mult * 0.6),
                    tp_atr_mult=min(1.8, base_tp_mult * 0.45),
                    timeout_bars=max(10, self.config.horizon_bars // 3)
                )
            ]
        elif tactic_type == TacticType.GRID:
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="grid_wide",
                    stop_atr_mult=max(3.0, base_stop_mult * 1.2),
                    tp_atr_mult=min(2.5, base_tp_mult * 0.6),
                    timeout_bars=self.config.horizon_bars
                )
            ]
        elif tactic_type == TacticType.BREAKOUT:
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="breakout_aggro",
                    stop_atr_mult=max(2.0, base_stop_mult * 0.8),
                    tp_atr_mult=max(4.0, base_tp_mult * 1.0),
                    timeout_bars=self.config.horizon_bars
                )
            ]
        elif tactic_type == TacticType.HIGH_VOL_EVENT:
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="hvol_wide",
                    stop_atr_mult=max(3.0, base_stop_mult * 1.2),
                    tp_atr_mult=min(3.0, base_tp_mult * 0.75),
                    timeout_bars=self.config.horizon_bars
                )
            ]
        else:
            # Tactica generică
            param_sets = [
                BacktestParams(
                    tactic_type=tactic_type,
                    param_id="default",
                    stop_atr_mult=base_stop_mult,
                    tp_atr_mult=base_tp_mult,
                    timeout_bars=self.config.horizon_bars
                )
            ]
        
        return param_sets
    
    def evaluate_tactic(
        self,
        df: pd.DataFrame,
        side: Side,
        atr: float,
        tactic_type: TacticType,
        param_sets: Optional[List[BacktestParams]] = None
    ) -> TacticResult:
        """Evaluează o tactică cu multiple seturi de parametri."""
        # Generează seturi de parametri dacă nu sunt furnizate
        if param_sets is None:
            param_sets = self.generate_param_sets(
                tactic_type,
                self.config.default_stop_atr_mult,
                self.config.default_tp_atr_mult
            )
        
        if not param_sets:
            return TacticResult(
                tactic_type=tactic_type,
                best_params=BacktestParams(
                    tactic_type=tactic_type,
                    param_id="none",
                    stop_atr_mult=self.config.default_stop_atr_mult,
                    tp_atr_mult=self.config.default_tp_atr_mult,
                    timeout_bars=self.config.horizon_bars
                ),
                best_score=-1e9
            )
        
        # Generează puncte de intrare (ferestre)
        windows = min(self.config.windows, len(df) - self.config.horizon_bars - 1)
        if windows <= 0:
            return TacticResult(
                tactic_type=tactic_type,
                best_params=param_sets[0],
                best_score=-1e9
            )
        
        step = max(1, int(self.config.horizon_bars // 3))
        entry_indices = []
        for i in range(windows):
            idx = -(self.config.horizon_bars + 1 + i * step)
            if abs(idx) < len(df):
                entry_indices.append(idx)
        
        # Evaluează fiecare set de parametri
        best_score = -1e9
        best_params = param_sets[0]
        all_scores = {}
        sim_results = {}
        
        for params in param_sets:
            if params.param_id in self.results_cache:
                # Folosește rezultatele din cache dacă sunt disponibile
                cached_results = list(self.results_cache[params.param_id].values())
                if cached_results:
                    scores = [r.score for r in cached_results]
                    avg_score = np.mean(scores) if scores else -1e9
                else:
                    avg_score = -1e9
            else:
                # Rulează simulările
                scores = []
                param_sim_results = []
                
                for start_idx in entry_indices:
                    result = self.run_simulation(df, side, atr, params, start_idx)
                    scores.append(result.score)
                    param_sim_results.append(result)
                
                avg_score = np.mean(scores) if scores else -1e9
                sim_results[params.param_id] = SimulationResult(
                    score=avg_score,
                    trade_results=[]  # Pentru simplitate, nu stocăm toate tranzacțiile aici
                )
            
            all_scores[params.param_id] = avg_score
            
            if avg_score > best_score:
                best_score = avg_score
                best_params = params
        
        # Calculează statistici
        if all_scores:
            scores_list = list(all_scores.values())
            mean_score = np.mean(scores_list)
            std_score = np.std(scores_list) if len(scores_list) > 1 else 0.0
            confidence = 1.0 - (std_score / (abs(mean_score) + 1e-9))
            confidence = _clamp(confidence, 0.0, 1.0)
        else:
            confidence = 0.0
        
        return TacticResult(
            tactic_type=tactic_type,
            best_params=best_params,
            best_score=best_score,
            all_scores=all_scores,
            simulation_results=sim_results,
            confidence=confidence,
            statistics={
                "mean_score": mean_score if 'mean_score' in locals() else 0.0,
                "std_score": std_score if 'std_score' in locals() else 0.0,
                "num_windows": len(entry_indices)
            }
        )
    
    def run(
        self,
        df: pd.DataFrame,
        side: Union[str, Side],
        atr: float,
        tactics: Optional[List[Union[str, TacticType]]] = None,
        param_sets_override: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        score_hook: Optional[Callable] = None
    ) -> MicroBacktestResult:
        """Rulează micro-backtest-ul complet."""
        # Validare
        if not self.config.enabled:
            return MicroBacktestResult(
                enabled=False,
                reason="disabled",
                bars_used=0,
                horizon=self.config.horizon_bars
            )
        
        # Verifică date
        required_cols = ["open", "high", "low", "close"]
        if not all(col in df.columns for col in required_cols):
            return MicroBacktestResult(
                enabled=False,
                reason="missing_columns",
                bars_used=0,
                horizon=self.config.horizon_bars
            )
        
        if len(df) < max(self.config.require_min_bars, self.config.horizon_bars + 10):
            return MicroBacktestResult(
                enabled=False,
                reason="insufficient_data",
                bars_used=len(df),
                horizon=self.config.horizon_bars
            )
        
        # Convert side
        if isinstance(side, str):
            side = Side.from_string(side)
        
        # Determină tactici de testat
        if tactics is None:
            tactic_types = TacticType.default_tactics()
        else:
            tactic_types = []
            for t in tactics:
                if isinstance(t, str):
                    try:
                        tactic_types.append(TacticType(t))
                    except ValueError:
                        warnings.warn(f"Unknown tactic: {t}, skipping")
                elif isinstance(t, TacticType):
                    tactic_types.append(t)
        
        # Limită numărul de tactici
        tactic_types = tactic_types[:self.config.max_tactics]
        
        # Pregătește date
        df_slice = df.iloc[-self.config.bars:].copy()
        
        # Rulare
        start_time = time.time()
        tactic_results = {}
        best_overall_score = -1e9
        best_overall_tactic = TacticType.NONE
        best_overall_params = None
        
        for tactic_type in tactic_types:
            # Verifică bugetul de timp
            elapsed_ms = (time.time() - start_time) * 1000
            if elapsed_ms > self.config.budget_ms:
                break
            
            # Salt tacticile "none"
            if tactic_type == TacticType.NONE:
                tactic_results[tactic_type.value] = TacticResult(
                    tactic_type=tactic_type,
                    best_params=BacktestParams(
                        tactic_type=tactic_type,
                        param_id="none",
                        stop_atr_mult=0.0,
                        tp_atr_mult=0.0,
                        timeout_bars=0
                    ),
                    best_score=-1e9
                )
                continue
            
            # Obține seturile de parametri (override > default)
            param_sets = None
            if param_sets_override and tactic_type.value in param_sets_override:
                try:
                    param_dicts = param_sets_override[tactic_type.value]
                    param_sets = []
                    for p_dict in param_dicts:
                        params = BacktestParams(
                            tactic_type=tactic_type,
                            param_id=str(p_dict.get("id", "override")),
                            stop_atr_mult=_safe_float(p_dict.get("stop_atr_mult"), 
                                                    self.config.default_stop_atr_mult),
                            tp_atr_mult=_safe_float(p_dict.get("tp_atr_mult"),
                                                  self.config.default_tp_atr_mult),
                            timeout_bars=self.config.horizon_bars
                        )
                        param_sets.append(params)
                except Exception as e:
                    warnings.warn(f"Failed to parse param sets for {tactic_type}: {e}")
            
            # Evaluează tactica
            result = self.evaluate_tactic(
                df=df_slice,
                side=side,
                atr=atr,
                tactic_type=tactic_type,
                param_sets=param_sets
            )
            
            # Hook pentru scoring (pentru învățare online)
            if score_hook and callable(score_hook):
                try:
                    score_hook(
                        tactic=tactic_type.value,
                        param_id=result.best_params.param_id,
                        score=result.best_score,
                        params=asdict(result.best_params)
                    )
                except Exception as e:
                    warnings.warn(f"Score hook failed: {e}")
            
            tactic_results[tactic_type.value] = result
            
            # Actualizează cel mai bun overall
            if result.best_score > best_overall_score:
                best_overall_score = result.best_score
                best_overall_tactic = tactic_type
                best_overall_params = result.best_params
        
        # Calculează încrederea (diferența între primul și al doilea)
        valid_results = [
            (t, r) for t, r in tactic_results.items() 
            if r.best_score > -1e8 and t != TacticType.NONE.value
        ]
        
        if len(valid_results) >= 2:
            sorted_results = sorted(valid_results, key=lambda x: x[1].best_score, reverse=True)
            best_score = sorted_results[0][1].best_score
            second_score = sorted_results[1][1].best_score
            confidence = (best_score - second_score) / (abs(best_score) + 1e-9)
            confidence = _clamp(confidence, 0.0, 1.0)
        else:
            confidence = 0.0
        
        # Pregătește metadate
        elapsed_ms = (time.time() - start_time) * 1000
        meta = {
            "execution_time_ms": elapsed_ms,
            "tactics_evaluated": len(tactic_results),
            "data_points": len(df_slice),
            "config": asdict(self.config),
            "timestamp": time.time()
        }
        
        # Statistici de execuție
        exec_stats = {
            "total_simulations": sum(
                len(r.all_scores) * r.statistics.get("num_windows", 1)
                for r in tactic_results.values()
            ),
            "cache_hits": sum(
                len(r.simulation_results) 
                for r in tactic_results.values() 
                if r.simulation_results
            )
        }
        
        return MicroBacktestResult(
            enabled=True,
            tactic_results=tactic_results,
            best_tactic=best_overall_tactic,
            best_score=best_overall_score,
            best_params=best_overall_params or BacktestParams(
                tactic_type=TacticType.NONE,
                param_id="none",
                stop_atr_mult=0.0,
                tp_atr_mult=0.0,
                timeout_bars=0
            ),
            reason="completed",
            bars_used=len(df_slice),
            horizon=self.config.horizon_bars,
            confidence=confidence,
            meta=meta,
            execution_stats=exec_stats
        )


# ==================== Wrapper pentru Compatibilitate ====================

def micro_backtest(
    df: pd.DataFrame,
    side: str,
    atr_val: float,
    signal_strength: float,
    cfg: Dict[str, Any],
    *,
    tactics: Optional[List[str]] = None,
    param_sets_override: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    score_hook: Optional[Callable] = None,
) -> MicroBacktestResult:
    """
    Fast micro-backtest on recent bars. Designed to be lightweight and safe.
    Wrapper around the new engine for backward compatibility.
    """
    # Extrage configurația
    bt_cfg = (cfg.get("decision_factor") or {}).get("backtest") or {}
    
    # Creează configurația pentru engine
    config = BacktestConfig(
        enabled=bool(bt_cfg.get("enabled", False)),
        bars=int(bt_cfg.get("bars", 600)),
        horizon_bars=int(bt_cfg.get("horizon_bars", 60)),
        max_tactics=int(bt_cfg.get("max_tactics", 6)),
        windows=int(bt_cfg.get("windows", 3)),
        min_signal_strength=_safe_float(bt_cfg.get("min_signal_strength", 1.3)),
        intrabar_policy=IntrabarPolicy.from_string(str(bt_cfg.get("intrabar_policy", "worst"))),
        entry_mode=EntryMode.from_string(str(bt_cfg.get("entry_mode", "close"))),
        budget_ms=_safe_float(bt_cfg.get("budget_ms", 50.0)),
        fee_bps=_safe_float(bt_cfg.get("fee_bps", 8.0)),
        slippage_bps=_safe_float(bt_cfg.get("slippage_bps", 4.0)),
        default_stop_atr_mult=_safe_float(bt_cfg.get("default_stop_atr_mult", 2.5)),
        default_tp_atr_mult=_safe_float(bt_cfg.get("default_tp_atr_mult", 4.0)),
        require_min_bars=50
    )
    
    # Verifică dacă este enabled
    if not config.enabled:
        return MicroBacktestResult(
            enabled=False,
            reason="disabled",
            bars_used=0,
            horizon=config.horizon_bars
        )
    
    # Verifică signal strength
    if signal_strength < config.min_signal_strength:
        return MicroBacktestResult(
            enabled=False,
            reason="signal_below_threshold",
            bars_used=0,
            horizon=config.horizon_bars
        )
    
    # Setup scale-out dacă este configurat
    base_risk = cfg.get("risk") or {}
    scale_cfg = base_risk.get("scale_out") or {}
    if bool(scale_cfg.get("enabled", False)):
        config.scale_out_enabled = True
        config.scale_out_levels = [
            ScaleOutLevel(
                atr_multiplier=_safe_float(scale_cfg.get("tp1_atr_mult", 2.0)),
                percentage=_safe_float(scale_cfg.get("tp1_pct", 0.25))
            ),
            ScaleOutLevel(
                atr_multiplier=_safe_float(scale_cfg.get("tp2_atr_mult", 3.0)),
                percentage=_safe_float(scale_cfg.get("tp2_pct", 0.25))
            ),
            ScaleOutLevel(
                atr_multiplier=_safe_float(scale_cfg.get("tp3_atr_mult", 4.0)),
                percentage=_safe_float(scale_cfg.get("tp3_pct", 0.50))
            )
        ]
    
    # Creează și rulează engine-ul
    engine = MicroBacktestEngine(config=config)
    
    # Convert tactics
    tactic_types = None
    if tactics:
        tactic_types = []
        for t in tactics:
            try:
                tactic_types.append(TacticType(t))
            except ValueError:
                # Tactica veche, convertește
                if t == "trend_follow":
                    tactic_types.append(TacticType.TREND_FOLLOW)
                elif t == "range_reversion":
                    tactic_types.append(TacticType.RANGE_REVERSION)
                elif t == "scalp":
                    tactic_types.append(TacticType.SCALP)
                elif t == "grid":
                    tactic_types.append(TacticType.GRID)
                elif t == "breakout":
                    tactic_types.append(TacticType.BREAKOUT)
                elif t == "high_vol_event":
                    tactic_types.append(TacticType.HIGH_VOL_EVENT)
                elif t == "none":
                    tactic_types.append(TacticType.NONE)
    
    result = engine.run(
        df=df,
        side=side,
        atr=atr_val,
        tactics=tactic_types,
        param_sets_override=param_sets_override,
        score_hook=score_hook
    )
    
    return result


# ==================== Test și Exemplu ====================

if __name__ == "__main__":
    # Exemplu de utilizare
    print("=== Micro Backtest Engine Demo ===")
    
    # Creează date de test
    np.random.seed(42)
    n_bars = 1000
    dates = pd.date_range(start="2023-01-01", periods=n_bars, freq="1H")
    
    # Prețuri sintetice
    prices = 100 + np.cumsum(np.random.randn(n_bars) * 0.5)
    
    df = pd.DataFrame({
        "open": prices + np.random.randn(n_bars) * 0.1,
        "high": prices + np.abs(np.random.randn(n_bars) * 0.2),
        "low": prices - np.abs(np.random.randn(n_bars) * 0.2),
        "close": prices,
        "volume": np.random.randint(100, 1000, n_bars)
    }, index=dates)
    
    # Configurație
    config = BacktestConfig(
        bars=500,
        horizon_bars=50,
        windows=3,
        budget_ms=100.0
    )
    
    # Creează engine
    engine = MicroBacktestEngine(config)
    
    # Rulează backtest
    result = engine.run(
        df=df,
        side="long",
        atr=1.5,  # ATR aproximativ
        tactics=[TacticType.TREND_FOLLOW, TacticType.RANGE_REVERSION]
    )
    
    # Afișează rezultate
    print(f"Backtest completed: {result.enabled}")
    print(f"Best tactic: {result.best_tactic.value}")
    print(f"Best score: {result.best_score:.4f}")
    print(f"Confidence: {result.confidence:.2%}")
    print(f"Execution time: {result.meta.get('execution_time_ms', 0):.1f} ms")
    
    if result.tactic_results:
        print("\nTactic scores:")
        for tactic_name, tactic_result in result.tactic_results.items():
            print(f"  {tactic_name}: {tactic_result.best_score:.4f} "
                  f"(confidence: {tactic_result.confidence:.2%})")
from __future__ import annotations

import smtplib
import ssl
import time
import hashlib
from email.message import EmailMessage
from typing import Any, Dict, Optional, Tuple, List
import urllib.request
import urllib.parse


def _s(x: Any, d: str = "") -> str:
    try:
        if x is None:
            return d
        return str(x)
    except Exception:
        return d


def _as_bool(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    return str(x).strip().lower() in ("1", "true", "yes", "y", "on")


class Notifier:
    """
    Notifier with Telegram + Email.

    Improvements vs minimal version:
      - dedupe + per-message TTL (avoid spam)
      - global rate limit (messages/min) fail-safe
      - retries with backoff for transient failures
      - timeouts configurable
      - telegram multi chat_id support
      - severity routing (INFO/WARN/CRITICAL)
    """

    def __init__(self, cfg: dict, log: Any):
        self.cfg = (cfg.get("notifier", {}) or {}) if isinstance(cfg, dict) else {}
        self.enabled = bool(self.cfg.get("enabled", False))
        self.log = log

        # controls
        self.dedupe_ttl_sec = float(self.cfg.get("dedupe_ttl_sec", 45.0) or 45.0)
        self.max_per_minute = int(self.cfg.get("max_per_minute", 12) or 12)
        self.http_timeout_sec = float(self.cfg.get("http_timeout_sec", 10.0) or 10.0)
        self.smtp_timeout_sec = float(self.cfg.get("smtp_timeout_sec", 15.0) or 15.0)

        # routing
        # Example:
        # routes:
        #   telegram: ["INFO","WARN","CRITICAL"]
        #   email: ["CRITICAL"]
        routes = self.cfg.get("routes", {}) or {}
        self.route_tg = set([_s(x).upper() for x in (routes.get("telegram") or ["INFO", "WARN", "CRITICAL"])])
        self.route_email = set([_s(x).upper() for x in (routes.get("email") or ["CRITICAL"])])

        # runtime: dedupe + rate tracking
        self._dedupe: Dict[str, float] = {}     # key -> last_ts
        self._window: List[float] = []          # timestamps of sent events

    # -----------------------
    # logging helpers
    # -----------------------
    def _log_warn(self, msg: str) -> None:
        try:
            if hasattr(self.log, "warning") and callable(getattr(self.log, "warning")):
                self.log.warning(msg)
            elif hasattr(self.log, "warn") and callable(getattr(self.log, "warn")):
                self.log.warn(msg)  # legacy
            elif hasattr(self.log, "info") and callable(getattr(self.log, "info")):
                self.log.info(msg)
        except Exception:
            pass

    def _log_info(self, msg: str) -> None:
        try:
            if hasattr(self.log, "info") and callable(getattr(self.log, "info")):
                self.log.info(msg)
        except Exception:
            pass

    # -----------------------
    # guards
    # -----------------------
    def _norm_kind(self, kind: str) -> str:
        k = _s(kind, "INFO").strip().upper()
        if k in ("DEBUG", "INFO", "WARN", "WARNING", "ERROR", "CRITICAL", "ALERT"):
            return "WARN" if k == "WARNING" else k
        return "INFO"

    def _hash_key(self, kind: str, text: str) -> str:
        h = hashlib.sha1()
        h.update((kind + "|" + text).encode("utf-8", errors="ignore"))
        return h.hexdigest()

    def _dedupe_ok(self, kind: str, text: str) -> bool:
        if self.dedupe_ttl_sec <= 0:
            return True
        now = time.time()
        key = self._hash_key(kind, text)
        last = float(self._dedupe.get(key, 0.0))
        if (now - last) < float(self.dedupe_ttl_sec):
            return False
        self._dedupe[key] = now
        # small cleanup
        if len(self._dedupe) > 5000:
            cutoff = now - float(self.dedupe_ttl_sec) * 3.0
            for k, ts in list(self._dedupe.items()):
                if float(ts) < cutoff:
                    self._dedupe.pop(k, None)
        return True

    def _rate_ok(self) -> bool:
        if self.max_per_minute <= 0:
            return True
        now = time.time()
        cutoff = now - 60.0
        self._window = [t for t in self._window if t >= cutoff]
        if len(self._window) >= int(self.max_per_minute):
            return False
        self._window.append(now)
        return True

    def _sanitize_text(self, text: str, limit: int = 3500) -> str:
        t = _s(text, "")
        t = t.replace("\r\n", "\n").strip()
        if len(t) > limit:
            t = t[: limit - 20] + "\n...(truncated)..."
        return t

    # -----------------------
    # Telegram
    # -----------------------
    def _tg_chat_ids(self, raw: Any) -> List[str]:
        if raw is None:
            return []
        if isinstance(raw, (list, tuple)):
            return [str(x).strip() for x in raw if str(x).strip()]
        s = str(raw).strip()
        if not s:
            return []
        # allow comma-separated
        if "," in s:
            return [x.strip() for x in s.split(",") if x.strip()]
        return [s]

    def _tg_send_once(self, token: str, chat_id: str, text: str) -> None:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        urllib.request.urlopen(req, timeout=float(self.http_timeout_sec)).read()

    def _tg(self, kind: str, text: str) -> None:
        tg = self.cfg.get("telegram", {}) or {}
        if not (self.enabled and _as_bool(tg.get("enabled", False))):
            return

        token = _s(tg.get("bot_token", "")).strip()
        chat_ids = self._tg_chat_ids(tg.get("chat_id", ""))
        if not token or not chat_ids:
            return

        payload = self._sanitize_text(f"[{kind}] {text}")

        # retries with backoff (small)
        for chat_id in chat_ids:
            last_err: Optional[Exception] = None
            for attempt in range(2):
                try:
                    self._tg_send_once(token, chat_id, payload)
                    last_err = None
                    break
                except Exception as e:
                    last_err = e
                    time.sleep(0.25 + 0.35 * attempt)
            if last_err is not None:
                self._log_warn(f"Notifier TG failed (chat_id={chat_id}): {type(last_err).__name__}: {last_err}")

    # -----------------------
    # Email
    # -----------------------
    def _email(self, kind: str, subject: str, text: str) -> None:
        em = self.cfg.get("email", {}) or {}
        if not (self.enabled and _as_bool(em.get("enabled", False))):
            return

        host = _s(em.get("smtp_host", "")).strip()
        port = int(em.get("smtp_port", 587) or 587)
        user = _s(em.get("username", "")).strip()
        pwd = _s(em.get("password", "")).strip()
        to_raw = em.get("to", "")
        use_tls = _as_bool(em.get("use_tls", True))

        # allow multi recipients
        tos = []
        if isinstance(to_raw, (list, tuple)):
            tos = [str(x).strip() for x in to_raw if str(x).strip()]
        else:
            s = _s(to_raw).strip()
            if s:
                tos = [x.strip() for x in s.split(",") if x.strip()]

        if not host or not user or not pwd or not tos:
            return

        msg = EmailMessage()
        msg["From"] = user
        msg["To"] = ", ".join(tos)
        msg["Subject"] = subject
        msg.set_content(self._sanitize_text(text, limit=50_000))

        last_err: Optional[Exception] = None
        for attempt in range(2):
            try:
                if use_tls:
                    context = ssl.create_default_context()
                    with smtplib.SMTP(host, port, timeout=float(self.smtp_timeout_sec)) as s:
                        s.starttls(context=context)
                        s.login(user, pwd)
                        s.send_message(msg)
                else:
                    with smtplib.SMTP(host, port, timeout=float(self.smtp_timeout_sec)) as s:
                        s.login(user, pwd)
                        s.send_message(msg)
                last_err = None
                break
            except Exception as e:
                last_err = e
                time.sleep(0.35 + 0.5 * attempt)

        if last_err is not None:
            self._log_warn(f"Notifier email failed: {type(last_err).__name__}: {last_err}")

    # -----------------------
    # Public
    # -----------------------
    def notify(self, kind: str, text: str) -> None:
        """
        kind is treated as severity/routing:
          - INFO/WARN/CRITICAL (recommended)
        """
        if not self.enabled:
            return

        k = self._norm_kind(kind)
        msg = self._sanitize_text(text)

        # fail-safe throttles
        if not self._rate_ok():
            return
        if not self._dedupe_ok(k, msg):
            return

        try:
            if k in self.route_tg:
                self._tg(k, msg)
        except Exception:
            pass

        try:
            if k in self.route_email:
                self._email(kind=k, subject=f"Bot alert: {k}", text=msg)
        except Exception:
            pass

# app/ai_brain.py
from __future__ import annotations

import time
import math
import uuid
import threading
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple


@dataclass
class BrainDecision:
    allow_entries: bool = True
    score_mult: float = 1.0   # multiplies signal strength
    risk_mult: float = 1.0    # multiplies sizing (qty notional)
    reasons: List[str] = field(default_factory=list)

    # Extensions (non-breaking for consumers that ignore extra keys)
    decision_id: str = ""
    confidence: float = 1.0           # 0..1
    tags: List[str] = field(default_factory=list)
    risk_off: bool = False
    cooldown_s: float = 0.0
    next_allowed_ts: float = 0.0      # epoch seconds

    def to_dict(self) -> Dict[str, Any]:
        return {
            "allow_entries": bool(self.allow_entries),
            "score_mult": float(self.score_mult),
            "risk_mult": float(self.risk_mult),
            "reasons": list(self.reasons or []),
            "decision_id": str(self.decision_id or ""),
            "confidence": float(self.confidence),
            "tags": list(self.tags or []),
            "risk_off": bool(self.risk_off),
            "cooldown_s": float(self.cooldown_s),
            "next_allowed_ts": float(self.next_allowed_ts),
        }


class AIBrain:
    """
    Policy layer (real-time): combines regime/spread/funding/drawdown gates and returns adjustments.
    It does NOT do online learning; that's autonomy.py territory.

    Additions in this version:
      - effective cooldown enforcement (per-symbol or GLOBAL)
      - optional free-equity gate
      - defensive config reads + pruning of cooldown maps
      - smoother regime scaling using regime_strength
      - clearer funding logic and messages
      - thread-safe operations
      - enhanced metrics collection
    """

    def __init__(self, cfg: dict, log: Any = None, store: Any = None):
        self.cfg = cfg or {}
        self.log = log
        self.store = store

        # Thread safety
        self._lock = threading.RLock()

        # Risk-off state with hysteresis (per-symbol optional)
        # structure: { "GLOBAL": {"active": bool, "until_ts": float}, "BTC/USDT": {...} }
        self._riskoff_state: Dict[str, Dict[str, Any]] = {}

        # Cooldowns (hard blocks) - enforced
        # structure: { "GLOBAL": until_ts, "BTC/USDT": until_ts }
        self._cooldown_until: Dict[str, float] = {}

        # Maintenance timestamps (avoid pruning every call)
        self._last_prune_ts: float = 0.0

        # Metrics and statistics
        self._decision_count: int = 0
        self._block_stats: Dict[str, int] = {}
        self._last_reset_ts: float = time.time()

    # ---------------------------
    # Utilities
    # ---------------------------
    def _get(self, path: str, default):
        cur = self.cfg
        for k in path.split("."):
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur

    def _get_sym(self, symbol: str, path: str, default):
        """
        Per-symbol overrides:
          ai_brain.overrides.<SYMBOL>.<path>
        Falls back to ai_brain.<path>
        """
        sym = (symbol or "").upper()
        ov = self._get(f"ai_brain.overrides.{sym}.{path}", None)
        if ov is not None:
            return ov
        return self._get(f"ai_brain.{path}", default)

    @staticmethod
    def _clamp(x: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, x))

    @staticmethod
    def _safe_float(x, default: float = 0.0) -> float:
        try:
            if x is None:
                return default
            v = float(x)
            if math.isnan(v) or math.isinf(v):
                return default
            return v
        except Exception:
            return default

    @staticmethod
    def _safe_int(x, default: int = 0) -> int:
        try:
            if x is None:
                return default
            return int(x)
        except Exception:
            return default

    @staticmethod
    def _safe_bool(x, default: bool = False) -> bool:
        if x is None:
            return default
        if isinstance(x, bool):
            return x
        try:
            return str(x).strip().lower() in ("1", "true", "yes", "y", "on")
        except Exception:
            return default

    @staticmethod
    def _now() -> float:
        return time.time()

    def _log(self, level: str, msg: str) -> None:
        if not self.log:
            return
        try:
            fn = getattr(self.log, level, None)
            if callable(fn):
                fn(msg)
            else:
                self.log.info(msg)
        except Exception:
            pass

    def _store_decision(self, symbol: str, payload: Dict[str, Any]) -> None:
        if not self.store:
            return
        if not self._safe_bool(self._get("ai_brain.store_decisions", False), False):
            return
        try:
            self.store.decision(
                decision_type="ai_brain",
                symbol=symbol,
                component="ai_brain",
                payload=payload,
            )
        except AttributeError:
            # Store doesn't have decision method
            self._log("warning", "Store object doesn't have 'decision' method")
        except Exception as e:
            self._log("error", f"Failed to store decision: {str(e)}")

    def _validate_context(self, context: Dict[str, Any]) -> None:
        """Optional runtime validation for context structure."""
        if not self._safe_bool(self._get("ai_brain.validate_context", False), False):
            return
            
        expected_types = {
            'symbol': str,
            'side': str,
            'signal_strength': (int, float, type(None)),
            'regime': (str, type(None)),
            'regime_strength': (int, float, type(None)),
            'spread_bps': (int, float, type(None)),
            'funding_rate': (int, float, type(None)),
            'atr_pct': (int, float, type(None)),
            'equity': (int, float, type(None)),
            'free_equity': (int, float, type(None)),
            'max_drawdown': (int, float, type(None)),
            'loss_streak': (int, type(None)),
            'open_positions_count': (int, type(None))
        }
        
        for key, expected in expected_types.items():
            if key in context:
                value = context[key]
                if value is not None and not isinstance(value, expected):
                    self._log("warning", 
                             f"Context field {key} has unexpected type: "
                             f"{type(value).__name__}, expected {expected}")

    # ---------------------------
    # Maintenance / pruning
    # ---------------------------
    def _prune(self) -> None:
        """Remove expired cooldown/riskoff entries occasionally."""
        with self._lock:
            now = self._now()
            # prune at most once per 10 seconds
            if (now - self._last_prune_ts) < 10.0:
                return
            self._last_prune_ts = now

            # Use list comprehension for cleaner cooldown pruning
            expired_cooldowns = [k for k, v in self._cooldown_until.items() 
                               if self._safe_float(v, 0.0) <= 0 or now >= v]
            for k in expired_cooldowns:
                self._cooldown_until.pop(k, None)

            # Prune riskoff (remove entire entry when expired)
            expired_riskoff = []
            for k, st in self._riskoff_state.items():
                until_ts = self._safe_float(st.get("until_ts"), 0.0)
                if until_ts > 0 and now >= until_ts:
                    expired_riskoff.append(k)
            
            for k in expired_riskoff:
                self._riskoff_state.pop(k, None)

    # ---------------------------
    # Cooldown enforcement
    # ---------------------------
    def _cooldown_key(self, symbol: str) -> str:
        per_symbol = self._safe_bool(self._get("ai_brain.cooldown.per_symbol", False), False)
        return (symbol or "").upper() if per_symbol else "GLOBAL"

    def _cooldown_active(self, symbol: str) -> Tuple[bool, float]:
        with self._lock:
            key = self._cooldown_key(symbol)
            until = self._safe_float(self._cooldown_until.get(key), 0.0)
            now = self._now()
            if until > now:
                return True, max(0.0, until - now)
            return False, 0.0

    def _set_cooldown(self, symbol: str, seconds: float) -> None:
        with self._lock:
            s = float(max(0.0, seconds or 0.0))
            if s <= 0:
                return
            key = self._cooldown_key(symbol)
            self._cooldown_until[key] = self._now() + s

    # ---------------------------
    # Risk-off hysteresis
    # ---------------------------
    def _riskoff_key(self, symbol: str) -> str:
        per_symbol = self._safe_bool(self._get("ai_brain.riskoff.per_symbol", False), False)
        return (symbol or "").upper() if per_symbol else "GLOBAL"

    def _is_riskoff_active(self, symbol: str) -> bool:
        with self._lock:
            key = self._riskoff_key(symbol)
            st = self._riskoff_state.get(key) or {}
            if not st:
                return False
            active = self._safe_bool(st.get("active", False), False)
            until_ts = self._safe_float(st.get("until_ts"), 0.0)
            if until_ts > 0 and self._now() > until_ts:
                # Expired, remove entry
                self._riskoff_state.pop(key, None)
                return False
            return active

    def _set_riskoff(self, symbol: str, active: bool, ttl_s: float = 0.0) -> None:
        with self._lock:
            key = self._riskoff_key(symbol)
            st = self._riskoff_state.get(key) or {}
            st["active"] = bool(active)
            if active and ttl_s and ttl_s > 0:
                st["until_ts"] = self._now() + float(ttl_s)
            else:
                st["until_ts"] = 0.0
            self._riskoff_state[key] = st

    # ---------------------------
    # Core decision helpers
    # ---------------------------
    @staticmethod
    def _normalize_regime(regime: str) -> str:
        r = (regime or "na").strip().lower().replace("-", "_")
        aliases = {
            "trend": "trend_up",
            "trending": "trend_up",
            "highvol": "high_vol",
            "lowvol": "low_vol",
        }
        return aliases.get(r, r)

    def _funding_is_unfavorable(self, funding: float, side: str, convention: str) -> bool:
        """
        Returns True if YOU would pay funding on that side (unfavorable).
        convention:
          - typical: funding>0 => longs pay shorts
          - invert:  funding>0 => shorts pay longs
        """
        s = (side or "").lower()
        conv = (convention or "typical").strip().lower()
        f = float(funding)
        if conv == "invert":
            f = -f
        # typical: f>0 => long pays; f<0 => short pays
        return (f > 0 and s == "long") or (f < 0 and s == "short")

    def _spread_max_bps(self, symbol: str, atr_pct: Optional[float]) -> float:
        """
        Supports either:
          - fixed max bps: ai_brain.spread_max_bps (legacy)
          - new nested config: ai_brain.spread.max_bps + optional adaptive max using ATR%
        """
        legacy = self._get_sym(symbol, "spread_max_bps", None)
        if legacy is not None:
            return self._safe_float(legacy, 25.0)

        fixed = self._safe_float(self._get_sym(symbol, "spread.max_bps", 25.0), 25.0)
        adaptive_enabled = self._safe_bool(self._get_sym(symbol, "spread.adaptive.enabled", False), False)
        if not adaptive_enabled:
            return fixed

        base_bps = self._safe_float(self._get_sym(symbol, "spread.adaptive.base_bps", fixed), fixed)
        k_atr = self._safe_float(self._get_sym(symbol, "spread.adaptive.k_atr", 1.5), 1.5)
        cap_bps = self._safe_float(self._get_sym(symbol, "spread.adaptive.cap_bps", 80.0), 80.0)

        ap = self._safe_float(atr_pct, 0.0)
        atr_bps = ap * 10_000.0
        max_spread = base_bps + k_atr * atr_bps
        return float(self._clamp(max_spread, 1.0, cap_bps))

    # ---------------------------
    # Public API
    # ---------------------------
    def decide_obj(self, context: Dict[str, Any]) -> BrainDecision:
        """
        context (best-effort):
          symbol, side, signal_strength, tf,
          regime, regime_strength,
          spread_bps,
          funding_rate,
          atr_pct,
          equity, free_equity,
          max_drawdown, loss_streak,
          open_positions_count
        """
        # Optional validation
        self._validate_context(context)
        
        with self._lock:
            # Update decision counter
            self._decision_count += 1
            
            self._prune()

            c = context or {}
            reasons: List[str] = []
            tags: List[str] = []

            enabled = self._safe_bool(self._get("ai_brain.enabled", True), True)
            decision_id = str(uuid.uuid4())

            if not enabled:
                return BrainDecision(
                    allow_entries=True,
                    score_mult=1.0,
                    risk_mult=1.0,
                    reasons=["INFO: ai_brain disabled"],
                    decision_id=decision_id,
                    confidence=1.0,
                    tags=["ai_brain_disabled"],
                )

            symbol = (c.get("symbol") or "").upper()
            side = (c.get("side") or "na").lower().strip()

            sig = self._safe_float(c.get("signal_strength"), 0.0)
            regime = self._normalize_regime(c.get("regime") or "na")
            reg_strength = self._clamp(self._safe_float(c.get("regime_strength"), 0.0), 0.0, 1.0)

            spread_bps = c.get("spread_bps")
            spread_bps = self._safe_float(spread_bps, -1.0) if spread_bps is not None else None

            funding = c.get("funding_rate")
            funding = self._safe_float(funding, 0.0) if funding is not None else None

            atr_pct = c.get("atr_pct")
            atr_pct = self._safe_float(atr_pct, 0.0) if atr_pct is not None else None

            equity = self._safe_float(c.get("equity"), 0.0)
            free_eq = self._safe_float(c.get("free_equity"), 0.0)

            dd = self._clamp(self._safe_float(c.get("max_drawdown"), 0.0), 0.0, 0.99)
            loss_streak = self._safe_int(c.get("loss_streak"), 0)
            open_pos_n = self._safe_int(c.get("open_positions_count"), 0)

            # Defaults
            score_mult = 1.0
            risk_mult = 1.0
            allow = True
            confidence = 1.0
            cooldown_s = 0.0
            next_allowed_ts = 0.0
            risk_off = False

            # -----------------------
            # 0) Enforce cooldown (hard block)
            cd_on, cd_left = self._cooldown_active(symbol)
            if cd_on:
                allow = False
                cooldown_s = float(cd_left)
                next_allowed_ts = self._now() + cooldown_s
                reasons.append(f"BLOCK: cooldown active ({cooldown_s:.1f}s left)")
                tags.append("block_cooldown")
                confidence *= 0.35
                self._block_stats["cooldown"] = self._block_stats.get("cooldown", 0) + 1

            # -----------------------
            # 1) Hard gate: max open positions
            if allow:
                max_pos = self._safe_int(self._get_sym(symbol, "max_open_positions", 8), 8)
                if open_pos_n >= max_pos:
                    allow = False
                    reasons.append(f"BLOCK: max_open_positions reached ({open_pos_n}/{max_pos})")
                    tags.append("block_max_positions")
                    self._block_stats["max_positions"] = self._block_stats.get("max_positions", 0) + 1

            # -----------------------
            # 2) Optional gate: min free equity %
            if allow:
                min_free_pct = self._safe_float(self._get_sym(symbol, "min_free_equity_pct", 0.0), 0.0)
                if min_free_pct > 0.0 and equity > 0:
                    free_pct = free_eq / max(1e-12, equity)
                    if free_pct < min_free_pct:
                        allow = False
                        reasons.append(f"BLOCK: low free equity ({free_pct:.2%} < {min_free_pct:.2%})")
                        tags.append("block_free_equity")
                        self._block_stats["free_equity"] = self._block_stats.get("free_equity", 0) + 1

            # -----------------------
            # 3) Spread gate (optional adaptive via ATR%)
            if allow and spread_bps is not None and spread_bps >= 0:
                max_spread = self._spread_max_bps(symbol, atr_pct)
                if spread_bps > max_spread:
                    allow = False
                    reasons.append(f"BLOCK: spread too high ({spread_bps:.1f} bps > {max_spread:.1f})")
                    tags.append("block_spread")
                    self._block_stats["spread"] = self._block_stats.get("spread", 0) + 1

            # -----------------------
            # 4) Funding gate (futures)
            if allow and funding is not None:
                # Backward compatible keys + new nested keys
                thr = self._get_sym(symbol, "funding_abs_threshold", None)
                thr = self._safe_float(thr, 0.0) if thr is not None else None
                if thr is None or thr <= 0:
                    thr = self._safe_float(self._get_sym(symbol, "funding.abs_threshold", 0.0005), 0.0005)

                block_legacy = self._get_sym(symbol, "funding_block_unfavorable", None)
                if isinstance(block_legacy, bool):
                    block_unf = block_legacy
                else:
                    block_unf = self._safe_bool(self._get_sym(symbol, "funding.block_unfavorable", True), True)

                convention = str(self._get_sym(symbol, "funding.sign_convention", "typical"))

                if block_unf and abs(float(funding)) >= float(thr):
                    if self._funding_is_unfavorable(float(funding), side, convention):
                        allow = False
                        reasons.append(f"BLOCK: funding unfavorable (you pay) ({funding:+.6f} | thr={float(thr):.6f})")
                        tags.append("block_funding")
                        self._block_stats["funding"] = self._block_stats.get("funding", 0) + 1

            # -----------------------
            # 5) Regime-based scaling (no hard veto)
            if allow:
                if regime == "high_vol":
                    rm = self._safe_float(self._get_sym(symbol, "regime.high_vol_risk_mult", 0.70), 0.70)
                    rm = 1.0 + (rm - 1.0) * self._clamp(reg_strength, 0.0, 1.0)
                    risk_mult *= self._clamp(rm, 0.10, 1.0)
                    confidence *= 0.95
                    reasons.append("SCALE: regime high_vol -> risk down")
                    tags.append("regime_high_vol")

                elif regime == "low_vol":
                    sm = self._safe_float(self._get_sym(symbol, "regime.low_vol_score_mult", 0.95), 0.95)
                    sm = 1.0 + (sm - 1.0) * self._clamp(reg_strength, 0.0, 1.0)
                    score_mult *= self._clamp(sm, 0.50, 1.20)
                    confidence *= 0.98
                    reasons.append("SCALE: regime low_vol -> mild score down")
                    tags.append("regime_low_vol")

                elif regime == "range":
                    sm = self._safe_float(self._get_sym(symbol, "regime.range_score_mult", 0.85), 0.85)
                    sm = 1.0 + (sm - 1.0) * self._clamp(reg_strength, 0.0, 1.0)
                    score_mult *= self._clamp(sm, 0.20, 1.0)
                    confidence *= 0.92
                    reasons.append("SCALE: regime range -> score down")
                    tags.append("regime_range")

                elif regime in ("trend_up", "trend_down"):
                    boost = self._safe_float(self._get_sym(symbol, "regime.trend_score_mult", 1.05), 1.05)
                    boost = 1.0 + (boost - 1.0) * self._clamp(reg_strength, 0.0, 1.0)
                    score_mult *= self._clamp(boost, 1.0, 1.25)
                    confidence *= 1.02
                    reasons.append("SCALE: regime trend -> score up")
                    tags.append("regime_trend")

            # -----------------------
            # 6) Risk-off with hysteresis (drawdown / streak)
            riskoff_enabled = self._safe_bool(self._get("ai_brain.riskoff.enabled", True), True)
            if allow and riskoff_enabled:
                dd_high = self._safe_float(self._get_sym(symbol, "riskoff.dd_high", 0.18), 0.18)
                dd_low = self._safe_float(self._get_sym(symbol, "riskoff.dd_low", 0.12), 0.12)
                streak_bad = self._safe_int(self._get_sym(symbol, "riskoff.loss_streak_bad", 4), 4)

                active = self._is_riskoff_active(symbol)

                # activate
                if (dd >= dd_high) or (loss_streak >= streak_bad):
                    active = True
                    ttl_s = self._safe_float(self._get("ai_brain.riskoff.ttl_s", 0.0), 0.0)
                    self._set_riskoff(symbol, True, ttl_s=ttl_s)
                    tags.append("risk_off")
                    reasons.append(f"SCALE: risk-off enter (dd={dd:.2f}, streak={loss_streak})")
                    self._block_stats["risk_off"] = self._block_stats.get("risk_off", 0) + 1

                # deactivate if below dd_low and streak ok
                if active and (dd <= dd_low) and (loss_streak < max(1, streak_bad - 1)):
                    active = False
                    self._set_riskoff(symbol, False)
                    reasons.append(f"INFO: risk-off exit (dd={dd:.2f}, streak={loss_streak})")
                    tags.append("risk_off_exit")

                if active:
                    risk_off = True
                    rm = self._safe_float(self._get_sym(symbol, "riskoff.risk_mult", 0.60), 0.60)
                    sm = self._safe_float(self._get_sym(symbol, "riskoff.score_mult", 0.90), 0.90)
                    risk_mult *= self._clamp(rm, 0.10, 1.0)
                    score_mult *= self._clamp(sm, 0.10, 1.0)
                    confidence *= 0.85

            # -----------------------
            # 7) Minimum absolute signal after scaling
            if allow:
                min_abs = self._safe_float(self._get_sym(symbol, "signal_min_abs", 1.10), 1.10)
                if abs(sig * score_mult) < min_abs:
                    allow = False
                    reasons.append(f"BLOCK: scaled signal too weak ({sig*score_mult:.2f} < {min_abs:.2f})")
                    tags.append("block_signal")
                    self._block_stats["signal_strength"] = self._block_stats.get("signal_strength", 0) + 1

            # -----------------------
            # 8) Cooldown writeback (hard blocks / soft riskoff)
            cd_block = self._safe_float(self._get("ai_brain.cooldown.on_block_s", 10.0), 10.0)
            cd_riskoff = self._safe_float(self._get("ai_brain.cooldown.on_riskoff_s", 20.0), 20.0)

            if not allow:
                cooldown_s = float(max(0.0, cd_block))
                next_allowed_ts = self._now() + cooldown_s
                confidence *= 0.50
                self._set_cooldown(symbol, cooldown_s)
            elif risk_off:
                cooldown_s = float(max(0.0, cd_riskoff))
                next_allowed_ts = self._now() + cooldown_s
                tags.append("cooldown_riskoff")
                # Note: riskoff cooldown is "advice" – but we can still set a short cooldown to reduce churn if desired
                if self._safe_bool(self._get("ai_brain.cooldown.enforce_on_riskoff", False), False):
                    self._set_cooldown(symbol, cooldown_s)

            # Final clamps
            score_mult = float(self._clamp(score_mult, 0.05, 2.0))
            risk_mult = float(self._clamp(risk_mult, 0.05, 2.0))
            confidence = float(self._clamp(confidence, 0.0, 1.0))

            if not reasons:
                reasons = ["INFO: ok"]
                tags.append("ok")

            decision = BrainDecision(
                allow_entries=bool(allow),
                score_mult=score_mult,
                risk_mult=risk_mult,
                reasons=reasons,
                decision_id=decision_id,
                confidence=confidence,
                tags=tags,
                risk_off=bool(risk_off),
                cooldown_s=float(cooldown_s),
                next_allowed_ts=float(next_allowed_ts),
            )

            # Optional logging
            if self._safe_bool(self._get("ai_brain.log_decisions", False), False):
                self._log("info", f"[ai_brain] {symbol} {side} -> {decision.to_dict()}")

            # Optional structured store
            self._store_decision(symbol, payload={"context": c, "decision": decision.to_dict()})

            return decision

    def decide(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Backward-compatible API.
        """
        return self.decide_obj(context).to_dict()

    # ---------------------------
    # Metrics and State Management
    # ---------------------------
    def get_metrics(self) -> Dict[str, Any]:
        """Return current brain state metrics."""
        with self._lock:
            return {
                "cooldown_active": len(self._cooldown_until),
                "riskoff_active": sum(1 for s in self._riskoff_state.values() 
                                    if s.get("active", False)),
                "total_decisions": self._decision_count,
                "blocks_by_reason": dict(self._block_stats),
                "uptime_seconds": self._now() - self._last_reset_ts,
                "memory_usage": {
                    "cooldown_entries": len(self._cooldown_until),
                    "riskoff_entries": len(self._riskoff_state)
                }
            }

    def reset_state(self) -> None:
        """Reset all internal state (for testing/maintenance)."""
        with self._lock:
            self._riskoff_state.clear()
            self._cooldown_until.clear()
            self._last_prune_ts = 0.0
            self._decision_count = 0
            self._block_stats.clear()
            self._last_reset_ts = self._now()
            self._log("info", "AI Brain state reset")

    def get_state_summary(self) -> Dict[str, Any]:
        """Get detailed state summary for debugging."""
        with self._lock:
            now = self._now()
            cooldowns = {}
            for key, until in self._cooldown_until.items():
                time_left = max(0.0, until - now) if until > now else 0.0
                cooldowns[key] = {
                    "until": until,
                    "time_left": time_left,
                    "active": time_left > 0
                }
            
            riskoffs = {}
            for key, state in self._riskoff_state.items():
                riskoffs[key] = {
                    "active": state.get("active", False),
                    "until_ts": state.get("until_ts", 0.0),
                    "time_left": max(0.0, state.get("until_ts", 0.0) - now) if state.get("active", False) else 0.0
                }
            
            return {
                "timestamp": now,
                "cooldowns": cooldowns,
                "riskoff_states": riskoffs,
                "config": {
                    "enabled": self._safe_bool(self._get("ai_brain.enabled", True), True),
                    "store_decisions": self._safe_bool(self._get("ai_brain.store_decisions", False), False),
                    "log_decisions": self._safe_bool(self._get("ai_brain.log_decisions", False), False)
                }
            }
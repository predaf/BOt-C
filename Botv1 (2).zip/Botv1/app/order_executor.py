from __future__ import annotations

import time
import random
import threading
from typing import Any, Dict, Optional, Tuple, List, Callable
from dataclasses import dataclass, asdict, field
from enum import Enum
import uuid
import math


# ============================================================
# Enums and Data Models
# ============================================================

class TWAPStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"
    STOPPED_EARLY = "stopped_early"


class SliceStatus(Enum):
    PENDING = "pending"
    SUBMITTING = "submitting"
    SUBMITTED = "submitted"
    FILLED = "filled"
    CANCELLED = "cancelled"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class TWAPSlice:
    """Represents a single slice in a TWAP execution"""
    slice_id: str
    slice_index: int
    target_qty: float
    actual_qty: Optional[float] = None
    price: Optional[float] = None
    status: SliceStatus = SliceStatus.PENDING
    submitted_at: Optional[float] = None
    filled_at: Optional[float] = None
    order_ids: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    attempts: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['status'] = self.status.value
        return d


@dataclass
class TWAPExecution:
    """Represents a complete TWAP execution"""
    execution_id: str
    symbol: str
    side: str
    target_qty: float
    duration_sec: int
    slices: int
    status: TWAPStatus = TWAPStatus.PENDING
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    submitted_qty: float = 0.0
    filled_qty: float = 0.0
    avg_price: Optional[float] = None
    slices_data: Dict[int, TWAPSlice] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['status'] = self.status.value
        d['slices_data'] = {idx: slice_data.to_dict() for idx, slice_data in self.slices_data.items()}
        d['progress_pct'] = self.progress_pct()
        return d
    
    def progress_pct(self) -> float:
        """Calculate progress percentage (0-100)"""
        if self.status == TWAPStatus.COMPLETED:
            return 100.0
        elif self.status in [TWAPStatus.CANCELLED, TWAPStatus.FAILED]:
            return 0.0
        
        if self.slices <= 0:
            return 0.0
        
        # Progress based on submitted slices
        submitted_slices = sum(1 for s in self.slices_data.values() 
                             if s.status in [SliceStatus.SUBMITTED, SliceStatus.FILLED])
        return (submitted_slices / self.slices) * 100.0


# ============================================================
# Core TWAP Executor
# ============================================================

class TWAPExecutor:
    """
    Enhanced TWAP executor with:
      - Stateful execution tracking
      - Circuit breaker for failures
      - Pause/resume capability
      - Detailed slice-by-slice reporting
      - Performance metrics
      - Graceful degradation
    """
    
    def __init__(self, engine: Any):
        self.engine = engine
        self.active_executions: Dict[str, TWAPExecution] = {}
        self.execution_history: List[TWAPExecution] = []
        self._lock = threading.RLock()
        
        # Circuit breaker state
        self._circuit_breaker = {
            "open": False,
            "failures": 0,
            "last_failure": 0.0,
            "cooldown_until": 0.0
        }
        self.max_failures = 5
        self.cooldown_sec = 30.0
        
        # Performance metrics
        self.metrics = {
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "total_qty_executed": 0.0,
            "avg_execution_time_sec": 0.0,
            "last_execution_time": 0.0
        }
        
        # Configuration defaults
        self.config = {
            "max_failures": 3,
            "max_skipped_slices": 6,
            "jitter_frac": 0.10,
            "min_delay_sec": 0.25,
            "max_slice_attempts": 2,
            "auto_cleanup_seconds": 3600,
            "max_concurrent_executions": 3
        }
    
    # -------------------------
    # Utility Functions
    # -------------------------
    
    @staticmethod
    def _safe_log(engine: Any, level: str, msg: str) -> None:
        """Safely log message through engine's logger"""
        try:
            log = getattr(engine, "log", None)
            if log is None:
                return
            fn = getattr(log, level, None)
            if callable(fn):
                fn(msg)
            else:
                # fallback
                if hasattr(log, "info") and callable(getattr(log, "info")):
                    log.info(f"[{level.upper()}] {msg}")
        except Exception:
            pass
    
    def _log(self, level: str, msg: str) -> None:
        """Log through engine with executor prefix"""
        self._safe_log(self.engine, level, f"[TWAPExecutor] {msg}")
    
    @staticmethod
    def _engine_should_stop(engine: Any) -> bool:
        """Check if engine is in a stopped/paused state"""
        try:
            if getattr(engine, "_stop", False):
                return True
            if getattr(engine, "halted", False):
                return True
            if getattr(engine, "paused", False) or getattr(engine, "_paused", False):
                return True
            if hasattr(engine, "running"):
                if bool(getattr(engine, "running")) is False:
                    return True
            if hasattr(engine, "_running"):
                if bool(getattr(engine, "_running")) is False:
                    return True
        except Exception:
            pass
        return False
    
    @staticmethod
    def _risk_blocks_execution(engine: Any) -> bool:
        """Check if risk management blocks execution"""
        try:
            rs = getattr(engine, "risk_state", None)
            if rs is None:
                return False
            
            # Try to get risk state
            st = getattr(rs, "state", None)
            if st is None and isinstance(rs, dict):
                st = rs.get("state")
            s = str(st or "").upper().strip()
            return s in ("HALT", "STOP", "PAUSE", "RISK_OFF", "DANGER")
        except Exception:
            return False
    
    @staticmethod
    def _get_price(engine: Any, symbol: str, side: str) -> float:
        """Get current price for a symbol"""
        s = str(side).strip().lower()
        try:
            # Try engine's internal price method
            bid, ask, last = engine._get_bid_ask_last(symbol)
            last_f = float(last) if last is not None else 0.0
            if last_f > 0:
                return last_f
            
            # Fallback to bid/ask
            b = float(bid) if bid is not None else 0.0
            a = float(ask) if ask is not None else 0.0
            if s == "buy":
                return a if a > 0 else b
            return b if b > 0 else a
        except Exception:
            pass
        
        # Client ticker fallback
        try:
            client = getattr(engine, "client", None)
            if client is not None and hasattr(client, "fetch_ticker"):
                t = client.fetch_ticker(symbol) or {}
                px = float(t.get("last") or t.get("close") or 0.0)
                return px
        except Exception:
            pass
        
        return 0.0
    
    @staticmethod
    def _format_and_enforce(engine: Any, symbol: str, side: str, qty: float, px: float) -> float:
        """Format quantity and enforce trading rules"""
        q = float(qty)
        
        try:
            q = float(engine.client.format_amount(symbol, q))
        except Exception:
            pass
        
        try:
            q2, _ = engine.client.enforce_trade_rules(symbol, side, q, float(px))
            q = float(q2)
        except Exception:
            pass
        
        return float(q)
    
    # -------------------------
    # Circuit Breaker Management
    # -------------------------
    
    def _check_circuit_breaker(self) -> bool:
        """Check if circuit breaker is open"""
        now = time.time()
        cb = self._circuit_breaker
        
        if cb["open"]:
            if now < cb["cooldown_until"]:
                remaining = cb["cooldown_until"] - now
                raise Exception(
                    f"TWAP circuit breaker open - too many failures. "
                    f"Cooldown for {remaining:.1f} seconds"
                )
            else:
                # Cooldown expired, reset
                cb["open"] = False
                cb["failures"] = 0
                self._log("info", "Circuit breaker reset after cooldown")
        
        return True
    
    def _record_failure(self) -> None:
        """Record a failure and potentially open circuit breaker"""
        cb = self._circuit_breaker
        cb["failures"] += 1
        cb["last_failure"] = time.time()
        
        if cb["failures"] >= self.max_failures:
            cb["open"] = True
            cb["cooldown_until"] = time.time() + self.cooldown_sec
            self._log("error", 
                f"Circuit breaker opened after {cb['failures']} failures. "
                f"Cooldown for {self.cooldown_sec} seconds"
            )
    
    def _record_success(self) -> None:
        """Record success - reset failure count"""
        self._circuit_breaker["failures"] = 0
        self._circuit_breaker["open"] = False
    
    def get_circuit_breaker_status(self) -> Dict[str, Any]:
        """Get current circuit breaker status"""
        cb = self._circuit_breaker
        now = time.time()
        status = {
            "open": cb["open"],
            "failures": cb["failures"],
            "max_failures": self.max_failures,
            "last_failure_ago": now - cb["last_failure"] if cb["last_failure"] > 0 else None,
        }
        
        if cb["open"]:
            status["cooldown_remaining"] = max(0, cb["cooldown_until"] - now)
            status["cooldown_until"] = cb["cooldown_until"]
        
        return status
    
    # -------------------------
    # Execution Management
    # -------------------------
    
    def create_twap_execution(
        self,
        symbol: str,
        side: str,
        qty: float,
        duration_sec: int = 60,
        slices: int = 10,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> TWAPExecution:
        """Create a new TWAP execution"""
        with self._lock:
            # Check concurrent execution limit
            active_count = sum(1 for e in self.active_executions.values() 
                             if e.status in [TWAPStatus.RUNNING, TWAPStatus.PAUSED])
            if active_count >= self.config["max_concurrent_executions"]:
                raise Exception(
                    f"Maximum concurrent TWAP executions ({self.config['max_concurrent_executions']}) reached"
                )
            
            execution_id = f"twap_{int(time.time())}_{uuid.uuid4().hex[:8]}"
            
            # Create execution object
            execution = TWAPExecution(
                execution_id=execution_id,
                symbol=str(symbol),
                side=str(side).lower().strip(),
                target_qty=float(qty),
                duration_sec=int(duration_sec),
                slices=int(slices),
                metadata={
                    **(metadata or {}),
                    "config": {**self.config, **kwargs}
                }
            )
            
            # Initialize slices
            slice_qty = float(qty) / slices
            for i in range(slices):
                execution.slices_data[i] = TWAPSlice(
                    slice_id=f"{execution_id}_slice_{i}",
                    slice_index=i,
                    target_qty=slice_qty
                )
            
            self.active_executions[execution_id] = execution
            self.metrics["total_executions"] += 1
            
            self._log("info", 
                f"Created TWAP execution {execution_id}: {side} {qty} {symbol} "
                f"over {duration_sec}s in {slices} slices"
            )
            
            return execution
    
    def execute_twap(
        self,
        symbol: str,
        side: str,
        qty: float,
        duration_sec: int = 60,
        slices: int = 10,
        reason: str = "twap",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute TWAP synchronously and return summary.
        For async execution, use create_twap_execution + start_execution.
        """
        try:
            self._check_circuit_breaker()
            
            # Create execution
            execution = self.create_twap_execution(
                symbol=symbol,
                side=side,
                qty=qty,
                duration_sec=duration_sec,
                slices=slices,
                metadata={"reason": reason, **kwargs}
            )
            
            # Execute synchronously
            result = self._execute_twap_sync(execution, **kwargs)
            
            # Update metrics
            if result["ok"]:
                self.metrics["successful_executions"] += 1
                self.metrics["total_qty_executed"] += result["submitted_qty"]
                self._record_success()
            else:
                self.metrics["failed_executions"] += 1
                self._record_failure()
            
            return result
            
        except Exception as e:
            self._record_failure()
            self.metrics["failed_executions"] += 1
            return {
                "ok": False,
                "error": f"TWAP execution failed: {type(e).__name__}: {e}",
                "errors": [f"INIT:{type(e).__name__}:{e}"]
            }
    
    def _execute_twap_sync(self, execution: TWAPExecution, **kwargs) -> Dict[str, Any]:
        """Execute TWAP synchronously"""
        start_time = time.time()
        execution.status = TWAPStatus.RUNNING
        execution.started_at = start_time
        
        config = {**self.config, **execution.metadata.get("config", {}), **kwargs}
        
        # Initial validation
        if execution.target_qty <= 0:
            execution.status = TWAPStatus.FAILED
            execution.errors.append("qty<=0")
            return self._execution_to_result(execution, start_time)
        
        if execution.side not in ("buy", "sell"):
            execution.status = TWAPStatus.FAILED
            execution.errors.append("invalid_side")
            return self._execution_to_result(execution, start_time)
        
        slices = max(1, execution.slices)
        duration_sec = max(1, execution.duration_sec)
        
        # Calculate pacing
        if slices <= 1:
            base_delay = 0.0
        else:
            base_delay = float(duration_sec) / float(slices - 1)
        base_delay = max(float(config["min_delay_sec"]), float(base_delay))
        
        jitter_frac = max(0.0, min(0.5, float(config.get("jitter_frac", 0.10))))
        
        # Track remaining quantity
        remaining_qty = float(execution.target_qty)
        failures = 0
        skipped = 0
        
        self._log("info", 
            f"Starting TWAP {execution.execution_id}: {execution.side} {execution.target_qty} "
            f"{execution.symbol} over {duration_sec}s ({slices} slices)"
        )
        
        # Execute each slice
        for i in range(slices):
            if self._should_stop_execution(execution):
                execution.status = TWAPStatus.STOPPED_EARLY
                break
            
            if remaining_qty <= 0:
                self._log("info", f"TWAP {execution.execution_id}: No remaining quantity")
                break
            
            slice_data = execution.slices_data[i]
            slice_data.status = SliceStatus.SUBMITTING
            
            # Calculate slice quantity
            slices_left = max(1, (slices - i))
            raw_slice_qty = float(remaining_qty) / float(slices_left)
            
            # Get price for trade rules
            price = self._get_price(self.engine, execution.symbol, execution.side)
            if price <= 0:
                slice_data.status = SliceStatus.SKIPPED
                slice_data.errors.append("no_price_available")
                skipped += 1
                execution.errors.append(f"slice{i+1}:no_price")
                
                if skipped >= config["max_skipped_slices"]:
                    execution.status = TWAPStatus.FAILED
                    execution.errors.append("max_skipped_slices_reached")
                    break
                
                time.sleep(base_delay)
                continue
            
            # Format and enforce trading rules
            formatted_qty = self._format_and_enforce(
                self.engine, 
                execution.symbol, 
                execution.side, 
                raw_slice_qty, 
                float(price)
            )
            
            if formatted_qty <= 0:
                slice_data.status = SliceStatus.SKIPPED
                slice_data.errors.append("invalid_qty_after_formatting")
                skipped += 1
                execution.errors.append(f"slice{i+1}:qty<=0_after_rules")
                
                if skipped >= config["max_skipped_slices"]:
                    execution.status = TWAPStatus.FAILED
                    break
                
                time.sleep(base_delay)
                continue
            
            # Don't exceed remaining
            slice_qty = min(float(formatted_qty), float(remaining_qty))
            if slice_qty <= 0:
                slice_data.status = SliceStatus.SKIPPED
                time.sleep(base_delay)
                continue
            
            slice_data.target_qty = slice_qty
            slice_data.price = price
            slice_data.attempts += 1
            
            # Submit slice
            submitted = False
            last_error = None
            
            for attempt in range(config["max_slice_attempts"]):
                if self._should_stop_execution(execution):
                    break
                
                try:
                    # Generate unique tag for this slice
                    tag = f"{execution.metadata.get('reason', 'twap')}:{i+1}/{slices}:{execution.execution_id}"
                    
                    # Use engine's place_order method
                    order_result = self.engine._place_order(
                        execution.symbol,
                        execution.side,
                        float(slice_qty),
                        tag,
                        atr_pct=float(execution.metadata.get("atr_pct", 0.0))
                    )
                    
                    # Record order ID if available
                    if order_result and hasattr(order_result, 'get'):
                        order_id = order_result.get("id") or order_result.get("orderId")
                        if order_id:
                            slice_data.order_ids.append(str(order_id))
                    
                    slice_data.status = SliceStatus.SUBMITTED
                    slice_data.submitted_at = time.time()
                    slice_data.actual_qty = slice_qty
                    
                    execution.submitted_qty += slice_qty
                    remaining_qty -= slice_qty
                    
                    submitted = True
                    self._log("debug", 
                        f"TWAP {execution.execution_id} slice {i+1}/{slices}: "
                        f"Submitted {slice_qty} @ {price}"
                    )
                    break
                    
                except Exception as e:
                    last_error = e
                    slice_data.errors.append(f"attempt{attempt+1}:{type(e).__name__}:{str(e)[:100]}")
                    failures += 1
                    
                    self._log("error", 
                        f"TWAP {execution.execution_id} slice {i+1}/{slices} "
                        f"attempt {attempt+1} failed: {type(e).__name__}: {e}"
                    )
                    
                    # Short backoff for retry
                    if attempt < config["max_slice_attempts"] - 1:
                        time.sleep(min(1.5, base_delay * 0.35 + 0.15))
            
            if not submitted:
                slice_data.status = SliceStatus.FAILED
                execution.errors.append(
                    f"slice{i+1}:submit_failed:{type(last_error).__name__ if last_error else 'Error'}"
                )
                
                if failures >= config["max_failures"]:
                    execution.status = TWAPStatus.FAILED
                    self._log("error", 
                        f"TWAP {execution.execution_id}: Max failures ({config['max_failures']}) reached"
                    )
                    break
            
            # Sleep between slices (except last)
            if i < slices - 1:
                jitter = 1.0
                if jitter_frac > 0:
                    jitter = 1.0 + random.uniform(-jitter_frac, jitter_frac)
                delay = max(float(config["min_delay_sec"]), float(base_delay) * float(jitter))
                time.sleep(delay)
        
        # Finalize execution
        execution.completed_at = time.time()
        
        if execution.status == TWAPStatus.RUNNING:
            if execution.submitted_qty <= 0:
                execution.status = TWAPStatus.FAILED
            else:
                execution.status = TWAPStatus.COMPLETED
        
        # Calculate average price if we have price data
        slices_with_price = [s for s in execution.slices_data.values() 
                           if s.status == SliceStatus.SUBMITTED and s.price]
        if slices_with_price:
            total_value = sum(s.actual_qty or s.target_qty for s in slices_with_price)
            if total_value > 0:
                weighted_price = sum((s.actual_qty or s.target_qty) * s.price 
                                   for s in slices_with_price)
                execution.avg_price = weighted_price / total_value
        
        return self._execution_to_result(execution, start_time)
    
    def _execution_to_result(self, execution: TWAPExecution, start_time: float) -> Dict[str, Any]:
        """Convert execution to result dictionary"""
        elapsed = time.time() - start_time
        
        # Update metrics
        self.metrics["last_execution_time"] = time.time()
        if self.metrics["total_executions"] > 0:
            self.metrics["avg_execution_time_sec"] = (
                self.metrics["avg_execution_time_sec"] * (self.metrics["total_executions"] - 1) + elapsed
            ) / self.metrics["total_executions"]
        
        # Move to history if completed
        if execution.status in [TWAPStatus.COMPLETED, TWAPStatus.FAILED, 
                              TWAPStatus.CANCELLED, TWAPStatus.STOPPED_EARLY]:
            with self._lock:
                if execution.execution_id in self.active_executions:
                    self.execution_history.append(execution)
                    del self.active_executions[execution.execution_id]
        
        result = {
            "ok": execution.status == TWAPStatus.COMPLETED,
            "execution_id": execution.execution_id,
            "symbol": execution.symbol,
            "side": execution.side,
            "qty_target": execution.target_qty,
            "duration_sec": execution.duration_sec,
            "slices": execution.slices,
            "status": execution.status.value,
            "submitted_slices": sum(1 for s in execution.slices_data.values() 
                                  if s.status in [SliceStatus.SUBMITTED, SliceStatus.FILLED]),
            "submitted_qty": float(execution.submitted_qty),
            "filled_qty": float(execution.filled_qty),
            "avg_price": float(execution.avg_price) if execution.avg_price else None,
            "skipped_slices": sum(1 for s in execution.slices_data.values() 
                                if s.status == SliceStatus.SKIPPED),
            "failed_slices": sum(1 for s in execution.slices_data.values() 
                               if s.status == SliceStatus.FAILED),
            "stopped_early": execution.status == TWAPStatus.STOPPED_EARLY,
            "errors": execution.errors,
            "elapsed_sec": elapsed,
            "progress_pct": execution.progress_pct(),
            "created_at": execution.created_at,
            "started_at": execution.started_at,
            "completed_at": execution.completed_at,
        }
        
        # Add detailed slice information
        result["slices_detail"] = {
            idx: slice_data.to_dict() 
            for idx, slice_data in execution.slices_data.items()
        }
        
        self._log("info", 
            f"TWAP {execution.execution_id} completed: "
            f"status={execution.status.value}, "
            f"submitted={execution.submitted_qty}/{execution.target_qty}, "
            f"elapsed={elapsed:.1f}s"
        )
        
        return result
    
    def _should_stop_execution(self, execution: TWAPExecution) -> bool:
        """Check if execution should be stopped"""
        if self._engine_should_stop(self.engine):
            self._log("warning", f"TWAP {execution.execution_id}: Engine stopped")
            return True
        
        if self._risk_blocks_execution(self.engine):
            self._log("warning", f"TWAP {execution.execution_id}: Risk management blocked")
            return True
        
        if execution.status in [TWAPStatus.CANCELLED, TWAPStatus.FAILED]:
            return True
        
        return False
    
    # -------------------------
    # Execution Control Methods
    # -------------------------
    
    def start_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Start an existing execution asynchronously"""
        with self._lock:
            execution = self.active_executions.get(execution_id)
            if not execution:
                self._log("error", f"Execution {execution_id} not found")
                return None
            
            if execution.status != TWAPStatus.PENDING:
                self._log("error", f"Execution {execution_id} not in PENDING state")
                return None
            
            # Start execution in a separate thread
            import threading
            thread = threading.Thread(
                target=self._execute_twap_sync,
                args=(execution,),
                kwargs=kwargs,
                daemon=True,
                name=f"TWAP-{execution_id}"
            )
            thread.start()
            
            return {"ok": True, "execution_id": execution_id, "thread_started": True}
    
    def cancel_execution(self, execution_id: str) -> Dict[str, Any]:
        """Cancel an active execution"""
        with self._lock:
            execution = self.active_executions.get(execution_id)
            if not execution:
                # Check history
                for e in self.execution_history:
                    if e.execution_id == execution_id:
                        return {
                            "ok": False,
                            "error": f"Execution {execution_id} already completed"
                        }
                return {"ok": False, "error": f"Execution {execution_id} not found"}
            
            if execution.status not in [TWAPStatus.PENDING, TWAPStatus.RUNNING, TWAPStatus.PAUSED]:
                return {
                    "ok": False,
                    "error": f"Cannot cancel execution in {execution.status.value} state"
                }
            
            execution.status = TWAPStatus.CANCELLED
            execution.completed_at = time.time()
            
            # Cancel any pending orders through engine if possible
            try:
                if hasattr(self.engine, 'cancel_all_orders'):
                    self.engine.cancel_all_orders(execution.symbol)
            except Exception as e:
                self._log("error", f"Failed to cancel orders for {execution_id}: {e}")
            
            self._log("info", f"Cancelled TWAP execution {execution_id}")
            
            # Move to history
            self.execution_history.append(execution)
            del self.active_executions[execution_id]
            
            return {
                "ok": True,
                "execution_id": execution_id,
                "status": TWAPStatus.CANCELLED.value
            }
    
    def pause_execution(self, execution_id: str) -> Dict[str, Any]:
        """Pause an active execution"""
        with self._lock:
            execution = self.active_executions.get(execution_id)
            if not execution:
                return {"ok": False, "error": f"Execution {execution_id} not found"}
            
            if execution.status != TWAPStatus.RUNNING:
                return {
                    "ok": False,
                    "error": f"Cannot pause execution in {execution.status.value} state"
                }
            
            execution.status = TWAPStatus.PAUSED
            self._log("info", f"Paused TWAP execution {execution_id}")
            
            return {
                "ok": True,
                "execution_id": execution_id,
                "status": TWAPStatus.PAUSED.value
            }
    
    def resume_execution(self, execution_id: str) -> Dict[str, Any]:
        """Resume a paused execution"""
        with self._lock:
            execution = self.active_executions.get(execution_id)
            if not execution:
                return {"ok": False, "error": f"Execution {execution_id} not found"}
            
            if execution.status != TWAPStatus.PAUSED:
                return {
                    "ok": False,
                    "error": f"Cannot resume execution in {execution.status.value} state"
                }
            
            execution.status = TWAPStatus.RUNNING
            self._log("info", f"Resumed TWAP execution {execution_id}")
            
            # Continue execution in background
            return self.start_execution(execution_id)
    
    # -------------------------
    # Query Methods
    # -------------------------
    
    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get execution details"""
        with self._lock:
            # Check active executions
            execution = self.active_executions.get(execution_id)
            if execution:
                return execution.to_dict()
            
            # Check history
            for e in self.execution_history:
                if e.execution_id == execution_id:
                    return e.to_dict()
            
            return None
    
    def list_executions(self, active_only: bool = False) -> List[Dict[str, Any]]:
        """List all executions"""
        with self._lock:
            results = []
            
            if not active_only:
                # Include history (most recent first)
                for execution in reversed(self.execution_history):
                    results.append(execution.to_dict())
            
            # Add active executions
            for execution in self.active_executions.values():
                results.append(execution.to_dict())
            
            return results
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get executor metrics"""
        with self._lock:
            metrics = self.metrics.copy()
            
            # Calculate additional metrics
            if metrics["total_executions"] > 0:
                metrics["success_rate"] = metrics["successful_executions"] / metrics["total_executions"]
                metrics["failure_rate"] = metrics["failed_executions"] / metrics["total_executions"]
            
            metrics["active_executions"] = len(self.active_executions)
            metrics["history_size"] = len(self.execution_history)
            metrics["circuit_breaker"] = self.get_circuit_breaker_status()
            
            return metrics
    
    def cleanup_old_executions(self, max_age_seconds: Optional[float] = None) -> Dict[str, Any]:
        """Clean up old executions from history"""
        if max_age_seconds is None:
            max_age_seconds = self.config["auto_cleanup_seconds"]
        
        now = time.time()
        removed = 0
        
        with self._lock:
            # Remove old history entries
            new_history = []
            for execution in self.execution_history:
                age = now - (execution.completed_at or execution.created_at)
                if age <= max_age_seconds:
                    new_history.append(execution)
                else:
                    removed += 1
            
            self.execution_history = new_history
            
            # Also clean up stuck active executions
            stuck_executions = []
            for exec_id, execution in list(self.active_executions.items()):
                age = now - execution.created_at
                if age > max_age_seconds * 2:  # Longer threshold for active
                    stuck_executions.append(exec_id)
                    removed += 1
                    del self.active_executions[exec_id]
            
            if removed > 0:
                self._log("info", f"Cleaned up {removed} old executions")
            
            return {
                "removed_count": removed,
                "stuck_executions": stuck_executions,
                "history_size": len(self.execution_history),
                "active_count": len(self.active_executions)
            }


# ============================================================
# Legacy Function (for backward compatibility)
# ============================================================

def execute_twap(
    engine: Any,
    symbol: str,
    side: str,
    qty: float,
    duration_sec: int = 60,
    slices: int = 10,
    reason: str = "twap",
    **kwargs
) -> Dict[str, Any]:
    """
    Legacy function for backward compatibility.
    Creates a TWAPExecutor instance and executes TWAP.
    """
    executor = TWAPExecutor(engine)
    return executor.execute_twap(
        symbol=symbol,
        side=side,
        qty=qty,
        duration_sec=duration_sec,
        slices=slices,
        reason=reason,
        **kwargs
    )
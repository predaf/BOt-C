from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Protocol, runtime_checkable
import time
import hashlib
import json
import logging
from enum import Enum
from abc import ABC, abstractmethod


# ============================================================================
# TYPES AND ENUMS
# ============================================================================

class SentimentProviderType(Enum):
    """Tipuri de provideri de sentiment"""
    STUB = "stub"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    CUSTOM_API = "custom_api"
    HUGGINGFACE = "huggingface"


class SentimentScore(Enum):
    """Scoruri de sentiment"""
    STRONG_NEGATIVE = -1.0
    NEGATIVE = -0.5
    NEUTRAL = 0.0
    POSITIVE = 0.5
    STRONG_POSITIVE = 1.0


@dataclass
class NewsEvent:
    """Structură pentru evenimente de știri"""
    title: str
    timestamp: float
    source: str
    url: Optional[str] = None
    score: float = 0.0
    confidence: float = 0.0
    categories: List[str] = field(default_factory=list)
    summary: Optional[str] = None


@dataclass
class SymbolSentiment:
    """Rezultat de sentiment pentru un simbol"""
    symbol: str
    base_token: str
    sentiment_score: float
    confidence: float
    veto: bool
    reasons: List[str]
    events: List[NewsEvent]
    provider: str
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire la dicționar"""
        return {
            "symbol": self.symbol,
            "base_token": self.base_token,
            "sentiment_score": self.sentiment_score,
            "confidence": self.confidence,
            "veto": self.veto,
            "reasons": self.reasons,
            "events": [{
                "title": e.title,
                "timestamp": e.timestamp,
                "source": e.source,
                "url": e.url,
                "score": e.score,
                "confidence": e.confidence,
                "categories": e.categories,
                "summary": e.summary
            } for e in self.events],
            "provider": self.provider,
            "timestamp": self.timestamp
        }


# ============================================================================
# PROTOCOL PROVIDER
# ============================================================================

@runtime_checkable
class SentimentProvider(Protocol):
    """Protocol pentru provideri de sentiment"""
    
    @abstractmethod
    def fetch_sentiment(self, symbols: List[str]) -> Dict[str, SymbolSentiment]:
        """Fetch sentiment pentru o listă de simboluri"""
        pass
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Numele providerului"""
        pass
    
    @property
    @abstractmethod
    def max_batch_size(self) -> int:
        """Mărimea maximă a batch-ului"""
        pass


# ============================================================================
# PROVIDERI IMPLEMENTAȚI
# ============================================================================

class StubSentimentProvider:
    """Provider stub pentru testare și fallback"""
    
    def __init__(self, log: Optional[logging.Logger] = None):
        self._log = log
        self._name = "stub"
        self._max_batch_size = 100
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def max_batch_size(self) -> int:
        return self._max_batch_size
    
    def fetch_sentiment(self, symbols: List[str]) -> Dict[str, SymbolSentiment]:
        """Returnează sentiment neutru pentru toate simbolurile"""
        result = {}
        
        for symbol in symbols:
            base_token = _sym_base(symbol)
            
            result[symbol] = SymbolSentiment(
                symbol=symbol,
                base_token=base_token,
                sentiment_score=0.0,
                confidence=0.0,
                veto=False,
                reasons=["Provider stub - no real data"],
                events=[],
                provider=self.name
            )
        
        if self._log:
            self._log.debug(f"Stub provider returned neutral sentiment for {len(symbols)} symbols")
        
        return result


class APISentimentProvider:
    """Provider pentru API-uri externe de sentiment"""
    
    def __init__(
        self,
        api_url: str,
        api_key: Optional[str] = None,
        timeout: float = 10.0,
        log: Optional[logging.Logger] = None
    ):
        self._api_url = api_url
        self._api_key = api_key
        self._timeout = timeout
        self._log = log
        self._name = "api"
        self._max_batch_size = 25
        
        # Headers
        self._headers = {"Content-Type": "application/json"}
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def max_batch_size(self) -> int:
        return self._max_batch_size
    
    def fetch_sentiment(self, symbols: List[str]) -> Dict[str, SymbolSentiment]:
        """Fetch sentiment de la API"""
        import requests
        
        if not symbols:
            return {}
        
        # Limităm batch-ul
        batch = symbols[:self._max_batch_size]
        
        try:
            # Construim payload
            payload = {
                "symbols": batch,
                "timestamp": time.time()
            }
            
            # Apel API
            response = requests.post(
                self._api_url,
                json=payload,
                headers=self._headers,
                timeout=self._timeout
            )
            
            response.raise_for_status()
            data = response.json()
            
            # Parsează răspunsul
            return self._parse_response(data, batch)
            
        except requests.exceptions.Timeout:
            if self._log:
                self._log.warning(f"API timeout pentru {len(batch)} simboluri")
            raise
        except requests.exceptions.RequestException as e:
            if self._log:
                self._log.error(f"API error: {e}")
            raise
        except (KeyError, ValueError) as e:
            if self._log:
                self._log.error(f"Parsing error: {e}")
            raise
    
    def _parse_response(self, data: Dict[str, Any], symbols: List[str]) -> Dict[str, SymbolSentiment]:
        """Parsează răspunsul API"""
        result = {}
        
        for symbol in symbols:
            symbol_data = data.get(symbol, {})
            
            result[symbol] = SymbolSentiment(
                symbol=symbol,
                base_token=_sym_base(symbol),
                sentiment_score=float(symbol_data.get("sentiment", 0.0)),
                confidence=float(symbol_data.get("confidence", 0.0)),
                veto=bool(symbol_data.get("veto", False)),
                reasons=list(symbol_data.get("reasons", [])),
                events=[
                    NewsEvent(
                        title=event.get("title", ""),
                        timestamp=float(event.get("timestamp", time.time())),
                        source=event.get("source", "unknown"),
                        url=event.get("url"),
                        score=float(event.get("score", 0.0)),
                        confidence=float(event.get("confidence", 0.0)),
                        categories=list(event.get("categories", [])),
                        summary=event.get("summary")
                    )
                    for event in symbol_data.get("events", [])
                ],
                provider=self.name
            )
        
        return result


# ============================================================================
# FALLBACK PROVIDER MANAGER
# ============================================================================

class FallbackSentimentProvider:
    """Manager pentru multiple provideri cu fallback"""
    
    def __init__(
        self,
        providers: List[SentimentProvider],
        log: Optional[logging.Logger] = None
    ):
        self._providers = providers
        self._log = log
        self._name = "fallback_manager"
        self._max_batch_size = min(p.max_batch_size for p in providers) if providers else 50
        
        if self._log:
            self._log.info(f"Initialized fallback provider with {len(providers)} providers")
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def max_batch_size(self) -> int:
        return self._max_batch_size
    
    def fetch_sentiment(self, symbols: List[str]) -> Dict[str, SymbolSentiment]:
        """Încearcă providerii în ordine până când unul reușește"""
        if not symbols:
            return {}
        
        batch = symbols[:self._max_batch_size]
        last_error = None
        
        for provider in self._providers:
            try:
                if self._log:
                    self._log.debug(f"Trying provider: {provider.name}")
                
                result = provider.fetch_sentiment(batch)
                
                if self._log:
                    self._log.info(f"Provider {provider.name} succeeded for {len(batch)} symbols")
                
                return result
                
            except Exception as e:
                last_error = e
                if self._log:
                    self._log.warning(f"Provider {provider.name} failed: {e}")
                continue
        
        # Toți providerii au eșuat
        if self._log:
            self._log.error(f"All providers failed, using stub. Last error: {last_error}")
        
        # Fallback la stub
        stub = StubSentimentProvider(self._log)
        return stub.fetch_sentiment(batch)


# ============================================================================
# UTILITARE
# ============================================================================

def _as_bool(x: Any, default: bool = False) -> bool:
    """Convertire sigură la boolean"""
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    
    s = str(x).strip().lower()
    return s in ("1", "true", "yes", "y", "on", "enable", "enabled")


def _as_float(x: Any, default: float = 0.0) -> float:
    """Convertire sigură la float"""
    try:
        return float(x)
    except (ValueError, TypeError):
        return float(default)


def _sym_base(symbol: str) -> str:
    """
    Normalizează simboluri CCXT-like în token de bază pentru mapare știri.
    
    Exemple:
      BTC/USDT -> BTC
      ETHUSDT  -> ETH (best effort)
      1000PEPE/USDT -> PEPE
      BTC-PERP -> BTC
    """
    if not symbol:
        return ""
    
    s = symbol.upper().strip()
    
    # Elimină suffixe comune
    remove_patterns = [
        ("/USDT", "/"),
        ("/USDC", "/"),
        ("/BUSD", "/"),
        ("/USD", "/"),
        ("-PERP", ""),
        ("-SWAP", ""),
        ("-FUTURES", ""),
        ("USDT", ""),
        ("USDC", ""),
        ("BUSD", ""),
    ]
    
    for pattern, replacement in remove_patterns:
        if pattern in s:
            s = s.replace(pattern, replacement)
    
    # Separat după / sau -
    for sep in ("/", "-", ":"):
        if sep in s:
            s = s.split(sep)[0]
    
    # Elimină prefixe numerice (ex: 1000PEPE -> PEPE)
    while s and s[0].isdigit():
        s = s[1:]
    
    # Elimină spații și verifică gol
    s = s.strip()
    return s if s else symbol.upper()


def _cache_key(symbols: List[str]) -> str:
    """Generează cheie de cache pentru simboluri"""
    if not symbols:
        return "empty"
    
    # Normalizează și sortează
    bases = sorted([_sym_base(s) for s in symbols])
    base_str = "|".join(bases)
    
    # Hash pentru cheie compactă
    return hashlib.sha256(base_str.encode("utf-8")).hexdigest()[:16]


def _validate_sentiment_score(score: float) -> float:
    """Validează și clipește scorul de sentiment între -1 și 1"""
    return max(-1.0, min(1.0, float(score)))


def _validate_confidence(confidence: float) -> float:
    """Validează și clipește confidence între 0 și 1"""
    return max(0.0, min(1.0, float(confidence)))


# ============================================================================
# CLOUD SENTIMENT ENGINE
# ============================================================================

@dataclass
class CloudSentiment:
    """
    Engine pentru sentiment analysis cu caching și circuit breaker.
    
    Features:
      - Multiple provider support cu fallback
      - Intelligent caching cu TTL
      - Circuit breaker pattern
      - Batch processing optimizat
      - Metrics și logging
    """
    
    # Configurație
    enabled: bool = False
    ttl_sec: float = 120.0
    max_symbols: int = 50
    open_after_failures: int = 3
    open_sec: float = 60.0
    
    # Provider
    provider: Optional[SentimentProvider] = None
    
    # Cache
    _cache: Dict[str, Tuple[float, Dict[str, SymbolSentiment]]] = field(default_factory=dict)
    _cache_hits: int = 0
    _cache_misses: int = 0
    
    # Circuit breaker
    _fail_count: int = 0
    _open_until: float = 0.0
    
    # Metrics
    _request_count: int = 0
    _total_latency: float = 0.0
    _log: Optional[logging.Logger] = None
    
    def __post_init__(self):
        """Initializează providerul default dacă nu este setat"""
        if self.enabled and self.provider is None:
            self.provider = StubSentimentProvider(self._log)
    
    def set_logger(self, logger: logging.Logger) -> None:
        """Setează logger-ul"""
        self._log = logger
        if isinstance(self.provider, StubSentimentProvider):
            self.provider._log = logger
    
    def fetch(self, symbols: List[str]) -> Dict[str, Any]:
        """
        Fetch sentiment pentru simboluri.
        
        Returns:
            {
                "veto": {SYM: bool},
                "sentiment": {SYM: float [-1..1]},
                "confidence": {SYM: float [0..1]},
                "reasons": {SYM: [str]},
                "events": {SYM: [ {title, ts, source, url, score} ]},
                "metrics": {...},
                "meta": {...}
            }
        """
        self._request_count += 1
        start_time = time.time()
        
        try:
            # Verifică dacă este dezactivat
            if not self.enabled:
                return self._neutral_response(
                    symbols, 
                    meta={"enabled": False, "provider": "disabled"}
                )
            
            # Circuit breaker
            now = time.time()
            if now < self._open_until:
                if self._log:
                    self._log.warning(f"Circuit breaker open until {self._open_until}")
                return self._neutral_response(
                    symbols,
                    meta={
                        "circuit_open": True,
                        "open_until": self._open_until,
                        "fail_count": self._fail_count
                    }
                )
            
            # Limitează numărul de simboluri
            syms = symbols[:self.max_symbols]
            if len(symbols) > self.max_symbols and self._log:
                self._log.warning(f"Limiting symbols from {len(symbols)} to {self.max_symbols}")
            
            # Verifică cache
            cache_key = _cache_key(syms)
            cached_data = self._get_from_cache(cache_key, now)
            
            if cached_data is not None:
                self._cache_hits += 1
                result = self._format_response(cached_data)
                result["meta"]["cache_hit"] = True
                result["meta"]["cache_key"] = cache_key
                
                if self._log:
                    self._log.debug(f"Cache hit for key: {cache_key}")
                
                return result
            
            self._cache_misses += 1
            
            # Fetch de la provider
            if not self.provider:
                raise ValueError("No sentiment provider configured")
            
            sentiment_data = self.provider.fetch_sentiment(syms)
            
            # Salvează în cache
            self._save_to_cache(cache_key, sentiment_data, now)
            
            # Formatează răspunsul
            result = self._format_response(sentiment_data)
            result["meta"].update({
                "cache_hit": False,
                "cache_key": cache_key,
                "provider": self.provider.name
            })
            
            # Resetează circuit breaker la succes
            self._fail_count = 0
            self._open_until = 0.0
            
            return result
            
        except Exception as e:
            # Gestionează eroarea
            self._handle_error(e)
            
            # Returnează răspuns neutru cu informații de eroare
            return self._neutral_response(
                symbols,
                meta={
                    "error": f"{type(e).__name__}: {str(e)}",
                    "fail_count": self._fail_count,
                    "provider": getattr(self.provider, 'name', 'unknown') if self.provider else 'none'
                }
            )
            
        finally:
            # Actualizează metrici
            latency = time.time() - start_time
            self._total_latency += latency
            
            if self._log and self._log.isEnabledFor(logging.DEBUG):
                self._log.debug(f"Request processed in {latency:.3f}s for {len(symbols)} symbols")
    
    def _get_from_cache(self, cache_key: str, current_time: float) -> Optional[Dict[str, SymbolSentiment]]:
        """Obține date din cache"""
        if cache_key in self._cache:
            timestamp, data = self._cache[cache_key]
            if current_time < timestamp + self.ttl_sec:
                return data
        
        return None
    
    def _save_to_cache(self, cache_key: str, data: Dict[str, SymbolSentiment], timestamp: float) -> None:
        """Salvează date în cache"""
        self._cache[cache_key] = (timestamp, data)
        
        # Cleanup cache vechi (LRU simplu)
        if len(self._cache) > 100:  # Max 100 intrări în cache
            oldest_key = None
            oldest_time = float('inf')
            
            for key, (ts, _) in self._cache.items():
                if ts < oldest_time:
                    oldest_time = ts
                    oldest_key = key
            
            if oldest_key:
                del self._cache[oldest_key]
                if self._log:
                    self._log.debug(f"Evicted cache entry: {oldest_key}")
    
    def _format_response(self, sentiment_data: Dict[str, SymbolSentiment]) -> Dict[str, Any]:
        """Formatează datele de sentiment în răspunsul așteptat"""
        result = {
            "veto": {},
            "sentiment": {},
            "confidence": {},
            "reasons": {},
            "events": {},
            "symbol_data": {},
            "metrics": self._get_metrics(),
            "meta": {
                "timestamp": time.time(),
                "cache_size": len(self._cache),
                "request_count": self._request_count
            }
        }
        
        for symbol, data in sentiment_data.items():
            result["veto"][symbol] = data.veto
            result["sentiment"][symbol] = _validate_sentiment_score(data.sentiment_score)
            result["confidence"][symbol] = _validate_confidence(data.confidence)
            result["reasons"][symbol] = data.reasons
            result["events"][symbol] = [e.__dict__ for e in data.events]
            result["symbol_data"][symbol] = data.to_dict()
        
        return result
    
    def _neutral_response(self, symbols: List[str], meta: Dict[str, Any]) -> Dict[str, Any]:
        """Răspuns neutru pentru fallback sau eroare"""
        syms = symbols[:self.max_symbols]
        
        result = {
            "veto": {},
            "sentiment": {},
            "confidence": {},
            "reasons": {},
            "events": {},
            "symbol_data": {},
            "metrics": self._get_metrics(),
            "meta": meta or {}
        }
        
        for symbol in syms:
            base = _sym_base(symbol)
            result["veto"][symbol] = False
            result["sentiment"][symbol] = 0.0
            result["confidence"][symbol] = 0.0
            result["reasons"][symbol] = ["Neutral fallback response"]
            result["events"][symbol] = []
            
            result["symbol_data"][symbol] = SymbolSentiment(
                symbol=symbol,
                base_token=base,
                sentiment_score=0.0,
                confidence=0.0,
                veto=False,
                reasons=["Neutral fallback response"],
                events=[],
                provider="fallback"
            ).to_dict()
        
        result["meta"]["timestamp"] = time.time()
        return result
    
    def _handle_error(self, error: Exception) -> None:
        """Gestionează erori și circuit breaker"""
        self._fail_count += 1
        
        if self._log:
            self._log.error(f"Sentiment fetch error: {error}", exc_info=True)
        
        # Activează circuit breaker dacă depășim threshold-ul
        if self._fail_count >= self.open_after_failures:
            self._open_until = time.time() + self.open_sec
            
            if self._log:
                self._log.warning(
                    f"Circuit breaker opened for {self.open_sec}s "
                    f"after {self._fail_count} failures"
                )
    
    def _get_metrics(self) -> Dict[str, Any]:
        """Returnează metrici de performanță"""
        total_requests = self._cache_hits + self._cache_misses
        cache_hit_rate = self._cache_hits / max(1, total_requests)
        avg_latency = self._total_latency / max(1, self._request_count)
        
        return {
            "cache_hits": self._cache_hits,
            "cache_misses": self._cache_misses,
            "cache_hit_rate": round(cache_hit_rate, 3),
            "total_requests": self._request_count,
            "total_latency_sec": round(self._total_latency, 3),
            "avg_latency_sec": round(avg_latency, 3),
            "fail_count": self._fail_count,
            "circuit_open": time.time() < self._open_until,
            "open_until": self._open_until if self._open_until > 0 else None
        }
    
    def clear_cache(self) -> None:
        """Șterge cache-ul"""
        self._cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0
        
        if self._log:
            self._log.info("Cache cleared")
    
    def reset_circuit_breaker(self) -> None:
        """Resetează circuit breaker-ul"""
        self._fail_count = 0
        self._open_until = 0.0
        
        if self._log:
            self._log.info("Circuit breaker reset")
    
    def get_status(self) -> Dict[str, Any]:
        """Returnează statusul curent al engine-ului"""
        return {
            "enabled": self.enabled,
            "provider": self.provider.name if self.provider else None,
            "cache_size": len(self._cache),
            "circuit_breaker": {
                "fail_count": self._fail_count,
                "open": time.time() < self._open_until,
                "open_until": self._open_until,
                "threshold": self.open_after_failures
            },
            "metrics": self._get_metrics()
        }


# ============================================================================
# FACTORY FUNCTIONS
# ============================================================================

def from_cfg(cfg: Dict[str, Any], log: Optional[logging.Logger] = None) -> CloudSentiment:
    """
    Creează un CloudSentiment engine din configurație.
    
    Configurație exemplu:
    {
        "llm": {
            "cloud": {
                "enabled": true,
                "ttl_sec": 120,
                "max_symbols": 50,
                "open_after_failures": 3,
                "open_sec": 60,
                "provider": "stub",
                "providers": [
                    {
                        "type": "api",
                        "url": "https://api.example.com/sentiment",
                        "api_key": "your_key",
                        "timeout": 10
                    },
                    {
                        "type": "stub"
                    }
                ]
            }
        }
    }
    """
    llm_config = (cfg or {}).get("llm", {}) or {}
    cloud_config = llm_config.get("cloud", {}) or {}
    
    # Configurație de bază
    enabled = _as_bool(cloud_config.get("enabled", False))
    
    if not enabled:
        if log:
            log.info("Cloud sentiment disabled in config")
        return CloudSentiment(enabled=False)
    
    # Creează provideri
    providers_config = cloud_config.get("providers", [])
    providers = []
    
    for provider_cfg in providers_config:
        provider_type = provider_cfg.get("type", "stub")
        
        if provider_type == "stub":
            providers.append(StubSentimentProvider(log))
        
        elif provider_type == "api":
            api_url = provider_cfg.get("url")
            api_key = provider_cfg.get("api_key")
            timeout = _as_float(provider_cfg.get("timeout", 10.0))
            
            if not api_url:
                if log:
                    log.warning("API provider missing URL, skipping")
                continue
            
            providers.append(APISentimentProvider(
                api_url=api_url,
                api_key=api_key,
                timeout=timeout,
                log=log
            ))
        
        else:
            if log:
                log.warning(f"Unknown provider type: {provider_type}")
    
    # Dacă nu sunt provideri, adaugă un stub
    if not providers:
        if log:
            log.info("No providers configured, using stub")
        providers.append(StubSentimentProvider(log))
    
    # Creează fallback provider
    if len(providers) > 1:
        provider = FallbackSentimentProvider(providers, log)
    else:
        provider = providers[0]
    
    # Creează engine
    engine = CloudSentiment(
        enabled=True,
        ttl_sec=_as_float(cloud_config.get("ttl_sec", 120.0)),
        max_symbols=int(cloud_config.get("max_symbols", 50)),
        open_after_failures=int(cloud_config.get("open_after_failures", 3)),
        open_sec=_as_float(cloud_config.get("open_sec", 60.0)),
        provider=provider
    )
    
    # Setează logger
    if log:
        engine.set_logger(log)
        log.info(
            f"Cloud sentiment initialized with provider: {provider.name}, "
            f"TTL: {engine.ttl_sec}s, max symbols: {engine.max_symbols}"
        )
    
    return engine


# ============================================================================
# MAIN FOR TESTING
# ============================================================================

if __name__ == "__main__":
    # Testare
    import sys
    
    # Setup logging
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # Configurație de test
    test_config = {
        "llm": {
            "cloud": {
                "enabled": True,
                "ttl_sec": 30,
                "max_symbols": 10,
                "providers": [
                    {
                        "type": "stub"
                    }
                ]
            }
        }
    }
    
    # Creează engine
    engine = from_cfg(test_config, logger)
    
    # Testează cu câteva simboluri
    test_symbols = ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "XRP/USDT"]
    
    print("Testing CloudSentiment Engine...")
    print(f"Status: {engine.get_status()}")
    print(f"Testing with symbols: {test_symbols}")
    
    # Primul request
    result1 = engine.fetch(test_symbols)
    print(f"\nFirst request cache hit: {result1['meta'].get('cache_hit', False)}")
    print(f"Sentiment for BTC: {result1['sentiment'].get('BTC/USDT')}")
    
    # Al doilea request (ar trebui să fie din cache)
    time.sleep(1)
    result2 = engine.fetch(test_symbols)
    print(f"\nSecond request cache hit: {result2['meta'].get('cache_hit', False)}")
    
    # Afișează metrici
    print(f"\nMetrics: {result2['metrics']}")
    
    # Status final
    print(f"\nFinal status: {engine.get_status()}")
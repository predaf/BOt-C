from __future__ import annotations

import time
import re
import hashlib
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Tuple, Optional


# -----------------------
# Defaults / vocab
# -----------------------

DEFAULT_ASSET_ALIASES: Dict[str, List[str]] = {
    "BTC": ["BTC", "BITCOIN"],
    "ETH": ["ETH", "ETHEREUM"],
    "BNB": ["BNB", "BINANCE", "BINANCE COIN"],
    "SOL": ["SOL", "SOLANA"],
    "XRP": ["XRP", "RIPPLE"],
    "ADA": ["ADA", "CARDANO"],
    "DOGE": ["DOGE", "DOGECOIN"],
}

# You can tune weights; phrases are matched first
DEFAULT_POS_PHRASES = {
    "spot etf": 1.4,
    "etf approval": 1.6,
    "partnership": 1.0,
    "token burn": 1.0,
    "mainnet launch": 1.2,
}
DEFAULT_NEG_PHRASES = {
    "sec lawsuit": 1.6,
    "exchange hack": 1.8,
    "security breach": 1.5,
    "rug pull": 2.0,
}

DEFAULT_POS_WORDS = {
    "surge", "soar", "rally", "record", "bull", "bullish", "pump", "approval",
    "win", "breakout", "partner", "launch", "upgrade", "listing", "integrates",
}
DEFAULT_NEG_WORDS = {
    "crash", "plunge", "dump", "bear", "bearish", "hack", "exploit", "ban",
    "lawsuit", "sec", "fine", "downgrade", "outage", "liquidation", "bankrupt",
    "rug", "fraud",
}

# Token regex: words & common crypto tickers
TOKEN_RE = re.compile(r"[A-Za-z0-9\-\_]+")


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(float(lo), min(float(hi), float(x)))


def _safe_log(log: Any, level: str, msg: str) -> None:
    try:
        fn = getattr(log, level, None)
        if callable(fn):
            fn(msg)
            return
        # fallback
        if hasattr(log, "info") and callable(getattr(log, "info")):
            log.info(msg)
    except Exception:
        pass


def _hash_text(s: str) -> str:
    h = hashlib.sha1()
    h.update((s or "").encode("utf-8", errors="ignore"))
    return h.hexdigest()


def _parse_base_asset(symbol: str) -> str:
    """
    Supports:
      - BTC/USDT
      - BTC/USDT:USDT
      - BTCUSDT
      - BTC-USDT
    Returns base (e.g. BTC).
    """
    s = (symbol or "").strip().upper()

    # strip suffix like :USDT
    if ":" in s:
        s = s.split(":", 1)[0]

    if "/" in s:
        return s.split("/", 1)[0].strip()

    if "-" in s:
        return s.split("-", 1)[0].strip()

    # fallback: assume quote is USDT/BUSD/USDC etc and strip common quote tails
    for q in ("USDT", "USDC", "BUSD", "USD", "EUR"):
        if s.endswith(q) and len(s) > len(q):
            return s[: -len(q)]
    return s


def _tokenize(text: str) -> List[str]:
    tt = (text or "").lower()
    return [t.lower() for t in TOKEN_RE.findall(tt) if t]


def _score_text(
    title: str,
    *,
    pos_words: set,
    neg_words: set,
    pos_phrases: Dict[str, float],
    neg_phrases: Dict[str, float],
) -> Tuple[float, Dict[str, Any]]:
    """
    Score in [-1, +1]. Returns (score, debug).
    Uses:
      - phrase weights (substring)
      - token boundaries for words
    """
    t = (title or "").strip()
    tt = t.lower()
    tokens = set(_tokenize(tt))

    score = 0.0
    hits: Dict[str, Any] = {"pos": [], "neg": []}

    # phrases
    for p, w in (pos_phrases or {}).items():
        if p and p in tt:
            score += float(w)
            hits["pos"].append({"phrase": p, "w": float(w)})
    for p, w in (neg_phrases or {}).items():
        if p and p in tt:
            score -= float(w)
            hits["neg"].append({"phrase": p, "w": float(w)})

    # words by tokens (word boundaries)
    for w in pos_words:
        if w in tokens:
            score += 1.0
            hits["pos"].append({"word": w, "w": 1.0})
    for w in neg_words:
        if w in tokens:
            score -= 1.0
            hits["neg"].append({"word": w, "w": 1.0})

    # clamp raw score to [-3, +3] then normalize
    score = _clamp(score, -3.0, 3.0) / 3.0
    return float(score), {"title": t, "hits": hits, "raw": float(score)}


@dataclass
class AssetScore:
    score: float
    updated_ts: float
    last_titles: List[str]
    last_debug: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class NewsFeed:
    """Lightweight RSS-based news sentiment (best-effort), with caching + dedupe + explain.

    Config:
      news:
        enabled: false
        poll_sec: 300
        timeout_sec: 10
        user_agent: "CryptoBot/1.0"
        sources:
          - https://cointelegraph.com/rss
          - https://www.coindesk.com/arc/outboundfeeds/rss/
        aliases: { "BTC": ["BTC","BITCOIN"], ... }   # optional override/extend
        pos_words: [...]
        neg_words: [...]
        pos_phrases: {...}
        neg_phrases: {...}
        title_dedupe_ttl_sec: 21600   # 6h
        max_titles_per_poll: 120
        per_title_weight: 0.25
        half_life_hours: 6
    """

    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log

        ncfg = (self.cfg.get("news") or {}) if isinstance(self.cfg.get("news"), dict) else {}
        self.enabled = bool(ncfg.get("enabled", False))
        self.poll_sec = float(ncfg.get("poll_sec", 300) or 300.0)
        self.timeout_sec = float(ncfg.get("timeout_sec", 10) or 10.0)
        self.user_agent = str(ncfg.get("user_agent", "CryptoBot/1.0")).strip() or "CryptoBot/1.0"

        self.sources: List[str] = list(ncfg.get("sources") or [])
        if not self.sources:
            self.sources = [
                "https://cointelegraph.com/rss",
                "https://www.coindesk.com/arc/outboundfeeds/rss/",
            ]

        # vocab/aliases (merge defaults + user overrides)
        aliases_cfg = ncfg.get("aliases") or {}
        self.aliases: Dict[str, List[str]] = {k: list(v) for k, v in DEFAULT_ASSET_ALIASES.items()}
        if isinstance(aliases_cfg, dict):
            for k, v in aliases_cfg.items():
                kk = str(k).upper().strip()
                if isinstance(v, (list, tuple)):
                    self.aliases[kk] = [str(x).upper().strip() for x in v if str(x).strip()]
                elif isinstance(v, str) and v.strip():
                    self.aliases[kk] = [v.upper().strip()]

        self.pos_words = set([str(x).lower() for x in (ncfg.get("pos_words") or DEFAULT_POS_WORDS)])
        self.neg_words = set([str(x).lower() for x in (ncfg.get("neg_words") or DEFAULT_NEG_WORDS)])
        self.pos_phrases = dict(ncfg.get("pos_phrases") or DEFAULT_POS_PHRASES)
        self.neg_phrases = dict(ncfg.get("neg_phrases") or DEFAULT_NEG_PHRASES)

        self.title_dedupe_ttl_sec = float(ncfg.get("title_dedupe_ttl_sec", 6 * 3600) or (6 * 3600))
        self.max_titles_per_poll = int(ncfg.get("max_titles_per_poll", 120) or 120)
        self.per_title_weight = float(ncfg.get("per_title_weight", 0.25) or 0.25)

        self.half_life_hours = float(ncfg.get("half_life_hours", 6.0) or 6.0)
        self._half_life_sec = max(60.0, self.half_life_hours * 3600.0)

        self._last_poll = 0.0

        # asset -> AssetScore
        self._scores: Dict[str, AssetScore] = {}

        # title hash -> last_seen_ts (dedupe)
        self._seen: Dict[str, float] = {}

        # rss http cache: url -> {etag,last_modified,last_ts}
        self._rss_cache: Dict[str, Dict[str, Any]] = {}

    # -----------------------
    # HTTP fetch with ETag/Last-Modified
    # -----------------------
    def _fetch_rss(self, url: str) -> List[str]:
        try:
            headers = {"User-Agent": self.user_agent, "Accept": "application/rss+xml, application/xml;q=0.9,*/*;q=0.8"}

            cache = self._rss_cache.get(url) or {}
            if cache.get("etag"):
                headers["If-None-Match"] = str(cache["etag"])
            if cache.get("last_modified"):
                headers["If-Modified-Since"] = str(cache["last_modified"])

            req = urllib.request.Request(url, headers=headers, method="GET")
            try:
                with urllib.request.urlopen(req, timeout=float(self.timeout_sec)) as r:
                    status = getattr(r, "status", 200)
                    if int(status) == 304:
                        return []  # not modified
                    data = r.read()
                    etag = r.headers.get("ETag")
                    lm = r.headers.get("Last-Modified")
                    self._rss_cache[url] = {"etag": etag, "last_modified": lm, "last_ts": time.time()}
            except urllib.error.HTTPError as he:
                if he.code == 304:
                    return []
                raise

            root = ET.fromstring(data)
            titles = []
            for item in root.findall(".//item/title"):
                if item is not None and item.text:
                    t = item.text.strip()
                    if t:
                        titles.append(t)
            return titles[:50]
        except Exception:
            return []

    # -----------------------
    # main loop
    # -----------------------
    def tick(self) -> None:
        if not self.enabled:
            return
        now = time.time()
        if (now - float(self._last_poll)) < float(self.poll_sec):
            return
        self._last_poll = now

        # fetch titles
        titles: List[str] = []
        for src in self.sources:
            titles.extend(self._fetch_rss(src))

        if not titles:
            return

        # keep within cap
        titles = titles[: int(self.max_titles_per_poll)]

        # cleanup seen
        if self.title_dedupe_ttl_sec > 0:
            cutoff = now - float(self.title_dedupe_ttl_sec)
            for k, ts in list(self._seen.items()):
                if float(ts) < cutoff:
                    self._seen.pop(k, None)

        # decay existing scores
        for a, st in list(self._scores.items()):
            age = max(0.0, now - float(st.updated_ts))
            decay = 0.5 ** (age / float(self._half_life_sec))
            st.score = float(st.score) * float(decay)
            # keep updated_ts as-is; decay is based on age since last update
            self._scores[a] = st

        # update per title
        updated_any = False
        for t in titles:
            th = _hash_text(t)
            if self.title_dedupe_ttl_sec > 0 and th in self._seen:
                continue
            self._seen[th] = now

            st, debug = _score_text(
                t,
                pos_words=self.pos_words,
                neg_words=self.neg_words,
                pos_phrases=self.pos_phrases,
                neg_phrases=self.neg_phrases,
            )
            if st == 0.0:
                continue

            up = t.upper()
            for asset, aliases in self.aliases.items():
                if any(a in up for a in aliases):
                    prev = self._scores.get(asset)
                    if prev is None:
                        prev = AssetScore(score=0.0, updated_ts=now, last_titles=[], last_debug=[])
                    prev.score = float(_clamp(prev.score + float(st) * float(self.per_title_weight), -1.0, 1.0))
                    prev.updated_ts = now
                    # store last titles for explain (bounded)
                    prev.last_titles.append(t)
                    prev.last_titles = prev.last_titles[-30:]
                    prev.last_debug.append(debug)
                    prev.last_debug = prev.last_debug[-30:]
                    self._scores[asset] = prev
                    updated_any = True

        if updated_any:
            _safe_log(self.log, "info", "NewsFeed: updated")

    def score_for_symbol(self, symbol: str, explain: bool = False) -> Any:
        """
        symbol can be 'BTC/USDT' or 'BTC/USDT:USDT' or 'BTCUSDT'
        returns score in [-1,1] or dict if explain=True
        """
        base = _parse_base_asset(symbol)
        st = self._scores.get(base)
        score = float(st.score) if st else 0.0
        score = float(_clamp(score, -1.0, 1.0))

        if not explain:
            return float(score)

        return {
            "base": base,
            "score": float(score),
            "updated_ts": float(st.updated_ts) if st else 0.0,
            "last_titles": list(st.last_titles) if st else [],
            "last_debug": list(st.last_debug) if st else [],
        }

    def last_titles(self, asset: str) -> List[str]:
        a = str(asset).upper().strip()
        st = self._scores.get(a)
        return list(st.last_titles) if st else []

    def status(self) -> Dict[str, Any]:
        return {
            "enabled": bool(self.enabled),
            "poll_sec": float(self.poll_sec),
            "timeout_sec": float(self.timeout_sec),
            "sources": list(self.sources),
            "assets_tracked": int(len(self._scores)),
            "last_poll_ts": float(self._last_poll),
            "seen_titles": int(len(self._seen)),
        }

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, Tuple, Optional, List
import math
import time


# -----------------------------
# Data models
# -----------------------------
@dataclass
class PaperPosition:
    symbol: str
    qty: float      # >0 long, <0 short
    avg_price: float

    def side(self) -> str:
        return "long" if self.qty > 0 else "short"

    def abs_qty(self) -> float:
        return float(abs(self.qty))


@dataclass
class PaperFill:
    ts: float
    symbol: str
    side: str           # "buy"|"sell"
    qty: float
    price: float
    maker: bool
    fee: float
    realized_gross: float


# -----------------------------
# Portfolio
# -----------------------------
class PaperPortfolio:
    """
    PaperPortfolio (spot-like PnL model with short support via negative qty).

    Accounting model:
      - Cash is debited on BUY and credited on SELL (minus fees).
      - Positions are tracked with signed quantity:
          long: qty > 0
          short: qty < 0
      - Equity is computed as:
          equity = cash + Σ(qty * mark_price)
        which works naturally for shorts (qty negative => reduces equity by buyback cost).

    Optional realism features (cfg.paper.*):
      - enforce_cash: bool (default True) -> rejects BUY if cash insufficient
      - enable_margin: bool (default False) -> allow negative cash and enforce max_leverage
      - max_leverage: float (default 3.0) -> |gross_notional| <= equity * max_leverage
      - min_notional: float (default 5.0) -> rejects fills below this notional
      - qty_step: float (default 0.0) -> rounds qty down to step
      - price_step: float (default 0.0) -> rounds price to step
      - keep_last_fills: int (default 200) -> in-memory audit for UI/debug
    """

    def __init__(self, cfg: Dict[str, Any]):
        paper = (cfg.get("paper") or {}) if isinstance(cfg.get("paper"), dict) else {}

        self.initial_cash = float(paper.get("initial_cash_quote", 0.0) or 0.0)
        self.cash = float(paper.get("initial_cash_quote", 0.0) or 0.0)

        self.positions: Dict[str, PaperPosition] = {}

        self.realized_pnl_gross = 0.0   # excludes fees
        self.fees_paid = 0.0

        self.taker_fee = float(paper.get("taker_fee_rate", 0.0006) or 0.0006)
        self.maker_fee = float(paper.get("maker_fee_rate", 0.0002) or 0.0002)

        self.market_slip_bps = float(paper.get("market_slippage_bps", 2.0) or 2.0)
        self.limit_slip_bps = float(paper.get("limit_slippage_bps", 0.5) or 0.5)

        # realism controls
        self.enforce_cash = bool(paper.get("enforce_cash", True))
        self.enable_margin = bool(paper.get("enable_margin", False))
        self.max_leverage = float(paper.get("max_leverage", 3.0) or 3.0)

        self.min_notional = float(paper.get("min_notional", 0.0) or 0.0)
        self.qty_step = float(paper.get("qty_step", 0.0) or 0.0)
        self.price_step = float(paper.get("price_step", 0.0) or 0.0)

        self.keep_last_fills = int(paper.get("keep_last_fills", 200) or 200)
        self.fills: List[PaperFill] = []

    # -----------------------------
    # Small utilities
    # -----------------------------
    @staticmethod
    def _now() -> float:
        return float(time.time())

    @staticmethod
    def _round_down(x: float, step: float) -> float:
        if step <= 0:
            return float(x)
        return float(math.floor(float(x) / float(step)) * float(step))

    def _fee_rate(self, maker: bool) -> float:
        return float(self.maker_fee if maker else self.taker_fee)

    def _slip(self, price: float, side: str, maker: bool) -> float:
        """
        Apply slippage in basis points.
          - Buy: increases price
          - Sell: decreases price
        """
        bps = float(self.limit_slip_bps if maker else self.market_slip_bps)
        if side == "buy":
            return float(price) * (1.0 + (bps / 10000.0))
        return float(price) * (1.0 - (bps / 10000.0))

    def _append_fill(self, fill: PaperFill) -> None:
        self.fills.append(fill)
        if self.keep_last_fills > 0 and len(self.fills) > self.keep_last_fills:
            self.fills = self.fills[-self.keep_last_fills :]

    # -----------------------------
    # Core portfolio state helpers
    # -----------------------------
    def has_position(self, symbol: str) -> bool:
        return symbol in self.positions and abs(self.positions[symbol].qty) > 1e-12

    def get_position(self, symbol: str) -> Optional[PaperPosition]:
        p = self.positions.get(symbol)
        if not p or abs(p.qty) <= 1e-12:
            return None
        return p

    def reset(self) -> None:
        self.cash = float(self.initial_cash)
        self.positions = {}
        self.realized_pnl_gross = 0.0
        self.fees_paid = 0.0
        self.fills = []

    # -----------------------------
    # Equity / exposure / PnL
    # -----------------------------
    def equity(self, mark_prices: Dict[str, float]) -> float:
        eq = float(self.cash)
        for sym, pos in self.positions.items():
            px = mark_prices.get(sym)
            if px is None or float(px) <= 0:
                continue
            eq += float(pos.qty) * float(px)
        return float(eq)

    def gross_notional(self, mark_prices: Dict[str, float]) -> float:
        """Sum of |qty| * mark (exposure magnitude)."""
        tot = 0.0
        for sym, pos in self.positions.items():
            px = mark_prices.get(sym)
            if px is None or float(px) <= 0:
                continue
            tot += abs(float(pos.qty)) * float(px)
        return float(tot)

    def unrealized_pnl(self, mark_prices: Dict[str, float]) -> float:
        upnl = 0.0
        for sym, pos in self.positions.items():
            px = mark_prices.get(sym)
            if px is None or float(px) <= 0:
                continue
            upnl += float(pos.qty) * (float(px) - float(pos.avg_price))
        return float(upnl)

    def net_pnl(self, mark_prices: Dict[str, float]) -> float:
        return float(self.equity(mark_prices) - self.initial_cash)

    def realized_pnl_net(self) -> float:
        return float(self.realized_pnl_gross - self.fees_paid)

    # -----------------------------
    # Constraints / guards
    # -----------------------------
    def _check_min_notional(self, notional: float) -> None:
        if self.min_notional > 0 and float(notional) < float(self.min_notional):
            raise ValueError(f"paper: notional too small ({notional:.8f} < {self.min_notional})")

    def _check_cash_for_buy(self, cost_with_fee: float) -> None:
        if self.enable_margin:
            return
        if self.enforce_cash and float(self.cash) + 1e-12 < float(cost_with_fee):
            raise ValueError(f"paper: insufficient cash for buy (cash={self.cash:.8f}, need={cost_with_fee:.8f})")

    def _check_leverage(self, mark_prices: Dict[str, float], extra_symbol: str, extra_qty: float, extra_price: float) -> None:
        """
        If enable_margin=True, enforce |gross_notional| <= equity * max_leverage.
        Uses best-effort mark prices; if missing, uses extra_price for extra_symbol.
        """
        if not self.enable_margin:
            return
        if self.max_leverage <= 0:
            return

        # build a temporary exposure estimate
        eq = self.equity(mark_prices)
        if eq <= 0:
            raise ValueError("paper: equity <= 0, cannot increase exposure in margin mode")

        exposure = self.gross_notional(mark_prices)

        # incorporate extra exposure (approx)
        px = mark_prices.get(extra_symbol)
        px_use = float(px) if px is not None and float(px) > 0 else float(extra_price)
        exposure += abs(float(extra_qty)) * float(px_use)

        if exposure > float(eq) * float(self.max_leverage) + 1e-9:
            raise ValueError(
                f"paper: max_leverage exceeded (exposure={exposure:.8f} > equity*lev={eq*self.max_leverage:.8f})"
            )

    # -----------------------------
    # Trading operations (core)
    # -----------------------------
    def execute(
        self,
        symbol: str,
        side: str,
        qty: float,
        price: float,
        maker: bool,
        *,
        mark_prices_for_risk: Optional[Dict[str, float]] = None,
    ) -> Tuple[float, float, float, float]:
        """
        Unified executor.

        side: "buy" or "sell"
        qty: > 0
        price: > 0

        Returns: (fill_price, fee_paid, realized_pnl_gross, executed_qty)
        """
        side = str(side).lower().strip()
        if side not in ("buy", "sell"):
            raise ValueError(f"paper.execute(): invalid side={side}")
        if qty <= 0:
            raise ValueError(f"paper.execute(): qty must be > 0, got {qty}")
        if price <= 0:
            raise ValueError(f"paper.execute(): price must be > 0, got {price}")

        # rounding
        qty2 = self._round_down(float(qty), float(self.qty_step))
        if qty2 <= 0:
            raise ValueError(f"paper.execute(): qty after rounding is 0 (qty={qty}, step={self.qty_step})")

        px0 = float(price)
        px0 = self._round_down(px0, float(self.price_step)) if self.price_step > 0 else px0
        if px0 <= 0:
            raise ValueError("paper.execute(): price after rounding invalid")

        fill = float(self._slip(px0, side, maker))
        notional = float(qty2) * float(fill)
        self._check_min_notional(notional)

        fee = float(notional) * float(self._fee_rate(maker))
        realized = 0.0

        # leverage check (approx exposure increment)
        marks = mark_prices_for_risk or {}
        # extra_qty sign: buy increases position qty, sell decreases qty; but for exposure we take abs anyway
        self._check_leverage(marks, symbol, qty2, fill)

        if side == "buy":
            # Pay for buy + fee
            self._check_cash_for_buy(notional + fee)
            self.cash -= notional
            self.cash -= fee
            self.fees_paid += fee

            pos = self.positions.get(symbol)
            if not pos:
                # New long
                self.positions[symbol] = PaperPosition(symbol, float(qty2), float(fill))

            elif pos.qty >= 0:
                # Add to long (VWAP)
                new_qty = float(pos.qty) + float(qty2)
                pos.avg_price = (float(pos.qty) * float(pos.avg_price) + float(qty2) * float(fill)) / max(1e-12, new_qty)
                pos.qty = new_qty

            else:
                # Cover short
                cover_qty = min(float(qty2), abs(float(pos.qty)))
                remain_buy = float(qty2) - cover_qty

                # Short PnL (gross): (entry - exit) * covered_qty
                realized = (float(pos.avg_price) - float(fill)) * float(cover_qty)
                self.realized_pnl_gross += float(realized)

                pos.qty = float(pos.qty) + float(cover_qty)  # less negative
                if abs(float(pos.qty)) < 1e-12:
                    del self.positions[symbol]
                    if remain_buy > 1e-12:
                        # flip to long
                        self.positions[symbol] = PaperPosition(symbol, float(remain_buy), float(fill))

        else:  # sell
            # Receive proceeds from sell - fee
            self.cash += notional
            self.cash -= fee
            self.fees_paid += fee

            pos = self.positions.get(symbol)
            if not pos:
                # New short
                self.positions[symbol] = PaperPosition(symbol, -float(qty2), float(fill))

            elif pos.qty <= 0:
                # Add to short (VWAP on abs qty)
                current_abs = abs(float(pos.qty))
                new_abs = current_abs + float(qty2)
                pos.avg_price = (current_abs * float(pos.avg_price) + float(qty2) * float(fill)) / max(1e-12, new_abs)
                pos.qty = float(pos.qty) - float(qty2)  # more negative

            else:
                # Close long
                close_qty = min(float(qty2), float(pos.qty))
                remain_sell = float(qty2) - close_qty

                realized = (float(fill) - float(pos.avg_price)) * float(close_qty)
                self.realized_pnl_gross += float(realized)

                pos.qty = float(pos.qty) - float(close_qty)
                if float(pos.qty) < 1e-12:
                    del self.positions[symbol]
                    if remain_sell > 1e-12:
                        # flip to short
                        self.positions[symbol] = PaperPosition(symbol, -float(remain_sell), float(fill))

        # audit fill
        self._append_fill(
            PaperFill(
                ts=self._now(),
                symbol=str(symbol),
                side=str(side),
                qty=float(qty2),
                price=float(fill),
                maker=bool(maker),
                fee=float(fee),
                realized_gross=float(realized),
            )
        )

        executed_qty = float(qty2)
        return float(fill), float(fee), float(realized), executed_qty

    # Backwards-compatible wrappers
    def buy(self, symbol: str, qty: float, price: float, maker: bool) -> Tuple[float, float, float, float]:
        return self.execute(symbol, "buy", qty, price, maker)

    def sell(self, symbol: str, qty: float, price: float, maker: bool) -> Tuple[float, float, float, float]:
        return self.execute(symbol, "sell", qty, price, maker)

    # -----------------------------
    # Convenience operations
    # -----------------------------
    def close_all(self, mark_prices: Dict[str, float], maker: bool = False) -> Dict[str, Any]:
        """
        Close all positions at mark (with slippage + fees).
        Returns summary.
        """
        closed = 0
        realized = 0.0
        fees = 0.0
        # copy keys because execute mutates positions
        for sym in list(self.positions.keys()):
            pos = self.positions.get(sym)
            if not pos:
                continue
            px = mark_prices.get(sym)
            if px is None or float(px) <= 0:
                continue
            if pos.qty > 0:
                _, f, r, _ = self.sell(sym, abs(pos.qty), float(px), maker)
            else:
                _, f, r, _ = self.buy(sym, abs(pos.qty), float(px), maker)
            closed += 1
            realized += float(r)
            fees += float(f)
        return {"closed": int(closed), "realized_gross": float(realized), "fees": float(fees)}

    # -----------------------------
    # Persistence / UI snapshots
    # -----------------------------
    def snapshot(self, mark_prices: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        mp = mark_prices or {}
        eq = self.equity(mp) if mp else float(self.cash)  # best-effort if no marks
        return {
            "initial_cash": float(self.initial_cash),
            "cash": float(self.cash),
            "equity": float(eq),
            "realized_pnl_gross": float(self.realized_pnl_gross),
            "fees_paid": float(self.fees_paid),
            "realized_pnl_net": float(self.realized_pnl_net()),
            "positions": [
                {
                    "symbol": p.symbol,
                    "side": p.side(),
                    "qty": float(abs(p.qty)),
                    "signed_qty": float(p.qty),
                    "avg_price": float(p.avg_price),
                }
                for p in self.positions.values()
                if abs(p.qty) > 1e-12
            ],
            "last_fills": [
                {
                    "ts": float(f.ts),
                    "symbol": f.symbol,
                    "side": f.side,
                    "qty": float(f.qty),
                    "price": float(f.price),
                    "maker": bool(f.maker),
                    "fee": float(f.fee),
                    "realized_gross": float(f.realized_gross),
                }
                for f in (self.fills[-20:] if self.fills else [])
            ],
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "initial_cash": float(self.initial_cash),
            "cash": float(self.cash),
            "positions": {
                k: {"symbol": v.symbol, "qty": float(v.qty), "avg_price": float(v.avg_price)}
                for k, v in self.positions.items()
            },
            "realized_pnl_gross": float(self.realized_pnl_gross),
            "fees_paid": float(self.fees_paid),
            "fills": [
                {
                    "ts": float(f.ts),
                    "symbol": f.symbol,
                    "side": f.side,
                    "qty": float(f.qty),
                    "price": float(f.price),
                    "maker": bool(f.maker),
                    "fee": float(f.fee),
                    "realized_gross": float(f.realized_gross),
                }
                for f in self.fills
            ],
        }

    @staticmethod
    def from_dict(cfg: Dict[str, Any], d: Dict[str, Any]) -> "PaperPortfolio":
        p = PaperPortfolio(cfg)
        p.initial_cash = float(d.get("initial_cash", p.initial_cash))
        p.cash = float(d.get("cash", p.cash))
        p.realized_pnl_gross = float(d.get("realized_pnl_gross", 0.0))
        p.fees_paid = float(d.get("fees_paid", 0.0))

        pos_data = d.get("positions", {}) or {}
        if isinstance(pos_data, dict):
            for k, v in pos_data.items():
                if not isinstance(v, dict):
                    continue
                p.positions[str(k)] = PaperPosition(
                    symbol=str(v.get("symbol", k)),
                    qty=float(v.get("qty", 0.0) or 0.0),
                    avg_price=float(v.get("avg_price", 0.0) or 0.0),
                )

        fills = d.get("fills", []) or []
        if isinstance(fills, list):
            out: List[PaperFill] = []
            for it in fills:
                if not isinstance(it, dict):
                    continue
                out.append(
                    PaperFill(
                        ts=float(it.get("ts", 0.0) or 0.0),
                        symbol=str(it.get("symbol", "")),
                        side=str(it.get("side", "")),
                        qty=float(it.get("qty", 0.0) or 0.0),
                        price=float(it.get("price", 0.0) or 0.0),
                        maker=bool(it.get("maker", False)),
                        fee=float(it.get("fee", 0.0) or 0.0),
                        realized_gross=float(it.get("realized_gross", 0.0) or 0.0),
                    )
                )
            p.fills = out[-p.keep_last_fills :] if p.keep_last_fills > 0 else out

        return p
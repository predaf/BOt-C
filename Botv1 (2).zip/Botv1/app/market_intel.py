from __future__ import annotations

import os
import time
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional, TypedDict
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd

from .data_validator import DataValidator
from .indicators import atr, ema
from .micro_model import orderbook_metrics, expected_market_slippage_bps
from .portfolio import corr_ok


# ============================================================================
# TYPES AND DATA CLASSES
# ============================================================================

class ScoreComponent(Enum):
    """Componente ale sistemului de scoring"""
    ATR = "atr"
    TREND = "trend"
    LIQUIDITY = "liquidity"
    CORRELATION = "correlation"
    VOLUME = "volume"


class IntelConfig(TypedDict, total=False):
    """Tip pentru configurația pipeline-ului"""
    enabled: bool
    refresh_sec: float
    watchlist_size: int
    universe_max: int
    min_quote_volume: float
    timeframe: str
    lookback: int
    prefilter_topk: int
    ema_fast: int
    ema_slow: int
    spread_bps_bad: float
    slippage_bps_bad: float
    slippage_notional_usd: float
    missing_ob_penalty: float
    atr_pct_ref: float
    trend_ref: float
    corr_penalty: float
    tickers_ttl: float
    max_workers: int
    weights: Dict[str, float]


@dataclass
class WatchlistItem:
    """Element al watchlist-ului cu scor și motive"""
    symbol: str
    score: float
    reasons: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)


@dataclass
class PipelineMetrics:
    """Metrici pentru monitorizarea performanței pipeline-ului"""
    execution_time: float = 0.0
    symbols_analyzed: int = 0
    symbols_passed: int = 0
    api_calls: int = 0
    errors: List[str] = field(default_factory=list)
    cache_hits: int = 0
    cache_misses: int = 0
    start_time: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertire metrici în dicționar"""
        return {
            "execution_time_sec": round(self.execution_time, 3),
            "symbols_analyzed": self.symbols_analyzed,
            "symbols_passed": self.symbols_passed,
            "success_rate": round(self.symbols_passed / max(1, self.symbols_analyzed), 3),
            "api_calls": self.api_calls,
            "cache_hit_rate": round(
                self.cache_hits / max(1, self.cache_hits + self.cache_misses), 3
            ),
            "errors_count": len(self.errors),
            "errors": self.errors[:5]  # Primele 5 erori
        }


# ============================================================================
# UTILITARE
# ============================================================================

def _safe_float(x: Any, d: float = 0.0) -> float:
    """Convertire sigură la float"""
    try:
        if x is None:
            return float(d)
        return float(x)
    except (ValueError, TypeError):
        return float(d)


def _safe_int(x: Any, d: int = 0) -> int:
    """Convertire sigură la int"""
    try:
        return int(x)
    except (ValueError, TypeError):
        return int(d)


def _clamp(x: float, lo: float, hi: float) -> float:
    """Limitare valoare între min și max"""
    return max(float(lo), min(float(hi), float(x)))


def _norm_symbol(sym: str) -> str:
    """
    Normalizează simboluri CCXT futures.
    ATENȚIE: Nu folosi acest simbol normalizat pentru tranzacționare.
    """
    s = str(sym or "").strip()
    if ":" in s:
        s = s.split(":", 1)[0]
    return s


def _sigmoid_norm(x: float, scale: float = 1.0) -> float:
    """Normalizare sigmoid pentru a evita valori extreme"""
    return 2.0 / (1.0 + np.exp(-x / max(1e-12, scale))) - 1.0


# ============================================================================
# CIRCUIT BREAKER
# ============================================================================

class CircuitBreaker:
    """Circuit breaker pentru apeluri API cu protecție la rate limiting"""
    
    def __init__(self, failure_threshold: int = 5, reset_timeout: int = 60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self._lock = threading.RLock()
    
    def execute(self, func, *args, **kwargs) -> Any:
        """Execută o funcție cu circuit breaker"""
        with self._lock:
            current_time = time.time()
            
            if self.state == "OPEN":
                if current_time - self.last_failure_time > self.reset_timeout:
                    self.state = "HALF_OPEN"
                    self.logger.debug("Circuit breaker moving to HALF_OPEN")
                else:
                    raise Exception(f"Circuit breaker OPEN (cooldown: {self.reset_timeout}s)")
            
            try:
                result = func(*args, **kwargs)
                self._on_success()
                return result
            except Exception as e:
                self._on_failure()
                raise e
    
    def _on_success(self):
        """Handler pentru succes"""
        with self._lock:
            if self.state == "HALF_OPEN":
                self.state = "CLOSED"
            self.failure_count = 0
    
    def _on_failure(self):
        """Handler pentru eșec"""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
    
    def reset(self):
        """Resetează circuit breaker-ul"""
        with self._lock:
            self.state = "CLOSED"
            self.failure_count = 0
            self.last_failure_time = 0


# ============================================================================
# PIPELINE PRINCIPAL
# ============================================================================

class MarketIntelligencePipeline:
    """
    Market Intelligence Pipeline: date -> verificări calitate -> scoring -> selecție.
    
    Proiectat pentru viteză și degradare grațioasă în cazul lipsei datelor.
    """
    
    def __init__(self, cfg: Dict[str, Any], log: Any):
        """Initializează pipeline-ul cu configurație și logger"""
        self.cfg = self._merge_with_env(cfg or {})
        self.log = log
        self.validator = DataValidator()
        
        # Stare cache
        self._last_watchlist: List[str] = []
        self._last_reasons: Dict[str, Any] = {}
        self._last_ts: float = 0.0
        
        # Cache pentru tickers
        self._cached_tickers: Dict[str, Any] = {}
        self._cached_tickers_ts: float = 0.0
        
        # Circuit breakers
        self._tickers_cb = CircuitBreaker(
            failure_threshold=int(self.cfg.get("intel", {}).get("cb_failure_threshold", 3)),
            reset_timeout=int(self.cfg.get("intel", {}).get("cb_reset_timeout", 30))
        )
        self._tickers_cb.logger = log
        
        # Metrice
        self.metrics = PipelineMetrics()
        
        # Validare configurație
        self._validate_config()
        
        self.log.info(f"MarketIntelligencePipeline initializat cu {len(self._get_universe_config())} simboluri maxime")
    
    # ============================================================================
    # METODE PUBLICE
    # ============================================================================
    
    def last(self) -> Tuple[List[str], Dict[str, Any], float]:
        """Returnează ultima watchlist generată cu timestamp"""
        return list(self._last_watchlist), dict(self._last_reasons), float(self._last_ts)
    
    def build(self, engine: Any, force: bool = False) -> Tuple[List[str], Dict[str, Any]]:
        """
        Construiește watchlist-ul bazat pe analiza pieței.
        
        Args:
            engine: Motorul de trading
            force: Forțează regenerarea (ignoră cache)
        
        Returns:
            Tuple cu (watchlist, reasons)
        """
        # Reset metrici
        self.metrics = PipelineMetrics()
        
        try:
            intel_cfg = self.cfg.get("intel", {})
            
            # Verifică dacă e dezactivat
            if not bool(intel_cfg.get("enabled", True)):
                self.log.info("Market intelligence dezactivat, folosind fallback")
                return self._fallback(engine)
            
            # Verifică cache
            ttl = float(intel_cfg.get("refresh_sec", 60))
            now = time.time()
            
            if not force and self._last_watchlist and (now - self._last_ts) <= ttl:
                self.metrics.cache_hits += 1
                self.log.debug(f"Folosind cache (TTL: {ttl}s, rămas: {ttl - (now - self._last_ts):.1f}s)")
                return list(self._last_watchlist), dict(self._last_reasons)
            
            self.metrics.cache_misses += 1
            
            # Obține configurații
            config = self._get_build_config(intel_cfg)
            
            # Construiește universul
            symbols = self._universe(engine, max_symbols=config["universe_n"])
            if not symbols:
                self.log.warning("Niciun simbol în univers, folosind fallback")
                return self._fallback(engine)
            
            self.log.info(f"Analizând {len(symbols)} simboluri din univers")
            
            # Obține tickers
            tickers = self._tickers(engine, symbols)
            if not tickers:
                self.log.warning("Niciun ticker disponibil, folosind fallback")
                return self._fallback(engine)
            
            # Faza 1: Pre-filtrare după volum
            vol_rank = self._prefilter_by_volume(symbols, tickers, config["min_qv"])
            if not vol_rank:
                self.log.warning("Niciun simbol cu volum suficient, folosind fallback")
                return self._fallback(engine)
            
            # Reducere la topk pentru analiza OHLCV
            vol_rank = vol_rank[:config["prefilter_topk"]]
            pre_symbols = [s for (s, _) in vol_rank]
            
            self.log.info(f"Prefiltrare: {len(pre_symbols)} simboluri pentru analiză detaliată")
            
            # Faza 2: Analiză detaliată
            if config.get("parallel_processing", True) and len(pre_symbols) > 5:
                candidates = self._analyze_symbols_parallel(
                    pre_symbols, vol_rank, engine, config
                )
            else:
                candidates = self._analyze_symbols_sequential(
                    pre_symbols, vol_rank, engine, config
                )
            
            # Sortează și selectează
            watchlist, reasons_map = self._select_watchlist(candidates, config["limit"])
            
            # Update cache
            self._last_watchlist = list(watchlist)
            self._last_reasons = dict(reasons_map)
            self._last_ts = time.time()
            
            # Calcul metrici finale
            self.metrics.execution_time = time.time() - self.metrics.start_time
            self.metrics.symbols_passed = len(watchlist)
            
            # Log metrici
            self._log_metrics(watchlist)
            
            return list(watchlist), dict(reasons_map)
            
        except Exception as e:
            self.metrics.errors.append(str(e))
            self.log.error(f"Eroare în build: {e}", exc_info=True)
            return self._fallback(engine)
    
    # ============================================================================
    # METODE PRIVATE - HELPERS
    # ============================================================================
    
    def _merge_with_env(self, cfg: Dict[str, Any]) -> Dict[str, Any]:
        """Combină configurația cu variabile de mediu"""
        env_mapping = {
            "MARKET_INTEL_ENABLED": ("intel", "enabled", bool),
            "MARKET_INTEL_WATCHLIST_SIZE": ("intel", "watchlist_size", int),
            "MARKET_INTEL_REFRESH_SEC": ("intel", "refresh_sec", float),
            "MARKET_INTEL_MIN_VOLUME": ("intel", "min_quote_volume", float),
            "MARKET_INTEL_MAX_WORKERS": ("intel", "max_workers", int),
            "MARKET_INTEL_PARALLEL": ("intel", "parallel_processing", bool),
        }
        
        for env_var, (section, key, conv_type) in env_mapping.items():
            if env_var in os.environ:
                value = os.environ[env_var]
                try:
                    if conv_type == bool:
                        value = value.lower() in ("true", "1", "yes", "on")
                    else:
                        value = conv_type(value)
                    
                    if section not in cfg:
                        cfg[section] = {}
                    cfg[section][key] = value
                    self.log.debug(f"Config override din {env_var}: {key}={value}")
                except ValueError as e:
                    self.log.warning(f"Variabilă de mediu invalidă {env_var}: {e}")
        
        return cfg
    
    def _validate_config(self):
        """Validare configurație și setare valori default"""
        intel_cfg = self.cfg.get("intel", {})
        
        required_defaults = {
            "enabled": (bool, True),
            "refresh_sec": ((int, float), 60.0),
            "watchlist_size": (int, 15),
            "universe_max": (int, 250),
            "min_quote_volume": ((int, float), 1_000_000.0),
            "timeframe": (str, "5m"),
            "lookback": (int, 240),
            "prefilter_topk": (int, 60),
            "ema_fast": (int, 20),
            "ema_slow": (int, 80),
            "spread_bps_bad": (float, 25.0),
            "slippage_bps_bad": (float, 40.0),
            "slippage_notional_usd": (float, 250.0),
            "missing_ob_penalty": (float, 0.08),
            "atr_pct_ref": (float, 0.02),
            "trend_ref": (float, 0.01),
            "corr_penalty": (float, 0.25),
            "tickers_ttl": (float, 10.0),
            "max_workers": (int, min(32, (os.cpu_count() or 1) + 4)),
            "parallel_processing": (bool, True),
            "cb_failure_threshold": (int, 3),
            "cb_reset_timeout": (int, 30),
        }
        
        for key, (expected_type, default) in required_defaults.items():
            if key not in intel_cfg:
                intel_cfg[key] = default
            elif not isinstance(intel_cfg[key], expected_type):
                self.log.warning(f"Config {key} are tip invalid ({type(intel_cfg[key])}), folosesc default")
                intel_cfg[key] = default
        
        # Validează weights
        weights = intel_cfg.get("weights", {})
        default_weights = {"atr": 0.35, "trend": 0.35, "liquidity": 0.30}
        
        for key, default in default_weights.items():
            if key not in weights:
                weights[key] = default
        
        # Normalizează weights să sumeze 1.0
        total = sum(weights.values())
        if total > 0:
            for key in weights:
                weights[key] /= total
        intel_cfg["weights"] = weights
    
    def _get_universe_config(self) -> Dict[str, Any]:
        """Returnează configurația pentru univers"""
        intel_cfg = self.cfg.get("intel", {})
        risk_cfg = self.cfg.get("risk", {})
        
        return {
            "universe_n": int(intel_cfg.get("universe_max", 250)),
            "timeframe": str(intel_cfg.get("timeframe", "5m")),
            "lookback": int(intel_cfg.get("lookback", 240)),
            "atr_period": int(risk_cfg.get("atr_period", 14)),
            "max_corr": float(risk_cfg.get("portfolio", {}).get("correlation_filter", {}).get("max_corr", 0.85)),
        }
    
    def _get_build_config(self, intel_cfg: Dict[str, Any]) -> Dict[str, Any]:
        """Returnează configurația pentru build"""
        return {
            "limit": int(intel_cfg.get("watchlist_size", 15)),
            "universe_n": int(intel_cfg.get("universe_max", 250)),
            "min_qv": float(intel_cfg.get("min_quote_volume", 1_000_000.0)),
            "tf": str(intel_cfg.get("timeframe", "5m")),
            "lookback": int(intel_cfg.get("lookback", 240)),
            "prefilter_topk": int(intel_cfg.get("prefilter_topk", 60)),
            "atr_period": int((self.cfg.get("risk") or {}).get("atr_period", 14)),
            "fast": int(intel_cfg.get("ema_fast", 20)),
            "slow": int(intel_cfg.get("ema_slow", 80)),
            "spread_bad": float(intel_cfg.get("spread_bps_bad", 25.0)),
            "slip_bad": float(intel_cfg.get("slippage_bps_bad", 40.0)),
            "slip_notional": float(intel_cfg.get("slippage_notional_usd", 250.0)),
            "missing_ob_penalty": float(intel_cfg.get("missing_ob_penalty", 0.08)),
            "atr_ref": float(intel_cfg.get("atr_pct_ref", 0.02)),
            "trend_ref": float(intel_cfg.get("trend_ref", 0.01)),
            "weights": intel_cfg.get("weights", {"atr": 0.35, "trend": 0.35, "liquidity": 0.30}),
            "corr_penalty": float(intel_cfg.get("corr_penalty", 0.25)),
            "max_corr": float((self.cfg.get("risk") or {}).get("portfolio", {}).get("correlation_filter", {}).get("max_corr", 0.85)),
            "parallel_processing": bool(intel_cfg.get("parallel_processing", True)),
            "max_workers": int(intel_cfg.get("max_workers", min(32, (os.cpu_count() or 1) + 4))),
        }
    
    def _log_metrics(self, watchlist: List[str]):
        """Loghează metricile pipeline-ului"""
        metrics_dict = self.metrics.to_dict()
        
        self.log.info(
            f"Pipeline finalizat: {len(watchlist)} simboluri în {metrics_dict['execution_time_sec']:.2f}s, "
            f"success rate: {metrics_dict['success_rate']:.1%}, "
            f"cache hit: {metrics_dict['cache_hit_rate']:.1%}"
        )
        
        if metrics_dict["errors_count"] > 0:
            self.log.warning(f"Au apărut {metrics_dict['errors_count']} erori în pipeline")
            for error in metrics_dict["errors"]:
                self.log.debug(f"Eroare pipeline: {error}")
    
    # ============================================================================
    # ANALIZĂ SIMBOLURI
    # ============================================================================
    
    def _analyze_single_symbol(
        self, 
        sym: str, 
        qv: float,
        engine: Any, 
        config: Dict[str, Any],
        port_syms: List[str],
        ret_map: Optional[Dict] = None
    ) -> Optional[WatchlistItem]:
        """Analizează un singur simbol"""
        try:
            self.metrics.symbols_analyzed += 1
            
            # OHLCV
            df = None
            try:
                df = engine.client.fetch_ohlcv_df(sym, config["tf"], limit=config["lookback"])
                self.metrics.api_calls += 1
            except Exception as e:
                self.log.debug(f"Nu pot fetch OHLCV pentru {sym}: {e}")
                return None
            
            df = self._ensure_ohlcv_schema(df)
            dq = self.validator.detect_data_anomalies(df) if df is not None else {"ok": False, "reason": "no_ohlcv"}
            if not dq.get("ok"):
                return None
            
            df = self.validator.sanitize_ohlcv(df)
            if df is None or df.empty:
                return None
            
            # Necesită suficiente bare
            min_len = max(50, int(config["lookback"] * 0.35))
            if len(df) < min_len:
                return None
            
            # Componente scoring
            last_px = float(df["close"].iloc[-1])
            a = float(atr(df, config["atr_period"]).iloc[-1])
            atr_pct = float(a / max(1e-12, last_px))
            
            e_fast = float(ema(df["close"], config["fast"]).iloc[-1])
            e_slow = float(ema(df["close"], config["slow"]).iloc[-1])
            trend_strength = abs(e_fast - e_slow) / max(1e-12, last_px)
            
            # Lichiditate: spread + slippage așteptat
            spread_bps = float("nan")
            slip_bps = float("nan")
            liq_pen = 0.0
            ob_ok = False
            
            try:
                depth = int((self.cfg.get("micro_model") or {}).get("orderbook_depth", 20))
                ob = engine.client.fetch_order_book(sym, limit=depth)
                self.metrics.api_calls += 1
                met = orderbook_metrics(ob, depth=depth)
                spread_bps = float(met.get("spread_bps", float("nan")))
                slip_bps = float(expected_market_slippage_bps(ob, notional_usd=config["slip_notional"]))
                ob_ok = True
            except Exception as e:
                liq_pen = float(config["missing_ob_penalty"])
                self.log.debug(f"Nu pot fetch order book pentru {sym}: {e}")
            
            # Penalizare corelație cu portofoliu
            corr_pen = 0.0
            corr_ok_flag: Optional[bool] = None
            
            try:
                if port_syms and ret_map is not None:
                    okc = corr_ok(sym, port_syms, ret_map, max_corr=config["max_corr"])
                    corr_ok_flag = bool(okc)
                    corr_pen = 0.0 if okc else float(config["corr_penalty"])
            except Exception as e:
                self.log.debug(f"Eroare calcul corelație pentru {sym}: {e}")
            
            # Calcul scoring
            score, components = self._calculate_symbol_score(
                atr_pct=atr_pct,
                trend_strength=trend_strength,
                spread_bps=spread_bps,
                slip_bps=slip_bps,
                qv=qv,
                corr_penalty=corr_pen,
                liq_penalty=liq_pen,
                config=config
            )
            
            # Motive
            reasons = {
                "quoteVolume": float(qv),
                "atr_pct": float(atr_pct),
                "trend_strength": float(trend_strength),
                "spread_bps": float(spread_bps),
                "slippage_bps": float(slip_bps),
                "corr_penalty": float(corr_pen),
                "corr_ok": corr_ok_flag,
                "ob_ok": bool(ob_ok),
                "liq_penalty": float(liq_pen),
                "dq": dq,
                "components": components,
                "weights": config["weights"],
                "tf": config["tf"],
                "lookback": int(config["lookback"]),
            }
            
            return WatchlistItem(symbol=sym, score=float(score), reasons=reasons)
            
        except Exception as e:
            self.metrics.errors.append(f"{sym}: {str(e)}")
            self.log.debug(f"Eroare analiză simbol {sym}: {e}")
            return None
    
    def _analyze_symbols_sequential(
        self,
        symbols: List[str],
        vol_rank: List[Tuple[str, float]],
        engine: Any,
        config: Dict[str, Any]
    ) -> List[WatchlistItem]:
        """Analiză secvențială a simbolurilor"""
        candidates = []
        vol_dict = dict(vol_rank)
        
        # Determină simboluri din portofoliu
        port_syms = self._get_portfolio_symbols(engine)
        
        # Mapează returns pentru corelație
        ret_map = self._compute_returns_map(engine, list(set(port_syms + symbols)))
        
        for sym in symbols:
            qv = vol_dict.get(sym, 0.0)
            candidate = self._analyze_single_symbol(sym, qv, engine, config, port_syms, ret_map)
            if candidate:
                candidates.append(candidate)
        
        return candidates
    
    def _analyze_symbols_parallel(
        self,
        symbols: List[str],
        vol_rank: List[Tuple[str, float]],
        engine: Any,
        config: Dict[str, Any]
    ) -> List[WatchlistItem]:
        """Analiză paralelă a simbolurilor"""
        candidates = []
        vol_dict = dict(vol_rank)
        
        # Determină simboluri din portofoliu
        port_syms = self._get_portfolio_symbols(engine)
        
        # Mapează returns pentru corelație
        ret_map = self._compute_returns_map(engine, list(set(port_syms + symbols)))
        
        max_workers = min(len(symbols), config["max_workers"])
        
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="mkt_intel") as executor:
            future_to_symbol = {}
            
            for sym in symbols:
                qv = vol_dict.get(sym, 0.0)
                future = executor.submit(
                    self._analyze_single_symbol,
                    sym, qv, engine, config, port_syms, ret_map
                )
                future_to_symbol[future] = sym
            
            for future in as_completed(future_to_symbol):
                sym = future_to_symbol[future]
                try:
                    candidate = future.result(timeout=30.0)
                    if candidate:
                        candidates.append(candidate)
                except Exception as e:
                    self.log.warning(f"Analiză eșuată pentru {sym}: {e}")
                    self.metrics.errors.append(f"{sym}: {str(e)}")
        
        return candidates
    
    def _calculate_symbol_score(
        self,
        atr_pct: float,
        trend_strength: float,
        spread_bps: float,
        slip_bps: float,
        qv: float,
        corr_penalty: float,
        liq_penalty: float,
        config: Dict[str, Any]
    ) -> Tuple[float, Dict[str, float]]:
        """Calcul scor pentru un simbol"""
        weights = config["weights"]
        
        # Normalizare sigmoid pentru ATR și trend
        atr_norm = _sigmoid_norm(atr_pct / max(1e-12, config["atr_ref"]), scale=0.5)
        trend_norm = _sigmoid_norm(trend_strength / max(1e-12, config["trend_ref"]), scale=0.5)
        
        # Calcul lichiditate
        liq_parts = 0
        liq_sum = 0.0
        
        if not np.isnan(spread_bps):
            liq_sum += max(0.0, 1.0 - (float(spread_bps) / max(1e-9, float(config["spread_bad"]))))
            liq_parts += 1
        
        if not np.isnan(slip_bps):
            liq_sum += max(0.0, 1.0 - (float(slip_bps) / max(1e-9, float(config["slip_bad"]))))
            liq_parts += 1
        
        liquidity = (liq_sum / liq_parts) if liq_parts > 0 else 0.0
        
        # Scor final
        score = (
            weights.get("atr", 0.35) * atr_norm +
            weights.get("trend", 0.35) * trend_norm +
            weights.get("liquidity", 0.30) * liquidity
        ) - corr_penalty - liq_penalty
        
        # Asigură scor pozitiv
        score = max(0.0, score)
        
        components = {
            "atr": float(atr_norm),
            "trend": float(trend_norm),
            "liq": float(liquidity),
            "corr_penalty": float(corr_penalty),
            "liq_penalty": float(liq_penalty)
        }
        
        return score, components
    
    # ============================================================================
    # SELECTIE WATCHLIST
    # ============================================================================
    
    def _select_watchlist(
        self, 
        candidates: List[WatchlistItem], 
        limit: int
    ) -> Tuple[List[str], Dict[str, Any]]:
        """Selectează watchlist-ul final din candidați"""
        if not candidates:
            self.log.warning("Niciun candidat valid, folosesc fallback")
            return [], {}
        
        # Sortează descrescător după scor
        candidates.sort(key=lambda x: x.score, reverse=True)
        
        # Selectează top N
        chosen = candidates[:max(1, limit)]
        
        watchlist = [c.symbol for c in chosen]
        reasons_map = {}
        
        for idx, c in enumerate(chosen):
            reasons_map[c.symbol] = {
                "rank": idx + 1,
                "score": float(c.score),
                "timestamp": c.timestamp,
                **(c.reasons or {})
            }
        
        return watchlist, reasons_map
    
    # ============================================================================
    # PRE-FILTRARE
    # ============================================================================
    
    def _prefilter_by_volume(
        self, 
        symbols: List[str], 
        tickers: Dict[str, Any],
        min_qv: float
    ) -> List[Tuple[str, float]]:
        """Prefiltrare simboluri după volum"""
        vol_rank = []
        
        for sym in symbols:
            t = tickers.get(sym, {})
            
            # Volume în quote currency
            qv = _safe_float(t.get("quoteVolume"), 0.0)
            
            if qv <= 0:
                # Fallback: baseVolume * last
                base_v = _safe_float(t.get("baseVolume"), 0.0)
                last = _safe_float(t.get("last"), 0.0)
                if base_v > 0 and last > 0:
                    qv = base_v * last
            
            if qv >= min_qv:
                vol_rank.append((sym, float(qv)))
        
        # Sortează descrescător după volum
        vol_rank.sort(key=lambda x: x[1], reverse=True)
        
        return vol_rank
    
    # ============================================================================
    # FALLBACK STRATEGII
    # ============================================================================
    
    def _fallback(self, engine: Any) -> Tuple[List[str], Dict[str, Any]]:
        """Strategii fallback în ordinea importanței"""
        fallback_strategies = [
            self._fallback_from_cache,
            self._fallback_from_selector,
            self._fallback_from_volume_only,
            self._fallback_static
        ]
        
        for strategy in fallback_strategies:
            try:
                pairs, reasons = strategy(engine)
                if pairs:
                    strategy_name = strategy.__name__.replace("_fallback_", "")
                    self.log.info(f"Folosesc fallback strategy: {strategy_name}")
                    return pairs, reasons
            except Exception as e:
                self.log.debug(f"Fallback strategy {strategy.__name__} failed: {e}")
                continue
        
        # Fallback ultimate
        return self._fallback_static(engine)
    
    def _fallback_from_cache(self, engine: Any) -> Tuple[List[str], Dict[str, Any]]:
        """Fallback din cache"""
        if self._last_watchlist:
            return list(self._last_watchlist), dict(self._last_reasons)
        return [], {}
    
    def _fallback_from_selector(self, engine: Any) -> Tuple[List[str], Dict[str, Any]]:
        """Fallback folosind selectorul default"""
        try:
            pairs = engine.selector.select(engine.client)
            reasons = {s: {"score": 0.0, "reason": "fallback_selector"} for s in pairs}
            return list(pairs), dict(reasons)
        except Exception:
            return [], {}
    
    def _fallback_from_volume_only(self, engine: Any) -> Tuple[List[str], Dict[str, Any]]:
        """Fallback bazat doar pe volum"""
        try:
            symbols = self._universe(engine, max_symbols=50)
            tickers = self._tickers(engine, symbols)
            
            vol_rank = []
            for sym in symbols:
                t = tickers.get(sym, {})
                qv = _safe_float(t.get("quoteVolume"), 0.0)
                if qv > 100000:  # Volum minim
                    vol_rank.append((sym, qv))
            
            vol_rank.sort(key=lambda x: x[1], reverse=True)
            pairs = [s for s, _ in vol_rank[:10]]
            
            reasons = {
                s: {"score": float(idx/10.0), "reason": f"volume_rank_{idx+1}"}
                for idx, s in enumerate(pairs)
            }
            
            return pairs, reasons
        except Exception:
            return [], {}
    
    def _fallback_static(self, engine: Any) -> Tuple[List[str], Dict[str, Any]]:
        """Fallback static cu perechi populare"""
        static_pairs = ["BTC/USDT:USDT", "ETH/USDT:USDT", "BNB/USDT:USDT", "SOL/USDT:USDT"]
        reasons = {s: {"score": 0.0, "reason": "static_fallback"} for s in static_pairs}
        return static_pairs, reasons
    
    # ============================================================================
    # DATA FETCHING
    # ============================================================================
    
    def _universe(self, engine: Any, max_symbols: int = 250) -> List[str]:
        """Obține universul de simboluri"""
        try:
            engine.client.load_markets()
            syms = list(getattr(engine.client.ex, "symbols", []) or [])
        except Exception as e:
            self.log.warning(f"Eroare load markets: {e}")
            return []
        
        out = []
        for s in syms:
            # Acceptă doar perechi USDT
            if "/USDT" in s or s.endswith(":USDT") or ":USDT" in s:
                out.append(s)
        
        # Filtrează doar markets active
        mk = getattr(engine.client.ex, "markets", {}) or {}
        active = []
        for s in out:
            m = mk.get(s, {})
            if m.get("active", True):
                active.append(s)
        
        return active[:max_symbols]
    
    def _tickers(self, engine: Any, symbols: List[str], force_refresh: bool = False) -> Dict[str, Any]:
        """Obține tickers cu caching și circuit breaker"""
        ttl = float((self.cfg.get("intel") or {}).get("tickers_ttl", 10.0))
        now = time.time()
        
        # Verifică cache
        if not force_refresh and self._cached_tickers and (now - self._cached_tickers_ts) <= ttl:
            self.metrics.cache_hits += 1
            return self._cached_tickers
        
        self.metrics.cache_misses += 1
        
        try:
            # Folosește circuit breaker
            def fetch_tickers():
                if symbols:
                    return engine.client.ex.fetch_tickers(symbols)
                else:
                    return engine.client.ex.fetch_tickers()
            
            tickers = self._tickers_cb.execute(fetch_tickers)
            
            if tickers:
                self._cached_tickers = tickers
                self._cached_tickers_ts = now
                self._tickers_cb.reset()  # Resetează circuit breaker la succes
            return tickers or {}
            
        except Exception as e:
            self.log.warning(f"Eroare fetch tickers: {e}")
            # Returnează cache chiar dacă e expirat
            if self._cached_tickers:
                return self._cached_tickers
            return {}
    
    def _get_portfolio_symbols(self, engine: Any) -> List[str]:
        """Obține simbolurile din portofoliu"""
        try:
            return list(getattr(engine, "positions", {}).keys())
        except Exception:
            return []
    
    def _compute_returns_map(self, engine: Any, symbols: List[str]) -> Optional[Dict]:
        """Calculează returns map pentru corelații"""
        try:
            return engine._compute_returns_map(symbols)
        except Exception:
            return None
    
    # ============================================================================
    # DATA PROCESSING
    # ============================================================================
    
    def _ensure_ohlcv_schema(self, df: Any) -> Optional[pd.DataFrame]:
        """
        Asigură că DataFrame-ul OHLCV are coloanele standard.
        """
        if df is None:
            return None
        
        try:
            if isinstance(df, pd.DataFrame):
                d = df.copy()
            else:
                # Încearcă conversia list-of-lists
                d = pd.DataFrame(df)
            
            # Dacă coloanele sunt numerice (indici), încercă maparea standard CCXT
            cols = list(d.columns)
            if len(cols) >= 6 and all(isinstance(c, (int, float)) for c in cols[:6]):
                d = d.rename(columns={
                    cols[0]: "timestamp",
                    cols[1]: "open", 
                    cols[2]: "high", 
                    cols[3]: "low", 
                    cols[4]: "close", 
                    cols[5]: "volume"
                })
            
            # Acceptă deja numite
            needed = {"open", "high", "low", "close", "volume"}
            
            if not needed.issubset(set(map(str, d.columns))):
                # Încearcă mapping lowercase
                lower_map = {str(c).lower(): c for c in d.columns}
                rename = {}
                
                for k in ("open", "high", "low", "close", "volume"):
                    if k in lower_map:
                        rename[lower_map[k]] = k
                
                if rename:
                    d = d.rename(columns=rename)
            
            if "close" not in d.columns:
                return None
            
            return d
            
        except Exception as e:
            self.log.debug(f"Eroare normalizare schema OHLCV: {e}")
            return None
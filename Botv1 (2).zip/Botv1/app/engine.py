# app/engine.py
from __future__ import annotations

import os
import re
import time
import math
import json
import random
import threading
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from collections import deque

import numpy as np
import pandas as pd

from .exchange import ExchangeClient
from .marketdata_ws import MarketDataWS
from .strategy import StrategyEngine
from .paper import PaperPortfolio
from .records import TradeRecorder, TradeRecord
from .watchdog import ErrorWatchdog
from .approvals import ApprovalQueue
from .store_sqlite import SQLiteStore
from .notifier import Notifier
from .market_guard import MarketGuard
from .micro_model import orderbook_metrics, maker_fill_probability, expected_market_slippage_bps
from .indicators import atr, ema
from .portfolio import corr_ok
from .state import StateManager
from .metrics import Metrics
from .utils import safe_float, now_utc_iso, clamp, fetch_fear_greed
from .autonomy import AutonomyController
from .llm_router import LLMRouter
from .ai_brain import AIBrain
from .decision_factor import DecisionFactor, MarketProfile, TradePlan, BacktestSummary
try:
    from .symbol_policy import SymbolPolicyStore
except Exception:
    SymbolPolicyStore = None  # type: ignore

try:
    from .param_evolver import ParamSetEvolver
except Exception:
    ParamSetEvolver = None  # type: ignore
try:
    from .online_ml import OnlineWinModel
except Exception:
    OnlineWinModel = None  # type: ignore
from .backtest_micro import micro_backtest

from .selftest import SelfTester
from .telemetry import Telemetry, instrument

# Append-only audit trail (JSONL)
from .audit import AuditLogger

# New runtime subsystems
from .capabilities import CapabilityRegistry
from .portfolio_snapshot import PortfolioSnapshotter
from .market_intel import MarketIntelligencePipeline
from .regime_detector import MarketRegimeDetector
from .meta_strategy import MetaStrategySelector
from .execution_router import ExecutionRouter
from .order_lifecycle import OrderLifecycleManager
from .position_fsm import PositionFSM
from .risk_state import RiskStateOrchestrator
from .self_tuner import SelfTuner
from .health import HealthMonitor
from .trace import TraceBuffer

# -----------------------------
# Helpers (robuste + backward-compatible)
# -----------------------------
class _NullLock:
    """A no-op context manager used when a lock is absent (defensive)."""
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc, tb):
        return False

def _sf(x: Any, default: float = float("nan")) -> float:
    return float(safe_float(x, default))


def _cl(x: float, lo: float, hi: float) -> float:
    return float(clamp(float(x), float(lo), float(hi)))


def _extract_limits(m: Dict[str, Any]) -> Tuple[Optional[float], Optional[float]]:
    """
    Return (min_qty, min_cost) from CCXT-like market structure.
    """
    min_qty = None
    min_cost = None

    try:
        limits = m.get("limits") or {}
        amt = limits.get("amount") or {}
        cost = limits.get("cost") or {}
        a = amt.get("min")
        c = cost.get("min")
        if a is not None:
            min_qty = float(a)
        if c is not None:
            min_cost = float(c)
    except Exception:
        pass

    # Some exchanges expose filter-like info (best-effort)
    info = m.get("info") or {}
    try:
        # Binance futures spot-ish filters sometimes in info["filters"]
        filters = info.get("filters") or []
        for f in filters:
            ftype = (f.get("filterType") or "").upper()
            if ftype in ("LOT_SIZE", "MARKET_LOT_SIZE"):
                if f.get("minQty") is not None:
                    min_qty = float(f["minQty"])
            if ftype in ("MIN_NOTIONAL", "NOTIONAL"):
                if f.get("notional") is not None:
                    min_cost = float(f["notional"])
                elif f.get("minNotional") is not None:
                    min_cost = float(f["minNotional"])
    except Exception:
        pass

    return min_qty, min_cost


def _extract_step_and_precision(m: Dict[str, Any]) -> Tuple[Optional[float], Optional[int]]:
    """
    Return (step, amount_precision) for amount rounding.
    """
    step = None
    amt_prec = None

    try:
        prec = m.get("precision") or {}
        if prec.get("amount") is not None:
            amt_prec = int(prec["amount"])
    except Exception:
        pass

    info = m.get("info") or {}
    try:
        filters = info.get("filters") or []
        for f in filters:
            ftype = (f.get("filterType") or "").upper()
            if ftype in ("LOT_SIZE", "MARKET_LOT_SIZE"):
                s = f.get("stepSize")
                if s is not None:
                    step = float(s)
                break
    except Exception:
        pass

    return step, amt_prec


def _round_qty_floor(qty: float, step: Optional[float], amt_prec: Optional[int]) -> float:
    if qty <= 0:
        return 0.0
    q = float(qty)

    # Step-based floor rounding
    if step is not None and step > 0:
        q = math.floor(q / step) * step

    # Precision-based rounding (floor-ish via string formatting not guaranteed; use round then ensure <= original)
    if amt_prec is not None and amt_prec >= 0:
        q2 = round(q, amt_prec)
        # Ensure not accidentally rounding up
        if q2 > q:
            # subtract one unit in last decimal
            q2 = q2 - (10 ** (-amt_prec))
        q = max(0.0, q2)

    return float(q)


# -----------------------------
# Data models
# -----------------------------
@dataclass(slots=True)
class LivePosition:
    symbol: str
    side: str  # "long" / "short"
    qty: float
    entry: float
    stop: float
    tp: float
    trailing: Optional[float] = None
    tp1_done: bool = False
    # Native protection orders (best-effort for futures)
    sl_order_id: Optional[str] = None
    tp_order_id: Optional[str] = None
    trailing_order_id: Optional[str] = None
    protected_qty: float = 0.0
    protection_ts: float = 0.0
    # Multi scale-out progress (TP1/TP2/TP3)
    tp2_done: bool = False
    tp3_done: bool = False
    # Entry context for adaptive management
    initial_qty: float = 0.0
    entry_atr: float = 0.0
    entry_atr_pct: float = 0.0
    # Disable adding (DCA/pyramid) temporarily (e.g., volatility throttle)
    no_adds_until: float = 0.0
    plan_id: str = ""
    tactic: str = ""
    plan: dict = field(default_factory=dict)
    entry_features: dict = field(default_factory=dict)
    opened_ts: float = field(default_factory=time.time)
    
@dataclass(slots=True)
class EntryIntent:
    symbol: str
    side: str                 # "long" / "short"
    order_side: str           # "buy" / "sell"
    atr_val: float
    atr_pct: float
    signal_strength: float
    created_ts: float = field(default_factory=time.time)
    reason: str = "signal_entry"
    plan_id: str = ""
    tactic: str = ""
    plan: dict = field(default_factory=dict)
    entry_features: dict = field(default_factory=dict)





@dataclass(slots=True)
class PendingOrder:
    symbol: str
    side: str
    qty: float
    price: float
    order_id: str
    created_ts: float

    # Common execution metadata
    order_type: str = "limit"          # "limit" / "market" / "stop" etc.
    reduce_only: bool = False

    # Retry/repost bookkeeping
    reposts: int = 0
    reason: str = ""

    # TWAP/Maker routing metadata
    plan_id: str = ""
    tactic: str = ""
    plan: dict = field(default_factory=dict)
    is_maker: bool = True
    atr_pct: float = 0.0

    # Fill tracking
    filled_qty: float = 0.0

    # --------- Backward-compat aliases (read/write) ----------
    @property
    def ts(self) -> float:
        return float(self.created_ts)

    @ts.setter
    def ts(self, v: float) -> None:
        self.created_ts = float(v)

    @property
    def type(self) -> str:
        return str(self.order_type)

    @type.setter
    def type(self, v: str) -> None:
        self.order_type = str(v)



@dataclass(slots=True)
class TwapPlan:
    symbol: str
    side: str  # "buy" / "sell"
    total_qty: float
    remaining_qty: float
    slice_qty: float
    interval_sec: float
    created_ts: float = field(default_factory=time.time)
    next_ts: float = field(default_factory=time.time)
    executed_slices: int = 0
    max_slices: int = 0
    reason: str = ""
    plan_id: str = ""
    tactic: str = ""
    plan: dict = field(default_factory=dict)
    atr_pct: float = 0.0


# -----------------------------
# Pair selection
# -----------------------------
class PairSelector:
    def __init__(self, cfg: dict, log: Any):
        self.cfg = cfg
        self.log = log

    def _is_symbol_ok(self, sym: str, m: Dict[str, Any], quote: str) -> bool:
        if not m.get("active", True):
            return False

        enable_fut = bool(self.cfg.get("enable_futures", False))

        # Market type filter
        if enable_fut:
            if not (m.get("swap") or m.get("future") or m.get("contract")):
                return False
        else:
            if m.get("spot") is False:
                return False
            if ":" in sym:
                return False

        # Quote filter: accept /USDT and contract variants with :USDT
        if not (sym.endswith(f"/{quote}") or sym.endswith(f":{quote}") or (f"/{quote}:" in sym)):
            return False

        # Exclude leveraged tokens (spot)
        if (not enable_fut) and (self.cfg.get("pair_filters", {}) or {}).get("exclude_leveraged_tokens", True):
            for b in ["UP/", "DOWN/", "BULL/", "BEAR/"]:
                if b in sym:
                    return False

        return True

    def select(self, client: ExchangeClient) -> List[str]:
        quote = self.cfg["quote_asset"]
        mode = (self.cfg.get("pair_filters", {}) or {}).get("scanner_mode", "v7_advanced")

        # optional v8 scanner
        if mode == "v8_simple":
            try:
                from .scanner_v8 import find_best_pairs
                limit = int(self.cfg.get("max_pairs", 5))
                min_vol = float((self.cfg.get("pair_filters", {}) or {}).get("min_quote_volume_usd", 1_000_000))
                syms = find_best_pairs(client.ex, limit=limit, min_volume=min_vol)
                out = []
                for s in syms:
                    m = client.markets.get(s) or {}
                    if self._is_symbol_ok(s, m, quote):
                        out.append(s)
                if out:
                    return out[:limit]
            except Exception:
                pass

        markets = client.load_markets()
        w = [s.upper().strip() for s in ((self.cfg.get("pair_filters", {}) or {}).get("whitelist") or []) if s.strip()]
        bl = set([s.upper().strip() for s in ((self.cfg.get("pair_filters", {}) or {}).get("blacklist") or []) if s.strip()])

        if w:
            top = [s for s in w if s in markets and self._is_symbol_ok(s, markets[s], quote) and s not in bl]
            self.log.info(f"PairSelector: WHITELIST {top}")
            return top[: int(self.cfg.get("max_pairs", 20))]

        candidates = [s for s, m in markets.items() if self._is_symbol_ok(s, m, quote)]
        candidates = [s for s in candidates if s.upper() not in bl]

        pf = (self.cfg.get("pair_filters", {}) or {})
        min_qv = float(pf.get("min_quote_volume_usd", 1_000_000))
        min_px = float(pf.get("min_price_usd", 0.00001))
        max_spread = float(pf.get("max_spread_bps", 50))

        # bulk tickers (best-effort)
        tickers = {}
        try:
            tickers = client.ex.fetch_tickers(candidates)
        except Exception:
            tickers = {}
            CHUNK = 120
            for i in range(0, len(candidates), CHUNK):
                ch = candidates[i:i + CHUNK]
                try:
                    tt = client.ex.fetch_tickers(ch)
                    if isinstance(tt, dict):
                        tickers.update(tt)
                except Exception:
                    continue

        pre: List[Tuple[float, str]] = []
        for sym in candidates:
            t = tickers.get(sym)
            if not isinstance(t, dict):
                continue

            bid = _sf(t.get("bid"))
            ask = _sf(t.get("ask"))
            last = _sf(t.get("last"))

            if not np.isfinite(last) or last <= 0:
                continue

            if np.isfinite(bid) and np.isfinite(ask) and bid > 0 and ask > 0:
                spread_bps = (ask - bid) / bid * 10_000
                if spread_bps > max_spread:
                    continue

            qv = _sf(t.get("quoteVolume"), 0.0)
            if (not np.isfinite(qv)) or qv <= 0:
                bv = _sf(t.get("baseVolume"), 0.0)
                if np.isfinite(bv) and bv > 0:
                    qv = bv * last
                else:
                    info = t.get("info") or {}
                    qv = _sf(info.get("quoteVolume") or info.get("quote_volume") or info.get("q"), 0.0)

            if qv < min_qv:
                continue
            if last < min_px:
                continue

            pre.append((float(qv), sym))

        pre.sort(reverse=True, key=lambda x: x[0])
        TOPN = min(80, max(20, int(self.cfg.get("max_pairs", 16)) * 10))
        shortlist = [sym for _, sym in pre[:TOPN]]

        scored: List[Tuple[float, str]] = []
        for sym in shortlist:
            try:
                t = tickers.get(sym, {}) or {}
                last = _sf(t.get("last"))
                if not np.isfinite(last) or last <= 0:
                    continue

                df = client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=180)
                if len(df) < 120:
                    continue

                a = float(atr(df, int((self.cfg.get("risk", {}) or {}).get("atr_period", 14))).iloc[-1])
                atr_pct = (a / df["close"].iloc[-1]) if df["close"].iloc[-1] > 0 else 0.0
                trend = abs(ema(df["close"], 12).iloc[-1] - ema(df["close"], 26).iloc[-1]) / df["close"].iloc[-1]

                bid = _sf(t.get("bid"))
                ask = _sf(t.get("ask"))
                spread_bps = 0.0
                if np.isfinite(bid) and np.isfinite(ask) and bid > 0 and ask > 0:
                    spread_bps = (ask - bid) / bid * 10_000

                qv = 0.0
                try:
                    qv = float([x[0] for x in pre if x[1] == sym][0])
                except Exception:
                    qv = _sf(t.get("quoteVolume"), 0.0)

                s = (
                    0.6 * math.log10(max(qv, 1.0))
                    + 2.2 * atr_pct
                    + 4.0 * float(trend)
                    - 0.15 * (spread_bps / max_spread if max_spread > 0 else 0.0)
                )
                scored.append((float(s), sym))
            except Exception:
                continue

        scored.sort(reverse=True, key=lambda x: x[0])
        out = [sym for _, sym in scored[: int(self.cfg.get("max_pairs", 20))]]
        if not out:
            self.log.warning("PairSelector: no pairs after filtering. Consider lowering min_quote_volume_usd or raising max_spread_bps.")
        return out


# -----------------------------
# Risk management
# -----------------------------
class RiskManager:
    def __init__(self, cfg: dict, log: Any):
        self.cfg = cfg
        self.log = log
        self.last_trade_ts: Dict[str, float] = {}
        self.trades_today = 0
        self.day_key = pd.Timestamp.utcnow().strftime("%Y-%m-%d")

        # engine sets this
        self.futures_enabled: bool = bool(cfg.get("enable_futures", False))

        # entry-scale (Autonomy)
        self._entry_risk_mult: float = 1.0

    def new_day_if_needed(self):
        dk = pd.Timestamp.utcnow().strftime("%Y-%m-%d")
        if dk != self.day_key:
            self.day_key = dk
            self.trades_today = 0

    def in_cooldown(self, symbol: str) -> bool:
        cd = float((self.cfg.get("risk", {}) or {}).get("cooldown_sec", 0))
        return (time.time() - self.last_trade_ts.get(symbol, 0.0)) < cd

    def mark_trade(self, symbol: str):
        self.last_trade_ts[symbol] = time.time()
        self.new_day_if_needed()
        self.trades_today += 1

    def max_trades_reached(self) -> bool:
        self.new_day_if_needed()
        ks = (self.cfg.get("risk", {}) or {}).get("kill_switch", {}) or {}
        return self.trades_today >= int(ks.get("max_trades_per_day", 999999))

    def size_qty(self, equity: float, price: float, atr_val: float, markets: Dict[str, Any], symbol: str) -> float:
        """
        Unified sizing: Spot/Futures.
        """
        r = (self.cfg.get("risk") or {})
        if equity <= 0 or price <= 0:
            return 0.0

        is_futures = bool(self.futures_enabled)
        lev = _sf((self.cfg.get("futures") or {}).get("leverage"), 1.0)
        lev = max(1.0, lev)

        base_risk_pct = _sf(r.get("risk_per_trade"), 0.01)
        risk_cap = _sf(r.get("risk_per_trade_cap"), 0.10)
        risk_pct = _cl(base_risk_pct, 0.0, risk_cap)

        risk_amt = risk_pct * equity
        risk_mult = float(getattr(self, "_entry_risk_mult", 1.0) or 1.0)
        risk_mult = _cl(risk_mult, 0.0, 3.0)
        risk_amt *= risk_mult

        stop_atr_mult = _sf(r.get("stop_atr_mult"), 2.0)
        min_stop_pct = _sf(r.get("min_stop_pct"), 0.002)
        stop_dist = max(float(atr_val) * stop_atr_mult, float(price) * min_stop_pct)

        m = markets.get(symbol, {}) or {}
        contract_size = _sf(m.get("contractSize"), 1.0)
        if not is_futures:
            contract_size = 1.0

        min_qty, min_cost = _extract_limits(m)
        step, amt_prec = _extract_step_and_precision(m)

        if min_cost is None:
            min_cost = _sf(r.get("fallback_min_notional"), 6.0)

        # base qty by risk
        qty = float(risk_amt) / max(1e-12, (stop_dist * contract_size))

        # meet min notional with tolerance
        current_notional = qty * contract_size * price
        if current_notional < min_cost:
            required_qty = float(min_cost) / max(1e-12, (contract_size * price))
            implied_risk_amt = required_qty * contract_size * stop_dist
            implied_risk_pct = implied_risk_amt / max(1e-12, equity)

            max_tol = _sf(r.get("max_tolerable_risk_for_min_notional"), 0.05)
            if implied_risk_pct <= max_tol:
                self.log.info(
                    f"SmartSize: boosting {symbol} qty to meet min_notional "
                    f"({current_notional:.2f}$ -> {min_cost:.2f}$), implied risk {implied_risk_pct*100:.2f}%"
                )
                qty = max(qty, required_qty)
            else:
                self.log.warning(
                    f"SmartSize: {symbol} skipped. Need {implied_risk_pct*100:.1f}% risk "
                    f"to meet min_notional {min_cost:.2f}$ (cap {max_tol*100:.1f}%)."
                )
                return 0.0

        # exposure caps
        max_notional = _sf(r.get("max_position_pct"), 0.30) * equity

        # margin cap for futures
        max_margin_pct = r.get("max_margin_pct")
        if is_futures and max_margin_pct is not None:
            max_margin = _sf(max_margin_pct, 0.30) * equity
            max_notional = min(max_notional, max_margin * lev)

        qty = min(qty, max_notional / max(1e-12, (contract_size * price)))

        if min_qty is not None:
            qty = max(qty, float(min_qty))

        qty = _round_qty_floor(qty, step, amt_prec)

        final_notional = qty * contract_size * price
        if qty <= 0 or final_notional < (float(min_cost) * 0.999):
            return 0.0

        return float(qty)

    def stop_tp(self, side: str, price: float, atr_val: float) -> Tuple[float, float]:
        r = self.cfg["risk"]
        sl_dist = float(atr_val) * float(r["stop_atr_mult"])
        tp_dist = float(atr_val) * float(r["tp_atr_mult"])
        if side == "long":
            return (price - sl_dist, price + tp_dist)
        return (price + sl_dist, price - tp_dist)

    def tp1_level(self, side: str, entry: float, atr_val: float) -> float:
        so = (self.cfg.get("risk") or {}).get("scale_out", {}) or {}
        dist = float(atr_val) * float(so.get("tp1_atr_mult", 1.0))
        return (entry + dist) if side == "long" else (entry - dist)

    def tp2_level(self, side: str, entry: float, atr_val: float) -> float:
        so = (self.cfg.get("risk") or {}).get("scale_out", {}) or {}
        dist = float(atr_val) * float(so.get("tp2_atr_mult", 2.0))
        return (entry + dist) if side == "long" else (entry - dist)

    def tp3_level(self, side: str, entry: float, atr_val: float) -> float:
        so = (self.cfg.get("risk") or {}).get("scale_out", {}) or {}
        dist = float(atr_val) * float(so.get("tp3_atr_mult", 3.0))
        return (entry + dist) if side == "long" else (entry - dist)

    def fee_lock_stop(self, side: str, entry: float, price: float, *, fee_bps: float, buffer_bps: float) -> float:
        """Return a stop level that locks at least fees+buffer once price has moved favorably.
        For long: stop >= entry*(1+fees+buffer). For short: stop <= entry*(1-fees-buffer).
        """
        fb = (float(fee_bps) + float(buffer_bps)) / 10000.0
        if side == "long":
            return float(entry) * (1.0 + fb)
        else:
            return float(entry) * (1.0 - fb)

    def update_trailing(self, pos: LivePosition, last: float, atr_val: float, df: Optional[pd.DataFrame] = None):
        """Adaptive trailing stop.
        Modes:
          - atr: classic ATR trailing
          - step: only updates when price advances by a step threshold (reduces noise)
          - structure: trails below/above last swing low/high (simple heuristic)
        """
        r = (self.cfg.get("risk") or {})
        if not bool(r.get("use_trailing", True)):
            return

        tr_cfg = (r.get("trailing") or {})
        mode = str(tr_cfg.get("mode", "atr")).lower()

        atr_mult = float(tr_cfg.get("atr_mult", r.get("trail_atr_mult", 2.0)))
        step_trigger_atr = float(tr_cfg.get("step_trigger_atr_mult", 0.75))
        step_atr_mult = float(tr_cfg.get("step_atr_mult", atr_mult))
        lookback = int(tr_cfg.get("structure_lookback", 20))

        # --- compute candidate level
        if mode == "structure" and df is not None and len(df) >= max(lookback, 5):
            win = df.iloc[-lookback:]
            if pos.side == "long":
                lvl = float(win["low"].min())
                candidate = min(last - 0.2 * float(atr_val), lvl - 0.1 * float(atr_val))
            else:
                lvl = float(win["high"].max())
                candidate = max(last + 0.2 * float(atr_val), lvl + 0.1 * float(atr_val))
        else:
            m = step_atr_mult if mode == "step" else atr_mult
            dist = float(atr_val) * float(m)
            candidate = (last - dist) if pos.side == "long" else (last + dist)

        # --- step gating
        if mode == "step":
            ref = pos.trailing if pos.trailing is not None else (pos.stop if pos.stop else None)
            if ref is not None:
                trig = float(atr_val) * float(step_trigger_atr)
                if pos.side == "long":
                    if (last - float(ref)) < trig:
                        return
                else:
                    if (float(ref) - last) < trig:
                        return

        # --- monotonic update
        if pos.side == "long":
            if pos.trailing is None or float(candidate) > float(pos.trailing):
                pos.trailing = float(candidate)
        else:
            if pos.trailing is None or float(candidate) < float(pos.trailing):
                pos.trailing = float(candidate)


# -----------------------------
# Mapping codes
# -----------------------------

ENTRY_SKIP_CODES = {
    "halted": "E101",
    "watchdog_paused": "E102",
    "pause_entries": "E103",
    "risk_state_block": "E104",
    "market_guard_block": "E110",
    "symbol_blocked": "E111",


    "cooldown": "E201",
    "max_trades_day": "E202",
    "pending_exists": "E203",
    "already_in_position": "E204",
    "max_open_positions": "E205",
    "volatility_pause": "E206",
    "correlation_filter": "E207",
    "funding_block": "E208",
    "entry_intent_exists": "E209",


    "bad_equity_or_price": "E301",
    "autonomy_error": "E302",
    "autonomy_block": "E303",
    "ai_brain_block": "E304",


    "size_qty_zero": "E401",
    "trade_rules_block": "E402",
    "bad_stop_tp": "E403",
    

    "approval_already_pending": "E501",
}

# -----------------------------
# Trading engine
# -----------------------------
class TradingEngine:
    def __init__(self, cfg: dict, log: Any, recorder: TradeRecorder, base_dir: str):
        self.cfg = cfg
        self.log = log
        self.log.info(f"ENGINE FILE = {os.path.abspath(__file__)}")
        self.rec = recorder
        self.base_dir = base_dir

        # -----------------------------
        # Audit trail (append-only JSONL)
        # -----------------------------
        audit_cfg = (cfg.get("audit") or {})
        audit_path = os.path.join(base_dir, str(audit_cfg.get("path", "logs/audit.jsonl")))
        self.audit = AuditLogger(
            path=audit_path,
            enabled=bool(audit_cfg.get("enabled", True)),
            max_bytes=int(audit_cfg.get("max_bytes", 5_000_000)),
            backup_count=int(audit_cfg.get("backup_count", 5)),
        )
        try:
            if getattr(self.audit, "enabled", False):
                self.log.info(f"Audit trail enabled: {audit_path}")
        except Exception:
            pass

        self.metrics = Metrics(cfg, log)
        self.ws = MarketDataWS(cfg, log)
        self.client = ExchangeClient(cfg, log, ws_cache=self.ws)
        # Boot self-test (după ce avem cfg/log și după ce ExchangeClient este creat)
        self._run_boot_selftest()
        if getattr(self, "_stop", False):
            return

        self.selector = PairSelector(cfg, log)
        self.strategy = StrategyEngine(cfg, log)
        self.risk = RiskManager(cfg, log)
        self.watchdog = ErrorWatchdog(cfg, log)
        self.state = StateManager(cfg, base_dir, log)
        self.position_meta = {}  # symbol -> {"side": "long|short", "stop": float, "tp": float, "entry": float, "ts_open": float}

        self.ai_brain = AIBrain(self.cfg, self.log)
        self.entry_intents: Dict[str, EntryIntent] = {}

        # Re-entry state (per symbol). Used to enforce cooldown + confirmation after a position closes,
        # so the bot can re-evaluate before re-entering and avoid immediate churn.
        # Persisted via StateManager snapshot.
        self.reentry_state: Dict[str, Dict[str, Any]] = {}



        self.autonomy = AutonomyController(self.cfg, self.log)

        # Optional LLM decision layer (local + cloud). Disabled by default via cfg['llm'].
        try:
            self.llm = LLMRouter(self.cfg, self.log)
            if getattr(self.llm, 'enabled', False):
                loc_on = bool(getattr(getattr(self.llm, 'local', None), 'enabled', False))
                cld_on = bool(getattr(getattr(self.llm, 'cloud', None), 'enabled', False))
                llm_cfg = (self.cfg.get('llm') or {})
                mode = str(llm_cfg.get('mode', 'local')).lower()
                self.log.info(f"LLM module started: enabled=True local={loc_on} cloud={cld_on} (mode={mode})")
            else:
                self.log.debug('LLM module disabled by config')
        except Exception as e:
            self.llm = None
            try:
                self.log.debug(f"llm init failed: {type(e).__name__}: {e}")
            except Exception:
                pass



        # Decision Factor (single plan selection to avoid tool conflicts)
        try:
            self.decision_factor = DecisionFactor(self.cfg, self.log)
        except Exception:
            self.decision_factor = None

        # Lightweight, human-readable trace stream for debugging and UI.
        # Controlled via config: debug.trace_enabled (default true).
        try:
            self.trace = TraceBuffer(self.cfg, self.log, getattr(self, "audit", None))
        except Exception:
            self.trace = None

        self.pause_entries = False

        # Concurrency guards (API/UI threads may read/write)
        self._pos_lock = threading.RLock()
        self._pending_lock = threading.RLock()
        self._plan_lock = threading.RLock()  # protects twap_plans / plan-level state
        self._last_cycle_ts: float = 0.0
        self._last_cycle_error: str = ""
        self._order_lock = threading.RLock()

        approvals_cfg = cfg.get("approvals", {}) or {}
        self.approvals = (
            ApprovalQueue(timeout_sec=int(approvals_cfg.get("timeout_sec", 300)))
            if approvals_cfg.get("enabled", True)
            else None
        )

        sqlite_cfg = cfg.get("sqlite", {}) or {}
        self.store = (
            SQLiteStore(os.path.join(base_dir, str(sqlite_cfg.get("path", "bot.db"))))
            if sqlite_cfg.get("enabled", True)
            else None
        )

        # Autonomy learning stores (SQLite-backed)
        self.symbol_policy = None
        self.online_ml = None
        try:
            if self.store is not None and SymbolPolicyStore is not None:
                df_cfg = (self.cfg.get("decision_factor") or {})
                bandit_cfg = (df_cfg.get("bandit") or {}) if isinstance(df_cfg.get("bandit"), dict) else {}
                if bool(bandit_cfg.get("enabled", True)):
                    self.symbol_policy = SymbolPolicyStore(getattr(self.store, "path", ""), table_prefix="policy")
                    if getattr(self, "decision_factor", None) is not None and hasattr(self.decision_factor, "bind_symbol_policy"):
                        self.decision_factor.bind_symbol_policy(self.symbol_policy)
        except Exception:
            self.symbol_policy = None
        try:
            if self.store is not None and OnlineWinModel is not None:
                ml_cfg = (self.cfg.get("online_ml") or {})
                if bool(ml_cfg.get("enabled", False)):
                    self.online_ml = OnlineWinModel(getattr(self.store, "path", ""), table_prefix="ml")
        except Exception:
            self.online_ml = None

        
        # Param-set evolution (per symbol+tactic)
        self.param_evolver = None
        try:
            if self.store is not None and ParamSetEvolver is not None:
                pe_cfg = (self.cfg.get("param_evolver") or {})
                if bool(pe_cfg.get("enabled", True)):
                    self.param_evolver = ParamSetEvolver(
                        getattr(self.store, "path", ""),
                        cfg=self.cfg,
                        log=self.log,
                        table_prefix="evo",
                    )
        except Exception:
            self.param_evolver = None

# Daily PnL guardrails (realized)
        self._day_key = pd.Timestamp.utcnow().strftime("%Y-%m-%d")
        self._day_start_equity: Optional[float] = None
        self._day_realized_pnl: float = 0.0

        self.notifier = Notifier(cfg, log)

        sig_cfg = cfg.get("signals", {}) or {}
        self.signals_history_max = int(sig_cfg.get("history_max", 2000))
        self.record_hold_signals = bool(sig_cfg.get("record_hold", False))
        self.snapshot_interval_sec = float(sig_cfg.get("snapshot_interval_sec", 10))

        self.last_signals: Dict[str, Any] = {}
        self.signal_history: deque = deque(maxlen=self.signals_history_max)
        self._signals_lock = threading.Lock()
        self._last_snapshot_ts = 0.0

        self._fng_cache = 50
        self._fng_ts = 0.0

        mg_cfg = cfg.get("market_guard", {}) or {}
        self.market_guard = MarketGuard(cfg, log) if mg_cfg.get("enabled", False) else None

        self.paper = PaperPortfolio(cfg) if cfg.get("mode") == "paper" else None
        self.positions: Dict[str, LivePosition] = {}
        self.pending: Dict[str, PendingOrder] = {}
        self.twap_plans: Dict[str, TwapPlan] = {}
        self.pairs: List[str] = []
        self._ai_brain_next_allowed: dict[str, float] = {}

        # Unified runtime subsystems (capabilities, portfolio snapshot, market intelligence, regime/meta, lifecycle, health)
        self.capabilities = CapabilityRegistry.detect(self.cfg, base_dir)
        self.portfolio_snapshotter = PortfolioSnapshotter(self)
        self.market_intel = MarketIntelligencePipeline(self.cfg, self.log)
        self.regime_detector = MarketRegimeDetector(self.cfg, self.log)
        self.meta_strategy_selector = MetaStrategySelector(self.cfg, self.log)
        self.execution_router = ExecutionRouter(self.cfg, self.log)
        self.order_lifecycle = OrderLifecycleManager(self.cfg, self.log)
        self.position_fsm = PositionFSM(self.cfg, self.log)
        self.risk_state = RiskStateOrchestrator(self.cfg, self.log)
        self.self_tuner = SelfTuner(self.cfg, self.log, base_dir=base_dir)
        self.health = HealthMonitor(self.cfg, self.log)
        self.watchlist_reasons: Dict[str, Any] = {}


        self._stop = False

        self.halted = False
        self.day_start_equity = None
        self.peak_equity = None
        self.equity_window = deque(maxlen=5000)  # (ts, equity)

        self._last_opt_ts = 0.0

        # autonomy tuning cadence
        self._last_autonomy_tune_ts = 0.0
        self.telemetry = Telemetry(self.log)
        # propagate futures flag to risk manager
        self.risk.futures_enabled = bool(self.cfg.get("enable_futures", False))

        # resume
        if (self.cfg.get("state", {}) or {}).get("resume_on_start", False):
            self._resume()
        
        snap = self.state.load()
        if snap:
            try:
                self._restore_from_state(snap)
                self.log.info("Resumed state from state.json")
            except Exception as e:
                self.log.warn(f"State restore failed: {e}")

        # Startup reconcile / rebuild snapshot (best-effort)
        try:
            self._startup_reconcile()
        except Exception as e:
            try:
                self.log.warn(f"Startup reconcile failed: {e}")
            except Exception:
                pass

        try:
            self.position_fsm.update(self)
            self.order_lifecycle.sync(self, force=True)
            self.health.check_now(self)
        except Exception:
            pass

        # Boot audit record (best-effort)
        try:
            self._audit_event(
                "engine_boot",
                applied_profile=str(self.cfg.get("applied_profile") or ""),
            )
        except Exception:
            pass

    def _think(self, msg: str, level: str = "info", **ctx: Any) -> None:
        """Human-readable trace of autonomous decisions/actions.

        This deliberately emits short, structured messages to the log
        and also stores them in an in-memory ring buffer exposed via /trace.
        """
        try:
            tb = getattr(self, "trace", None)
            if tb is not None:
                tb.emit(msg, level=level, ctx=ctx)
            else:
                # fallback to log only
                lg = getattr(self, "log", None)
                if lg is not None:
                    fn = getattr(lg, level, lg.info)
                    fn(f"[think] {msg} | ctx={ctx}")
        except Exception:
            # tracing must never break the engine
            return


    def _normalize_risk_state(self, rs: Any) -> tuple[str, str, str]:
        """Normalize RiskState-like object/dict into (state, reason, controller).

        - Ensures reason is never empty (prevents blank 'reason' in logs/UI).
        - Never throws; safe to call inside the main loop.
        """
        try:
            if rs is None:
                return ("", "no risk_state (None)", "risk_state")

            if isinstance(rs, dict):
                state = str(rs.get("state") or "")
                reason = str(rs.get("reason") or "")
                controller = str(rs.get("controller") or "risk_state")
            else:
                state = str(getattr(rs, "state", "") or "")
                reason = str(getattr(rs, "reason", "") or "")
                controller = str(getattr(rs, "controller", "risk_state") or "risk_state")

            st_u = state.strip().upper()
            if not reason.strip():
                if st_u in ("", "NORMAL", "OK", "GREEN"):
                    reason = "all checks passed"
                elif st_u in ("CAUTION", "WARN", "YELLOW"):
                    reason = "caution threshold triggered"
                elif st_u in ("RISK_OFF", "RISKOFF", "RED"):
                    reason = "risk-off guardrail triggered"
                elif st_u in ("HALT", "STOP", "BLACK"):
                    reason = "halted by guardrail"
                else:
                    reason = "no reason provided"

            # Best-effort write-back for downstream consumers
            try:
                if not isinstance(rs, dict) and hasattr(rs, "reason"):
                    setattr(rs, "reason", reason)
                if not isinstance(rs, dict) and hasattr(rs, "controller") and not getattr(rs, "controller", None):
                    setattr(rs, "controller", controller)
            except Exception:
                pass

            return (state, reason, controller)
        except Exception:
            return ("", "risk_state normalization failed", "risk_state")


    def _startup_reconcile(self) -> None:
        """
        Rulează o singură dată la pornire:
        - LIVE: trage pozițiile și ordinele deschise de pe exchange și reconstruiește meta (LivePosition).
        - PAPER: reîncarcă paper_positions/pending din state persistat.
        """
        try:
            if not ((self.cfg.get("startup") or {}).get("reconcile_on_start", True)):
                return

            mode = str(self.cfg.get("mode", "paper")).lower().strip()

            if mode == "paper":
                self._restore_paper_from_state()
            else:
                self._restore_live_from_exchange()

        except Exception:
            # nu bloca pornirea dacă reconcilierea eșuează
            pass


    def _restore_paper_from_state(self) -> None:
        """PAPER mode: restore unified state snapshot (schema>=2).

        - Restores PaperPortfolio from persisted snapshot (cash, positions, PnL).
        - Restores `position_meta` as the single source of truth for stop/tp/trailing.
        - Restores engine.pending in the unified `pending_orders` format.
        - Rebuilds engine `LivePosition` view for UI/SL/TP management.
        """
        try:
            if str(self.cfg.get("mode", "")).lower().strip() != "paper":
                return
            st = self.state.load() if hasattr(self, "state") else None
            if not st:
                return

            # PaperPortfolio
            p = st.get("paper")
            if p and getattr(self, "paper", None) is not None:
                try:
                    self.paper = PaperPortfolio.from_dict(self.cfg, p)
                except Exception:
                    # fallback: keep instance but try to copy fields
                    try:
                        self.paper.cash = float(p.get("cash", self.paper.cash))
                        self.paper.realized_pnl_gross = float(p.get("realized_pnl_gross", self.paper.realized_pnl_gross))
                        self.paper.fees_paid = float(p.get("fees_paid", self.paper.fees_paid))
                        pos_data = p.get("positions") or {}
                        self.paper.positions = {}
                        for sym, vv in pos_data.items():
                            self.paper.positions[sym] = type(self.paper.positions.get(sym) or object())()
                            self.paper.positions[sym].symbol = str(vv.get("symbol", sym))
                            self.paper.positions[sym].qty = float(vv.get("qty", 0.0))
                            self.paper.positions[sym].avg_price = float(vv.get("avg_price", 0.0))
                    except Exception:
                        pass

            # meta
            self.position_meta = dict(st.get("position_meta") or st.get("positions_meta") or {})

            # re-entry state
            self.reentry_state = dict(st.get("reentry_state") or {})

            # pending
            pend_list = list(st.get("pending_orders") or [])
            pend_dict = {}

            for o in pend_list:
                try:
                    sym = str(o.get("symbol") or "").strip()
                    if not sym:
                        continue

                    pend_dict[sym] = PendingOrder(
                        symbol=sym,
                        side=str(o.get("side") or ""),
                        qty=float(o.get("qty") or o.get("amount") or 0.0),
                        price=float(o.get("price") or 0.0),
                        order_id=str(o.get("id") or o.get("order_id") or ""),
                        created_ts=float(o.get("created_ts") or o.get("ts") or time.time()),
                        order_type=str(o.get("order_type") or o.get("type") or "limit"),
                        reduce_only=bool(o.get("reduce_only", False)),
                        reason=str(o.get("reason") or ""),
                        plan_id=str(o.get("plan_id") or ""),
                        tactic=str(o.get("tactic") or ""),
                        plan=dict(o.get("plan") or {}),
                        is_maker=bool(o.get("is_maker", True)),
                        atr_pct=float(o.get("atr_pct") or 0.0),
                        filled_qty=float(o.get("filled_qty") or 0.0),
                        reposts=int(o.get("reposts") or 0),
                    )
                except Exception:
                    continue

            self.pending = pend_dict


            # rebuild LivePosition view from paper positions and meta
            if getattr(self, "paper", None) is not None:
                for sym in list((self.paper.positions or {}).keys()):
                    try:
                        self._sync_paper_meta(sym)
                    except Exception:
                        pass
        except Exception:
            return

    def _persist_paper_state(self) -> None:
        """Persist paper-mode state via schema v2 snapshot."""
        if str(self.cfg.get("mode", "")).lower().strip() != "paper":
            return
        try:
            snap = self._state_snapshot()
            self.state.save(snap)
        except Exception:
            pass
            
    def _ai_brain_gate(self, ctx: dict) -> tuple[bool, dict]:
        """
        Returns (ok_to_enter, brain_decision_dict).
        Enforces:
          - allow_entries flag
          - next_allowed_ts cooldown (including persistence per symbol to avoid jitter)
        """
        brain = {}
        try:
            brain = self.ai_brain.decide(ctx) if getattr(self, "ai_brain", None) else {}
        except Exception:
            brain = {}

        symbol = str((ctx or {}).get("symbol") or "").upper()
        now = time.time()

        # 1) direct allow flag
        allow = bool(brain.get("allow_entries", True))

        # 2) cooldown ts (from brain) + sticky local cache per symbol
        nxt = float(brain.get("next_allowed_ts") or 0.0)
        cached = float(self._ai_brain_next_allowed.get(symbol, 0.0)) if symbol else 0.0
        nxt_eff = max(nxt, cached)

        if symbol and nxt_eff > 0:
            self._ai_brain_next_allowed[symbol] = nxt_eff

        # enforce cooldown (even if allow_entries True)
        if nxt_eff and now < nxt_eff:
            allow = False
            try:
                rs = list(brain.get("reasons") or [])
                rs.append(f"BLOCK: ai_brain cooldown active ({nxt_eff-now:.1f}s remaining)")
                brain["reasons"] = rs
            except Exception:
                pass

        return allow, brain


    def _restore_live_from_exchange(self) -> None:
        """
        Live: verifică open positions + open orders de pe exchange și sincronizează engine state.
        Necesită metode în ExchangeClient: fetch_open_positions() + fetch_open_orders().
        """
        max_syms = int(((self.cfg.get("startup") or {}).get("reconcile_symbols_limit", 200)) or 200)

        # 1) poziții de pe exchange
        positions = {}
        try:
            positions = self.client.fetch_open_positions()  # {symbol: {side, qty, entry, ...}, ...}
        except Exception:
            positions = {}

        # 2) ordine deschise de pe exchange (pentru pending + pentru a detecta SL/TP native)
        open_orders = []
        try:
            open_orders = self.client.fetch_open_orders(limit=max_syms)  # list[dict]
        except Exception:
            open_orders = []

        # 3) reconstruiește meta LivePosition în engine
        for sym, p in (positions or {}).items():
            try:
                side = str(p.get("side") or "").lower()
                qty = abs(float(p.get("qty") or 0.0))
                entry = float(p.get("entry") or 0.0)
                if qty <= 0 or entry <= 0:
                    continue

                # încearcă să extragi stop/tp din ordinele native existente (reduceOnly STOP/TP)
                stop, tp = self._infer_native_sl_tp_from_orders(sym, side, open_orders)

                # dacă nu găsești, calculează default din risk (ATR fallback)
                if (stop is None) or (tp is None):
                    atr_val = max(entry * 0.01, 1e-12)
                    calc_stop, calc_tp = self.risk.stop_tp(side, entry, atr_val)
                    if stop is None:
                        stop = float(self.client.format_price(sym, calc_stop))
                    if tp is None:
                        tp = float(self.client.format_price(sym, calc_tp))

                self.positions[sym] = LivePosition(
                    symbol=sym, side=side, qty=qty, entry=entry,
                    stop=float(stop or 0.0), tp=float(tp or 0.0),
                    initial_qty=float(qty)
                )
            except Exception:
                continue

        # 4) pending from exchange open orders (non-reduceOnly)
        try:
            pend = {}
            for o in open_orders or []:
                try:
                    if bool(o.get("reduceOnly", False)):
                        continue
                    sym = str(o.get("symbol") or "")
                    if not sym:
                        continue
                    oid = str(o.get("id") or "")
                    side = str(o.get("side") or "")
                    qty = float(o.get("amount") or o.get("qty") or 0.0)
                    px = float(o.get("price") or 0.0)
                    created_ts = float(o.get("timestamp") or time.time()/1000.0)
                    pend[sym] = PendingOrder(
                        symbol=sym,
                        side=side,
                        qty=qty,
                        price=px,
                        order_id=oid,
                        created_ts=time.time(),
                        reason="reconcile",
                        is_maker=True,
                        atr_pct=0.0,
                    )
                except Exception:
                    continue
            self.pending = pend
        except Exception:
            pass

        # 5) ensure native protections exist (best-effort)
        try:
            for sym, pos in (self.positions or {}).items():
                try:
                    self._ensure_native_protection(sym, pos)
                except Exception:
                    pass
        except Exception:
            pass


    def _infer_native_sl_tp_from_orders(self, symbol: str, side: str, open_orders: list) -> tuple:
        """
        Caută în open_orders ordine STOP/TP native (reduceOnly) pentru simbol.
        Returnează (stop, tp) ca float sau None.
        """
        stop = None
        tp = None
        try:
            for o in open_orders or []:
                if o.get("symbol") != symbol:
                    continue
                if not bool(o.get("reduceOnly", False)):
                    continue

                otype = str(o.get("type") or "").upper()
                price = o.get("stopPrice") or o.get("triggerPrice") or o.get("price")
                if price is None:
                    continue
                price = float(price)

                # STOP
                if "STOP" in otype:
                    stop = price
                # TP
                if "TAKE_PROFIT" in otype or "TP" == otype:
                    tp = price
        except Exception:
            pass
        return stop, tp

    
    def _audit_event(self, event_type: str, **fields: Any) -> None:
        """Write an audit event without risking engine stability."""
        try:
            if not getattr(self, "audit", None):
                return
            ev: Dict[str, Any] = {
                "type": str(event_type),
                "mode": str(self.cfg.get("mode", "")),
                "exchange": str(self.cfg.get("exchange", "")),
                "sandbox": bool(self.cfg.get("sandbox", False)),
                "enable_futures": bool(self.cfg.get("enable_futures", False)),
            }
            # Avoid non-serializable values
            for k, v in (fields or {}).items():
                try:
                    json.dumps(v)
                    ev[k] = v
                except Exception:
                    ev[k] = str(v)
            self.audit.log(ev)
        except Exception:
            return

    # -----------------------------
    # Re-entry gating
    # -----------------------------
    def _record_exit_event(self, symbol: str, reason: str, realized: float = 0.0, side: str = "") -> None:
        """Record a position close event for re-entry cooldown/confirmation."""
        try:
            r = str(reason or "")
            rlow = r.lower()
            outcome = "other"
            # heuristic classification
            if any(x in rlow for x in ("stop", "sl", "liquid", "stop_hit", "stoploss")):
                outcome = "stop"
            elif any(x in rlow for x in ("tp", "take_profit", "profit", "scale_out")):
                outcome = "tp"
            elif "timeout" in rlow:
                outcome = "time"

            self.reentry_state[str(symbol)] = {
                "ts": float(time.time()),
                "reason": r,
                "outcome": outcome,
                "side": str(side or ""),
                "realized": float(realized or 0.0),
            }
        except Exception:
            return

    def _autonomy_on_trade_closed(self, symbol: str, pos: Optional[LivePosition], realized: float, notional: float) -> None:
        """Update learning models and guardrails after a trade closes."""
        try:
            today = pd.Timestamp.utcnow().strftime("%Y-%m-%d")
            if getattr(self, "_day_key", None) != today:
                self._day_key = today
                self._day_start_equity = None
                self._day_realized_pnl = 0.0
            self._day_realized_pnl = float(getattr(self, "_day_realized_pnl", 0.0) or 0.0) + float(realized or 0.0)
        except Exception:
            pass

        # Bandit / symbol policy update
        try:
            if self.symbol_policy is not None and pos is not None:
                ret = float(realized or 0.0) / max(1e-12, float(notional or 0.0))
                self.symbol_policy.update_on_close(
                    symbol=str(symbol),
                    tactic=str(getattr(pos, "tactic", "") or ""),
                    reward=float(ret),
                    win=bool(float(realized or 0.0) > 0.0),
                    realized_pnl_usd=float(realized or 0.0),
                    notional_usd=float(notional or 0.0),
                    cooldown_sec_on_loss=float(((self.cfg.get("autonomy") or {}).get("symbol_cooldown_on_loss_sec", 0.0)) or 0.0),
                )
        except Exception:
            pass

        # Param-set evolver update (per symbol+tactic)
        try:
            pe = getattr(self, "param_evolver", None)
            if pe is not None and pos is not None:
                plan = getattr(pos, "plan", {}) or {}
                best_pid = ((plan.get("overrides") or {}).get("backtest") or {}).get("best_param_id", "") or ""
                if best_pid:
                    ret = float(realized or 0.0) / max(1e-12, float(notional or 0.0))
                    pe.record_trade_reward(str(symbol), str(getattr(pos, "tactic", "") or ""), str(best_pid), float(ret))
        except Exception:
            pass

        # Online ML update
        try:
            if self.online_ml is not None and pos is not None:
                feats = dict(getattr(pos, "entry_features", {}) or {})
                y = 1 if float(realized or 0.0) > 0.0 else 0
                self.online_ml.update(symbol=str(symbol), feats=feats, y=y)
        except Exception:
            pass

        # Trace for UI
        try:
            self._think(
                "trade_closed",
                level="info",
                symbol=str(symbol),
                realized=float(realized or 0.0),
                notional=float(notional or 0.0),
                day_pnl=float(getattr(self, "_day_realized_pnl", 0.0) or 0.0),
                tactic=str(getattr(pos, "tactic", "") or "") if pos is not None else "",
                controller="autonomy",
            )
        except Exception:
            pass

    def _reentry_allowed(self, symbol: str, side: str, df: pd.DataFrame, df_trend: Optional[pd.DataFrame]) -> Tuple[bool, str, str]:
        """Enforce re-entry rules after a position closes.

        Returns: (allowed, code, detail)
        code is non-empty when denied.
        """
        try:
            rcfg = ((self.cfg.get("risk") or {}).get("reentry") or {})
            if not bool(rcfg.get("enabled", False)):
                return True, "", ""

            last = (getattr(self, "reentry_state", {}) or {}).get(str(symbol))
            if not last or not isinstance(last, dict):
                return True, "", ""

            now = time.time()
            ts = float(last.get("ts", 0.0) or 0.0)
            if ts <= 0:
                return True, "", ""

            outcome = str(last.get("outcome") or "other").lower()
            base_cd_min = float(rcfg.get("cooldown_min", 0.0) or 0.0)
            stop_cd_min = float(rcfg.get("after_stop_cooldown_min", base_cd_min) or base_cd_min)
            tp_cd_min = float(rcfg.get("after_tp_cooldown_min", base_cd_min) or base_cd_min)
            other_cd_min = float(rcfg.get("after_other_cooldown_min", base_cd_min) or base_cd_min)

            cd_min = other_cd_min
            if outcome == "stop":
                cd_min = stop_cd_min
            elif outcome == "tp":
                cd_min = tp_cd_min

            cd_sec = max(0.0, cd_min * 60.0)
            left = cd_sec - (now - ts)
            if left > 0.0:
                return False, "reentry_cooldown", f"cooldown_left_sec={int(left)} outcome={outcome} last_reason={last.get('reason','')}"

            # optional confirmation filters
            if bool(rcfg.get("require_confirm", True)):
                mtf_ok = True
                vol_ok = True

                # --- MTF confirm via EMA trend on df_trend
                try:
                    conf = (rcfg.get("confirm") or {}) if isinstance(rcfg.get("confirm"), dict) else {}
                    if bool(conf.get("mtf", True)) and df_trend is not None and not df_trend.empty:
                        fast = int((((self.cfg.get("strategies") or {}).get("ema_cross") or {}).get("fast", 9)) or 9)
                        slow = int((((self.cfg.get("strategies") or {}).get("ema_cross") or {}).get("slow", 21)) or 21)
                        close = df_trend["close"].astype(float)
                        ef = ema(close, fast)
                        es = ema(close, slow)
                        if len(ef) > 0 and len(es) > 0:
                            trend_dir = "long" if float(ef.iloc[-1]) >= float(es.iloc[-1]) else "short"
                            mtf_ok = (trend_dir == str(side))
                except Exception:
                    mtf_ok = True  # fail-open

                # --- Volume confirm (last vs rolling mean)
                try:
                    conf = (rcfg.get("confirm") or {}) if isinstance(rcfg.get("confirm"), dict) else {}
                    vcfg = conf.get("volume") if isinstance(conf.get("volume"), dict) else {}
                    if bool(vcfg.get("enabled", True)) and "volume" in df.columns:
                        lookback = int(vcfg.get("lookback", 20) or 20)
                        min_mult = float(vcfg.get("min_mult", 1.1) or 1.1)
                        vol = df["volume"].astype(float)
                        if len(vol) >= max(3, lookback):
                            meanv = float(vol.iloc[-lookback:].mean())
                            lastv = float(vol.iloc[-1])
                            if meanv > 0:
                                vol_ok = (lastv / meanv) >= min_mult
                except Exception:
                    vol_ok = True  # fail-open

                if not (mtf_ok and vol_ok):
                    return False, "reentry_confirm", f"mtf_ok={mtf_ok} vol_ok={vol_ok}"

            return True, "", ""
        except Exception:
            return True, "", ""

    def _state_snapshot(self) -> dict:
        """
        Build a persistence snapshot that is UI/API friendly and deduplicated.
        Works for both paper and live modes.
        """
        snap = {
            "schema": 2,
            "mode": str(self.cfg.get("mode", "")),
            "exchange": str(self.cfg.get("exchange", "")),
            "position_meta": dict(self.position_meta or {}),
            "reentry_state": dict(getattr(self, "reentry_state", {}) or {}),
            "positions": [],
            "pending_orders": [],
        }

        # --- PAPER portfolio persistence
        if getattr(self, "paper", None) is not None:
            try:
                snap["paper"] = self.paper.to_dict()
            except Exception:
                snap["paper"] = None

        # --- Open positions (unified)
        # Prefer an internal list/dict of live positions if present.
        # Otherwise derive from paper portfolio positions.
        pos_rows = []

        # 1) If you have self.positions / self.open_positions / similar, serialize those
        for attr in ("positions", "open_positions", "live_positions"):
            obj = getattr(self, attr, None)
            if obj:
                try:
                    # handle dict or list
                    items = obj.values() if isinstance(obj, dict) else obj
                    for p in list(items):
                        row = self._serialize_position_any(p)
                        if row:
                            pos_rows.append(row)
                except Exception:
                    pass

        # 2) Fallback: derive from paper positions
        if not pos_rows and getattr(self, "paper", None) is not None:
            try:
                for sym, p in (self.paper.positions or {}).items():
                    meta = (self.position_meta or {}).get(sym, {}) or {}
                    side = meta.get("side")
                    if not side:
                        side = "long" if float(p.qty) > 0 else "short"
                    row = {
                        "symbol": str(sym),
                        "side": str(side),
                        "qty": float(p.qty),
                        "entry": float(meta.get("entry", p.avg_price)),
                        "avg_price": float(p.avg_price),
                        "stop": float(meta.get("stop", 0.0) or 0.0),
                        "tp": float(meta.get("tp", 0.0) or 0.0),
                        "ts_open": float(meta.get("ts_open", 0.0) or 0.0),
                        "mode": "paper",
                        "exchange": str(self.cfg.get("exchange")),
                    }
                    pos_rows.append(row)
            except Exception:
                pass

        # Deduplicate by (symbol, side)
        dedup = {}
        for r in pos_rows:
            if not r:
                continue
            k = (str(r.get("symbol", "")), str(r.get("side", "")))
            # keep latest (or keep non-zero stop/tp)
            prev = dedup.get(k)
            if not prev:
                dedup[k] = r
            else:
                # prefer one with stop/tp populated
                if (float(prev.get("stop", 0.0)) == 0.0 and float(r.get("stop", 0.0)) != 0.0) or \
                   (float(prev.get("tp", 0.0)) == 0.0 and float(r.get("tp", 0.0)) != 0.0):
                    dedup[k] = r
                else:
                    # prefer larger abs qty (defensive)
                    if abs(float(r.get("qty", 0.0))) > abs(float(prev.get("qty", 0.0))):
                        dedup[k] = r

        snap["positions"] = list(dedup.values())

        # --- Pending orders (unified)
        pending_rows = []
        for attr in ("pending_orders", "orders_pending", "pending"):
            obj = getattr(self, attr, None)
            if obj:
                try:
                    items = obj.values() if isinstance(obj, dict) else obj
                    for o in list(items):
                        row = self._serialize_order_any(o)
                        if row:
                            pending_rows.append(row)
                except Exception:
                    pass

        # Dedup pending by id if possible
        pend_dedup = {}
        for r in pending_rows:
            oid = str(r.get("id") or "")
            if oid:
                pend_dedup[oid] = r
        snap["pending_orders"] = list(pend_dedup.values()) if pend_dedup else pending_rows

        return snap

    def get_metrics_snapshot(self) -> Dict[str, Any]:
        """Return a JSON-serializable snapshot for the API/dashboard."""
        try:
            if hasattr(self.metrics, 'snapshot') and callable(getattr(self.metrics, 'snapshot')):
                return self.metrics.snapshot()
            if isinstance(self.metrics, dict):
                return dict(self.metrics)
            return {
                'gauges': getattr(self.metrics, 'gauges', {}),
                'counters': getattr(self.metrics, 'counters', {}),
            }
        except Exception:
            return {'gauges': {}, 'counters': {}}

    def get_positions_snapshot(self):
        """Best-effort positions snapshot for UI/API.

        - PAPER: returns paper portfolio positions enriched with engine meta.
        - LIVE: returns engine live positions (self.positions).
        Never throws.
        """
        out = []
        try:
            # PAPER
            if str(self.cfg.get("mode", "")).lower() == "paper" and getattr(self, "paper", None):
                # Sync meta without breaking the snapshot if anything fails
                for sym, p in (self.paper.positions or {}).items():
                    try:
                        self._sync_paper_meta(sym)
                    except Exception:
                        pass
                    with getattr(self, "_pos_lock", _NullLock()):
                        pos = (getattr(self, "positions", {}) or {}).get(sym)
                        meta = (getattr(self, "position_meta", {}) or {}).get(sym, {}) or {}
                    plan = meta.get("plan") or {}
                    out.append({
                        "symbol": sym,
                        "qty": float(getattr(p, "qty", 0.0) or 0.0),
                        "entry": float(getattr(p, "avg_price", 0.0) or 0.0),
                        "stop": float(getattr(pos, "stop", 0.0) or 0.0) if pos else 0.0,
                        "tp": float(getattr(pos, "tp", 0.0) or 0.0) if pos else 0.0,
                        "plan_id": str(meta.get("plan_id", "") or ""),
                        "tactic": str(meta.get("tactic", "") or ""),
                        "exec_pref": str(plan.get("execution_prefer", "") or ""),
                        "allow_dca": bool(plan.get("allow_dca", False)),
                        "allow_pyramid": bool(plan.get("allow_pyramid", False)),
                        "side": "long" if float(getattr(p, "qty", 0.0) or 0.0) > 0 else "short" if float(getattr(p, "qty", 0.0) or 0.0) < 0 else "flat",
                    })
                return out

            # LIVE / non-paper
            with getattr(self, "_pos_lock", _NullLock()):
                for sym, pos in (getattr(self, "positions", {}) or {}).items():
                    out.append({
                        "symbol": sym,
                        "qty": float(getattr(pos, "qty", 0.0) or 0.0),
                        "entry": float(getattr(pos, "entry", 0.0) or 0.0),
                        "stop": float(getattr(pos, "stop", 0.0) or 0.0),
                        "tp": float(getattr(pos, "tp", 0.0) or 0.0),
                        "plan_id": str(getattr(pos, "plan_id", "") or ""),
                        "tactic": str(getattr(pos, "tactic", "") or ""),
                        "exec_pref": str((getattr(pos, "plan", {}) or {}).get("execution_prefer", "") or ""),
                        "allow_dca": bool((getattr(pos, "plan", {}) or {}).get("allow_dca", False)),
                        "allow_pyramid": bool((getattr(pos, "plan", {}) or {}).get("allow_pyramid", False)),
                    })
            return out
        except Exception:
            return out


    def get_pending_snapshot(self):
        """Best-effort pending orders snapshot for UI/API.

        Canonical source in this engine is self.pending (dict[symbol]->PendingOrder).
        Also keeps compatibility with older pending_orders list.
        Never throws.
        """
        out = []
        try:
            pend_dict = getattr(self, 'pending', None)
            if isinstance(pend_dict, dict) and pend_dict:
                with getattr(self, "_pending_lock", _NullLock()):
                    vals = list(pend_dict.values())
                for v in vals:
                    if isinstance(v, dict):
                        out.append(v)
                    else:
                        out.append(getattr(v, '__dict__', {'repr': str(v)}))
                return out

            po = getattr(self, 'pending_orders', None)
            if isinstance(po, list):
                for o in po:
                    if isinstance(o, dict):
                        out.append(o)
                    else:
                        out.append(getattr(o, '__dict__', {'repr': str(o)}))
            return out
        except Exception:
            return out


    def _run_boot_selftest(self) -> None:
        """
        Rulează self-test la pornire.
        - NU se rulează la import de modul.
        - Rulează după ce există self.cfg și self.log.
        """
        st_cfg = (self.cfg.get("selftest") or {})
        enabled = bool(st_cfg.get("enabled", True))
        if not enabled:
            self.log.info("[selftest] disabled by config selftest.enabled=false")
            return

        try:
            tester = SelfTester(self.cfg, log=self.log)
            report = tester.run()

            # opțional: păstrezi raportul în engine pentru API/UI
            try:
                self.selftest_report = report.to_dict()
            except Exception:
                self.selftest_report = None

            # Extra visibility for debugging: emit a concise boot trace + capability summary.
            try:
                self._think("boot_selftest_done", summary=getattr(report, "summary", None) or {})
                caps = None
                try:
                    caps = self.get_capabilities() if hasattr(self, "get_capabilities") else getattr(self, "capabilities", None)
                except Exception:
                    caps = None
                if caps is not None:
                    self.log.info(f"[capabilities] {caps}")
            except Exception:
                pass

            # opțional: blochezi pornirea dacă există FAIL
            halt = bool((self.cfg.get("debug") or {}).get("halt_on_selftest_fail", False))
            if halt and (not report.ok):
                self.log.error("[selftest] FAIL detected; halting startup (debug.halt_on_selftest_fail=true)")
                # stop clean
                self.halted = True
                self._stop = True

        except Exception as e:
            self.log.warning(f"[selftest] unexpected error: {type(e).__name__}: {e}")
            
            
    def _update_metrics_snapshot(self):
        try:
            # mark_prices: folosește cache-ul de prețuri pe care îl ai deja (ws/last prices)
            # În multe implementări: self._last_prices sau self.ticker_cache etc.
            # Dacă nu ai, poți pune {} și equity va rămâne cash în paper.
            mark_prices = getattr(self, "last_prices", None) or getattr(self, "ticker_cache", None) or {}

            # equity: în paper mode, ia equity din PaperPortfolio; altfel folosește ce ai deja.
            eq = None
            if getattr(self, "paper", None) is not None:
                try:
                    eq = float(self.paper.equity(mark_prices))
                except Exception:
                    eq = None

            # fallback la ce foloseai deja (dacă ai)
            if eq is None:
                eq = float(getattr(self.metrics.state, "equity", 0.0))

            open_positions = len(self.get_positions_snapshot())
            pending_orders = len(self.get_pending_snapshot())

            self.metrics.update(
                equity=float(eq),
                open_positions=int(open_positions),
                pending_orders=int(pending_orders),
            )
        except Exception:
            pass


    
    def get_status_positions(self) -> list[dict]:
        """
        Snapshot pentru GUI (Status tab).
        Returnează pozițiile urmărite de engine + (opțional) ordinele pending.
        """
        rows = []

        # 1) Live positions tracking (engine-level)
        try:
            for sym, pos in (self.positions or {}).items():
                rows.append({
                    "symbol": sym,
                    "qty": float(getattr(pos, "qty", 0.0) or 0.0),
                    "entry": float(getattr(pos, "entry", 0.0) or 0.0),
                    "stop": float(getattr(pos, "stop", 0.0) or 0.0),
                    "tp": float(getattr(pos, "tp", 0.0) or 0.0),
                    "side": str(getattr(pos, "side", "")),
                })
        except Exception:
            pass

        # 2) Pending orders (ca să vezi și LIMIT-urile înainte de fill)
        try:
            for sym, po in (self.pending or {}).items():
                # dacă nu ai stop/tp în PendingOrder, le lăsăm 0
                rows.append({
                    "symbol": sym,
                    "qty": float(getattr(po, "qty", 0.0) or 0.0),
                    "entry": float(getattr(po, "price", 0.0) or 0.0),
                    "stop": float(getattr(po, "stop", 0.0) or 0.0),
                    "tp": float(getattr(po, "tp", 0.0) or 0.0),
                    "side": str(getattr(po, "side", "")),
                })
        except Exception:
            pass
 
        return rows

    def _is_binance_reduce_only_regulation_error(self, e: Exception) -> bool:
        s = str(e)
        return ('"code":-4408' in s) or ("code': -4408" in s) or ("reduce only mode due to regulation" in s.lower())


    def _block_symbol(self, symbol: str, reason: str, seconds: int = 24 * 3600) -> None:
        if not hasattr(self, "_symbol_block"):
            self._symbol_block = {}
        until = time.time() + int(seconds)
        self._symbol_block[symbol] = {"until": until, "reason": reason}
        try:
            self.log.warning(f"{symbol}: BLOCKED for {seconds}s ({reason})")
        except Exception:
            pass


    def _is_symbol_blocked(self, symbol: str) -> bool:
        d = getattr(self, "_symbol_block", None) or {}
        info = d.get(symbol)
        if not info:
            return False
        if time.time() >= float(info.get("until", 0)):
            try:
                del d[symbol]
            except Exception:
                pass
            return False
        return True


    # -----------------------------
    # Lifecycle
    # -----------------------------
    def stop(self):
        self._stop = True
        try:
            self.cancel_twap(reason="engine_stop")
        except Exception:
            pass
        try:
            self.ws.stop()
        except Exception:
            pass
        try:
            if self.store:
                self.store.event(
                    "info",
                    "engine_stop",
                    "Stop requested",
                    {"exchange": self.cfg.get("exchange"), "mode": self.cfg.get("mode")},
                )
        except Exception:
            pass
            
    def place_native_sl_tp(
        self,
        symbol: str,
        pos_side: str,          # "long" / "short"
        qty: float,
        stop_price: float,
        tp_price: float,
        use_trailing: bool = False,
        trailing_callback_rate: float = 0.2,
    ) -> Dict[str, Optional[str]]:
        if not bool(self.cfg.get("enable_futures", False)):
            return {"sl": None, "tp": None, "trailing": None}

        close_side = "sell" if str(pos_side).lower() == "long" else "buy"

        # hedge_mode din config (nu _is_hedge_enabled)
        fut = (self.cfg.get("futures") or {}) if isinstance(self.cfg.get("futures"), dict) else {}
        hedge_mode = bool(fut.get("hedge_mode", False))
        position_side = None
        if hedge_mode:
            position_side = "LONG" if str(pos_side).lower() == "long" else "SHORT"

        sl_id = tp_id = tr_id = None

        try:
            r = self.client.create_stop_market(
                symbol=symbol,
                side=close_side,
                amount=float(qty),
                stop_price=float(stop_price),
                reduce_only=True,
                position_side=position_side,
                close_position=False,
            )
            if isinstance(r, dict) and r.get("id") is not None:
                sl_id = str(r["id"])
        except Exception:
            sl_id = None

        try:
            r = self.client.create_take_profit_market(
                symbol=symbol,
                side=close_side,
                amount=float(qty),
                tp_price=float(tp_price),
                reduce_only=True,
                position_side=position_side,
                close_position=False,
            )
            if isinstance(r, dict) and r.get("id") is not None:
                tp_id = str(r["id"])
        except Exception:
            tp_id = None

        if use_trailing:
            try:
                r = self.client.create_trailing_stop_market(
                    symbol=symbol,
                    side=close_side,
                    amount=float(qty),
                    callback_rate=float(trailing_callback_rate),
                    activation_price=None,
                    reduce_only=True,
                    position_side=position_side,
                )
                if isinstance(r, dict) and r.get("id") is not None:
                    tr_id = str(r["id"])
            except Exception:
                tr_id = None

        return {"sl": sl_id, "tp": tp_id, "trailing": tr_id}

            
            
    def request_manual_entry(self, symbol: str, side: str, notional_usd: float, leverage: int | None = None) -> dict:
        """
        Manual entry cerut din API.
        - notional_usd: mărimea în USDT
        - side: buy/sell sau long/short (normalizat)
        - leverage: opțional (doar dacă enable_futures=True)
        """
        sym = symbol.strip()
        s = side.strip().lower()
        if s in ("long", "buy"):
            s = "buy"
        elif s in ("short", "sell"):
            s = "sell"
        else:
            raise ValueError("side must be buy/sell/long/short")

        notional = float(notional_usd)
        if notional <= 0:
            raise ValueError("notional_usd must be > 0")

        bid, ask, last = self._get_bid_ask_last(sym)
        px = float(last) if last else float(ask if s == "buy" else bid)
        if px <= 0:
            raise RuntimeError("invalid price")

        if px <= 0:
            raise RuntimeError("invalid price")

        qty = notional / px

        # Futures settings (opțional)
        if bool(self.cfg.get("enable_futures", False)):
            lev = int(leverage) if leverage is not None else int((self.cfg.get("futures") or {}).get("leverage", 1))
            try:
                self.client.set_leverage(sym, lev)
            except Exception:
                # nu oprim manual entry dacă exchange-ul refuză setarea leverage-ului,
                # dar e bine să logăm.
                try:
                    self.log.warning(f"{sym}: set_leverage({lev}) failed; continuing")
                except Exception:
                    pass

        # execută entry prin engine (respectă routing-ul TWAP dacă e activ)
        self._place_order(sym, s, float(qty), reason="manual_entry", atr_pct=0.0)

        return {"ok": True, "symbol": sym, "side": s, "notional_usd": notional, "qty": qty, "price": px}
            
    def backtest(self, symbol: str, tf: str, days: int, initial_quote: float = 1000.0) -> dict:
        from .backtest import simulate

        sym = symbol.strip()
        tf = tf.strip()
        d = int(days)
        if d <= 0:
            raise ValueError("days must be > 0")

        def tf_to_minutes(t: str) -> int:
            t = t.strip().lower()
            if t.endswith("m"):
                return int(t[:-1])
            if t.endswith("h"):
                return int(t[:-1]) * 60
            if t.endswith("d"):
                return int(t[:-1]) * 1440
            raise ValueError(f"Unsupported tf: {t}")

        mins = tf_to_minutes(tf)
        limit = max(200, int((d * 1440) / mins) + 10)

        # trend timeframe simplu (poți rafina ulterior din config)
        if mins <= 15:
            trend_tf = "1h"
        elif mins <= 60:
            trend_tf = "4h"
        else:
            trend_tf = "1d"
        trend_mins = tf_to_minutes(trend_tf)
        trend_limit = max(200, int((d * 1440) / trend_mins) + 10)

        df = self.client.fetch_ohlcv_df(sym, timeframe=tf, limit=limit)
        df_trend = self.client.fetch_ohlcv_df(sym, timeframe=trend_tf, limit=trend_limit)

        return simulate(self.cfg, df, df_trend, days=d, initial_quote=float(initial_quote))


    # -----------------------------
    # Signals journaling
    # -----------------------------
    def _record_signal(self, symbol: str, sig: Any, price: float, approval_id: str | None = None, status: str = "computed") -> None:
        row = {
            "ts": now_utc_iso(),
            "symbol": symbol,
            "action": getattr(sig, "action", "hold"),
            "strength": float(getattr(sig, "strength", 0.0)),
            "price": float(price),
            "reason": str(getattr(sig, "reason", "")),
            "details": getattr(sig, "details", {}) or {},
        }
        with self._signals_lock:
            self.last_signals[symbol] = row
            self.signal_history.append(row)

        try:
            if self.store and (row["action"] != "hold" or self.record_hold_signals):
                self.store.signal(time.time(), symbol, row["action"], row["strength"], row["reason"], approval_id, status, row["details"])
        except Exception:
            pass

    def get_signals_latest(self) -> List[Dict[str, Any]]:
        """Return latest signals for UI.

        Historically `last_signals` is a dict {symbol: payload}. When no signals were produced yet,
        the GUI would show an empty table. To keep the UI informative, we fall back to the current
        symbol universe (watchlist/pairs) and emit synthetic WATCH entries.
        """
        with self._signals_lock:
            try:
                items = list((getattr(self, "last_signals", {}) or {}).values())
            except Exception:
                items = []

        # Primary path: real signals exist
        if isinstance(items, list) and items:
            try:
                items.sort(
                    key=lambda x: (str(x.get("action", "")), abs(float(x.get("strength", 0.0)))),
                    reverse=True,
                )
            except Exception:
                pass
            return items

        # Fallback: show universe even if no signals yet
        universe = []
        for attr in ("watchlist", "pairs", "selected_pairs", "symbols", "selected_symbols"):
            try:
                v = getattr(self, attr, None)
            except Exception:
                v = None
            if isinstance(v, dict):
                v = list(v.keys())
            if isinstance(v, (set, tuple)):
                v = list(v)
            if isinstance(v, list) and v:
                universe = [str(s) for s in v if isinstance(s, str) and "/" in s]
                if universe:
                    break

        if not universe:
            try:
                reasons = getattr(self, "watchlist_reasons", {}) or {}
                if isinstance(reasons, dict) and reasons:
                    universe = [str(k) for k in reasons.keys()]
            except Exception:
                universe = []

        # de-dupe keep order
        seen = set()
        uni = []
        for s in universe:
            if s and s not in seen:
                uni.append(s)
                seen.add(s)

        now = time.time()
        out = [
            {
                "ts": now,
                "symbol": s,
                "action": "watch",
                "strength": 0.0,
                "price": None,
                "reason": "universe (no signals yet)",
                "signal": "WATCH",
                "score": 0.0,
                "side": None,
            }
            for s in uni
        ]
        return out


    def _build_market_profile(self, sym: str, side: str, tf: str, df: pd.DataFrame, df_trend: pd.DataFrame,
                              px: float, atr_val: float, atr_pct: float, ticker: Optional[dict] = None) -> MarketProfile:
        notes = []
        spread_bps = 0.0
        vol_usd = 0.0
        trend_strength = 0.0

        try:
            # spread from websocket ticker cache if present
            if ticker and isinstance(ticker, dict):
                bid = float(ticker.get("bid") or 0.0)
                ask = float(ticker.get("ask") or 0.0)
                if bid > 0 and ask > 0:
                    spread_bps = (ask - bid) / ((ask + bid) / 2.0) * 10000.0
        except Exception:
            pass

        try:
            # approximate quote volume from recent candles (15m -> last 96 bars ~ 24h)
            look = min(96, len(df))
            if look >= 5:
                v = float(df["volume"].iloc[-look:].sum())
                vol_usd = float(v * float(px))
        except Exception:
            pass

        try:
            # simple trend strength proxy from trend timeframe: EMA slope normalized by price
            if df_trend is not None and len(df_trend) > 50:
                e_fast = ema(df_trend["close"], 9).iloc[-1]
                e_slow = ema(df_trend["close"], 21).iloc[-1]
                if float(px) > 0:
                    trend_strength = abs(float(e_fast) - float(e_slow)) / float(px)
        except Exception:
            pass

        # liquidity and vol states
        liquidity_state = "OK"
        try:
            min_vol = float(((self.cfg.get("pair_filters") or {}).get("min_quote_volume_usd", 0.0)) or 0.0)
            if min_vol > 0 and vol_usd < min_vol:
                liquidity_state = "LOW"
                notes.append("low_quote_volume")
        except Exception:
            pass

        vol_state = "NORMAL"
        try:
            hi = float(((self.cfg.get("risk") or {}).get("volatility_throttle") or {}).get("atr_pct_high", 0.06) or 0.06)
            if float(atr_pct) >= hi:
                vol_state = "HIGH"
                notes.append("high_atr_pct")
        except Exception:
            pass

        # regime from autonomy if available
        regime = "NA"
        try:
            r = getattr(self.autonomy, "get_regime_state", None)
            if callable(r):
                rr = r(sym) or {}
                regime = str(rr.get("regime") or "NA")
        except Exception:
            pass

        return MarketProfile(
            symbol=str(sym),
            side=str(side),
            tf=str(tf),
            last_price=float(px),
            atr_val=float(atr_val),
            atr_pct=float(atr_pct),
            spread_bps=float(spread_bps),
            vol_quote_usd_24h=float(vol_usd),
            trend_strength=float(trend_strength),
            regime=str(regime),
            liquidity_state=str(liquidity_state),
            vol_state=str(vol_state),
            notes=list(notes),
        )

    def _select_trade_plan(self, sym: str, side: str, tf: str, df: pd.DataFrame, df_trend: pd.DataFrame,
                           px: float, atr_val: float, atr_pct: float, signal_strength: float,
                           autonomy_decision: Any, ai_brain_adj: dict, llm_adj: dict, ticker: Optional[dict] = None) -> Optional[TradePlan]:
        df_cfg = (self.cfg.get("decision_factor") or {})
        enabled = bool(df_cfg.get("enabled", False))
        if not enabled or getattr(self, "decision_factor", None) is None:
            return None

        mp = self._build_market_profile(sym, side, tf, df, df_trend, px, atr_val, atr_pct, ticker=ticker)

        # risk_state snapshot (if available)
        rs = {}
        try:
            rs_obj = getattr(self, "risk_state", None)
            if rs_obj is not None:
                rs = rs_obj.snapshot() if hasattr(rs_obj, "snapshot") else {}
        except Exception:
            rs = {}        # micro-backtest (optional; fast) + param-set evolution hook
        bt_sum = None
        try:
            tactics = None
            try:
                df_cfg = (self.cfg.get("decision_factor") or {})
                bandit_cfg = (df_cfg.get("bandit") or {}) if isinstance(df_cfg.get("bandit"), dict) else {}
                tt = bandit_cfg.get("tactics", None)
                if isinstance(tt, list) and tt:
                    tactics = [str(x) for x in tt if x]
            except Exception:
                tactics = None

            param_sets_override = None
            try:
                pe = getattr(self, "param_evolver", None)
                if pe is not None and hasattr(pe, "param_sets_override_for_symbol"):
                    param_sets_override = pe.param_sets_override_for_symbol(sym, tactics or [])
                    if not param_sets_override:
                        param_sets_override = None
            except Exception:
                param_sets_override = None

            def _score_hook(*, tactic: str, param_id: str, score: float, params: Dict[str, Any]):
                try:
                    pe2 = getattr(self, "param_evolver", None)
                    if pe2 is not None:
                        pe2.record_micro_score(sym, str(tactic), str(param_id), float(score))
                except Exception:
                    pass

            mbr = micro_backtest(
                df,
                side=side,
                atr_val=float(atr_val),
                signal_strength=float(signal_strength),
                cfg=self.cfg,
                tactics=tactics,
                param_sets_override=param_sets_override,
                score_hook=_score_hook,
            )
            if getattr(mbr, "enabled", False):
                bt_sum = BacktestSummary(
                    enabled=True,
                    tactic_scores=dict(getattr(mbr, "tactic_scores", {}) or {}),
                    tactic_param_scores=dict(getattr(mbr, "tactic_param_scores", {}) or {}),
                    best_tactic=str(getattr(mbr, "best_tactic", "none") or "none"),
                    best_score=float(getattr(mbr, "best_score", 0.0) or 0.0),
                    best_param_id=str(getattr(mbr, "best_param_id", "") or ""),
                    best_params=dict(getattr(mbr, "best_params", {}) or {}),
                    reason=str(getattr(mbr, "reason", "ok") or "ok"),
                )
        except Exception:
            bt_sum = None

        # Normalize autonomy decision dict for audit
        a_dec = {}
        try:
            if autonomy_decision is not None:
                a_dec = getattr(autonomy_decision, "to_dict", None)() if callable(getattr(autonomy_decision, "to_dict", None)) else dict(getattr(autonomy_decision, "__dict__", {}) or {})
        except Exception:
            a_dec = {}

        plan = self.decision_factor.build_plan(
            symbol=str(sym),
            side=str(side),
            tf=str(tf),
            market_profile=mp,
            autonomy_decision=a_dec,
            ai_brain_adj=ai_brain_adj or {},
            llm_adj=llm_adj or {},
            backtest=bt_sum,
            risk_state=rs or {},
        )
        return plan

    def get_trades(self, limit: int = 200, since_ts: Optional[float] = None) -> List[Dict[str, Any]]:
        """
        Returnează trades pentru API /trades.
        - Preferă SQLiteStore dacă există (self.store)
        - Fallback: TradeRecorder (self.rec)
        - limit este capped ca să nu explodeze răspunsul
        - since_ts este epoch seconds (opțional)
        """
        try:
            limit = int(limit or 200)
        except Exception:
            limit = 200
        limit = max(1, min(limit, 5000))

        # 1) Prefer store (dacă există)
        try:
            st = getattr(self, "store", None)
            if st and hasattr(st, "list_trades"):
                rows = st.list_trades(limit=limit, since_ts=since_ts)
                return rows if isinstance(rows, list) else []
        except Exception:
            # nu blocăm endpoint-ul dacă store pică
            pass

        # 2) Fallback: recorder
        try:
            rec = getattr(self, "rec", None)
            if not rec:
                return []

            rows = rec.to_list(limit) if hasattr(rec, "to_list") else []
            if not isinstance(rows, list):
                return []

            # dacă nu ai store, filtrarea by since_ts o facem best-effort
            if since_ts is not None:
                def _to_epoch(ts_val: Any) -> float:
                    try:
                        # ts în TradeRecord e de obicei ISO string
                        s = str(ts_val).replace("Z", "+00:00")
                        dt = datetime.datetime.fromisoformat(s)
                        return dt.timestamp()
                    except Exception:
                        return 0.0

                rows = [r for r in rows if _to_epoch(r.get("ts")) >= float(since_ts)]

            # return newest first (dacă ai nevoie invers, scoți reverse)
            rows.sort(key=lambda r: str(r.get("ts", "")), reverse=True)
            return rows[:limit]
        except Exception:
            return []

    def get_signals_history(self, limit: int = 200) -> List[Dict[str, Any]]:
        limit = int(limit)
        with self._signals_lock:
            items = list(self.signal_history)[-limit:]
        return items

    def manual_resume(self):
        self.watchdog.force_resume()

    # -----------------------------
    # State persistence
    # -----------------------------
    def _resume(self):
        d = self.state.load()
        if not d or not isinstance(d, dict):
            return

        # accept both schemas
        ex_in_state = d.get("cfg_exchange") or d.get("exchange")
        if ex_in_state and ex_in_state != self.cfg.get("exchange"):
            self.log.warning("State found but exchange mismatch; skipping resume.")
            return

        # paper restore (works for both)
        if self.cfg.get("mode") == "paper" and isinstance(d.get("paper"), dict):
            try:
                self.paper = PaperPortfolio.from_dict(self.cfg, d["paper"])
            except Exception:
                pass

        # ---- positions restore
        self.positions = {}

        # schema v1
        meta = d.get("positions_meta")
        if isinstance(meta, dict) and meta:
            for k, v in meta.items():
                try:
                    self.positions[k] = LivePosition(**v)
                except Exception:
                    continue
        else:
            # schema v2
            rows = d.get("positions")
            if isinstance(rows, list):
                for r in rows:
                    try:
                        if not isinstance(r, dict):
                            continue
                        sym = str(r.get("symbol") or "").strip()
                        if not sym:
                            continue
                        self.positions[sym] = LivePosition(
                            symbol=sym,
                            side=str(r.get("side") or "").lower() or "long",
                            qty=float(r.get("qty") or 0.0),
                            entry=float(r.get("entry") or r.get("avg_price") or 0.0),
                            stop=float(r.get("stop") or 0.0),
                            tp=float(r.get("tp") or 0.0),
                        )
                    except Exception:
                        continue

        # ---- pending restore
        self.pending = {}

        # schema v1
        pend = d.get("pending")
        if isinstance(pend, dict) and pend:
            for k, v in pend.items():
                try:
                    self.pending[k] = PendingOrder(**v)
                except Exception:
                    continue
        else:
            # schema v2
            rows = d.get("pending_orders")
            if isinstance(rows, list):
                for r in rows:
                    try:
                        if not isinstance(r, dict):
                            continue
                        # key by id if available, else by symbol
                        key = str(r.get("id") or r.get("order_id") or r.get("symbol") or "").strip()
                        if not key:
                            continue
                        self.pending[key] = PendingOrder(**r)
                    except Exception:
                        continue

        # pairs / guard / trades
        self.pairs = list(d.get("pairs") or [])

        try:
            self.rec.trades = TradeRecorder.from_list(d.get("trades") or []).trades
        except Exception:
            pass

        self.halted = bool((d.get("guard") or {}).get("halted", False))
        self.day_start_equity = (d.get("guard") or {}).get("day_start_equity")
        self.peak_equity = (d.get("guard") or {}).get("peak_equity")

        self.log.info(f"Resumed state from {self.cfg['state']['path']}")

       
    def _restore_from_state(self, d: dict) -> None:
        if not isinstance(d, dict):
            return

        # restore meta
        self.position_meta = dict(d.get("position_meta") or {})

        # restore paper portfolio
        if getattr(self, "paper", None) is not None:
            try:
                pdata = d.get("paper")
                if isinstance(pdata, dict):
                    self.paper = self.paper.from_dict(self.cfg, pdata)
            except Exception:
                pass

        # restore positions view if you keep an internal store
        # (optional): if you have a dict for open positions, populate it from d["positions"]
        # Important: DO NOT append duplicates; do upsert by (symbol, side)

        # If you don't have a live positions store, it's still OK:
        # UI/API will read from paper + position_meta + snapshot views.

        
    def _snapshot(self) -> Dict[str, Any]:
        return {
            "cfg_exchange": self.cfg.get("exchange"),
            "cfg_mode": self.cfg.get("mode"),
            "paper": self.paper.to_dict() if self.paper else None,
            "positions_meta": {k: pos.__dict__ for k, pos in self.positions.items()},
            "pending": {k: po.__dict__ for k, po in self.pending.items()},
            "pairs": self.pairs,
            "guard": {"halted": self.halted, "day_start_equity": self.day_start_equity, "peak_equity": self.peak_equity},
            "trades": self.rec.to_list(5000),
        }

    def _save_state_periodic(self, last_save: float) -> float:
        interval = float((self.cfg.get("state", {}) or {}).get("save_interval_sec", 30))
        if time.time() - last_save < interval:
            return last_save

        # Alege UN singur format de snapshot. Recomand _state_snapshot() (e mai UI/API friendly)
        try:
            snap = self._state_snapshot()
        except Exception:
            # fallback la snapshot-ul vechi
            snap = self._snapshot()

        try:
            self.state.save(snap)
        except Exception:
            pass

        # optional backups
        bint = float((self.cfg.get("state", {}) or {}).get("backup_interval_sec", 0))
        if bint > 0:
            last_b = float(getattr(self, "_last_backup_ts", 0.0) or 0.0)
            if time.time() - last_b >= bint:
                try:
                    self.state.save_backup(snap)
                except Exception:
                    pass
                setattr(self, "_last_backup_ts", time.time())

        return time.time()

            

         

    # -----------------------------
    # Equity helpers
    # -----------------------------
    def _mark_prices(self) -> Dict[str, float]:
        syms = set(self.pairs) | set(self.positions.keys())
        if self.paper:
            syms |= set(self.paper.positions.keys())
        prices: Dict[str, float] = {}
        for sym in syms:
            try:
                t = self.client.fetch_ticker_cached(sym)
                last = _sf(t.get("last"))
                if np.isfinite(last) and last > 0:
                    prices[sym] = float(last)
            except Exception:
                continue
        return prices

    def equity(self) -> float:
        quote = self.cfg["quote_asset"]
        if self.cfg.get("mode") == "paper" and self.paper:
            return float(self.paper.equity(self._mark_prices()))

        eq = 0.0
        try:
            eq += float(self.client.fetch_balance_quote(quote))
        except Exception:
            pass

        # IMPORTANT: Futures equity != notional. Nu adăuga pos.qty * price.
        if bool(self.cfg.get("enable_futures", False)):
            return float(eq)

        prices = self._mark_prices()
        for sym, pos in self.positions.items():
            px = prices.get(sym)
            if px:
                eq += float(pos.qty) * float(px)
        return float(eq)


    def free_equity(self) -> float:
        if self.cfg.get("mode") == "paper" and self.paper:
            for attr in ("cash", "quote_cash", "balance"):
                v = getattr(self.paper, attr, None)
                if isinstance(v, (int, float)) and v >= 0:
                    return float(v)
            return float(self.equity())

        quote = self.cfg["quote_asset"]
        for fn in ("fetch_free_balance_quote", "fetch_available_quote", "fetch_free_quote"):
            f = getattr(self.client, fn, None)
            if callable(f):
                try:
                    v = float(f(quote))
                    if v >= 0:
                        return v
                except Exception:
                    pass

        try:
            return float(self.client.fetch_balance_quote(quote))
        except Exception:
            return float(self.equity())

    # -----------------------------
    # Daily + kill switch
    # -----------------------------
    def _new_day_check(self):
        dk = pd.Timestamp.utcnow().strftime("%Y-%m-%d")
        cur = getattr(self, "_day_key", None)
        if cur != dk:
            self._day_key = dk
            eq = self.equity()
            self.day_start_equity = eq
            self.peak_equity = eq
            self.halted = False
            self.risk.new_day_if_needed()
            self.equity_window.clear()
            self.log.info(f"New trading day {dk}. day_start_equity={eq:.2f}")

    def _halt(self, reason: str):
        if self.halted:
            return
        self.halted = True
        self.log.warning(f"KILL SWITCH HALT: {reason}")
        if (self.cfg.get("risk", {}) or {}).get("kill_switch", {}).get("close_all_on_halt", False):
            self.log.warning("close_all_on_halt enabled -> closing all positions.")
            self.close_all(reason="halt")
    
    

    
    
    def _apply_kill_switch(self):
        ks = (self.cfg.get("risk", {}) or {}).get("kill_switch", {}) or {}
        eq = self.equity()
        if self.day_start_equity is None:
            self.day_start_equity = eq
        if self.peak_equity is None:
            self.peak_equity = eq
        self.peak_equity = max(float(self.peak_equity), float(eq))

        daily_loss = (float(self.day_start_equity) - float(eq)) / max(1e-9, float(self.day_start_equity))
        dd = (float(self.peak_equity) - float(eq)) / max(1e-9, float(self.peak_equity))

        shock = ks.get("intraday_shock", {}) or {}
        if shock.get("enabled", True):
            win = int(shock.get("window_min", 30)) * 60
            drop = float(shock.get("drop_pct", 0.015))
            self.equity_window.append((time.time(), float(eq)))
            t0 = None
            e0 = None
            for t, e in self.equity_window:
                if time.time() - t <= win:
                    t0 = t
                    e0 = e
                    break
            min_eq = float(shock.get('min_equity', 50.0))
            # Guard against nonsensical % moves when baseline equity is too small or negative (paper can go negative).
            if e0 is not None and float(e0) >= min_eq:
                drop_frac = (float(e0) - float(eq)) / max(1e-9, float(e0))
                if drop_frac >= drop:
                    self._halt(f"Intraday shock: equity drop {drop_frac * 100:.2f}% in {win / 60:.0f}min")

        if daily_loss >= float(ks.get("max_daily_loss_pct", 1e9)):
            self._halt(f"Max DAILY loss reached: {daily_loss * 100:.2f}%")
        if dd >= float(ks.get("max_drawdown_pct", 1e9)):
            self._halt(f"Max DRAWDOWN reached: {dd * 100:.2f}%")
        if self.risk.max_trades_reached():
            self._halt("Max trades/day reached")

        realized = self.paper.realized_pnl_gross if self.paper else 0.0
        fees = self.paper.fees_paid if self.paper else 0.0
        self.metrics.update(
            equity=float(eq),
            realized_pnl=float(realized),
            fees=float(fees),
            open_positions=len([p for p in self.positions.values() if p.qty > 0]),
            pending_orders=len(self.pending),
        )

        try:
            if self.store:
                now_ts = time.time()
                if (now_ts - float(self._last_snapshot_ts)) >= float(self.snapshot_interval_sec):
                    self.store.snapshot(
                        float(eq),
                        len([p for p in self.positions.values() if p.qty > 0]),
                        len(self.pending),
                        {"exchange": self.cfg.get("exchange"), "mode": self.cfg.get("mode"), "quote": self.cfg.get("quote_asset")},
                    )
                    self._last_snapshot_ts = now_ts
        except Exception:
            pass

    # -----------------------------
    # Market + correlation helpers
    # -----------------------------
    def _refresh_pairs(self):
        self.client.load_markets()

        intel_cfg = (self.cfg.get("intel") or {})
        use_intel = bool(intel_cfg.get("enabled", False))

        pairs = []
        reasons = {}
        if use_intel:
            try:
                # Build a portfolio-aware watchlist with audited reasons
                portfolio_syms = list(getattr(self, "positions", {}) or {})
                if str(self.cfg.get("mode", "")).lower().strip() == "paper" and getattr(self, "paper", None) is not None:
                    portfolio_syms = list((self.paper.positions or {}).keys())

                ret_map = {}
                try:
                    # correlation gate uses returns
                    ret_map = self._compute_returns_map(list(set(portfolio_syms))) if portfolio_syms else {}
                except Exception:
                    ret_map = {}

                pairs, reasons = self.market_intel.build_watchlist(self.client, portfolio_symbols=portfolio_syms, ret_map=ret_map)
            except Exception as e:
                self.log.warning(f"Market intel pipeline failed, falling back to selector: {type(e).__name__}: {e}")
                pairs = []

        if not pairs:
            pairs = self.selector.select(self.client)
            reasons = {s: {"source": "selector"} for s in pairs}

        self.pairs = list(pairs)
        self.watchlist_reasons = dict(reasons or {})

        try:
            # Regime + meta strategy decisions are cached for UI/API
            for sym in self.pairs:
                rs = self.regime_detector.per_symbol(sym, self.autonomy)
                ms = self.meta_strategy_selector.select(sym, rs.regime, rs.strength)
                # persist decision audit (best-effort)
                try:
                    if self.store:
                        self.store.decision(
                            decision_type="watchlist",
                            symbol=sym,
                            component="market_intel",
                            payload={"reasons": self.watchlist_reasons.get(sym, {}), "regime": rs.__dict__, "meta": ms.__dict__},
                        )
                except Exception:
                    pass
        except Exception:
            pass

        self.ws.set_symbols(self.pairs)
        self.log.info(f"Selected pairs: {', '.join(self.pairs[:20])}")
        # Human-readable trace for debugging selection logic
        try:
            self._think(
                "watchlist_selected",
                count=len(self.pairs),
                sample=self.pairs[:10],
            )
            for sym in self.pairs[:10]:
                rs = self.regime_detector.per_symbol(sym, self.autonomy)
                ms = self.meta_strategy_selector.select(sym, rs.regime, rs.strength)
                self._think(
                    "watchlist_symbol",
                    symbol=sym,
                    reasons=self.watchlist_reasons.get(sym, {}),
                    regime=getattr(rs, "regime", None),
                    strength=float(getattr(rs, "strength", 0.0) or 0.0),
                    meta=getattr(ms, "name", None) or getattr(ms, "style", None) or "",
                )
        except Exception:
            pass

    def _compute_returns_map(self, symbols: List[str]) -> Dict[str, np.ndarray]:
        look = int(((self.cfg.get("risk", {}) or {}).get("portfolio", {}) or {}).get("correlation_filter", {}).get("lookback", 120))
        ret: Dict[str, np.ndarray] = {}
        for sym in symbols:
            try:
                df = self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=look + 50)
                c = df["close"].values.astype(float)
                r = np.diff(np.log(c + 1e-12))
                ret[sym] = r[-look:]
            except Exception:
                continue
        return ret

    def _volatility_pause(self, df: pd.DataFrame) -> bool:
        thr = float((self.cfg.get("risk", {}) or {}).get("volatility_pause_atr_pct", 1e9))
        if thr <= 0:
            return False
        a = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        px = float(df["close"].iloc[-1])
        if px <= 0:
            return False
        return (a / px) >= thr

    @instrument(
    "engine.get_bid_ask_last",
    disable_after=10,
    disable_sec=10,
    ctx_builder=lambda self, symbol: self._ctx(symbol=symbol),
    )

    def _get_bid_ask_last(self, symbol: str) -> Tuple[float, float, float]:
        t = self.client.fetch_ticker_cached(symbol)
        bid = _sf(t.get("bid"))
        ask = _sf(t.get("ask"))
        last = _sf(t.get("last"))
        return float(bid), float(ask), float(last)

    def _atr_pct(self, df: pd.DataFrame) -> float:
        a = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        px = float(df["close"].iloc[-1])
        return (a / px) if px > 0 else 0.0
        
    def _ctx(self, **kw) -> Dict[str, Any]:
        base = {
            "exchange": self.cfg.get("exchange"),
            "mode": self.cfg.get("mode"),
            "futures": bool(self.cfg.get("enable_futures", False)),
            "halted": bool(getattr(self, "halted", False)),
            "paused": bool(self.watchdog.is_paused()) if hasattr(self, "watchdog") else False,
        }
        base.update({k: v for k, v in kw.items() if v is not None})
        return base


    # -----------------------------
    # Execution micro-model
    # -----------------------------
    def _choose_maker_offset_bps(self, symbol: str, side: str, atr_pct: float) -> Tuple[float, Dict[str, float], float]:
        mm = self.cfg.get("micro_model", {}) or {}
        base = float((self.cfg.get("execution", {}) or {}).get("maker_offset_bps", 6.0))
        if not mm.get("enabled", True):
            return base, {}, float("nan")

        depth = int(mm.get("orderbook_depth", 20))
        ob = self.client.fetch_order_book(symbol, limit=depth)
        met = orderbook_metrics(ob, depth=depth)
        spread = met.get("spread_bps", float("nan"))
        imb = met.get("imbalance", 0.0)

        off_min = float(mm.get("offset_min_bps", 1.0))
        off_max = float(mm.get("offset_max_bps", 14.0))
        dyn = bool(mm.get("dynamic_offset", True))
        if not dyn or not np.isfinite(spread):
            off = clamp(base, off_min, off_max)
        else:
            off = base + 0.25 * (float(spread) - 5.0) / 5.0 + 120.0 * max(0.0, float(atr_pct) - 0.01)
            off = clamp(off, off_min, off_max)

        p_fill = maker_fill_probability(self.cfg, side, distance_bps=float(off), atr_pct=float(atr_pct), imbalance=float(imb))
        return float(off), met, float(p_fill)

    def _maker_price(self, symbol: str, side: str, bid: float, ask: float, last: float, atr_pct: float) -> float:
        off_bps, _, _ = self._choose_maker_offset_bps(symbol, side, atr_pct=atr_pct)
        off = float(off_bps) / 10_000.0

        if side == "buy":
            base = bid if np.isfinite(bid) and bid > 0 else last
            px = base * (1.0 - off)
        else:
            base = ask if np.isfinite(ask) and ask > 0 else last
            px = base * (1.0 + off)

        return float(self.client.format_price(symbol, px))

    # -----------------------------
    # TWAP / Iceberg
    # -----------------------------
    def _twap_cfg(self) -> Dict[str, Any]:
        return (self.cfg.get("execution", {}) or {}).get("twap", {}) or {}

    def _twap_should_use(
        self,
        symbol: str,
        side: str,
        qty: float,
        last: float,
        reason: str,
        *,
        ex_type: str = "limit",
        force_market: bool = False,
    ) -> bool:
        cfg = self._twap_cfg()
        if not cfg.get("enabled", False):
            return False

        allow_reasons = cfg.get("allow_reasons")
        if isinstance(allow_reasons, list) and allow_reasons:
            if not any(str(r) in str(reason) for r in allow_reasons):
                return False

        deny_reasons = cfg.get("deny_reasons")
        if isinstance(deny_reasons, list) and deny_reasons:
            if any(str(r) in str(reason) for r in deny_reasons):
                return False

        min_notional = float(cfg.get("min_notional_usd", 0.0))
        min_qty = float(cfg.get("min_qty", 0.0))
        notional = float(qty) * float(last)

        if (notional < min_notional) or (float(qty) < min_qty):
            return False

        resolved_type = "market" if force_market else str(ex_type or "limit").lower()
        allow_for_limit = bool(cfg.get("allow_for_limit", False))
        if resolved_type != "market" and not allow_for_limit:
            return False

        if symbol in getattr(self, "twap_plans", {}):
            return False

        return True


        # Execution router (intent -> order type). Best-effort, does not block.
        plan = None
        try:
            er_cfg = ((self.cfg.get("execution") or {}).get("router") or {})
            if (not force_market) and bool(er_cfg.get("enabled", True)):
                plan = self.execution_router.route(
                    self.client,
                    symbol=symbol,
                    side=side,
                    qty=float(qty),
                    bid=float(bid),
                    ask=float(ask),
                    last=float(last),
                    atr_pct=float(atr_pct or 0.0),
                    reason=str(reason or ""),
                )
                try:
                    if self.store:
                        self.store.decision(
                            decision_type="execution_route",
                            symbol=symbol,
                            component="execution_router",
                            payload={"plan": {"kind": plan.kind, "params": plan.params, "reasons": plan.reasons}, "reason": str(reason or "")},
                        )
                except Exception:
                    pass
        except Exception:
            plan = None

        ex_type = str((self.cfg.get("execution", {}) or {}).get("type", "limit")).lower()

        if plan is not None and (not force_market):
            if str(plan.kind) == "twap":
                if self._start_twap(symbol, side, float(qty), float(last), reason + "|router_twap", atr_pct=atr_pct):
                    return
            elif str(plan.kind) == "market":
                ex_type = "market"
            elif str(plan.kind) == "maker":
                ex_type = "limit"

        if force_market:
            ex_type = 'market'
        allow_for_limit = bool(cfg.get("allow_for_limit", False))
        if ex_type != "market" and not allow_for_limit:
            return False

        if symbol in self.twap_plans:
            return False

        return True

    def _start_twap(self, symbol: str, side: str, qty: float, last: float, reason: str, atr_pct: float = 0.0) -> bool:
        cfg = self._twap_cfg()
        slices = int(cfg.get("slices", 10))
        slices = max(1, min(slices, int(cfg.get("max_slices", slices)) or slices))

        target_slice_notional = float(cfg.get("target_slice_notional_usd", 0.0))
        if target_slice_notional > 0 and last > 0:
            derived = int(math.ceil((float(qty) * float(last)) / max(1e-9, target_slice_notional)))
            slices = max(1, min(slices, derived))

        interval_sec = float(cfg.get("interval_sec", 2.0))
        interval_sec = max(0.2, interval_sec)

        slice_qty = float(qty) / float(slices)
        slice_qty = float(self.client.format_amount(symbol, slice_qty))
        slice_qty, _ = self.client.enforce_trade_rules(symbol, side, slice_qty, float(last))
        if slice_qty <= 0:
            return False

        plan = TwapPlan(
            symbol=symbol,
            side=side,
            total_qty=float(qty),
            remaining_qty=float(qty),
            slice_qty=float(slice_qty),
            interval_sec=float(interval_sec),
            next_ts=time.time(),
            executed_slices=0,
            max_slices=int(slices),
            reason=str(reason),
            atr_pct=float(atr_pct),
        )
        self.twap_plans[symbol] = plan
        self.log.info(
            f"[TWAP] START {side.upper()} {symbol} total={qty:.8f} slices={slices} interval={interval_sec:.2f}s slice_qty~{slice_qty:.8f} reason={reason}"
        )
        return True

    def cancel_twap(self, symbol: Optional[str] = None, reason: str = "manual_cancel") -> None:
        if not self.twap_plans:
            return
        if symbol:
            if symbol in self.twap_plans:
                del self.twap_plans[symbol]
                self.log.warning(f"[TWAP] CANCEL {symbol} ({reason})")
            return
        self.twap_plans.clear()
        self.log.warning(f"[TWAP] CANCEL ALL ({reason})")
        
    @instrument(
        "engine.process_twap",
        disable_after=10,
        disable_sec=10,
        ctx_builder=lambda self: self._ctx(twap=len(self.twap_plans)),
    )

    def _process_twap_plans(self) -> None:
        if not self.twap_plans:
            return

        cfg = self._twap_cfg()
        now_ts = time.time()
        max_slices_per_tick = int(cfg.get("max_slices_per_tick", 3))
        max_slices_per_tick = max(1, min(20, max_slices_per_tick))

        jitter_sec = float(cfg.get("interval_jitter_sec", 0.0))
        jitter_sec = max(0.0, jitter_sec)

        qty_jitter_pct = float(cfg.get("qty_jitter_pct", 0.0))
        qty_jitter_pct = max(0.0, min(0.5, qty_jitter_pct))

        max_duration_sec = float(cfg.get("max_duration_sec", 0.0))

        done: List[str] = []
        slices_executed = 0

        for sym, plan in list(self.twap_plans.items()):
            if slices_executed >= max_slices_per_tick:
                break

            if max_duration_sec > 0 and (now_ts - plan.created_ts) > max_duration_sec:
                self.log.warning(f"[TWAP] TIMEOUT {sym} -> cancel")
                done.append(sym)
                continue

            if now_ts < float(plan.next_ts):
                continue

            try:
                _, _, last = self._get_bid_ask_last(sym)
            except Exception:
                last = float("nan")

            if not np.isfinite(last) or last <= 0:
                plan.next_ts = now_ts + max(0.5, plan.interval_sec)
                self.twap_plans[sym] = plan
                continue

            q = min(float(plan.slice_qty), float(plan.remaining_qty))
            if qty_jitter_pct > 0:
                j = (random.random() * 2.0 - 1.0) * qty_jitter_pct
                q = q * (1.0 + j)

            q = float(self.client.format_amount(sym, q))
            q, _ = self.client.enforce_trade_rules(sym, plan.side, q, float(last))
            if q <= 0:
                done.append(sym)
                continue

            try:
                self._fill_market(sym, plan.side, float(q), float(last), f"twap:{plan.reason}")
            except Exception as e:
                self.metrics.inc_error()
                self.watchdog.record_error(e)
                try:
                    self._last_cycle_error = f"{type(e).__name__}: {e}"
                except Exception:
                    self._last_cycle_error = ""
                try:
                    self._think("loop_error", level="warning", error=self._last_cycle_error)
                except Exception:
                    pass
                plan.next_ts = now_ts + max(1.0, plan.interval_sec)
                self.twap_plans[sym] = plan
                continue

            plan.remaining_qty = float(plan.remaining_qty) - float(q)
            plan.executed_slices += 1

            interval = float(plan.interval_sec)
            if jitter_sec > 0:
                interval = max(0.2, interval + (random.random() * 2.0 - 1.0) * jitter_sec)
            plan.next_ts = now_ts + interval

            if plan.remaining_qty <= 1e-12 or plan.executed_slices >= int(plan.max_slices):
                self.log.info(
                    f"[TWAP] DONE {sym} side={plan.side} slices={plan.executed_slices}/{plan.max_slices} remaining={plan.remaining_qty:.8f}"
                )
                done.append(sym)
            else:
                self.twap_plans[sym] = plan

            slices_executed += 1

        for sym in done:
            if sym in self.twap_plans:
                del self.twap_plans[sym]

    # -----------------------------
    # Orders + fills
    # -----------------------------
    
    @instrument(
        "engine.place_order",
        disable_after=5,
        disable_sec=20,
        ctx_builder=lambda self, symbol, side, qty, reason, atr_pct=0.0: self._ctx(
            symbol=symbol, side=side, qty=float(qty), reason=reason, atr_pct=float(atr_pct)
        ),
    )
    
    def _place_order(self, symbol: str, side: str, qty: float, reason: str, atr_pct: float = 0.0) -> None:
        if qty <= 0:
            return

        # Force-immediate execution for exit/protection reasons (do not block on maker pending orders)
        force_market_reasons = {
            'stop_loss', 'take_profit', 'tp', 'sl', 'panic_stop', 'manual_close_all', 'manual_close',
            'signal_exit', 'exit', 'close', 'liquidation_guard',
            'volatility_throttle', 'time_exit'
        }
        force_market = str(reason or '').lower().strip() in force_market_reasons

        mode = str(self.cfg.get("mode", "paper")).lower().strip()
        is_paper = (mode == "paper")

        # If we must close now, cancel any existing pending maker order for this symbol
        if force_market and symbol in self.pending:
            try:
                po = self.pending.get(symbol)
                oid = getattr(po, 'order_id', None) if po is not None else None
                if isinstance(po, dict):
                    oid = po.get('order_id') or po.get('id')
                if (not is_paper) and oid:
                    try:
                        self.client.cancel_order(str(oid), symbol)
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                del self.pending[symbol]
            except Exception:
                pass

        bid, ask, last = self._get_bid_ask_last(symbol)

        qty, _ = self.client.enforce_trade_rules(symbol, side, qty, last)
        if qty <= 0:
            self.log.warning(f"{symbol}: qty <= 0 after rules ({reason})")
            return


        # PAPER realism guard: cap notional by a configurable leverage ceiling (prevents negative equity spirals).
        if is_paper and bool(self.cfg.get('enable_futures', False)):
            try:
                p_cfg = (self.cfg.get('paper') or {})
                max_lev = float(p_cfg.get('max_leverage', 3.0))
                if max_lev < 1.0:
                    max_lev = 1.0
                eq_now = float(self.equity())
                notional = float(qty) * float(last)
                cap = max(0.0, eq_now) * max_lev
                if cap > 0 and notional > cap:
                    new_qty = cap / max(1e-12, float(last))
                    new_qty, _ = self.client.enforce_trade_rules(symbol, side, new_qty, last)
                    if new_qty <= 0:
                        self.log.warning(f"{symbol}: PAPER leverage cap blocks order (notional={notional:.2f} > cap={cap:.2f}) ({reason})")
                        return
                    self.log.warning(f"{symbol}: PAPER leverage cap scales qty {qty:.8f} -> {new_qty:.8f} (notional={notional:.2f} cap={cap:.2f}) reason={reason}")
                    qty = float(new_qty)
            except Exception:
                pass

        # Execution router (intent -> order type). Best-effort, does not block.
        plan = None
        try:
            er_cfg = ((self.cfg.get("execution") or {}).get("router") or {})
            if (not force_market) and bool(er_cfg.get("enabled", True)):
                plan = self.execution_router.route(
                    self.client,
                    symbol=symbol,
                    side=side,
                    qty=float(qty),
                    bid=float(bid),
                    ask=float(ask),
                    last=float(last),
                    atr_pct=float(atr_pct or 0.0),
                    reason=str(reason or ""),
                )
                try:
                    if self.store:
                        self.store.decision(
                            decision_type="execution_route",
                            symbol=symbol,
                            component="execution_router",
                            payload={"plan": {"kind": plan.kind, "params": plan.params, "reasons": plan.reasons}, "reason": str(reason or "")},
                        )
                except Exception:
                    pass
        except Exception:
            plan = None

        ex_type = str((self.cfg.get("execution", {}) or {}).get("type", "limit")).lower()

        if plan is not None and (not force_market):
            if str(plan.kind) == "twap":
                if self._start_twap(symbol, side, float(qty), float(last), reason + "|router_twap", atr_pct=atr_pct):
                    return
            elif str(plan.kind) == "market":
                ex_type = "market"
            elif str(plan.kind) == "maker":
                ex_type = "limit"

        if force_market:
            ex_type = 'market'

        # TWAP route (optional) — în PAPER facem TWAP “simulat” prin market fills, sau îl putem dezactiva.
        # Recomand: în paper, păstrează TWAP ca plan (și _process_twap_plans va apela _fill_market care deja e paper-safe).
        if (not force_market) and self._twap_should_use(symbol, side, float(qty), float(last), reason):
            if self._start_twap(symbol, side, float(qty), float(last), reason, atr_pct=atr_pct):
                return

        # MARKET: _fill_market e deja paper-safe (are branch de paper)
        if ex_type == "market":
            self._fill_market(symbol, side, qty, last, reason)
            return

        # LIMIT (maker)
        px = self._maker_price(symbol, side, bid, ask, last, atr_pct=atr_pct)

        if (not force_market) and symbol in self.pending:
            self.log.debug(f"{symbol}: skip place_order -> pending exists ({reason})")
            return

        # PAPER: nu trimite pe exchange, creează PendingOrder “virtual” și îl va procesa _check_pending()
        if is_paper:
            oid = f"paper-{int(time.time()*1000)}-{random.randint(1000,9999)}"
            self.pending[symbol] = PendingOrder(
                symbol=symbol,
                side=side,
                qty=float(qty),
                price=float(px),
                order_id=str(oid),
                created_ts=time.time(),
                reason=reason,
                is_maker=True,
                atr_pct=float(atr_pct),
            )
            self.log.info(f"[PAPER] LIMIT {side.upper()} {symbol} qty={qty:.8f} price={px:.8f} id={oid} reason={reason}")
            return

        # LIVE: post-only best effort
        post_only = bool((self.cfg.get("execution", {}) or {}).get("post_only", True))
        params = {"postOnly": True} if post_only else {}

        try:
            resp = self.client.create_order(symbol, "limit", side, qty, px, params=params)
        except Exception as e:
            if post_only:
                self.log.warning(f"{symbol}: post-only rejected; retry normal limit ({type(e).__name__})")
                resp = self.client.create_order(symbol, "limit", side, qty, px, params={})
            else:
                raise

        oid = str(resp.get("id"))
        self.pending[symbol] = PendingOrder(symbol, side, float(qty), float(px), oid, time.time(), reason=reason, is_maker=True, atr_pct=float(atr_pct))
        self.log.info(f"[LIVE] LIMIT {side.upper()} {symbol} qty={qty:.8f} price={px:.8f} id={oid} reason={reason}")


    # -----------------------------
    # Futures configuration + native protection (best-effort)
    # -----------------------------
    def _ensure_futures_settings(self, symbol: str, side: str, df: pd.DataFrame, df_trend: pd.DataFrame, signal_strength: float, desired_leverage: Optional[int] = None) -> bool:
        """Best-effort: set position mode, margin mode, leverage. Returns False to skip entry."""
        if not bool(self.cfg.get("enable_futures", False)):
            return True

        # In PAPER mode we do not touch exchange futures settings (margin/position mode/leverage).
        # These CCXT calls can fail on Binance depending on account status and are irrelevant for simulation.
        if str(self.cfg.get("mode", "")).lower() == "paper":
            return True


        fut = (self.cfg.get("futures") or {})
        # position mode
        hedge = bool(fut.get("hedge_mode", False))
        try:
            self.client.set_position_mode(hedge)
        except Exception as e:
            self.log.debug(f"{symbol}: set_position_mode failed: {type(e).__name__}: {e}")

        # margin mode
        mm = str(fut.get("margin_mode", "isolated")).lower()
        if mm not in ("isolated", "cross"):
            mm = "isolated"
        try:
            self.client.set_margin_mode(symbol, mm)
        except Exception as e:
            self.log.debug(f"{symbol}: set_margin_mode failed: {type(e).__name__}: {e}")

        # dynamic leverage (optional)
        lev_cfg = fut.get("dynamic_leverage", {}) or {}
        lev = float(fut.get("leverage", 1))
        if bool(lev_cfg.get("enabled", False)):
            try:
                # simplistic dynamic rule: stronger signal -> higher leverage within bounds; volatile -> lower
                a = float(atr(df, int((self.cfg.get("risk") or {}).get("atr_period", 14))).iloc[-1])
                last = float(df["close"].iloc[-1])
                atr_pct = (a / max(1e-12, last))
                min_lev = float(lev_cfg.get("min", 1))
                max_lev = float(lev_cfg.get("max", lev))
                # volatility dampener
                vol_k = float(lev_cfg.get("volatility_k", 4.0))
                vol_factor = 1.0 / (1.0 + vol_k * atr_pct)
                sig_factor = 1.0 + float(lev_cfg.get("signal_k", 0.5)) * max(0.0, float(signal_strength))
                lev = max(min_lev, min(max_lev, lev * vol_factor * sig_factor))
            except Exception:
                pass
        lev_i = int(max(1, round(float(lev))))
        # Override leverage if the caller computed a safer/plan-aware value
        if desired_leverage is not None:
            try:
                lev_i = int(max(1, int(desired_leverage)))
            except Exception:
                pass
        try:
            self.client.set_leverage(symbol, lev_i)
        except Exception as e:
            self.log.debug(f"{symbol}: set_leverage({lev_i}) failed: {type(e).__name__}: {e}")

        # funding gate (optional)
        # If funding is unfavorable but not blocking, we can down-scale exposure at entry.
        self._funding_penalty = 1.0
        fchk = (fut.get("funding_check") or {})
        if bool(fchk.get("enabled", False)):
            thr = float(fchk.get("abs_threshold", 0.0005))  # 0.05% default
            block_unfavorable = bool(fchk.get("block_unfavorable", True))
            try:
                fr = self.client.fetch_funding_rate(symbol)
                if fr is not None:
                    try:
                        if hasattr(self.metrics, "state") and hasattr(self.metrics.state, "funding_rate"):
                            self.metrics.state.funding_rate = float(fr)
                    except Exception:
                        pass

                    if abs(float(fr)) >= thr:
                        # in perpetuals: positive funding -> longs pay shorts
                        paying = (side == "long" and float(fr) > 0) or (side == "short" and float(fr) < 0)
                        if paying:
                            if block_unfavorable:
                                self.log.info(
                                    f"{symbol}: Skip entry due to unfavorable funding rate {float(fr):.6f} (thr={thr})"
                                )
                                return False
                            # downscale when funding is against us, instead of blocking
                            pen = float(fchk.get("penalty_mult", 0.7) or 0.7)
                            self._funding_penalty = max(0.1, min(1.0, pen))
                            if bool(fchk.get("log", False)):
                                self.log.info(
                                    f"{symbol}: Funding unfavorable {float(fr):.6f}; applying penalty_mult={self._funding_penalty:.2f}"
                                )
                        else:
                            if bool(fchk.get("log", False)):
                                self.log.info(f"{symbol}: Funding rate {float(fr):.6f} ok for {side}")
            except Exception as e:
                if bool(fchk.get("log", False)):
                    self.log.warning(f"{symbol}: funding check failed: {type(e).__name__}: {e}")

        return True

    def _cancel_protection_orders(self, symbol: str, pos: LivePosition) -> None:
        if self.cfg.get("mode") != "live":
            pos.sl_order_id = None
            pos.tp_order_id = None
            pos.trailing_order_id = None
            pos.protected_qty = 0.0
            return

        ids = [pos.sl_order_id, pos.tp_order_id, pos.trailing_order_id]
        for oid in [x for x in ids if x]:
            try:
                self.client.cancel_order(str(oid), symbol)
            except Exception:
                pass
        pos.sl_order_id = None
        pos.tp_order_id = None
        pos.trailing_order_id = None
        pos.protected_qty = 0.0
        pos.protection_ts = time.time()

    def _place_stop_loss_native(self, symbol: str, side: str, qty: float, stop_price: float) -> Optional[str]:
        """Best-effort native STOP_MARKET for futures; reduce-only."""
        if self.cfg.get("mode") != "live":
            return None
        params = {"reduceOnly": True}
        ex = str(self.cfg.get("exchange", "")).lower()
        typ = "STOP_MARKET"
        # Binance futures expects stopPrice
        params["stopPrice"] = float(stop_price)
        try:
            r = self.client.create_order(symbol, typ, side, float(qty), None, params=params)
            return str(r.get("id"))
        except Exception as e:
            self.log.warning(f"{symbol}: native SL failed ({ex}) {type(e).__name__}: {e}")
            return None

    def _place_take_profit_native(self, symbol: str, side: str, qty: float, tp_price: float) -> Optional[str]:
        """Best-effort native TAKE_PROFIT_MARKET for futures; reduce-only."""
        if self.cfg.get("mode") != "live":
            return None
        params = {"reduceOnly": True, "stopPrice": float(tp_price)}
        ex = str(self.cfg.get("exchange", "")).lower()
        typ = "TAKE_PROFIT_MARKET"
        try:
            r = self.client.create_order(symbol, typ, side, float(qty), None, params=params)
            return str(r.get("id"))
        except Exception as e:
            self.log.warning(f"{symbol}: native TP failed ({ex}) {type(e).__name__}: {e}")
            return None

    def _place_trailing_stop_native(self, symbol: str, side: str, qty: float, callback_rate: float) -> Optional[str]:
        """Best-effort native TRAILING_STOP_MARKET for futures."""
        if self.cfg.get("mode") != "live":
            return None
        params = {"reduceOnly": True, "callbackRate": float(callback_rate)}
        typ = "TRAILING_STOP_MARKET"
        try:
            r = self.client.create_order(symbol, typ, side, float(qty), None, params=params)
            return str(r.get("id"))
        except Exception as e:
            self.log.warning(f"{symbol}: native trailing failed {type(e).__name__}: {e}")
            return None
            
    @instrument(
        "engine.ensure_native_protection",
        disable_after=5,
        disable_sec=60,
        ctx_builder=lambda self, symbol, pos: self._ctx(
            symbol=symbol, pos_side=getattr(pos, "side", None),
            qty=float(getattr(pos, "qty", 0.0) or 0.0),
            stop=float(getattr(pos, "stop", 0.0) or 0.0),
            tp=float(getattr(pos, "tp", 0.0) or 0.0),
        ),
    )


    # -----------------------------
    # DCA / Pyramiding (best-effort)
    # -----------------------------
    def _maybe_dca(self, pos: LivePosition, last: float, a: float) -> None:
        if getattr(self, "_disable_dca_global", False):
            return
        cfg = (self.cfg.get("risk") or {}).get("dca", {}) or {}
        if not bool(cfg.get("enabled", False)):
            return
        if self.cfg.get("mode") != "live" and not bool(cfg.get("allow_paper", True)):
            return
        # adaptive gating (autonomy): freeze adds on volatility throttle + regime-based allow/deny
        try:
            if float(getattr(pos, "no_adds_until", 0.0)) > time.time():
                return
            rs = (self.regime_detector.get_symbol(pos.symbol) or {})
            reg = str(rs.get("regime", "na"))
            if (reg == "trend") and (not bool(cfg.get("allow_in_trend", False))):
                return
            if (reg == "high_vol") and (not bool(cfg.get("allow_in_high_vol", False))):
                return
        except Exception:
            pass

        # cooldown per symbol
        cd = float(cfg.get("cooldown_sec", 300))
        now = time.time()
        key = f"dca_{pos.symbol}"
        if (now - getattr(self, "_dca_last_ts", {}).get(key, 0.0)) < cd:
            return

        step_atr = float(cfg.get("step_atr", 1.0))
        add_mult = float(cfg.get("add_qty_mult", 0.5))
        max_adds = int(cfg.get("max_adds", 2))
        adds_done = int(getattr(pos, "dca_adds", 0))
        if adds_done >= max_adds:
            return

        # Do not DCA if price already reached (or crossed) stop level
        try:
            if getattr(pos, 'stop', 0.0):
                if pos.side == 'long' and float(last) <= float(pos.stop):
                    return
                if pos.side == 'short' and float(last) >= float(pos.stop):
                    return
        except Exception:
            pass

        # trigger on adverse move by step_atr
        adverse = (float(pos.entry) - float(last)) if pos.side == 'long' else (float(last) - float(pos.entry))
        if adverse < float(a) * step_atr:
            return

        add_qty = float(pos.qty) * add_mult
        order_side = "buy" if pos.side == "long" else "sell"
        self.log.info(f"{pos.symbol}: DCA add {add_qty:.8f} (adds_done={adds_done})")
        self._place_order(pos.symbol, order_side, add_qty, "dca_add", atr_pct=0.0)
        # track
        if not hasattr(self, "_dca_last_ts"):
            self._dca_last_ts = {}
        self._dca_last_ts[key] = now
        setattr(pos, "dca_adds", adds_done + 1)

    def _maybe_pyramid(self, pos: LivePosition, last: float, trend_strength: float, a: float) -> None:
        cfg = (self.cfg.get("risk") or {}).get("pyramid", {}) or {}
        if not bool(cfg.get("enabled", False)):
            return

        # adaptive gating (autonomy): freeze adds on volatility throttle + regime-based allow/deny
        try:
            if float(getattr(pos, "no_adds_until", 0.0)) > time.time():
                return
            rs = (self.regime_detector.get_symbol(pos.symbol) or {})
            reg = str(rs.get("regime", "na"))
            # pyramid is anti-martingale: prefer trend; block in range/high-vol unless explicitly allowed
            if (reg != "trend") and (not bool(cfg.get("allow_outside_trend", False))):
                return
            if (reg == "high_vol") and (not bool(cfg.get("allow_in_high_vol", False))):
                return
        except Exception:
            pass

        cd = float(cfg.get("cooldown_sec", 300))
        now = time.time()
        key = f"pyr_{pos.symbol}"
        if (now - getattr(self, "_pyr_last_ts", {}).get(key, 0.0)) < cd:
            return

        min_trend = float(cfg.get("min_trend_strength", 0.5))
        if float(trend_strength) < min_trend:
            return

        step_atr = float(cfg.get("step_atr", 1.0))
        add_mult = float(cfg.get("add_qty_mult", 0.25))
        max_adds = int(cfg.get("max_adds", 2))
        adds_done = int(getattr(pos, "pyr_adds", 0))
        if adds_done >= max_adds:
            return

        favorable = (float(last) - float(pos.entry)) if pos.side == "long" else (float(pos.entry) - float(last))
        if favorable < float(a) * step_atr:
            return

        add_qty = float(pos.qty) * add_mult
        order_side = "buy" if pos.side == "long" else "sell"
        self.log.info(f"{pos.symbol}: Pyramid add {add_qty:.8f} (trend={trend_strength:.2f} adds_done={adds_done})")
        self._place_order(pos.symbol, order_side, add_qty, "pyramid_add", atr_pct=0.0)

        if not hasattr(self, "_pyr_last_ts"):
            self._pyr_last_ts = {}
        self._pyr_last_ts[key] = now
        setattr(pos, "pyr_adds", adds_done + 1)

    def _recalc_position_after_add(self, pos: LivePosition, df: pd.DataFrame) -> None:
        """Recompute soft stop/tp after average price changes; refresh hard protection."""
        try:
            a = float(atr(df, int((self.cfg.get("risk") or {}).get("atr_period", 14))).iloc[-1])
            # keep R multiple but recompute around new entry
            rr = float((self.cfg.get("risk") or {}).get("rr", 2.0))
            sl_atr = float((self.cfg.get("risk") or {}).get("sl_atr", 1.5))
            if pos.side == "long":
                pos.stop = float(pos.entry) - sl_atr * a
                pos.tp = float(pos.entry) + rr * sl_atr * a
            else:
                pos.stop = float(pos.entry) + sl_atr * a
                pos.tp = float(pos.entry) - rr * sl_atr * a
        except Exception:
            return
        try:
            self._ensure_native_protection(pos.symbol, pos)
        except Exception:
            pass


    @instrument(
        "engine.fill_market",
        disable_after=5,
        disable_sec=20,
        ctx_builder=lambda self, symbol, side, qty, last, reason: self._ctx(
            symbol=symbol, side=side, qty=float(qty), last=float(last) if last else None, reason=reason
        ),
    )

    def _fill_market(self, symbol: str, side: str, qty: float, last: float, reason: str) -> None:
        """
        Execute a MARKET order (paper or live).
        - Enforces amount formatting + trade rules.
        - Uses last price as reference for paper fills and for rule checks.
        - On live: sends market order and routes fill to _on_live_fill().
        """
        sym = str(symbol).strip()
        s = str(side).strip().lower()
        q = float(qty)

        if q <= 0:
            return

        # Reference price: last if valid, otherwise fetch ticker
        px_ref = float(last) if (isinstance(last, (int, float)) and np.isfinite(last) and float(last) > 0) else float("nan")
        if not np.isfinite(px_ref) or px_ref <= 0:
            try:
                _, _, last2 = self._get_bid_ask_last(sym)
                if np.isfinite(last2) and last2 > 0:
                    px_ref = float(last2)
            except Exception:
                pass

        if not np.isfinite(px_ref) or px_ref <= 0:
            raise RuntimeError(f"{sym}: invalid reference price for market fill")

        # Format amount first
        try:
            q = float(self.client.format_amount(sym, q))
        except Exception:
            q = float(q)

        # Enforce exchange trade rules (minQty/minNotional/step) using reference price
        try:
            q2, _ = self.client.enforce_trade_rules(sym, s, float(q), float(px_ref))
            q = float(q2)
        except Exception as e:
            raise RuntimeError(f"{sym}: enforce_trade_rules failed: {type(e).__name__}: {e}")

        if q <= 0:
            raise RuntimeError(f"{sym}: qty <= 0 after trade rules (minQty/minNotional/step)")

        # Paper mode: simulate immediate market fill at reference price (with slippage configured in PaperPortfolio)
        if self.cfg.get("mode") == "paper":
            self._fill_paper(sym, s, float(q), float(px_ref), maker=False, reason=reason)
            return

        # Live mode: send market order
        resp = self.client.create_order(sym, "market", s, float(q), None, params={})

        # Determine fill price (best-effort)
        fill = _sf(resp.get("average") or resp.get("price"), float(px_ref))

        # Some exchanges return fills in trades list; keep best-effort simple
        self._on_live_fill(sym, s, float(q), float(fill), maker=False, reason=reason)

    def _ensure_native_protection(self, symbol: str, pos: LivePosition) -> None:
        """Best-effort native SL/TP (and optional trailing) for futures in LIVE.

        Policy:
          - Only in live + futures.
          - Avoid spam: cooldown + only refresh on material change.
          - Cover current abs(qty). Track protected_qty and order ids on pos.
        """
        try:
            if str(self.cfg.get("mode", "")).lower().strip() != "live":
                return
            if not bool(self.cfg.get("enable_futures", False)):
                return
            if pos is None or float(getattr(pos, "qty", 0.0) or 0.0) == 0.0:
                return

            risk = (self.cfg.get("risk") or {})
            hard = (risk.get("hard_sl_tp") or {})
            if not bool(hard.get("enabled", True)):
                return

            # basic cooldown
            now = time.time()
            cd = float(hard.get("refresh_cooldown_sec", 8.0) or 8.0)
            if float(getattr(pos, "protection_ts", 0.0) or 0.0) > 0 and (now - float(pos.protection_ts)) < cd:
                return

            qty = abs(float(pos.qty))
            stop = float(getattr(pos, "stop", 0.0) or 0.0)
            tp = float(getattr(pos, "tp", 0.0) or 0.0)
            if qty <= 0 or stop <= 0 or tp <= 0:
                return

            # determine close side
            close_side = "sell" if str(pos.side).lower() == "long" else "buy"

            # decide whether refresh is needed
            protected_qty = float(getattr(pos, "protected_qty", 0.0) or 0.0)
            has_ids = bool(pos.sl_order_id or pos.tp_order_id or pos.trailing_order_id)

            # material change thresholds
            qty_eps = float(hard.get("qty_refresh_eps", 0.0000001) or 1e-7)
            price_eps_bps = float(hard.get("price_refresh_eps_bps", 2.0) or 2.0)  # 2 bps default

            def _bps_diff(a: float, b: float) -> float:
                if a <= 0 or b <= 0:
                    return 1e9
                return abs(a - b) / ((a + b) / 2.0) * 10000.0

            # store last protected prices on pos (soft state)
            last_sl = float(getattr(pos, "_prot_sl", 0.0) or 0.0)
            last_tp = float(getattr(pos, "_prot_tp", 0.0) or 0.0)

            need = False
            if not has_ids:
                need = True
            if abs(qty - protected_qty) > max(qty_eps, 0.01 * qty_eps):
                need = True
            if _bps_diff(stop, last_sl) >= price_eps_bps:
                need = True
            if _bps_diff(tp, last_tp) >= price_eps_bps:
                need = True

            if not need:
                return

            # cancel existing protections first (best-effort)
            try:
                self._cancel_protection_orders(symbol, pos)
            except Exception:
                pass

            # optional trailing
            use_trailing = bool((hard.get("trailing") or {}).get("enabled", False))
            cb_rate = float((hard.get("trailing") or {}).get("callback_rate", 0.2) or 0.2)

            # Hedge mode positionSide support (Binance/Bybit)
            fut = (self.cfg.get("futures") or {}) if isinstance(self.cfg.get("futures"), dict) else {}
            hedge_mode = bool(fut.get("hedge_mode", False))
            position_side = None
            if hedge_mode:
                position_side = "LONG" if str(pos.side).lower() == "long" else "SHORT"

            # place SL/TP using your higher-level helper (preferred)
            ids = {"sl": None, "tp": None, "trailing": None}
            try:
                ids = self.place_native_sl_tp(
                    symbol=symbol,
                    pos_side=str(pos.side),
                    qty=float(qty),
                    stop_price=float(stop),
                    tp_price=float(tp),
                    use_trailing=bool(use_trailing),
                    trailing_callback_rate=float(cb_rate),
                ) or ids
            except Exception as e:
                # detect Binance regulation reduce-only error and block symbol (optional)
                try:
                    if self._is_binance_reduce_only_regulation_error(e):
                        self._block_symbol(symbol, "reduce_only_regulation", seconds=6 * 3600)
                except Exception:
                    pass

            pos.sl_order_id = ids.get("sl")
            pos.tp_order_id = ids.get("tp")
            pos.trailing_order_id = ids.get("trailing")

            pos.protected_qty = float(qty)
            pos.protection_ts = now
            setattr(pos, "_prot_sl", float(stop))
            setattr(pos, "_prot_tp", float(tp))

            try:
                self.log.info(
                    f"{symbol}: native protection refreshed sl={pos.sl_order_id} tp={pos.tp_order_id} tr={pos.trailing_order_id} qty={qty:.8f}"
                )
            except Exception:
                pass

        except Exception:
            return




    def _fill_paper(self, symbol: str, side: str, qty: float, price: float, maker: bool, reason: str):
        assert self.paper is not None
        exch = self.cfg.get("exchange")
        mode = "paper"
        if side == "buy":
            # PaperPortfolio.buy may return either:
            #   (fill, fee, executed_qty)
            #   (fill, fee, realized_pnl, executed_qty)
            ret = self.paper.buy(symbol, qty, price, maker)
            fill = fee = aq = 0.0
            realized = 0.0
            try:
                if isinstance(ret, tuple) and len(ret) == 4:
                    fill, fee, realized, aq = ret
                elif isinstance(ret, tuple) and len(ret) == 3:
                    fill, fee, aq = ret
                    realized = 0.0
                else:
                    # Unexpected signature
                    return
            except Exception:
                return

            if fill <= 0 or aq <= 0:
                return

            # NOTE: realized_pnl is meaningful on BUY when covering a short.
            self.rec.add(TradeRecord(now_utc_iso(), exch, mode, symbol, "buy", aq, fill, aq * fill, fee, reason, float(realized)))
            try:
                # feed autonomy learning with the last trade record
                self.autonomy.learn_from_trades([self.rec.trades[-1].__dict__])
            except Exception:
                pass
            try:
                if self.store:
                    self.store.trade(self.rec.trades[-1].__dict__, {"maker": bool(maker)})
            except Exception:
                pass
            self.risk.mark_trade(symbol)
            self.metrics.inc_trade()
            if abs(float(realized)) > 1e-12:
                self.log.info(f"[PAPER] BUY {symbol} qty={aq:.8f} @ {fill:.8f} realized={float(realized):.4f} fee={fee:.4f} reason={reason}")
            else:
                self.log.info(f"[PAPER] BUY {symbol} qty={aq:.8f} @ {fill:.8f} fee={fee:.4f} reason={reason}")
            try:
                self._sync_paper_meta(symbol)
            except Exception:
                pass

            # If this BUY fully closed a short, capture exit for re-entry gating
            try:
                if symbol not in (self.paper.positions or {}):
                    self._record_exit_event(symbol, reason, float(realized), side="short")
                    try:
                        self._autonomy_on_trade_closed(symbol, self.positions.get(symbol), float(realized), float(abs(aq * fill)))
                    except Exception:
                        pass
            except Exception:
                pass
        else:
            fill, fee, realized, aq = self.paper.sell(symbol, qty, price, maker)
            if fill <= 0 or aq <= 0:
                return
            self.rec.add(TradeRecord(now_utc_iso(), exch, mode, symbol, "sell", aq, fill, aq * fill, fee, reason, realized))
            try:
                self.autonomy.learn_from_trades([self.rec.trades[-1].__dict__])
            except Exception:
                pass
            try:
                if self.store:
                    self.store.trade(self.rec.trades[-1].__dict__, {"maker": bool(maker)})
            except Exception:
                pass
            self.risk.mark_trade(symbol)
            self.metrics.inc_trade()
            self.log.info(f"[PAPER] SELL {symbol} qty={aq:.8f} @ {fill:.8f} realized={realized:.4f} reason={reason}")
            try:
                self._sync_paper_meta(symbol)
            except Exception:
                pass

            # If this SELL fully closed a long, capture exit for re-entry gating
            try:
                if symbol not in (self.paper.positions or {}):
                    self._record_exit_event(symbol, reason, float(realized), side="long")
                    try:
                        self._autonomy_on_trade_closed(symbol, self.positions.get(symbol), float(realized), float(abs(aq * fill)))
                    except Exception:
                        pass
            except Exception:
                pass


    def _sync_paper_meta(self, symbol: str) -> None:
        # PAPER mode: PaperPortfolio tine qty/avg_price. Engine-ul are nevoie de LivePosition meta
        # pentru SL/TP management + afisare in GUI (Status tab).
        try:
            if str(self.cfg.get("mode", "")).lower() != "paper":
                return
            if not getattr(self, "paper", None):
                return

            ppos = (self.paper.positions or {}).get(symbol)

            # Daca pozitia paper e inchisa -> sterge meta
            if not ppos:
                if symbol in self.positions:
                    try:
                        del self.positions[symbol]
                    except Exception:
                        pass
                if symbol in self.entry_intents:
                    try:
                        del self.entry_intents[symbol]
                    except Exception:
                        pass
                return

            qty = float(getattr(ppos, "qty", 0.0) or 0.0)
            entry = float(getattr(ppos, "avg_price", 0.0) or 0.0)
            if abs(qty) <= 1e-12 or entry <= 0:
                return

            side = "long" if qty > 0 else "short"
            qty_abs = abs(qty)

            pos = (self.positions or {}).get(symbol)

            # incearca sa folosesti ATR din intent (daca exista), altfel fallback ~1% din pret
            intent = (self.entry_intents or {}).get(symbol)
            atr_val = 0.0
            try:
                atr_val = float(getattr(intent, "atr_val", 0.0) or 0.0)
            except Exception:
                atr_val = 0.0
            if atr_val <= 0:
                atr_val = max(1e-12, entry * 0.01)
            meta = (self.position_meta or {}).get(symbol, {}) or {}
            mstop = float(meta.get("stop", 0.0) or 0.0)
            mtp = float(meta.get("tp", 0.0) or 0.0)
            if mstop > 0 and mtp > 0:
                stop, tp = float(mstop), float(mtp)
            else:
                stop, tp = self.risk.stop_tp(side, float(entry), float(atr_val))
            try:
                stop = float(self.client.format_price(symbol, float(stop)))
            except Exception:
                stop = float(stop)
            try:
                tp = float(self.client.format_price(symbol, float(tp)))
            except Exception:
                tp = float(tp)

            recreate = (pos is None) or (str(getattr(pos, "side", "")).lower() != side)

            if recreate:
                intent = self.entry_intents.get(symbol)
                self.positions[symbol] = LivePosition(
                    symbol=symbol,
                    side=side,
                    qty=float(qty_abs),
                    entry=float(entry),
                    stop=float(stop) if float(stop) > 0 else 0.0,
                    tp=float(tp) if float(tp) > 0 else 0.0,
                    initial_qty=float(qty_abs),
                    entry_atr=float(atr_val),
                    entry_atr_pct=(float(atr_val) / max(1e-12, float(entry))),
                    plan_id=str(getattr(intent, "plan_id", "") or "") if intent is not None else "",
                    tactic=str(getattr(intent, "tactic", "") or "") if intent is not None else "",
                    plan=(getattr(intent, "plan", {}) or {}) if intent is not None else {},
                    entry_features=(getattr(intent, "entry_features", {}) or {}) if intent is not None else {},
                )
                # clear intent after first fill
                if symbol in self.entry_intents:
                    try:
                        del self.entry_intents[symbol]
                    except Exception:
                        pass
                return

            # update meta existent
            try:
                pos.qty = float(qty_abs)
                pos.entry = float(entry)
            except Exception:
                pass

            # daca stop/tp sunt invalide, seteaza-le
            try:
                if float(getattr(pos, "stop", 0.0) or 0.0) <= 0:
                    pos.stop = float(stop) if float(stop) > 0 else 0.0
                if float(getattr(pos, "tp", 0.0) or 0.0) <= 0:
                    pos.tp = float(tp) if float(tp) > 0 else 0.0
            except Exception:
                pass

        except Exception:
            return

    def _on_live_fill(self, symbol: str, side: str, qty: float, fill: float, maker: bool, reason: str):
        exch = self.cfg.get("exchange")
        mode = "live"
        fee = 0.0
        notional = float(qty) * float(fill)

        pos = self.positions.get(symbol)
        
        intent = self.entry_intents.get(symbol)

        # If we have no internal position yet, but we have an entry intent, create position on first fill
        if pos is None and intent is not None:
            # Determine if this fill matches the intent direction
            # long entry -> buy fill; short entry -> sell fill
            if (intent.side == "long" and side == "buy") or (intent.side == "short" and side == "sell"):
                # Compute stop/tp around actual fill using stored ATR (plan-aware if present)
                plan_stop_mult = None
                plan_tp_mult = None
                try:
                    if getattr(intent, "plan", None):
                        plan_stop_mult = (intent.plan or {}).get("overrides", {}).get("stop_atr_mult", None)
                        plan_tp_mult = (intent.plan or {}).get("overrides", {}).get("tp_atr_mult", None)
                except Exception:
                    plan_stop_mult = None
                    plan_tp_mult = None

                if plan_stop_mult is not None or plan_tp_mult is not None:
                    sm = float(plan_stop_mult if plan_stop_mult is not None else (self.cfg.get("risk") or {}).get("stop_atr_mult", 2.5))
                    tm = float(plan_tp_mult if plan_tp_mult is not None else (self.cfg.get("risk") or {}).get("tp_atr_mult", 4.0))
                    if intent.side == "long":
                        stop = float(fill) - sm * float(intent.atr_val)
                        tp = float(fill) + tm * float(intent.atr_val)
                    else:
                        stop = float(fill) + sm * float(intent.atr_val)
                        tp = float(fill) - tm * float(intent.atr_val)
                else:
                    stop, tp = self.risk.stop_tp(intent.side, float(fill), float(intent.atr_val))

                stop = float(self.client.format_price(symbol, stop))
                tp = float(self.client.format_price(symbol, tp))

                self.positions[symbol] = LivePosition(
                    symbol=symbol,
                    side=intent.side,
                    qty=0.0,                  # will be increased below
                    entry=float(fill),
                    stop=float(stop),
                    tp=float(tp),
                    plan_id=str(getattr(intent, 'plan_id', '') or ''),
                    tactic=str(getattr(intent, 'tactic', '') or ''),
                    plan=(getattr(intent, 'plan', None) or {}),
                )
                pos = self.positions[symbol]

                # Clear intent after first fill so it can't block future logic
                try:
                    del self.entry_intents[symbol]
                except Exception:
                    pass


        if side == "buy":
            if pos and pos.side == "short":
                close_qty = min(float(qty), float(pos.qty))
                realized = (float(pos.entry) - float(fill)) * close_qty
                pos.qty -= close_qty
                if pos.qty <= 1e-12:
                    try:
                        self._cancel_protection_orders(symbol, pos)
                    except Exception:
                        pass
                    try:
                        self._record_exit_event(symbol, reason, float(realized), side="short")
                    except Exception:
                        pass
                    try:
                        self._autonomy_on_trade_closed(symbol, pos, float(realized), float(abs(close_qty * fill)))
                    except Exception:
                        pass
                    del self.positions[symbol]
                self.rec.add(TradeRecord(now_utc_iso(), exch, mode, symbol, "buy", qty, fill, notional, fee, reason, realized))
                try:
                    self.autonomy.learn_from_trades([self.rec.trades[-1].__dict__])
                except Exception:
                    pass
                self.log.info(f"[LIVE] BUY (Close Short) {symbol} qty={qty:.8f} @ {fill:.8f} realized~{realized:.4f} reason={reason}")
                return

            if pos and pos.side == "long":
                new_qty = float(pos.qty) + float(qty)
                pos.entry = (float(pos.entry) * float(pos.qty) + float(fill) * float(qty)) / max(1e-12, new_qty)
                pos.qty = new_qty

            self.rec.add(TradeRecord(now_utc_iso(), exch, mode, symbol, "buy", qty, fill, notional, fee, reason, 0.0))
            try:
                self.autonomy.learn_from_trades([self.rec.trades[-1].__dict__])
            except Exception:
                pass
            self.risk.mark_trade(symbol)
            self.metrics.inc_trade()
            self.log.info(f"[LIVE] BUY {symbol} qty={qty:.8f} @ {fill:.8f} reason={reason}")
            try:
                if pos is not None:
                    if "dca_add" in reason or "pyramid_add" in reason:
                        setattr(pos, "_needs_recalc", True)
                    self._ensure_native_protection(symbol, pos)
            except Exception:
                pass

        else:  # sell
            if pos and pos.side == "long":
                close_qty = min(float(qty), float(pos.qty))
                realized = (float(fill) - float(pos.entry)) * close_qty
                pos.qty -= close_qty
                if pos.qty <= 1e-12:
                    try:
                        self._cancel_protection_orders(symbol, pos)
                    except Exception:
                        pass
                    try:
                        self._record_exit_event(symbol, reason, float(realized), side="long")
                    except Exception:
                        pass
                    try:
                        self._autonomy_on_trade_closed(symbol, pos, float(realized), float(abs(close_qty * fill)))
                    except Exception:
                        pass
                    del self.positions[symbol]
                self.rec.add(TradeRecord(now_utc_iso(), exch, mode, symbol, "sell", qty, fill, notional, fee, reason, realized))
                try:
                    self.autonomy.learn_from_trades([self.rec.trades[-1].__dict__])
                except Exception:
                    pass
                self.log.info(f"[LIVE] SELL (Close Long) {symbol} qty={qty:.8f} @ {fill:.8f} realized~{realized:.4f} reason={reason}")
                return

            if pos and pos.side == "short":
                new_qty = float(pos.qty) + float(qty)
                pos.entry = (float(pos.entry) * float(pos.qty) + float(fill) * float(qty)) / max(1e-12, new_qty)
                pos.qty = new_qty

            self.rec.add(TradeRecord(now_utc_iso(), exch, mode, symbol, "sell", qty, fill, notional, fee, reason, 0.0))
            try:
                self.autonomy.learn_from_trades([self.rec.trades[-1].__dict__])
            except Exception:
                pass
            self.risk.mark_trade(symbol)
            self.metrics.inc_trade()
            self.log.info(f"[LIVE] SELL {symbol} qty={qty:.8f} @ {fill:.8f} reason={reason}")
            try:
                if pos is not None:
                    if "dca_add" in reason or "pyramid_add" in reason:
                        setattr(pos, "_needs_recalc", True)
                    self._ensure_native_protection(symbol, pos)
            except Exception:
                pass

    # -----------------------------
    # Pending orders
    # -----------------------------
    def _paper_should_fill(self, po: PendingOrder, last: float, met: Dict[str, float]) -> bool:
        if (self.cfg.get("micro_model", {}) or {}).get("enabled", True) and met:
            dist_bps = abs(float(last) - float(po.price)) / max(1e-12, float(po.price)) * 10_000
            p = maker_fill_probability(self.cfg, po.side, dist_bps, po.atr_pct, met.get("imbalance", 0.0))
            return random.random() < float(p)

        model = (self.cfg.get("paper", {}) or {}).get("limit_fill_model", {}) or {}
        near = float(model.get("near_bps", 6.0))
        p_near = float(model.get("p_near", 0.35))

        if po.side == "buy":
            if last <= po.price:
                return True
            dist = (last - po.price) / max(1e-12, po.price) * 10_000
            return (0 <= dist <= near) and (random.random() < p_near)

        if last >= po.price:
            return True
        dist = (po.price - last) / max(1e-12, po.price) * 10_000
        return (0 <= dist <= near) and (random.random() < p_near)

    @instrument(
        "engine.check_pending",
        disable_after=10,
        disable_sec=10,
        ctx_builder=lambda self: self._ctx(pending=len(self.pending)),
    )

    def _check_pending(self):
        if not self.pending:
            return

        # paper
        if self.cfg.get("mode") == "paper":
            model = (self.cfg.get("paper", {}) or {}).get("limit_fill_model", {}) or {}
            timeout = float(model.get("timeout_sec", 240))
            action = str(model.get("timeout_action", "cancel")).lower()

            for sym in list(self.pending.keys()):
                po = self.pending[sym]
                try:
                    _, _, last = self._get_bid_ask_last(sym)

                    met = {}
                    if (self.cfg.get("micro_model", {}) or {}).get("enabled", True):
                        ob = self.client.fetch_order_book(
                            sym,
                            limit=int((self.cfg.get("micro_model", {}) or {}).get("orderbook_depth", 20))
                        )
                        met = orderbook_metrics(
                            ob,
                            depth=int((self.cfg.get("micro_model", {}) or {}).get("orderbook_depth", 20))
                        )

                    # fill simulation
                    if self._paper_should_fill(po, last, met):
                        self._fill_paper(sym, po.side, po.qty, po.price, maker=True, reason=po.reason)
                        del self.pending[sym]

                        # dacă nu s-a creat poziție internă, șterge intent-ul (evită blocaj)
                        if sym in self.entry_intents and sym not in self.positions:
                            del self.entry_intents[sym]
                        continue

                    # timeout handling
                    if (time.time() - float(po.created_ts)) >= timeout:
                        self.log.warning(f"[PAPER] LIMIT timeout {sym} action={action}")
                        if action == "market":
                            self._fill_market(sym, po.side, po.qty, last, po.reason + "|timeout_market")
                        del self.pending[sym]
                        if sym in self.entry_intents and sym not in self.positions:
                            del self.entry_intents[sym]

                except Exception:
                    continue
            return


        # live
        repost_sec = float((self.cfg.get("execution", {}) or {}).get("repost_sec", 10))
        max_reposts = int((self.cfg.get("execution", {}) or {}).get("max_reposts", 3))

        for sym in list(self.pending.keys()):
            po = self.pending[sym]
            try:
                o = self.client.fetch_order(po.order_id, sym)
                status = (o.get("status") or "").lower()
                filled = _sf(o.get("filled"), 0.0)
                avg = _sf(o.get("average") or o.get("price"), po.price)

                if filled > float(po.filled_qty) + 1e-12:
                    delta = float(filled - float(po.filled_qty))
                    po.filled_qty = float(filled)
                    self.log.info(f"[LIVE] PARTIAL fill {sym} side={po.side} +{delta:.8f} avg~{avg:.8f}")
                    self._on_live_fill(sym, po.side, delta, float(avg), maker=True, reason=po.reason + "|partial")

                if status in ("closed", "filled") or (filled and filled >= float(po.qty) * 0.999):
                    self.log.info(f"[LIVE] LIMIT filled {sym} side={po.side} total={filled:.8f} avg={avg:.8f}")
                    if sym in self.pending:
                        del self.pending[sym]
                    continue

                age = time.time() - float(po.created_ts)
                if age >= repost_sec:
                    if int(po.reposts) >= max_reposts:
                        self.log.warning(f"[LIVE] LIMIT max reposts reached -> cancel {sym}")
                        try:
                            self.client.cancel_order(po.order_id, sym)
                        except Exception:
                            pass

                        # Optional fallback: maker -> market after exhaustion
                        try:
                            fb = ((self.cfg.get("execution") or {}).get("fallback") or {})
                            if bool(fb.get("maker_to_market_on_max_reposts", False)):
                                _, _, last = self._get_bid_ask_last(sym)
                                rem = max(0.0, float(po.qty) - float(po.filled_qty))
                                if rem > 0:
                                    self._fill_market(sym, po.side, rem, last, po.reason + "|max_reposts_market")
                        except Exception:
                            pass

                        del self.pending[sym]
                        continue

                    try:
                        self.client.cancel_order(po.order_id, sym)
                    except Exception:
                        pass

                    po.reposts += 1
                    po.created_ts = time.time()
                    remaining = max(0.0, float(po.qty) - float(po.filled_qty))
                    if remaining <= 0:
                        del self.pending[sym]
                        continue

                    bid, ask, last = self._get_bid_ask_last(sym)
                    px = self._maker_price(sym, po.side, bid, ask, last, atr_pct=float(po.atr_pct))

                    remaining, px = self.client.enforce_trade_rules(sym, po.side, remaining, px)

                    post_only = bool((self.cfg.get("execution", {}) or {}).get("post_only", True))
                    params = {"postOnly": True} if post_only else {}
                    try:
                        resp = self.client.create_order(sym, "limit", po.side, remaining, px, params=params)
                    except Exception:
                        resp = self.client.create_order(sym, "limit", po.side, remaining, px, params={})

                    po.order_id = str(resp.get("id"))
                    po.price = float(px)
                    po.qty = float(remaining)
                    po.filled_qty = 0.0
                    self.pending[sym] = po
            except Exception as e:
                self.metrics.inc_error()
                self.watchdog.record_error(e)
    
    # -----------------------------
    # Position management
    # -----------------------------
    
    @instrument(
        "engine.manage_position",
        disable_after=10,
        disable_sec=10,
        ctx_builder=lambda self, sym, df: self._ctx(symbol=sym, pos=bool(self.positions.get(sym))),
    )
    

    def _risk_cfg_for_pos(self, pos: LivePosition) -> dict:
        """Return a per-position risk config by merging plan overrides on top of cfg['risk']."""
        base = dict(self.cfg.get("risk") or {})
        try:
            plan = getattr(pos, "plan", None) or {}
            overrides = plan.get("overrides", {}) if isinstance(plan, dict) else {}
            if isinstance(overrides, dict) and overrides:
                # shallow merge; nested dicts merged one level
                for k, v in overrides.items():
                    if isinstance(v, dict) and isinstance(base.get(k), dict):
                        b2 = dict(base.get(k) or {})
                        b2.update(v)
                        base[k] = b2
                    else:
                        base[k] = v
        except Exception:
            pass
        return base
    def _manage_position(self, sym: str, df: pd.DataFrame):
        with self._pos_lock:
            pos = self.positions.get(sym)
            if not pos or pos.qty <= 0:
                return

        last = float(df["close"].iloc[-1])
        a = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        self.risk.update_trailing(pos, last, a, df=df)
        # If we averaged-in (DCA/pyramid), recompute soft SL/TP next tick
        if bool(getattr(pos, "_needs_recalc", False)):
            try:
                self._recalc_position_after_add(pos, df)
            except Exception:
                pass
            try:
                setattr(pos, "_needs_recalc", False)
            except Exception:
                pass

        # Optional: DCA / Pyramiding
        try:
            self._maybe_dca(pos, last, a)
        except Exception:
            pass
        try:
            trend_strength = float(self.strategy.trend_strength(df, df_trend=None)) if hasattr(self.strategy, 'trend_strength') else 0.0
            self._maybe_pyramid(pos, last, trend_strength, a)
        except Exception:
            pass

        should_close = False
        reason = ""

        if pos.side == "long":
            stop_level = max(float(pos.stop), float(pos.trailing)) if pos.trailing is not None else float(pos.stop)
            if last <= stop_level:
                should_close = True
                reason = "stop_loss"
            elif last >= float(pos.tp):
                should_close = True
                reason = "take_profit"
            else:
                so = (self.cfg.get("risk") or {}).get("scale_out", {}) or {}
                if bool(so.get("enabled", True)):
                    # defaults: 25/25/50
                    p1 = _cl(float(so.get("tp1_pct", 0.25)), 0.05, 0.95)
                    p2 = _cl(float(so.get("tp2_pct", 0.25)), 0.05, 0.95)
                    p3 = _cl(float(so.get("tp3_pct", 0.50)), 0.05, 0.95)

                    tp1 = float(self.risk.tp1_level("long", float(pos.entry), a))
                    tp2 = float(self.risk.tp2_level("long", float(pos.entry), a))
                    tp3 = float(self.risk.tp3_level("long", float(pos.entry), a))

                    # Fee-lock / BE on first take-profit
                    be_cfg = ((self.cfg.get("risk") or {}).get("break_even") or {})
                    fee_bps = float(be_cfg.get("fee_bps", 10.0))
                    buffer_bps = float(be_cfg.get("buffer_bps", 2.0))

                    try:
                        if (not pos.tp1_done) and last >= tp1:
                            qty_to_sell = float(pos.qty) * p1
                            self.log.info(f"{sym}: TP1 scale-out LONG -> sell {p1 * 100:.0f}%")
                            self._place_order(sym, "sell", qty_to_sell, "tp1_scale_out", atr_pct=0.0)
                            pos.tp1_done = True
                            if bool(so.get("move_stop_to_be", True)):
                                be = float(self.risk.fee_lock_stop("long", float(pos.entry), last, fee_bps=fee_bps, buffer_bps=buffer_bps))
                                pos.stop = max(float(pos.stop), be)

                        if pos.tp1_done and (not pos.tp2_done) and last >= tp2:
                            qty_to_sell = float(pos.qty) * p2
                            self.log.info(f"{sym}: TP2 scale-out LONG -> sell {p2 * 100:.0f}%")
                            self._place_order(sym, "sell", qty_to_sell, "tp2_scale_out", atr_pct=0.0)
                            pos.tp2_done = True

                        if pos.tp1_done and pos.tp2_done and (not pos.tp3_done) and last >= tp3:
                            qty_to_sell = float(pos.qty) * p3
                            self.log.info(f"{sym}: TP3 scale-out LONG -> sell {p3 * 100:.0f}%")
                            self._place_order(sym, "sell", qty_to_sell, "tp3_scale_out", atr_pct=0.0)
                            pos.tp3_done = True
                    except Exception:
                        pass

        else:
            stop_level = min(float(pos.stop), float(pos.trailing)) if pos.trailing is not None else float(pos.stop)
            if last >= stop_level:
                should_close = True
                reason = "stop_loss"
            elif last <= float(pos.tp):
                should_close = True
                reason = "take_profit"
            else:
                so = (self.cfg.get("risk") or {}).get("scale_out", {}) or {}
                if bool(so.get("enabled", True)):
                    p1 = _cl(float(so.get("tp1_pct", 0.25)), 0.05, 0.95)
                    p2 = _cl(float(so.get("tp2_pct", 0.25)), 0.05, 0.95)
                    p3 = _cl(float(so.get("tp3_pct", 0.50)), 0.05, 0.95)

                    tp1 = float(self.risk.tp1_level("short", float(pos.entry), a))
                    tp2 = float(self.risk.tp2_level("short", float(pos.entry), a))
                    tp3 = float(self.risk.tp3_level("short", float(pos.entry), a))

                    be_cfg = ((self.cfg.get("risk") or {}).get("break_even") or {})
                    fee_bps = float(be_cfg.get("fee_bps", 10.0))
                    buffer_bps = float(be_cfg.get("buffer_bps", 2.0))

                    try:
                        if (not pos.tp1_done) and last <= tp1:
                            qty_to_buy = float(pos.qty) * p1
                            self.log.info(f"{sym}: TP1 scale-out SHORT -> buy {p1 * 100:.0f}%")
                            self._place_order(sym, "buy", qty_to_buy, "tp1_scale_out", atr_pct=0.0)
                            pos.tp1_done = True
                            if bool(so.get("move_stop_to_be", True)):
                                be = float(self.risk.fee_lock_stop("short", float(pos.entry), last, fee_bps=fee_bps, buffer_bps=buffer_bps))
                                pos.stop = min(float(pos.stop), be)

                        if pos.tp1_done and (not pos.tp2_done) and last <= tp2:
                            qty_to_buy = float(pos.qty) * p2
                            self.log.info(f"{sym}: TP2 scale-out SHORT -> buy {p2 * 100:.0f}%")
                            self._place_order(sym, "buy", qty_to_buy, "tp2_scale_out", atr_pct=0.0)
                            pos.tp2_done = True

                        if pos.tp1_done and pos.tp2_done and (not pos.tp3_done) and last <= tp3:
                            qty_to_buy = float(pos.qty) * p3
                            self.log.info(f"{sym}: TP3 scale-out SHORT -> buy {p3 * 100:.0f}%")
                            self._place_order(sym, "buy", qty_to_buy, "tp3_scale_out", atr_pct=0.0)
                            pos.tp3_done = True
                    except Exception:
                        pass

                # --- Adaptive position management (break-even/fee-lock, volatility throttle, time-exit)
                try:
                    rs = (self.regime_detector.get_symbol(sym) or {})
                    regime = str(rs.get("regime", "na"))
                except Exception:
                    regime = "na"

                now_ts = time.time()
                atr_pct = float(a) / max(1e-12, float(last))

                # record entry volatility reference (once)
                try:
                    if float(getattr(pos, "entry_atr_pct", 0.0)) <= 0.0:
                        pos.entry_atr = float(a)
                        pos.entry_atr_pct = float(atr_pct)
                    if float(getattr(pos, "initial_qty", 0.0)) <= 0.0:
                        pos.initial_qty = float(pos.qty)
                except Exception:
                    pass

                # 1) Volatility throttle: reduce risk + freeze adds when volatility spikes
                try:
                    vt = ((self.cfg.get("risk") or {}).get("volatility_throttle") or {})
                    if bool(vt.get("enabled", True)):
                        atr_hi = float(vt.get("atr_pct_high", 0.06))
                        spike_mult = float(vt.get("spike_mult", 1.8))
                        cool = float(vt.get("cooldown_sec", 600))
                        reduce_pct = _cl(float(vt.get("reduce_pct", 0.25)), 0.05, 0.95)

                        ref = float(getattr(pos, "entry_atr_pct", 0.0)) or atr_pct
                        spiked = (atr_pct >= atr_hi) or (atr_pct >= (ref * spike_mult))
                        if spiked and now_ts >= float(getattr(pos, "no_adds_until", 0.0)):
                            qty_red = float(pos.qty) * reduce_pct
                            if qty_red > 0:
                                self.log.warning(f"{sym}: volatility_throttle (regime={regime}) -> reduce {reduce_pct*100:.0f}% and freeze adds")
                                if pos.side == "long":
                                    self._place_order(sym, "sell", qty_red, "volatility_throttle")
                                else:
                                    self._place_order(sym, "buy", qty_red, "volatility_throttle")
                                pos.no_adds_until = now_ts + cool
                except Exception:
                    pass

                # 2) Break-even + fee-lock: move stop to entry + fees/buffer after favorable move
                try:
                    be = ((self.cfg.get("risk") or {}).get("break_even") or {})
                    if bool(be.get("enabled", True)):
                        trig_atr = float(be.get("trigger_atr_mult", 1.0))
                        trig_pct = float(be.get("trigger_pct", 0.0))
                        fee_bps = float(be.get("fee_bps", 10.0))
                        buffer_bps = float(be.get("buffer_bps", 2.0))

                        move = (last - float(pos.entry)) if pos.side == "long" else (float(pos.entry) - last)
                        move_ok = (move >= (trig_atr * float(a))) or (trig_pct > 0 and (move / max(1e-12, float(pos.entry))) >= trig_pct)
                        if move_ok:
                            lvl = float(self.risk.fee_lock_stop(pos.side, float(pos.entry), last, fee_bps=fee_bps, buffer_bps=buffer_bps))
                            if pos.side == "long":
                                pos.stop = max(float(pos.stop), lvl)
                            else:
                                pos.stop = min(float(pos.stop), lvl)
                except Exception:
                    pass

                # 3) Time-based exit: if no follow-through after N minutes -> de-risk or close
                try:
                    te = ((self.cfg.get("risk") or {}).get("time_exit") or {})
                    if bool(te.get("enabled", True)):
                        minutes = float(te.get("minutes", 45))
                        min_move_atr = float(te.get("min_move_atr", 0.5))
                        action = str(te.get("action", "partial")).lower()  # "partial" or "close"
                        part_pct = _cl(float(te.get("partial_pct", 0.5)), 0.05, 0.95)

                        age = now_ts - float(getattr(pos, "opened_ts", now_ts))
                        if age >= (minutes * 60.0):
                            fav = (last - float(pos.entry)) if pos.side == "long" else (float(pos.entry) - last)
                            if fav < (min_move_atr * float(a)):
                                self.log.info(f"{sym}: time_exit triggered -> action={action}")
                                if action == "close":
                                    should_close = True
                                    reason = "time_exit"
                                else:
                                    qty_part = float(pos.qty) * part_pct
                                    if qty_part > 0:
                                        if pos.side == "long":
                                            self._place_order(sym, "sell", qty_part, "time_exit")
                                        else:
                                            self._place_order(sym, "buy", qty_part, "time_exit")
                except Exception:
                    pass

        if should_close:
            try:
                self._cancel_protection_orders(sym, pos)
            except Exception:
                pass
            self.log.info(f"{sym} ({pos.side}): Closing due to {reason} (Px={last})")
            side_to_close = "sell" if pos.side == "long" else "buy"
            self._place_order(sym, side_to_close, float(pos.qty), reason, atr_pct=0.0)

    # -----------------------------
    # Approvals
    # -----------------------------
    def _approvals_required(self) -> bool:
        acfg = self.cfg.get("approvals", {}) or {}
        if not acfg.get("enabled", True):
            return False
        if self.cfg.get("mode") == "live":
            return bool(acfg.get("require_for_live", True))
        return bool(acfg.get("require_for_paper", False))
        
    @instrument(
        "engine.process_approvals",
        disable_after=10,
        disable_sec=10,
        ctx_builder=lambda self: self._ctx(approvals=bool(self.approvals)),
    )

    def _process_approvals(self) -> None:
        aq = self.approvals
        if not aq:
            return
        try:
            aq.expire_old()
            approved = aq.list(status="approved")
        except Exception:
            return
        if not approved:
            return

        for a in approved:
            sym = a.symbol
            try:
                if sym in self.positions and self.positions[sym].qty > 0:
                    aq.mark_executed(a.id, by="engine_skip_existing")
                    continue

                _, _, last = self._get_bid_ask_last(sym)
                px = float(last) if last else float(a.price_ref)

                df = None
                try:
                    df = self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=int(self.cfg.get("ohlcv_limit", 400)))
                except Exception:
                    pass

                if df is not None and len(df) >= int(self.cfg["risk"]["atr_period"]) + 2:
                    a_val = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
                    atr_pct = self._atr_pct(df)
                else:
                    a_val = max(1e-12, px * 0.01)
                    atr_pct = 0.0

                side = "long" if a.side == "buy" else "short"
                stop, tp = self.risk.stop_tp(side, px, a_val)
                stop = float(self.client.format_price(sym, stop))
                tp = float(self.client.format_price(sym, tp))

                self.entry_intents[sym] = EntryIntent(
                    symbol=sym,
                    side=side,
                    order_side=a.side,            # "buy"/"sell"
                    atr_val=float(a_val),
                    atr_pct=float(atr_pct),
                    signal_strength=float(getattr(a, "signal_strength", 0.0) or 0.0),
                    reason=f"approved_{side}:{a.id}",
                )

                self._place_order(sym, a.side, float(a.qty), f"approved_{side}:{a.id}", atr_pct=atr_pct)


                try:
                    self.notifier.notify("entry_executed", f"{sym} {a.side.upper()} executed (approval {a.id})")
                except Exception:
                    pass

                aq.mark_executed(a.id, by="engine")
            except Exception as e:
                self.log.warning(f"Approval exec failed id={a.id}: {e}")
                continue

    # -----------------------------
    # Open/Close positions
    # -----------------------------
    
    @instrument(
        "engine.open_position",
        disable_after=8,
        disable_sec=30,
        ctx_builder=lambda self, sym, side, df, df_trend, returns_map, signal_strength=0.0: self._ctx(
            symbol=sym, side=side, signal_strength=float(signal_strength), pairs=len(self.pairs)
        ),
    )
    
    def _open_position(
        self,
        sym: str,
        side: str,  # "long"/"short"
        df: pd.DataFrame,
        df_trend: pd.DataFrame,
        returns_map: Dict[str, np.ndarray],
        signal_strength: float = 0.0,
    ):
        """
        Deschide poziție cu log-uri explicite pentru motive de skip.
        """

        def _log_skip(code: str, detail: str = "") -> None:
            # code = cheie semantică (ex: "cooldown")
            num = ENTRY_SKIP_CODES.get(code, "E999")
            full_code = f"{num}:{code}"

            # 1) Prometheus / metrics counter
            try:
                if hasattr(self, "metrics") and self.metrics:
                    self.metrics.inc_entry_skip(full_code, side=side)
            except Exception:
                pass

            # 2) Log
            if not getattr(self, "verbose_entry_reasons", True):
                return

            msg = f"{sym}: ENTRY SKIP [{side.upper()}] {full_code}"
            if detail:
                msg += f" | {detail}"

            lvl = getattr(self, "entry_reason_level", "info")
            if lvl == "debug" and hasattr(self.log, "debug"):
                self.log.debug(msg)
            else:
                self.log.info(msg)

            # 3) Optional: journal în SQLite
            try:
                if self.store:
                    self.store.event(
                        "info",
                        "entry_skip",
                        msg,
                        {"symbol": sym, "side": side, "code": full_code, "detail": detail}
                    )
            except Exception:
                pass

            # 4) In-memory trace (exposed via /trace + Streamlit "Log")
            try:
                self._think(
                    "entry_skip",
                    level="info",
                    symbol=sym,
                    side=side,
                    code=full_code,
                    detail=str(detail or ""),
                    controller="engine",
                )
            except Exception:
                pass
        
        if self._is_symbol_blocked(sym):
            info = (getattr(self, "_symbol_block", {}) or {}).get(sym, {})
            _log_skip("market_guard_block", f"symbol_blocked reason={info.get('reason')} until={info.get('until')}")
            return

        

        # 0) Hard blocks
        if self.halted:
            _log_skip("halted", "kill-switch halted")
            return

        if self.watchdog.is_paused():
            _log_skip("watchdog_paused", f"paused_reason={getattr(self.watchdog,'pause_reason',None)}")
            return
        if getattr(self, "pause_entries", False):
            _log_skip("pause_entries", "manual pause_entries=True")
            return

        if getattr(self, "_block_entries", False):
            st = "na"
            try:
                st = getattr(getattr(self, "risk_state", None), "current", None).state
            except Exception:
                st = "na"
            _log_skip("risk_state_block", f"state={st}")
            return

        # 1) MarketGuard
        if getattr(self, "market_guard", None) and (not self.market_guard.allow(side)):
            left = 0
            try:
                left = int(self.market_guard.seconds_left(side))
            except Exception:
                left = 0
            _log_skip("market_guard_block", f"{side} blocked, {left}s left")
            return

        # 2) Cooldown / daily trade cap
        if self.risk.in_cooldown(sym):
            cd = float((self.cfg.get("risk", {}) or {}).get("cooldown_sec", 0))
            last_ts = self.risk.last_trade_ts.get(sym, 0.0)
            left = max(0.0, cd - (time.time() - last_ts))
            _log_skip("cooldown", f"cooldown_left~{left:.1f}s")
            return

        # 2a) Re-entry gating (after a close event)
        try:
            ok_re, code_re, detail_re = self._reentry_allowed(sym, side, df, df_trend)
            if not ok_re:
                _log_skip(code_re or "reentry_block", detail_re or "blocked")
                return
        except Exception:
            pass

        if self.risk.max_trades_reached():
            ks = (self.cfg.get("risk", {}) or {}).get("kill_switch", {}) or {}
            _log_skip("max_trades_day", f"trades_today={self.risk.trades_today} max={int(ks.get('max_trades_per_day', 0))}")
            return

        # 2b) Portfolio position cap (global)
        try:
            pcap = ((self.cfg.get("risk") or {}).get("portfolio") or {})
            max_pos = int(pcap.get("max_positions", 6))
            if max_pos > 0 and len(self.positions) >= max_pos:
                _log_skip("position_cap", f"open_positions={len(self.positions)}/{max_pos}")
                return
        except Exception:
            pass

# 3) Already pending / already positioned
        if sym in self.pending:
            po = self.pending.get(sym)
            _log_skip("pending_exists", f"order_id={getattr(po,'order_id',None)} reason={getattr(po,'reason','')}")
            return
           
        if sym in self.entry_intents:
            _log_skip("entry_intent_exists", "entry_intent already exists")

            return


        if sym in self.positions and self.positions[sym].qty > 0:
            pos = self.positions[sym]
            _log_skip("already_in_position", f"pos_side={pos.side} qty={pos.qty:.8f}")
            return

        # 4) Max open positions
        if self.cfg.get("mode") == "paper" and self.paper:
            current_open = len(self.paper.positions)
        else:
            current_open = len([p for p in self.positions.values() if p.qty > 0])

        max_open = int((self.cfg.get("risk", {}) or {}).get("max_open_positions", 0))
        if max_open > 0 and current_open >= max_open:
            _log_skip("max_open_positions", f"open={current_open} max={max_open}")
            return

        # 5) Volatility pause
        if self._volatility_pause(df):
            try:
                atrp = float(self._atr_pct(df)) * 100.0
                thr = float((self.cfg.get("risk", {}) or {}).get("volatility_pause_atr_pct", 0)) * 100.0
                _log_skip("volatility_pause", f"atr%={atrp:.2f} >= thr%={thr:.2f}")
            except Exception:
                _log_skip("volatility_pause", "atr% above threshold")
            return

        # 6) Correlation filter
        open_syms = list(self.positions.keys())
        if not corr_ok(self.cfg, sym, open_syms, returns_map):
            _log_skip("correlation_filter", f"open_syms={len(open_syms)}")
            return

        # 7) Compute sizing inputs
        self.client.load_markets()
        eq = float(self.equity())
        free_eq = float(self.free_equity())

        px = float(df["close"].iloc[-1])
        a = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        atr_pct = float(self._atr_pct(df))

        # Trace the entry evaluation context (inputs only; no secrets)
        try:
            self._think(
                "entry_eval",
                level="debug",
                symbol=sym,
                side=side,
                px=float(px),
                atr=float(a),
                atr_pct=float(atr_pct),
                signal_strength=float(signal_strength),
                equity=float(eq),
                free_equity=float(free_eq),
                controller="engine",
            )
        except Exception:
            pass

        if eq <= 0 or free_eq <= 0 or px <= 0:
            _log_skip("bad_equity_or_price", f"equity={eq:.2f} free={free_eq:.2f} px={px:.8f}")
            return

        # 8) Autonomy (gate + scale)
        ticker = None
        try:
            ticker = self.client.fetch_ticker_cached(sym)
        except Exception:
            ticker = None

        tf = str(self.cfg.get("signal_timeframe", "5m"))
        # use autonomy regime predictor (lightweight) for better gating + logging
        try:
            regime_src = df_trend if (df_trend is not None and len(df_trend) > 80) else df
            r = self.autonomy.predict_market_regime(regime_src, df_trend=df_trend)
            regime = str((r or {}).get("regime") or "na")
        except Exception:
            regime = "na"

        try:
            decision = self.autonomy.evaluate_entry(
                sym=sym,
                side=side,
                signal_strength=float(signal_strength),
                equity=float(eq),
                free_equity=float(free_eq),
                ticker=ticker,
                df=df,
                df_trend=df_trend,
                tf=tf,
                regime=regime,
            )
        except Exception as e:
            _log_skip("autonomy_error", f"{type(e).__name__}: {e}")
            return

        if not decision.allow:
            _log_skip("autonomy_block", f"reason={decision.reason} risk_mult={getattr(decision,'risk_mult',1.0)}")
            return
        
        # 8.5) AI Brain (policy layer) - gate + scaling
        try:
            # best-effort spread
            spread_bps = None
            try:
                if ticker:
                    bid = _sf((ticker or {}).get("bid"))
                    ask = _sf((ticker or {}).get("ask"))
                    if np.isfinite(bid) and np.isfinite(ask) and bid > 0 and ask > 0:
                        spread_bps = (ask - bid) / bid * 10_000
            except Exception:
                spread_bps = None

            # best-effort funding (only futures)
            funding_rate = None
            if bool(self.cfg.get("enable_futures", False)):
                try:
                    funding_rate = self.client.fetch_funding_rate(sym)
                except Exception:
                    funding_rate = None

            # drawdown proxy (engine-level)
            eq_now = float(eq)
            peak = float(self.peak_equity or eq_now)
            max_drawdown = (peak - eq_now) / max(1e-12, peak)

            open_positions_count = current_open  # already computed above

            ctx = {
                "symbol": sym,
                "side": side,  # "long"/"short"
                "signal_strength": float(signal_strength),
                "tf": tf,
                "regime": regime,
                "regime_strength": 0.0,  # optional; keep 0 unless you compute it elsewhere
                "spread_bps": spread_bps,
                "funding_rate": funding_rate,
                "equity": float(eq),
                "free_equity": float(free_eq),
                "max_drawdown": float(max_drawdown),
                "loss_streak": 0,  # optional; set if you track it in recorder/metrics
                "open_positions_count": int(open_positions_count),
            }

            adj = self.ai_brain.decide(ctx)

            # Trace AI-brain policy layer decision (gate + scaling)
            try:
                self._think(
                    "ai_brain",
                    level="debug",
                    symbol=sym,
                    side=side,
                    allow_entries=bool(adj.get("allow_entries", True)),
                    score_mult=float(adj.get("score_mult", 1.0) or 1.0),
                    risk_mult=float(adj.get("risk_mult", 1.0) or 1.0),
                    reasons=adj.get("reasons"),
                    controller="ai_brain",
                )
            except Exception:
                pass

            if not adj.get("allow_entries", True):
                _log_skip("ai_brain_block", f"reasons={adj.get('reasons')}")
                return

            # apply scaling
            score_mult = float(adj.get("score_mult", 1.0) or 1.0)
            risk_mult2 = float(adj.get("risk_mult", 1.0) or 1.0)

            # signal_strength is used for gating/logging/strategy context; keep it consistent
            signal_strength = float(signal_strength) * score_mult

            # IMPORTANT: you already use Autonomy risk_mult via self.risk._entry_risk_mult later
            # We'll multiply it with AI brain risk_mult.
            # (We do it by adjusting decision.risk_mult effect in the next line below.)
            setattr(self, "_ai_brain_risk_mult", risk_mult2)

        except Exception as e:
            # Standard variant: if AIBrain fails, do NOT block trading; just log and continue.
            setattr(self, "_ai_brain_risk_mult", 1.0)
            self.log.debug(f"{sym}: ai_brain decide failed: {type(e).__name__}: {e}")
        


        # 8.7) LLM layer (optional): local regime/veto + optional cloud news/sentiment
        try:
            setattr(self, '_llm_risk_mult', 1.0)
            setattr(self, '_llm_score_mult', 1.0)
            setattr(self, '_llm_reason', '')
            if getattr(self, 'llm', None) is not None:
                ladj = self.llm.advise_trade(ctx, df=df, df_trend=df_trend)
                if ladj is not None:
                    # Trace LLM layer output (best-effort; prompt/response not logged)
                    try:
                        self._think(
                            "llm",
                            level="debug",
                            symbol=sym,
                            side=side,
                            allow_entries=bool(ladj.get("allow_entries", True)),
                            score_mult=float(ladj.get("score_mult", 1.0) or 1.0),
                            risk_mult=float(ladj.get("risk_mult", 1.0) or 1.0),
                            reasons=ladj.get("reasons"),
                            reason=str(ladj.get("reason") or ""),
                            controller="llm",
                        )
                    except Exception:
                        pass
                    if not ladj.get('allow_entries', True):
                        _log_skip('llm_block', f"reasons={ladj.get('reasons')}")
                        return
                    sm = float(ladj.get('score_mult', 1.0) or 1.0)
                    rm = float(ladj.get('risk_mult', 1.0) or 1.0)
                    setattr(self, '_llm_score_mult', sm)
                    setattr(self, '_llm_risk_mult', rm)
                    setattr(self, '_llm_reason', str(ladj.get('reason') or ''))
                    # apply score scaling (keeps logs consistent)
                    signal_strength = float(signal_strength) * sm
        except Exception as e:
            # fail-open: never block trading if LLM fails
            try:
                self.log.debug(f"{sym}: llm advise failed: {type(e).__name__}: {e}")
            except Exception:
                pass
        
        # --- Autonomy guardrails (daily loss + per-symbol cooldown/streak)
        try:
            today = pd.Timestamp.utcnow().strftime("%Y-%m-%d")
            if getattr(self, "_day_key", None) != today:
                self._day_key = today
                self._day_start_equity = float(eq)
                self._day_realized_pnl = 0.0
            if getattr(self, "_day_start_equity", None) is None:
                self._day_start_equity = float(eq)
            ks = ((self.cfg.get("risk") or {}).get("kill_switch") or {})
            dlim_usd = float(ks.get("daily_loss_limit_usd", 0.0) or 0.0)
            dlim_pct = float(ks.get("daily_loss_limit_pct", 0.0) or 0.0)
            lim = 0.0
            if dlim_usd > 0:
                lim = dlim_usd
            elif dlim_pct > 0 and float(self._day_start_equity or 0.0) > 0:
                lim = float(self._day_start_equity) * dlim_pct
            if lim > 0 and float(getattr(self, "_day_realized_pnl", 0.0) or 0.0) <= -abs(lim):
                _log_skip("daily_loss_limit", f"day_pnl={float(self._day_realized_pnl):.2f} limit={-abs(lim):.2f}")
                return

            if self.symbol_policy is not None:
                max_loss_streak = int(ks.get("per_symbol_loss_streak", 3) or 3)
                cooldown_sec = int(ks.get("per_symbol_cooldown_sec", 6 * 3600) or (6 * 3600))
                max_trades_sym = int(ks.get("max_trades_per_day_symbol", 0) or 0)
                ok, why = self.symbol_policy.can_open(
                    sym,
                    max_loss_streak=max_loss_streak,
                    cooldown_sec=cooldown_sec,
                    max_trades_per_day=(max_trades_sym if max_trades_sym > 0 else None),
                )
                if not ok:
                    _log_skip("symbol_policy_block", f"{why}")
                    return
        except Exception:
            pass

        # 8.8) Decision Factor (single-plan selection) to avoid conflicts between tools
        plan: Optional[TradePlan] = None
        try:
            # LLM + AI brain already executed above; we now pick ONE plan per symbol
            plan = self._select_trade_plan(
                sym=sym,
                side=side,
                tf=tf,
                df=df,
                df_trend=df_trend,
                px=float(px),
                atr_val=float(a),
                atr_pct=float(atr_pct),
                signal_strength=float(signal_strength),
                autonomy_decision=decision,
                ai_brain_adj=(adj if isinstance(adj, dict) else {}),
                llm_adj=(ladj if isinstance(ladj, dict) else {}),
                ticker=ticker,
            )

            if plan is not None and str(plan.tactic) == "none":
                _log_skip("decision_factor_skip", f"tactic=none reasons={plan.reasons}")
                return

            # Trace the chosen plan so UI can show *who* selected it and *why*
            try:
                if plan is not None:
                    self._think(
                        "trade_plan",
                        level="info",
                        symbol=sym,
                        side=side,
                        plan_id=str(getattr(plan, "plan_id", "") or ""),
                        tactic=str(getattr(plan, "tactic", "") or ""),
                        exec_pref=str(getattr(plan, "exec_pref", "") or ""),
                        allow_dca=bool(getattr(plan, "allow_dca", False)),
                        allow_pyramid=bool(getattr(plan, "allow_pyramid", False)),
                        reasons=getattr(plan, "reasons", None),
                        overrides=getattr(plan, "overrides", None),
                        controller="decision_factor",
                    )
            except Exception:
                pass
        except Exception as e:
            # fail-open: if decision factor errors, continue with legacy flow
            try:
                self.log.debug(f"decision_factor error: {type(e).__name__}: {e}")
            except Exception:
                pass
            plan = None

        # 9) Size qty + trade rules
                
        base_rm = float(getattr(decision, "risk_mult", 1.0) or 1.0)
        brain_rm = float(getattr(self, "_ai_brain_risk_mult", 1.0) or 1.0)
        llm_rm = float(getattr(self, "_llm_risk_mult", 1.0) or 1.0)
        self.risk._entry_risk_mult = float(base_rm) * float(brain_rm) * float(llm_rm)
        plan_rm = float(getattr(plan, 'overrides', {}).get('risk_mult', 1.0) or 1.0) if plan is not None else 1.0
        self.risk._entry_risk_mult = float(self.risk._entry_risk_mult) * float(plan_rm)
        # risk_state multiplier (from RiskStateOrchestrator.apply_to_engine)
        self.risk._entry_risk_mult = float(self.risk._entry_risk_mult) * float(getattr(self, "_risk_state_risk_mult", 1.0) or 1.0)

        # Online ML advice (optional): adjust risk and later leverage.
        self._online_ml_last = None
        self._online_ml_lev_mult = 1.0
        try:
            if self.online_ml is not None:
                mpv = {}
                if plan is not None and isinstance(getattr(plan, "votes", None), dict):
                    mpv = (plan.votes.get("market_profile") or {}) if isinstance(plan.votes.get("market_profile"), dict) else {}
                feats = dict(mpv or {})
                feats["signal_strength"] = float(signal_strength)
                # funding_rate filled later by futures settings; use 0.0 here
                feats.setdefault("funding_rate", 0.0)
                adv = self.online_ml.predict(sym, feats)
                self._online_ml_last = adv.to_dict() if hasattr(adv, "to_dict") else None
                self._online_ml_lev_mult = float(getattr(adv, "leverage_mult", 1.0) or 1.0)
                self.risk._entry_risk_mult = float(self.risk._entry_risk_mult) * float(getattr(adv, "risk_mult", 1.0) or 1.0)
        except Exception:
            pass

        try:
            qty = float(self.risk.size_qty(eq, px, a, self.client.markets, sym))
            if qty <= 0:
                _log_skip(
                    "size_qty_zero",
                    f"equity={eq:.2f} px={px:.8f} atr={a:.8f} atr%={atr_pct*100:.2f} risk_mult={self.risk._entry_risk_mult:.2f}",
                )
                return

            order_side = "buy" if side == "long" else "sell"
            qty2, px2 = self.client.enforce_trade_rules(sym, order_side, qty, px)
            if qty2 <= 0:
                _log_skip("trade_rules_block", f"order_side={order_side} qty_in={qty:.8f} qty_out={qty2:.8f}")
                return

            qty = float(qty2)
            px = float(px2)

            # 10) Stops/TP (plan-aware)
            plan_stop_mult = None
            plan_tp_mult = None
            try:
                if plan is not None:
                    plan_stop_mult = (plan.overrides or {}).get("stop_atr_mult", None)
                    plan_tp_mult = (plan.overrides or {}).get("tp_atr_mult", None)
            except Exception:
                plan_stop_mult = None
                plan_tp_mult = None

            if plan_stop_mult is not None or plan_tp_mult is not None:
                sm = float(plan_stop_mult if plan_stop_mult is not None else (self.cfg.get("risk") or {}).get("stop_atr_mult", 2.5))
                tm = float(plan_tp_mult if plan_tp_mult is not None else (self.cfg.get("risk") or {}).get("tp_atr_mult", 4.0))
                if side == "long":
                    stop = float(px) - sm * float(a)
                    tp = float(px) + tm * float(a)
                else:
                    stop = float(px) + sm * float(a)
                    tp = float(px) - tm * float(a)
            else:
                stop, tp = self.risk.stop_tp(side, px, a)
            stop = float(self.client.format_price(sym, stop))
            tp = float(self.client.format_price(sym, tp))

            # sanity
            if stop <= 0 or tp <= 0:
                _log_skip("bad_stop_tp", f"stop={stop:.8f} tp={tp:.8f} entry={px:.8f}")
                return

            # 10.1) Compute plan-aware safe leverage (futures) from stop distance
            desired_lev = None
            try:
                if bool((self.cfg.get("futures") or {}).get("enable", False)) and self.cfg.get("mode") == "live":
                    fcfg = (self.cfg.get("futures") or {})
                    user_max = int(fcfg.get("max_leverage", fcfg.get("leverage", 3)) or 3)
                    buffer_pct = float(fcfg.get("leverage_buffer_pct", 0.005) or 0.005)
                    stop_dist_pct = abs(float(px) - float(stop)) / max(1e-12, float(px))
                    max_safe = 1.0 / max(1e-6, stop_dist_pct + buffer_pct)
                    lev = int(max(1, math.floor(max_safe)))
                    # apply online ML leverage multiplier (<=1 typically when uncertain)
                    lev = int(max(1, math.floor(float(lev) * float(getattr(self, "_online_ml_lev_mult", 1.0) or 1.0))))
                    desired_lev = int(max(1, min(user_max, lev)))
            except Exception:
                desired_lev = None

            # 11) Approvals
            if self._approvals_required() and self.approvals:
                try:
                    existing = self.approvals.list(status="pending")
                except Exception:
                    existing = []

                if any((x.symbol == sym) for x in existing):
                    _log_skip("approval_already_pending", f"pending_count={len(existing)}")
                    return

                aobj = self.approvals.create(
                    sym, order_side, float(qty), float(px), f"signal_{side}",
                    meta={"atr_pct": float(atr_pct), "signal_strength": float(signal_strength), "autonomy_reason": decision.reason},
                )
                self.log.warning(f"{sym}: entry requires approval -> PENDING id={aobj.id}")
                try:
                    self.notifier.notify("approval_required", f"{sym} {order_side.upper()} pending approval {aobj.id}")
                except Exception:
                    pass
                return

            
            # Futures settings (leverage / margin / position mode) + funding gate (best-effort)
            if not self._ensure_futures_settings(sym, side, df, df_trend, float(signal_strength), desired_leverage=desired_lev):
                _log_skip("funding_block", "unfavorable funding or futures settings")
                return

            # Apply funding penalty (if configured) before sending the order
            try:
                pen = float(getattr(self, "_funding_penalty", 1.0) or 1.0)
                if pen < 1.0:
                    qty = float(qty) * pen
                    qty = float(self.client.format_amount(sym, qty))
            except Exception:
                pass

            # 12) Commit position intent + place order
            
            self.entry_intents[sym] = EntryIntent(
                symbol=sym,
                side=side,
                order_side=order_side,
                atr_val=float(a),
                atr_pct=float(atr_pct),
                signal_strength=float(signal_strength),
                reason=f"signal_{side}",
                plan_id=str(getattr(plan, 'plan_id', '') or ''),
                tactic=str(getattr(plan, 'tactic', '') or ''),
                plan=(getattr(plan, 'to_dict', lambda: {})() if plan is not None else {}),
                entry_features=(
                    (dict(((plan.votes.get("market_profile") or {}) if isinstance(getattr(plan, "votes", None), dict) else {}))
                     if plan is not None else {})
                ),
            )

            # Track per-symbol trade count for anti-overtrading controls
            try:
                if self.symbol_policy is not None:
                    self.symbol_policy.mark_open_attempt(sym)
            except Exception:
                pass

            # Human-readable trace for debugging autonomy decisions
            try:
                self._think(
                    "entry_intent",
                    symbol=sym,
                    side=side,
                    signal_strength=float(signal_strength),
                    atr_pct=float(atr_pct),
                    plan_id=str(getattr(plan, "plan_id", "") or ""),
                    tactic=str(getattr(plan, "tactic", "") or ""),
                    exec_pref=str(getattr(plan, "exec_pref", "") or ""),
                    allow_dca=bool(getattr(plan, "allow_dca", False)),
                    allow_pyramid=bool(getattr(plan, "allow_pyramid", False)),
                )
            except Exception:
                pass

            # 7b) Exposure caps (per-symbol and total), best-effort (uses equity and mark prices)
            try:
                pcap = ((self.cfg.get("risk") or {}).get("portfolio") or {})
                max_sym = float(pcap.get("max_symbol_exposure_pct", 0.35))
                max_tot = float(pcap.get("max_total_exposure_pct", 1.25))

                if eq and px and float(qty) > 0:
                    new_notional = abs(float(qty) * float(px))

                    # per-symbol cap
                    if max_sym > 0:
                        cap_sym = float(eq) * max_sym
                        if new_notional > cap_sym:
                            new_qty = cap_sym / max(1e-12, float(px))
                            self.log.warning(f"{sym}: symbol exposure cap -> reducing qty {qty:.6f} -> {new_qty:.6f}")
                            qty = float(new_qty)
                            new_notional = abs(float(qty) * float(px))

                    # total exposure cap
                    if max_tot > 0:
                        mark_prices = getattr(self, "last_prices", None) or getattr(self, "ticker_cache", None) or {}
                        total = 0.0
                        for s2, p2 in (self.positions or {}).items():
                            try:
                                if float(getattr(p2, "qty", 0.0)) <= 0:
                                    continue
                                mp = float(mark_prices.get(s2) or getattr(p2, "entry", 0.0) or 0.0)
                                total += abs(float(getattr(p2, "qty", 0.0)) * mp)
                            except Exception:
                                pass
                        cap_tot = float(eq) * max_tot
                        if (total + new_notional) > cap_tot:
                            room = max(0.0, cap_tot - total)
                            if room <= 0.0:
                                _log_skip("exposure_cap", f"total={total:.2f} cap={cap_tot:.2f}")
                                return
                            new_qty = room / max(1e-12, float(px))
                            self.log.warning(f"{sym}: total exposure cap -> reducing qty {qty:.6f} -> {new_qty:.6f}")
                            qty = float(new_qty)
            except Exception:
                pass

            self._place_order(sym, order_side, float(qty), f"signal_{side}", atr_pct=float(atr_pct))
            
                


            # success log (clar)
            meta_now = (self.position_meta or {}).get(sym, {}) or {}
            plan_tag = ""
            try:
                pid = str(meta_now.get("plan_id", "") or "")
                tac = str(meta_now.get("tactic", "") or "")
                if pid or tac:
                    plan_tag = f" plan={pid or '-'}|{tac or '-'}"
            except Exception:
                plan_tag = ""
            self.log.info(
                f"{sym}: ENTRY OK [{side.upper()}] qty={qty:.8f} entry~{px:.8f} stop={stop:.8f} tp={tp:.8f} "
                f"atr%={atr_pct*100:.2f} sig={float(signal_strength):.2f}{plan_tag} autonomy={decision.reason} llm={getattr(self,'_llm_reason','')} risk_mult={self.risk._entry_risk_mult:.2f}"
            )

        finally:
            self.risk._entry_risk_mult = 1.0
            try:
                setattr(self, "_ai_brain_risk_mult", 1.0)
            except Exception:
                pass
            try:
                setattr(self, "_llm_risk_mult", 1.0)
                setattr(self, "_llm_score_mult", 1.0)
                setattr(self, "_llm_reason", '')
            except Exception:
                pass


    def close_all(self, reason: str = "manual_close_all"):
        try:
            self.cancel_twap(reason=reason)
        except Exception:
            pass

        if self.cfg.get("mode") == "paper" and self.paper:
            for sym, pos in list(self.paper.positions.items()):
                try:
                    _, _, last = self._get_bid_ask_last(sym)
                    if pos.qty > 0:
                        self._fill_paper(sym, "sell", pos.qty, last, maker=False, reason=reason)
                    else:
                        self._fill_paper(sym, "buy", abs(pos.qty), last, maker=False, reason=reason)
                except Exception:
                    continue
            self.positions.clear()
            self.pending.clear()
            return

        for sym, pos in list(self.positions.items()):
            try:
                side_to_close = "sell" if pos.side == "long" else "buy"
                self._place_order(sym, side_to_close, float(pos.qty), reason, atr_pct=0.0)
            except Exception as e:
                if self._is_binance_reduce_only_regulation_error(e):
                    self._block_symbol(sym, "binance_reduce_only_regulation_-4408", seconds=24*3600)
                try:
                    self.log.warning(f"close_all: failed closing {sym}: {type(e).__name__}: {e}")
                except Exception:
                    pass
                continue


    # -----------------------------
    # Main loop (CORRECTED: no duplicates)
    # -----------------------------
    def loop(self):
        self.log.info(
            f"Engine start: exchange={self.cfg.get('exchange')} mode={self.cfg.get('mode')} FUTURES={self.cfg.get('enable_futures')}"
        )

        self.client.load_markets()
        if (self.cfg.get("websocket", {}) or {}).get("enabled", True):
            self.ws.start()
            
           
        self.log.info("Initial sync of SL/TP from exchange orders...")
        self.sync_sl_tp_from_open_orders()


        last_pairs_ts = 0.0
        last_state_save = 0.0

        while not self._stop:
            try:
                self._last_cycle_ts = time.time()
                self._last_cycle_error = ""
                self._new_day_check()
                self._apply_kill_switch()

                # RiskState orchestrator (NORMAL/CAUTION/RISK_OFF/HALT)
                try:
                    rs = self.risk_state.update(self)
                    # optional propagation to risk module
                    self.risk_state.apply_to_engine(self, rs)

                    rs_state, rs_reason, rs_controller = self._normalize_risk_state(rs)

                    # Trace: who is currently gating the engine (risk_state)
                    try:
                        self._think(
                            "risk_state",
                            level="info",
                            state=rs_state,
                            reason=rs_reason,
                            controller=rs_controller,
                        )
                    except Exception:
                        pass
                    try:
                        if self.store:
                            payload = rs if isinstance(rs, dict) else getattr(rs, "__dict__", {"repr": str(rs)})
                            self.store.decision(
                                decision_type="risk_state",
                                symbol="*",
                                component="risk_state",
                                payload={"state": payload, "normalized": {"state": rs_state, "reason": rs_reason, "controller": rs_controller}},
                            )
                    except Exception:
                        pass
                except Exception:
                    pass
                except Exception:
                    pass

                # Health checks + self-tuning (guardrailed)
                try:
                    self.health.tick(self)
                except Exception:
                    pass
                try:
                    self.self_tuner.tick(self)
                except Exception:
                    pass

                # Param-set evolution (periodic; conservative)
                try:
                    pe = getattr(self, "param_evolver", None)
                    if pe is not None and hasattr(pe, "enabled") and pe.enabled():
                        df_cfg = (self.cfg.get("decision_factor") or {})
                        bandit_cfg = (df_cfg.get("bandit") or {}) if isinstance(df_cfg.get("bandit"), dict) else {}
                        tactics = bandit_cfg.get("tactics", []) if isinstance(bandit_cfg.get("tactics", []), list) else []
                        symbols = list((getattr(self, "pairs", None) or {}).keys())
                        if symbols and tactics:
                            pe.tick(symbols, [str(x) for x in tactics if x])
                except Exception:
                    pass

                # Autonomy: lightweight online learning + dynamic tuning (optional)
                try:
                    tune_cfg = (self.cfg.get("autonomy", {}) or {}).get("tuning", {}) or {}
                    interval = float(tune_cfg.get("interval_sec", 900))
                    if interval > 0 and (time.time() - float(self._last_autonomy_tune_ts)) >= interval:
                        # build a minimal performance snapshot
                        eq = float(self.equity())
                        peak = float(self.peak_equity or eq)
                        dd = (peak - eq) / max(1e-12, peak)

                        last_trades = list(self.rec.trades[-50:]) if getattr(self.rec, "trades", None) else []
                        pnls = []
                        wins = 0
                        losses = 0
                        gp = 0.0
                        gl = 0.0
                        for tr in last_trades:
                            try:
                                p = float(getattr(tr, "realized_pnl", 0.0) or 0.0)
                            except Exception:
                                p = 0.0
                            pnls.append(p)
                            if p > 0:
                                wins += 1
                                gp += p
                            elif p < 0:
                                losses += 1
                                gl += -p

                        denom = (wins + losses)
                        win_rate = (wins / denom) if denom > 0 else 0.0
                        pf = (gp / max(1e-12, gl)) if gl > 0 else (gp if gp > 0 else 1.0)

                        res = self.autonomy.optimize_parameters_dynamically({
                            "win_rate": float(win_rate),
                            "profit_factor": float(pf),
                            "max_drawdown": float(dd),
                            "recent_pnls": pnls,
                        })
                        self._last_autonomy_tune_ts = time.time()

                        # Trace/record the tuning outcome so you can inspect it in GUI
                        try:
                            if isinstance(res, dict):
                                self._think(
                                    "autonomy_tune",
                                    level=("info" if res.get("updated") else "debug"),
                                    updated=bool(res.get("updated", False)),
                                    reason=str(res.get("reason") or ""),
                                    changes=res.get("changes"),
                                    win_rate=float(win_rate),
                                    profit_factor=float(pf),
                                    max_drawdown=float(dd),
                                    controller="autonomy",
                                )
                                if self.store:
                                    self.store.decision(
                                        dtype="autonomy_tune",
                                        symbol="*",
                                        payload={
                                            "updated": bool(res.get("updated", False)),
                                            "reason": res.get("reason"),
                                            "changes": res.get("changes"),
                                            "win_rate": float(win_rate),
                                            "profit_factor": float(pf),
                                            "max_drawdown": float(dd),
                                        },
                                    )
                        except Exception:
                            pass
                except Exception:
                    pass
                self._process_approvals()

                # always keep pending + twap moving, even if halted/paused
                self._process_twap_plans()
                self._check_pending()

                if self.halted or self.watchdog.is_paused():
                    time.sleep(1.0)
                    continue

                if (time.time() - last_pairs_ts) >= float(self.cfg.get("pair_refresh_sec", 60)) or not self.pairs:
                    self._refresh_pairs()
                    last_pairs_ts = time.time()

                if self.market_guard:
                    try:
                        reason = self.market_guard.check(self.client, self.pairs)
                        if reason:
                            self.log.warning(f"MarketGuard tripped: {reason}")
                            try:
                                self._think("market_guard", level="warning", reason=str(reason), controller="market_guard")
                            except Exception:
                                pass
                            try:
                                self.notifier.notify("market_guard", f"MarketGuard tripped: {reason}")
                            except Exception:
                                pass
                    except Exception:
                        pass

                # correlation map
                corr_cfg = ((self.cfg.get("risk", {}) or {}).get("portfolio", {}) or {}).get("correlation_filter", {}) or {}
                symbols_for_corr = list(set(self.pairs[: min(10, len(self.pairs))] + list(self.positions.keys())))
                returns_map = self._compute_returns_map(symbols_for_corr) if corr_cfg.get("enabled", True) else {}

                # update FNG (rate-limited)
                if (time.time() - self._fng_ts) > 900:
                    try:
                        self._fng_cache = int(fetch_fear_greed())
                        self._fng_ts = time.time()
                        self.log.info(f"Updated Fear & Greed Index: {self._fng_cache}")
                    except Exception:
                        pass
                        
                if not hasattr(self, "_last_tel_report_ts"):
                    self._last_tel_report_ts = 0.0

                if (time.time() - float(self._last_tel_report_ts)) >= 60.0:
                    snap = self.telemetry.snapshot()
                    # top erori
                    top_err = sorted(snap.items(), key=lambda kv: kv[1].get("err", 0), reverse=True)[:8]
                    if top_err:
                        self.log.info("[telemetry] top errors: " + " | ".join(
                            [f"{k}: err={v.get('err')} consec={v.get('consec_err')} last={v.get('last_err')}" for k, v in top_err]
                        ))
                    self._last_tel_report_ts = time.time()


                for sym in self.pairs:
                    if self._stop:
                        break

                    try:
                        df = self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=int(self.cfg.get("ohlcv_limit", 400)))
                        df_tr = self.client.fetch_ohlcv_df(
                            sym,
                            self.cfg["trend_timeframe"],
                            limit=min(2400, int(self.cfg.get("ohlcv_limit", 400)) * 4),
                        )

                        # ensure paper meta exists for open positions
                        if self.cfg.get("mode") == "paper" and getattr(self, "paper", None) and sym in (self.paper.positions or {}):
                            try:
                                self._sync_paper_meta(sym)
                            except Exception:
                                pass

                        # manage open position (SL/TP/trailing/scale-out)
                        self._manage_position(sym, df)

                        # compute signal on confirmed candles only
                        if len(df) <= 2:
                            continue

                        sig = None
                        try:
                            # if StrategyEngine supports fng_index
                            sig = self.strategy.compute(df.iloc[:-1], df_tr, sym, fng_index=int(self._fng_cache))
                        except TypeError:
                            sig = self.strategy.compute(df.iloc[:-1], df_tr, sym)

                        last_price = float(df["close"].iloc[-1])
                        self._record_signal(sym, sig, last_price)

                        # exit-on-opposite-signal (strategy-based)
                        if sym in self.positions:
                            pos = self.positions[sym]
                            if pos.side == "long" and getattr(sig, "action", "hold") == "sell":
                                self.log.info(f"{sym}: LONG exit signal received ({getattr(sig,'strength',0.0):.2f})")
                                self._place_order(sym, "sell", float(pos.qty), "signal_exit")
                            elif pos.side == "short" and getattr(sig, "action", "hold") == "buy":
                                self.log.info(f"{sym}: SHORT exit signal received ({getattr(sig,'strength',0.0):.2f})")
                                self._place_order(sym, "buy", float(pos.qty), "signal_exit")

                        # entries only if flat and no pending
                        if (sym not in self.positions) and (sym not in self.pending):
                            act = getattr(sig, "action", "hold")
                            strength = float(getattr(sig, "strength", 0.0))

                            if act == "buy":
                                self.log.info(f"{sym}: LONG signal {strength:.2f}")
                                self._open_position(sym, "long", df, df_tr, returns_map, signal_strength=strength)


                            elif act == "sell" and bool(self.cfg.get("enable_futures", False)):
                                self.log.info(f"{sym}: SHORT signal {strength:.2f}")
                                self._open_position(sym, "short", df, df_tr, returns_map, signal_strength=strength)


                        self.watchdog.record_success()

                    except Exception as e:
                        self.metrics.inc_error()
                        self.watchdog.record_error(e)                # paper sync (authoritative source: PaperPortfolio)
                if self.cfg.get("mode") == "paper" and getattr(self, "paper", None):
                    # ensure meta exists + qty stays aligned
                    for sym2 in list((self.paper.positions or {}).keys()):
                        try:
                            self._sync_paper_meta(sym2)
                        except Exception:
                            pass

                    # prune meta for symbols no longer open (unless pending entry exists)
                    for sym2 in list((self.positions or {}).keys()):
                        if sym2 in (self.paper.positions or {}):
                            try:
                                self.positions[sym2].qty = abs(self.paper.positions[sym2].qty)
                            except Exception:
                                pass
                            continue
                        if sym2 in (self.pending or {}):
                            continue
                        try:
                            del self.positions[sym2]
                        except Exception:
                            pass


                last_state_save = self._save_state_periodic(last_state_save)

            except Exception as e:
                self.metrics.inc_error()
                self.watchdog.record_error(e)

            time.sleep(max(0.2, float(self.cfg.get("scan_interval_sec", 1.0))))

        # final save
        self.state.save(self._snapshot())
        self.log.warning("Engine stopped.")

       
       
       
    # -----------------------------
    # Reconciliation / Recovery (best-effort)
    # -----------------------------
    def reconcile_with_exchange(self) -> Dict[str, Any]:
        """Best-effort: compare internal positions with exchange positions. Returns summary."""
        if str(self.cfg.get("mode","")).lower().strip() != "live":
            return {"mode": "paper", "ok": True, "details": "paper mode"}
        try:
            ex_pos = self.client.fetch_positions()
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

        # Build map: symbol -> netQty (best-effort)
        ex_map: Dict[str, float] = {}
        for p in ex_pos or []:
            try:
                sym = str(p.get("symbol") or p.get("info", {}).get("symbol") or "")
                if not sym:
                    continue
                amt = p.get("contracts")
                if amt is None:
                    amt = p.get("positionAmt") or p.get("info", {}).get("positionAmt")
                if amt is None:
                    amt = p.get("size") or p.get("info", {}).get("size")
                q = float(amt) if amt is not None else 0.0
                ex_map[sym] = ex_map.get(sym, 0.0) + q
            except Exception:
                continue

        diffs = []
        with self._pos_lock:
            for sym, pos in (self.positions or {}).items():
                iq = float(pos.qty) * (1.0 if pos.side == "long" else -1.0)
                eq = float(ex_map.get(sym, 0.0))
                if abs(iq - eq) > 1e-6:
                    diffs.append({"symbol": sym, "internal": iq, "exchange": eq})
        return {"ok": len(diffs) == 0, "diffs": diffs, "count": len(diffs)}
    # -----------------------------
    # Sync SL/TP Helper
    # -----------------------------
    def sync_sl_tp_from_open_orders(self) -> None:
        """
        Încearcă să populeze Stop/TP local citind ordinele deschise de pe exchange.
        Utilitate: Recovery după restart fără state.json sau pentru trade-uri manuale.
        """
        if self.cfg.get("mode") != "live":
            return

        try:
            # Nu rulăm sync-ul prea des pentru a evita rate-limits
            now = time.time()
            if (now - getattr(self, "_last_sl_tp_sync", 0.0)) < 60.0:
                return
            self._last_sl_tp_sync = now

            open_orders = self.client.fetch_open_orders() 
            if not open_orders:
                return

            # Grupăm ordinele per simbol
            orders_map = {}
            for o in open_orders:
                sym = o.get('symbol')
                if sym:
                    if sym not in orders_map:
                        orders_map[sym] = []
                    orders_map[sym].append(o)

            with self._pos_lock:
                for sym, pos in self.positions.items():
                    # Dacă avem deja valori, sărim
                    if float(getattr(pos, "stop", 0.0)) > 0 and float(getattr(pos, "tp", 0.0)) > 0:
                        continue

                    relevant_orders = orders_map.get(sym, [])
                    updated = False
                    
                    for o in relevant_orders:
                        o_type = str(o.get('type', '')).upper()
                        o_side = str(o.get('side', '')).lower()
                        stop_px = float(o.get('stopPrice') or o.get('triggerPrice') or 0.0)
                        price = float(o.get('price') or 0.0)

                        # Logică simplă de detecție bazată pe direcția poziției
                        # STOP LOSS
                        if stop_px > 0:
                            if pos.side == 'long' and o_side == 'sell' and stop_px < float(pos.entry):
                                if float(getattr(pos, "stop", 0.0)) == 0:
                                    pos.stop = stop_px
                                    updated = True
                            elif pos.side == 'short' and o_side == 'buy' and stop_px > float(pos.entry):
                                if float(getattr(pos, "stop", 0.0)) == 0:
                                    pos.stop = stop_px
                                    updated = True

                        # TAKE PROFIT (Limit sau TP Market)
                        eff_price = price if price > 0 else stop_px
                        if eff_price > 0:
                            # Ignorăm ordinele care par a fi SL (sub preț pt long) pentru detecția TP
                            if pos.side == 'long' and o_side == 'sell' and eff_price > float(pos.entry):
                                if float(getattr(pos, "tp", 0.0)) == 0:
                                    pos.tp = eff_price
                                    updated = True
                            elif pos.side == 'short' and o_side == 'buy' and eff_price < float(pos.entry):
                                if float(getattr(pos, "tp", 0.0)) == 0:
                                    pos.tp = eff_price
                                    updated = True
                    
                    if updated:
                        self.log.info(f"Sync: Recovered SL/TP for {sym} -> Stop: {pos.stop}, TP: {pos.tp}")

        except Exception as e:
            self.log.warning(f"Sync SL/TP failed: {e}")
    def audit_positions(self) -> Dict[str, Any]:
        """Audit snapshot for operational readiness + reconciliation hints.

        This is designed for *production-like* checks without placing live orders.
        API endpoint: GET /system/audit
        """
        out: Dict[str, Any] = {
            "ts": time.time(),
            "ok": True,
            "warnings": [],
            "errors": [],
        }

        # ---- Config context
        futures_cfg = (self.cfg.get("futures") or {})
        out["context"] = {
            "mode": str(self.cfg.get("mode")),
            "exchange": str(self.cfg.get("exchange")),
            "sandbox": bool(self.cfg.get("sandbox", False)),
            "enable_futures": bool(self.cfg.get("enable_futures", False)),
            "margin_mode": str(futures_cfg.get("margin_mode", "")),
            "hedge_mode": bool(futures_cfg.get("hedge_mode", False)),
            "leverage": futures_cfg.get("leverage"),
            "execution_type": str((self.cfg.get("execution") or {}).get("type", "")),
            "hard_protection_enabled": bool(((self.cfg.get("risk") or {}).get("hard_protection") or {}).get("enabled", False)),
        }

        # ---- Engine state summary
        try:
            out["metrics_equity"] = float(self.metrics.state.equity)
        except Exception:
            out["metrics_equity"] = None
        out["day_start_equity"] = self.day_start_equity
        out["peak_equity"] = self.peak_equity
        out["halted"] = bool(getattr(self, "halted", False))
        out["pairs_count"] = int(len(self.pairs or []))

        with self._pos_lock:
            out["engine_positions_count"] = int(len(self.positions or {}))
            out["engine_pending_count"] = int(len(self.pending or {}))
            # include details but keep reasonably sized
            out["positions"] = {k: v.__dict__ for k, v in (self.positions or {}).items()}
            out["pending"] = {k: v.__dict__ for k, v in (self.pending or {}).items()}

        # ---- Exchange capabilities (no network)
        try:
            ex = getattr(self.client, "ex", None)
            has = getattr(ex, "has", None)
            if isinstance(has, dict):
                out["ccxt_has"] = {
                    "fetchBalance": bool(has.get("fetchBalance", False)),
                    "fetchPositions": bool(has.get("fetchPositions", False)),
                    "fetchOpenOrders": bool(has.get("fetchOpenOrders", False)),
                    "createOrder": bool(has.get("createOrder", True)),
                }
        except Exception:
            pass

        mode = str(self.cfg.get("mode", "paper")).lower()
        is_live = mode == "live"

        # ---- Balances / equity
        try:
            quote = str(self.cfg.get("quote_asset", "USDT"))
            out["quote_asset"] = quote
        except Exception:
            quote = "USDT"
            out["quote_asset"] = quote

        if is_live:
            # live: best-effort balance + futures equity
            try:
                bal = self.client.fetch_balance()
                out["balances"] = bal
                # quick derived
                try:
                    out["quote_total"] = float(((bal.get("total") or {}).get(quote) or 0.0))
                except Exception:
                    out["quote_total"] = None
            except Exception as e:
                out["balances_error"] = f"{type(e).__name__}: {e}"
                out["errors"].append("balance_fetch_failed")
                out["ok"] = False

            try:
                fut_eq = self.client.fetch_futures_equity_usdt()
                out["futures_equity_usdt"] = fut_eq
            except Exception:
                out["futures_equity_usdt"] = None

            # common operational warning: 0 equity in live
            if (out.get("futures_equity_usdt") in (0, 0.0, None)) and (out.get("quote_total") in (0, 0.0, None)):
                out["warnings"].append("live_equity_zero_or_unknown")

            if self.day_start_equity in (0, 0.0, None):
                out["warnings"].append("day_start_equity_not_set_or_zero")

        else:
            # paper: use paper portfolio cash as equity proxy
            try:
                if getattr(self, "paper", None) is not None:
                    out["paper_cash_quote"] = float(getattr(self.paper, "cash_quote", 0.0))
            except Exception:
                pass

        # ---- Orders / positions on exchange (network)
        if is_live:
            try:
                out["open_orders"] = self.client.fetch_open_orders()
                out["open_orders_count"] = int(len(out.get("open_orders") or []))
            except Exception as e:
                out["open_orders_error"] = f"{type(e).__name__}: {e}"
                out["warnings"].append("open_orders_fetch_failed")

            try:
                ex_pos = self.client.fetch_positions()
                out["exchange_positions"] = ex_pos
                out["exchange_positions_count"] = int(len(ex_pos or []))
            except Exception as e:
                out["exchange_positions_error"] = f"{type(e).__name__}: {e}"
                out["warnings"].append("exchange_positions_fetch_failed")

            # Reconciliation hints (best-effort)
            try:
                eng_syms = set((self.positions or {}).keys())
                ex_syms = set()
                for p in (out.get("exchange_positions") or []):
                    s = p.get("symbol")
                    if s:
                        ex_syms.add(str(s))
                missing_on_engine = sorted(list(ex_syms - eng_syms))
                missing_on_exchange = sorted(list(eng_syms - ex_syms))
                out["reconcile"] = {
                    "missing_on_engine": missing_on_engine,
                    "missing_on_exchange": missing_on_exchange,
                }
                if missing_on_engine:
                    out["warnings"].append("engine_missing_some_exchange_positions")
                if missing_on_exchange:
                    out["warnings"].append("exchange_missing_some_engine_positions")
            except Exception:
                pass

        # ---- Kill switch sanity
        try:
            ks = ((self.cfg.get("risk") or {}).get("kill_switch") or {})
            out["kill_switch"] = {
                "enabled": bool(ks.get("enabled", False)),
                "max_daily_loss_pct": ks.get("max_daily_loss_pct"),
                "max_drawdown_pct": ks.get("max_drawdown_pct"),
                "intraday_shock": ks.get("intraday_shock"),
            }
        except Exception:
            pass

        # ---- Emit audit trail record
        try:
            self._audit_event(
                "audit_snapshot",
                ok=bool(out.get("ok")),
                warnings=len(out.get("warnings") or []),
                errors=len(out.get("errors") or []),
                engine_positions=int(out.get("engine_positions_count") or 0),
                engine_pending=int(out.get("engine_pending_count") or 0),
            )
        except Exception:
            pass

        return out

    def status(self) -> dict:
        """Stable, UI-friendly engine status. Never throws.

        This method is intentionally conservative: it only exposes a small set
        of fields that are safe to compute at any time (including during errors).
        """
        try:
            cfg = getattr(self, "cfg", {}) or {}
            mode = str(cfg.get("mode", "paper")).lower().strip()

            out: Dict[str, Any] = {
                "mode": mode,
                "exchange": str(cfg.get("exchange", "")),
                "sandbox": bool(cfg.get("sandbox", False)),
                "enable_futures": bool(cfg.get("enable_futures", False)),
                "halted": bool(getattr(self, "halted", False)),
                "pause_entries": bool(getattr(self, "pause_entries", False)),
                "stopped": bool(getattr(self, "_stop", False)),
                "last_cycle_ts": float(getattr(self, "_last_cycle_ts", 0.0) or 0.0),
                "last_cycle_error": str(getattr(self, "_last_cycle_error", "") or ""),
            }

            # Running flags (best-effort)
            try:
                out["running"] = bool(not out["stopped"])
            except Exception:
                out["running"] = None
            out["paused"] = bool(getattr(self, "paused", False) or getattr(self, "_paused", False))

            # Equity
            try:
                out["equity"] = float(getattr(self.metrics.state, "equity", None))
            except Exception:
                try:
                    out["equity"] = float(self.equity())
                except Exception:
                    out["equity"] = None

            # Counts (thread-safe best-effort)
            try:
                with getattr(self, "_pos_lock", _NullLock()):
                    out["positions_count"] = len(getattr(self, "positions", {}) or {})
            except Exception:
                out["positions_count"] = None
            try:
                with getattr(self, "_pending_lock", _NullLock()):
                    out["pending_count"] = len(getattr(self, "pending", {}) or {})
            except Exception:
                out["pending_count"] = None

            try:
                wl = getattr(self, "pairs", None) or getattr(self, "watchlist", None) or []
                out["watchlist_size"] = len(wl) if isinstance(wl, (list, tuple, set, dict)) else 0
            except Exception:
                out["watchlist_size"] = None

            # Risk state
            try:
                rs_obj = None
                rso = getattr(self, "risk_state", None)
                for attr in ("last_state", "last", "current"):
                    rs_obj = getattr(rso, attr, None)
                    if rs_obj is not None:
                        break
                if rs_obj is None:
                    rs_obj = getattr(rso, "state", None) or rso
                rs_state, rs_reason, rs_controller = self._normalize_risk_state(rs_obj)
                out["risk_state"] = {"state": rs_state, "reason": rs_reason, "controller": rs_controller}
            except Exception:
                out["risk_state"] = None

            # Capabilities
            try:
                caps = getattr(self, "capabilities", None)
                if hasattr(caps, "to_dict") and callable(getattr(caps, "to_dict")):
                    out["capabilities"] = caps.to_dict()
                elif hasattr(caps, "as_dict") and callable(getattr(caps, "as_dict")):
                    out["capabilities"] = caps.as_dict()
                elif isinstance(caps, dict):
                    out["capabilities"] = caps
                else:
                    out["capabilities"] = {}
            except Exception:
                out["capabilities"] = {}

            # Optional: last self-test
            try:
                out["selftest"] = getattr(self, "selftest_report", None)
            except Exception:
                out["selftest"] = None

            return out
        except Exception as e:
            return {
                "mode": "unknown",
                "running": False,
                "paused": False,
                "error": f"{type(e).__name__}: {e}",
            }


    def recover_from_disconnect(self) -> None:
        """Best-effort recovery: reconnect exchange + refresh state."""
        try:
            self.client._reconnect()
        except Exception:
            pass
        try:
            _ = self.client.fetch_balance()
        except Exception:
            pass
        try:
            self.reconcile_with_exchange()
        except Exception:
            pass

    def restore_from_backup(self, timestamp: Optional[str] = None) -> bool:
        """Restore engine state from StateManager backups (best-effort)."""
        try:
            d = self.state.load_backup(timestamp)
        except Exception:
            d = None
        if not d:
            return False

        # reuse resume logic (but don't force exchange match, only warn)
        if d.get("cfg_exchange") and d.get("cfg_exchange") != self.cfg.get("exchange"):
            self.log.warning("Backup state exchange mismatch; attempting restore anyway.")

        try:
            if self.cfg.get("mode") == "paper" and d.get("paper"):
                self.paper = PaperPortfolio.from_dict(self.cfg, d["paper"])
        except Exception:
            pass

        try:
            self.positions = {}
            for k, v in (d.get("positions_meta") or {}).items():
                try:
                    self.positions[k] = LivePosition(**v)
                except Exception:
                    continue
            self.pending = {}
            for k, v in (d.get("pending") or {}).items():
                try:
                    self.pending[k] = PendingOrder(**v)
                except Exception:
                    continue
            self.pairs = list(d.get("pairs") or [])
        except Exception:
            return False

        try:
            self.rec.trades = TradeRecorder.from_list(d.get("trades") or []).trades
        except Exception:
            pass

        try:
            self.halted = bool((d.get("guard") or {}).get("halted", False))
            self.day_start_equity = (d.get("guard") or {}).get("day_start_equity")
            self.peak_equity = (d.get("guard") or {}).get("peak_equity")
        except Exception:
            pass

        return True

        try:
            self._load_state_dict(d)
            return True
        except Exception:
            return True
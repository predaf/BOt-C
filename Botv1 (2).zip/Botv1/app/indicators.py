# app/indicators.py
from __future__ import annotations

import time
import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any, Optional, List, TypedDict, Protocol, Union, Callable
from dataclasses import dataclass, field
from functools import lru_cache, wraps
from enum import Enum, auto
import warnings
from collections import defaultdict
import threading


# ============================================================================
# Data Types
# ============================================================================

class IndicatorType(Enum):
    TREND = auto()
    MOMENTUM = auto()
    VOLATILITY = auto()
    VOLUME = auto()
    SUPPORT_RESISTANCE = auto()


class IndicatorResult(TypedDict, total=False):
    value: float
    series: pd.Series
    metadata: Dict[str, Any]
    signal: int  # -1, 0, 1
    strength: float


@dataclass
class IndicatorConfig:
    name: str
    indicator_type: IndicatorType
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    weight: float = 1.0
    min_periods: Optional[int] = None


class Indicator(Protocol):
    """Protocol for indicator functions."""
    
    def __call__(self, data: pd.DataFrame, **kwargs) -> Union[pd.Series, Tuple, Dict]:
        ...


# ============================================================================
# Utility Functions
# ============================================================================

def validate_dataframe(df: pd.DataFrame, required_cols: List[str]) -> pd.DataFrame:
    """Validate dataframe and required columns."""
    if df is None or df.empty:
        raise ValueError("DataFrame is None or empty")
    
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")
    
    return df


def clean_series(series: pd.Series) -> pd.Series:
    """Clean a pandas series: convert to numeric, remove inf, fill NaN with appropriate values."""
    if series is None or series.empty:
        return pd.Series(dtype=float)
    
    # Convert to numeric
    cleaned = pd.to_numeric(series, errors='coerce')
    
    # Replace infinite values with NaN
    cleaned = cleaned.replace([np.inf, -np.inf], np.nan)
    
    # Forward fill for some indicators, but be careful
    # For now, return as is - let each indicator decide how to handle NaNs
    return cleaned


def timing_decorator(func: Callable) -> Callable:
    """Decorator to time indicator calculations."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        wrapper.timing = getattr(wrapper, 'timing', [])
        wrapper.timing.append(elapsed)
        return result
    return wrapper


def cache_indicator(maxsize: int = 128):
    """Cache decorator for expensive indicator calculations."""
    def decorator(func: Callable):
        @lru_cache(maxsize=maxsize)
        @wraps(func)
        def cached_func(data_hash: int, *args, **kwargs):
            # This is a simplified cache - in practice you'd need the actual data
            return func.__wrapped__(*args, **kwargs) if hasattr(func, '__wrapped__') else func(*args, **kwargs)
        
        return cached_func
    return decorator


class IndicatorCache:
    """Simple cache for indicator calculations."""
    
    def __init__(self, max_size: int = 1000, ttl_seconds: float = 300.0):
        self.cache = {}
        self.max_size = max_size
        self.ttl = ttl_seconds
        self.lock = threading.RLock()
        self.stats = {"hits": 0, "misses": 0, "evictions": 0}
    
    def _generate_key(self, indicator_name: str, data_hash: int, params: Dict) -> str:
        """Generate a cache key."""
        param_str = "_".join(f"{k}={v}" for k, v in sorted(params.items()))
        return f"{indicator_name}_{data_hash}_{param_str}"
    
    def get(self, key: str) -> Optional[Any]:
        """Get cached value."""
        with self.lock:
            if key not in self.cache:
                self.stats["misses"] += 1
                return None
            
            value, timestamp = self.cache[key]
            if time.time() - timestamp > self.ttl:
                del self.cache[key]
                self.stats["misses"] += 1
                return None
            
            self.stats["hits"] += 1
            # Move to end (LRU)
            self.cache[key] = (value, timestamp)
            return value
    
    def set(self, key: str, value: Any):
        """Set cache value."""
        with self.lock:
            self.cache[key] = (value, time.time())
            
            # Evict if over size
            if len(self.cache) > self.max_size:
                oldest_key = next(iter(self.cache))
                del self.cache[oldest_key]
                self.stats["evictions"] += 1
    
    def clear(self):
        """Clear cache."""
        with self.lock:
            self.cache.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.lock:
            total = self.stats["hits"] + self.stats["misses"]
            hit_rate = self.stats["hits"] / total if total > 0 else 0.0
            return {
                **self.stats,
                "hit_rate": hit_rate,
                "size": len(self.cache),
                "max_size": self.max_size
            }


# ============================================================================
# Core Indicator Functions
# ============================================================================

@timing_decorator
def ema(series: pd.Series, span: int, adjust: bool = False, min_periods: Optional[int] = None) -> pd.Series:
    """
    Exponential Moving Average.
    
    Args:
        series: Input series
        span: EMA span (window)
        adjust: Whether to use adjust=True (dividing by decaying adjustment factor)
        min_periods: Minimum number of observations required
    
    Returns:
        EMA series
    """
    series = clean_series(series)
    span = max(1, int(span))
    min_periods = min_periods or span
    
    try:
        return series.ewm(span=span, adjust=adjust, min_periods=min_periods).mean()
    except Exception as e:
        warnings.warn(f"EMA calculation failed: {e}")
        return pd.Series([np.nan] * len(series), index=series.index)


@timing_decorator
def rsi(close: pd.Series, period: int = 14, method: str = "wilders") -> pd.Series:
    """
    Relative Strength Index.
    
    Args:
        close: Close price series
        period: RSI period
        method: "wilders" (Wilder's smoothing) or "ema" (EMA smoothing)
    
    Returns:
        RSI series (0-100)
    """
    close = clean_series(close)
    period = max(2, int(period))
    
    try:
        delta = close.diff()
        
        # Separate gains and losses
        gain = delta.clip(lower=0.0)
        loss = (-delta).clip(lower=0.0)
        
        if method.lower() == "wilders":
            # Wilder's smoothing: (prev * (n-1) + current) / n
            avg_gain = gain.ewm(alpha=1.0/period, adjust=False, min_periods=period).mean()
            avg_loss = loss.ewm(alpha=1.0/period, adjust=False, min_periods=period).mean()
        else:  # EMA smoothing
            avg_gain = gain.ewm(span=period, adjust=False, min_periods=period).mean()
            avg_loss = loss.ewm(span=period, adjust=False, min_periods=period).mean()
        
        # Avoid division by zero
        avg_loss_replaced = avg_loss.replace(0.0, np.nan)
        rs = avg_gain / avg_loss_replaced
        
        rsi_series = 100.0 - (100.0 / (1.0 + rs))
        
        # Handle edge cases
        rsi_series = rsi_series.where(~((avg_loss == 0.0) & (avg_gain > 0.0)), 100.0)
        rsi_series = rsi_series.where(~((avg_gain == 0.0) & (avg_loss > 0.0)), 0.0)
        
        # Fill leading NaNs with 50 (neutral)
        return rsi_series.fillna(50.0)
        
    except Exception as e:
        warnings.warn(f"RSI calculation failed: {e}")
        return pd.Series([50.0] * len(close), index=close.index)


@timing_decorator
def atr(df: pd.DataFrame, period: int = 14, method: str = "rma") -> pd.Series:
    """
    Average True Range.
    
    Args:
        df: DataFrame with 'high', 'low', 'close' columns
        period: ATR period
        method: "rma" (Wilder's RMA) or "ema" (EMA smoothing)
    
    Returns:
        ATR series
    """
    df = validate_dataframe(df, ["high", "low", "close"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    close = clean_series(df["close"])
    
    period = max(1, int(period))
    
    try:
        # Calculate True Range
        prev_close = close.shift(1)
        tr1 = high - low
        tr2 = (high - prev_close).abs()
        tr3 = (low - prev_close).abs()
        
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        
        # Apply smoothing
        if method.lower() == "rma":
            # Wilder's RMA (EMA with alpha = 1/period)
            alpha = 1.0 / period
            atr_series = true_range.ewm(alpha=alpha, adjust=False, min_periods=period).mean()
        else:  # EMA
            atr_series = true_range.ewm(span=period, adjust=False, min_periods=period).mean()
        
        return atr_series.fillna(method="bfill")
        
    except Exception as e:
        warnings.warn(f"ATR calculation failed: {e}")
        return pd.Series([np.nan] * len(df), index=df.index)


@timing_decorator
def donchian(df: pd.DataFrame, lookback: int = 20, 
             min_periods: Optional[int] = None) -> Tuple[pd.Series, pd.Series]:
    """
    Donchian Channels.
    
    Args:
        df: DataFrame with 'high', 'low' columns
        lookback: Lookback period
        min_periods: Minimum periods required
    
    Returns:
        Tuple of (upper_band, lower_band)
    """
    df = validate_dataframe(df, ["high", "low"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    
    lookback = max(1, int(lookback))
    min_periods = min_periods or lookback
    
    try:
        upper = high.rolling(window=lookback, min_periods=min_periods).max()
        lower = low.rolling(window=lookback, min_periods=min_periods).min()
        
        return upper, lower
        
    except Exception as e:
        warnings.warn(f"Donchian calculation failed: {e}")
        empty = pd.Series([np.nan] * len(df), index=df.index)
        return empty, empty


@timing_decorator
def macd(close: pd.Series, fast: int = 12, slow: int = 26, 
         signal: int = 9) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """
    MACD (Moving Average Convergence Divergence).
    
    Args:
        close: Close price series
        fast: Fast EMA period
        slow: Slow EMA period
        signal: Signal line period
    
    Returns:
        Tuple of (macd_line, signal_line, histogram)
    """
    close = clean_series(close)
    fast = max(1, int(fast))
    slow = max(fast + 1, int(slow))
    signal = max(1, int(signal))
    
    try:
        # Calculate EMAs
        ema_fast = ema(close, fast)
        ema_slow = ema(close, slow)
        
        # MACD line
        macd_line = ema_fast - ema_slow
        
        # Signal line
        signal_line = ema(macd_line, signal)
        
        # Histogram
        histogram = macd_line - signal_line
        
        return macd_line, signal_line, histogram
        
    except Exception as e:
        warnings.warn(f"MACD calculation failed: {e}")
        empty = pd.Series([np.nan] * len(close), index=close.index)
        return empty, empty, empty


@timing_decorator
def bbands(close: pd.Series, length: int = 20, std: float = 2.0,
           min_periods: Optional[int] = None) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """
    Bollinger Bands.
    
    Args:
        close: Close price series
        length: MA period
        std: Number of standard deviations
        min_periods: Minimum periods required
    
    Returns:
        Tuple of (lower_band, middle_band, upper_band)
    """
    close = clean_series(close)
    length = max(1, int(length))
    std = max(0.0, float(std))
    min_periods = min_periods or length
    
    try:
        # Middle band (SMA)
        middle = close.rolling(window=length, min_periods=min_periods).mean()
        
        # Standard deviation
        rolling_std = close.rolling(window=length, min_periods=min_periods).std(ddof=0)
        
        # Upper and lower bands
        upper = middle + (rolling_std * std)
        lower = middle - (rolling_std * std)
        
        return lower, middle, upper
        
    except Exception as e:
        warnings.warn(f"Bollinger Bands calculation failed: {e}")
        empty = pd.Series([np.nan] * len(close), index=close.index)
        return empty, empty, empty


@timing_decorator
def volume_delta(df: pd.DataFrame, method: str = "tick_rule") -> pd.Series:
    """
    Cumulative Volume Delta (CVD).
    
    Args:
        df: DataFrame with volume and price columns
        method: "tick_rule", "close_vs_open", "vwap"
    
    Returns:
        Cumulative volume delta series
    """
    if df is None or df.empty:
        return pd.Series(dtype=float)
    
    df = validate_dataframe(df, ["volume"])
    
    volume = clean_series(df["volume"]).fillna(0.0)
    
    try:
        if method == "tick_rule" and "close" in df.columns:
            # Tick rule: sign based on price change
            close = clean_series(df["close"])
            price_diff = close.diff()
            sign = np.sign(price_diff.fillna(0.0))
            
            # Replace zeros with NaN, forward fill, then fill remaining NaN with 0
            sign_series = pd.Series(sign, index=df.index).replace(0.0, np.nan).ffill().fillna(0.0)
            
        elif method == "close_vs_open" and "close" in df.columns and "open" in df.columns:
            # Sign based on close vs open
            close = clean_series(df["close"])
            open_ = clean_series(df["open"])
            sign = np.sign((close - open_).fillna(0.0))
            sign_series = pd.Series(sign, index=df.index)
            
        elif method == "vwap" and all(col in df.columns for col in ["high", "low", "close", "volume"]):
            # VWAP-based delta (more sophisticated)
            high = clean_series(df["high"])
            low = clean_series(df["low"])
            close = clean_series(df["close"])
            
            typical_price = (high + low + close) / 3.0
            vwap = (typical_price * volume).cumsum() / volume.cumsum()
            sign = np.sign((close - vwap).fillna(0.0))
            sign_series = pd.Series(sign, index=df.index)
            
        else:
            # Default to zero
            sign_series = pd.Series([0.0] * len(df), index=df.index)
        
        # Calculate cumulative delta
        delta = volume * sign_series
        cumulative_delta = delta.cumsum()
        
        return cumulative_delta
        
    except Exception as e:
        warnings.warn(f"Volume delta calculation failed: {e}")
        return pd.Series([0.0] * len(df), index=df.index)


@timing_decorator
def adx(df: pd.DataFrame, period: int = 14, di_period: int = 14) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """
    Average Directional Index (ADX) with +/- DI.
    
    Args:
        df: DataFrame with 'high', 'low', 'close' columns
        period: ADX smoothing period
        di_period: DI smoothing period
    
    Returns:
        Tuple of (adx, plus_di, minus_di)
    """
    df = validate_dataframe(df, ["high", "low", "close"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    close = clean_series(df["close"])
    
    period = max(1, int(period))
    di_period = max(1, int(di_period))
    
    try:
        # Calculate directional movements
        up_move = high.diff()
        down_move = low.diff().mul(-1)  # Negative for easier comparison
        
        plus_dm = up_move.where((up_move > down_move) & (up_move > 0.0), 0.0)
        minus_dm = down_move.where((down_move > up_move) & (down_move > 0.0), 0.0)
        
        # True Range
        prev_close = close.shift(1)
        tr = pd.concat([
            (high - low),
            (high - prev_close).abs(),
            (low - prev_close).abs()
        ], axis=1).max(axis=1)
        
        # Smooth TR, +DM, -DM using Wilder's smoothing (RMA)
        alpha = 1.0 / di_period
        atr_smoothed = tr.ewm(alpha=alpha, adjust=False, min_periods=di_period).mean()
        plus_dm_smoothed = plus_dm.ewm(alpha=alpha, adjust=False, min_periods=di_period).mean()
        minus_dm_smoothed = minus_dm.ewm(alpha=alpha, adjust=False, min_periods=di_period).mean()
        
        # Calculate Directional Indicators
        plus_di = 100.0 * plus_dm_smoothed / atr_smoothed.replace(0.0, np.nan)
        minus_di = 100.0 * minus_dm_smoothed / atr_smoothed.replace(0.0, np.nan)
        
        # Calculate Directional Index (DX)
        di_sum = plus_di + minus_di
        di_diff = (plus_di - minus_di).abs()
        dx = 100.0 * di_diff / di_sum.replace(0.0, np.nan)
        
        # Calculate ADX (smoothed DX)
        adx_series = dx.ewm(alpha=alpha, adjust=False, min_periods=period).mean()
        
        # Clean up
        adx_series = adx_series.fillna(0.0)
        plus_di = plus_di.fillna(0.0)
        minus_di = minus_di.fillna(0.0)
        
        return adx_series, plus_di, minus_di
        
    except Exception as e:
        warnings.warn(f"ADX calculation failed: {e}")
        empty = pd.Series([np.nan] * len(df), index=df.index)
        return empty, empty, empty


@timing_decorator
def stochastic(df: pd.DataFrame, k_period: int = 14, d_period: int = 3,
               smooth_k: int = 1) -> Tuple[pd.Series, pd.Series]:
    """
    Stochastic Oscillator.
    
    Args:
        df: DataFrame with 'high', 'low', 'close' columns
        k_period: %K period
        d_period: %D period (smoothing of %K)
        smooth_k: Smoothing for %K
    
    Returns:
        Tuple of (%K, %D)
    """
    df = validate_dataframe(df, ["high", "low", "close"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    close = clean_series(df["close"])
    
    k_period = max(1, int(k_period))
    d_period = max(1, int(d_period))
    smooth_k = max(1, int(smooth_k))
    
    try:
        # Calculate %K
        lowest_low = low.rolling(window=k_period).min()
        highest_high = high.rolling(window=k_period).max()
        
        k_raw = 100.0 * ((close - lowest_low) / (highest_high - lowest_low).replace(0.0, np.nan))
        
        # Smooth %K if requested
        if smooth_k > 1:
            k_smoothed = k_raw.rolling(window=smooth_k).mean()
        else:
            k_smoothed = k_raw
        
        # Calculate %D (smoothing of %K)
        d_smoothed = k_smoothed.rolling(window=d_period).mean()
        
        return k_smoothed.fillna(50.0), d_smoothed.fillna(50.0)
        
    except Exception as e:
        warnings.warn(f"Stochastic calculation failed: {e}")
        empty = pd.Series([50.0] * len(df), index=df.index)
        return empty, empty


@timing_decorator
def obv(df: pd.DataFrame) -> pd.Series:
    """
    On-Balance Volume.
    
    Args:
        df: DataFrame with 'close' and 'volume' columns
    
    Returns:
        OBV series
    """
    df = validate_dataframe(df, ["close", "volume"])
    
    close = clean_series(df["close"])
    volume = clean_series(df["volume"]).fillna(0.0)
    
    try:
        # Calculate price change sign
        price_change = close.diff()
        sign = np.sign(price_change.fillna(0.0))
        
        # OBV calculation
        obv_series = (volume * sign).cumsum()
        
        return obv_series
        
    except Exception as e:
        warnings.warn(f"OBV calculation failed: {e}")
        return pd.Series([0.0] * len(df), index=df.index)


# ============================================================================
# Advanced Indicator Functions
# ============================================================================

@timing_decorator
def ichimoku(df: pd.DataFrame, tenkan: int = 9, kijun: int = 26, 
             senkou: int = 52, chikou: int = 26) -> Dict[str, pd.Series]:
    """
    Ichimoku Cloud.
    
    Args:
        df: DataFrame with 'high', 'low', 'close' columns
        tenkan: Tenkan-sen period
        kijun: Kijun-sen period
        senkou: Senkou Span period
        chikou: Chikou Span period
    
    Returns:
        Dictionary with all Ichimoku components
    """
    df = validate_dataframe(df, ["high", "low", "close"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    close = clean_series(df["close"])
    
    try:
        # Tenkan-sen (Conversion Line)
        tenkan_high = high.rolling(window=tenkan).max()
        tenkan_low = low.rolling(window=tenkan).min()
        tenkan_sen = (tenkan_high + tenkan_low) / 2
        
        # Kijun-sen (Base Line)
        kijun_high = high.rolling(window=kijun).max()
        kijun_low = low.rolling(window=kijun).min()
        kijun_sen = (kijun_high + kijun_low) / 2
        
        # Senkou Span A (Leading Span A)
        senkou_a = ((tenkan_sen + kijun_sen) / 2).shift(kijun)
        
        # Senkou Span B (Leading Span B)
        senkou_b_high = high.rolling(window=senkou).max()
        senkou_b_low = low.rolling(window=senkou).min()
        senkou_b = ((senkou_b_high + senkou_b_low) / 2).shift(kijun)
        
        # Chikou Span (Lagging Span)
        chikou_span = close.shift(-chikou)
        
        return {
            "tenkan_sen": tenkan_sen,
            "kijun_sen": kijun_sen,
            "senkou_a": senkou_a,
            "senkou_b": senkou_b,
            "chikou_span": chikou_span,
            "cloud_top": pd.concat([senkou_a, senkou_b], axis=1).max(axis=1),
            "cloud_bottom": pd.concat([senkou_a, senkou_b], axis=1).min(axis=1)
        }
        
    except Exception as e:
        warnings.warn(f"Ichimoku calculation failed: {e}")
        empty = pd.Series([np.nan] * len(df), index=df.index)
        return {key: empty for key in ["tenkan_sen", "kijun_sen", "senkou_a", "senkou_b", 
                                      "chikou_span", "cloud_top", "cloud_bottom"]}


@timing_decorator
def fibonacci_retracement(df: pd.DataFrame, lookback: int = 20) -> Dict[str, float]:
    """
    Calculate Fibonacci retracement levels.
    
    Args:
        df: DataFrame with 'high', 'low' columns
        lookback: Lookback period to find swing high/low
    
    Returns:
        Dictionary with Fibonacci levels
    """
    df = validate_dataframe(df, ["high", "low"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    
    lookback = max(1, int(lookback))
    
    try:
        # Find recent swing high and low
        recent_high = high.rolling(window=lookback).max().iloc[-1]
        recent_low = low.rolling(window=lookback).min().iloc[-1]
        
        diff = recent_high - recent_low
        
        # Fibonacci levels
        levels = {
            "0.0": recent_low,
            "0.236": recent_low + diff * 0.236,
            "0.382": recent_low + diff * 0.382,
            "0.5": recent_low + diff * 0.5,
            "0.618": recent_low + diff * 0.618,
            "0.786": recent_low + diff * 0.786,
            "1.0": recent_high,
            "1.272": recent_high + diff * 0.272,
            "1.618": recent_high + diff * 0.618
        }
        
        return levels
        
    except Exception as e:
        warnings.warn(f"Fibonacci retracement calculation failed: {e}")
        return {}


@timing_decorator
def vwap(df: pd.DataFrame, period: Optional[int] = None) -> pd.Series:
    """
    Volume Weighted Average Price.
    
    Args:
        df: DataFrame with 'high', 'low', 'close', 'volume' columns
        period: Rolling period (None for cumulative)
    
    Returns:
        VWAP series
    """
    df = validate_dataframe(df, ["high", "low", "close", "volume"])
    
    high = clean_series(df["high"])
    low = clean_series(df["low"])
    close = clean_series(df["close"])
    volume = clean_series(df["volume"]).fillna(0.0)
    
    try:
        # Typical price
        typical_price = (high + low + close) / 3.0
        
        # VWAP calculation
        if period is not None:
            # Rolling VWAP
            window = int(period)
            cumulative_price = (typical_price * volume).rolling(window=window).sum()
            cumulative_volume = volume.rolling(window=window).sum()
            vwap_series = cumulative_price / cumulative_volume.replace(0.0, np.nan)
        else:
            # Cumulative VWAP
            cumulative_price = (typical_price * volume).cumsum()
            cumulative_volume = volume.cumsum()
            vwap_series = cumulative_price / cumulative_volume.replace(0.0, np.nan)
        
        return vwap_series.fillna(method="bfill")
        
    except Exception as e:
        warnings.warn(f"VWAP calculation failed: {e}")
        return pd.Series([np.nan] * len(df), index=df.index)


# ============================================================================
# Regime Detection
# ============================================================================

@timing_decorator
def regime_score(
    df: pd.DataFrame,
    *,
    min_len: int = 120,
    slope_lookback: int = 10,
    slope_thr: float = 0.0035,
    atr_thr: float = 0.008,
    adx_thr: float = 25.0,
    rsi_thr: float = 60.0
) -> Dict[str, Any]:
    """
    Advanced regime detection with multiple indicators.
    
    Args:
        df: DataFrame with OHLCV data
        min_len: Minimum data length required
        slope_lookback: Lookback for slope calculation
        slope_thr: Slope threshold for trend detection
        atr_thr: ATR threshold for volatility
        adx_thr: ADX threshold for trend strength
        rsi_thr: RSI threshold for overbought/oversold
    
    Returns:
        Dictionary with regime classification and scores
    """
    if df is None or len(df) < min_len:
        return {"regime": "unknown", "strength": 0.0, "confidence": 0.0}
    
    df = validate_dataframe(df, ["close", "high", "low"])
    
    try:
        close = clean_series(df["close"])
        
        # Calculate indicators
        e20 = ema(close, 20)
        e50 = ema(close, 50)
        
        # Slope calculation
        lb = int(slope_lookback)
        if len(e20) < lb + 1:
            return {"regime": "unknown", "strength": 0.0, "confidence": 0.0}
        
        current_price = float(close.iloc[-1])
        slope = (e20.iloc[-1] - e20.iloc[-1 - lb]) / max(1e-12, current_price)
        
        # ATR
        atr_series = atr(df, 14)
        atr_value = float(atr_series.iloc[-1]) if len(atr_series) > 0 else 0.0
        atr_pct = atr_value / max(1e-12, current_price)
        
        # RSI
        rsi_series = rsi(close, 14)
        rsi_value = float(rsi_series.iloc[-1]) if len(rsi_series) > 0 else 50.0
        
        # ADX
        adx_series, plus_di, minus_di = adx(df, 14)
        adx_value = float(adx_series.iloc[-1]) if len(adx_series) > 0 else 0.0
        
        # Determine regime
        regime = "range"
        strength = 0.0
        confidence = 0.0
        
        # Check for trend
        is_volatile = atr_pct > atr_thr
        has_slope = abs(slope) > slope_thr
        has_adx_strength = adx_value > adx_thr
        
        if (has_slope or has_adx_strength) and is_volatile:
            regime = "trend"
            strength = min(1.0, max(abs(slope) / slope_thr, adx_value / adx_thr))
            
            # Determine trend direction
            if plus_di.iloc[-1] > minus_di.iloc[-1]:
                regime = "trend_up"
            else:
                regime = "trend_down"
        
        # Check for volatility regime
        elif atr_pct > (atr_thr * 1.5):
            regime = "high_vol"
            strength = min(1.0, atr_pct / (atr_thr * 2))
        
        # Check for low volatility
        elif atr_pct < (atr_thr * 0.5):
            regime = "low_vol"
            strength = min(1.0, (atr_thr * 0.5) / max(atr_pct, 1e-12))
        
        # Check for overbought/oversold
        if rsi_value > rsi_thr:
            regime = "overbought" if regime == "range" else f"{regime}_overbought"
        elif rsi_value < (100 - rsi_thr):
            regime = "oversold" if regime == "range" else f"{regime}_oversold"
        
        # Calculate confidence
        confidence = min(1.0, (
            (1.0 if has_slope else 0.0) * 0.3 +
            (1.0 if has_adx_strength else 0.0) * 0.3 +
            (min(atr_pct / atr_thr, 1.0)) * 0.2 +
            (1.0 - abs(rsi_value - 50) / 50) * 0.2
        ))
        
        return {
            "regime": regime,
            "strength": float(strength),
            "confidence": float(confidence),
            "slope": float(slope),
            "atr_pct": float(atr_pct),
            "rsi": float(rsi_value),
            "adx": float(adx_value),
            "plus_di": float(plus_di.iloc[-1]) if len(plus_di) > 0 else 0.0,
            "minus_di": float(minus_di.iloc[-1]) if len(minus_di) > 0 else 0.0
        }
        
    except Exception as e:
        warnings.warn(f"Regime detection failed: {e}")
        return {"regime": "unknown", "strength": 0.0, "confidence": 0.0}


# ============================================================================
# Feature Computation
# ============================================================================

@timing_decorator
def compute_features(df: pd.DataFrame, cfg: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
    """
    Compute a comprehensive feature set.
    
    Args:
        df: Input DataFrame with OHLCV data
        cfg: Configuration dictionary
    
    Returns:
        DataFrame with added feature columns
    """
    if df is None or df.empty:
        return df
    
    # Default configuration
    default_cfg = {
        "indicators": {
            "ema": [20, 50, 100, 200],
            "rsi": [14],
            "atr": [14],
            "macd": {"fast": 12, "slow": 26, "signal": 9},
            "bbands": {"length": 20, "std": 2.0},
            "stochastic": {"k_period": 14, "d_period": 3},
            "adx": {"period": 14},
            "obv": True,
            "volume_delta": True,
            "vwap": True,
            "ichimoku": False,
        },
        "normalize": True,
        "fill_na": True,
        "add_regime": True,
    }
    
    cfg = {**default_cfg, **(cfg or {})}
    indicator_cfg = cfg.get("indicators", {})
    
    try:
        # Validate input
        df = validate_dataframe(df, ["open", "high", "low", "close", "volume"])
        out = df.copy()
        
        close = clean_series(out["close"])
        
        # Moving Averages
        if "ema" in indicator_cfg:
            periods = indicator_cfg["ema"]
            if isinstance(periods, list):
                for period in periods:
                    out[f"ema{period}"] = ema(close, period)
        
        # RSI
        if "rsi" in indicator_cfg:
            periods = indicator_cfg["rsi"]
            if isinstance(periods, list):
                for period in periods:
                    out[f"rsi{period}"] = rsi(close, period)
        
        # ATR
        if "atr" in indicator_cfg:
            periods = indicator_cfg["atr"]
            if isinstance(periods, list):
                for period in periods:
                    out[f"atr{period}"] = atr(out, period)
                    out[f"atr{period}_pct"] = out[f"atr{period}"] / close.replace(0.0, np.nan)
        
        # MACD
        if "macd" in indicator_cfg:
            macd_cfg = indicator_cfg["macd"]
            if isinstance(macd_cfg, dict):
                macd_line, signal_line, histogram = macd(
                    close,
                    fast=macd_cfg.get("fast", 12),
                    slow=macd_cfg.get("slow", 26),
                    signal=macd_cfg.get("signal", 9)
                )
                out["macd"] = macd_line
                out["macd_signal"] = signal_line
                out["macd_histogram"] = histogram
        
        # Bollinger Bands
        if "bbands" in indicator_cfg:
            bb_cfg = indicator_cfg["bbands"]
            if isinstance(bb_cfg, dict):
                lower, middle, upper = bbands(
                    close,
                    length=bb_cfg.get("length", 20),
                    std=bb_cfg.get("std", 2.0)
                )
                out["bb_lower"] = lower
                out["bb_middle"] = middle
                out["bb_upper"] = upper
                out["bb_width"] = (upper - lower) / middle.replace(0.0, np.nan)
                out["bb_position"] = (close - lower) / (upper - lower).replace(0.0, np.nan)
        
        # Stochastic
        if "stochastic" in indicator_cfg:
            stoch_cfg = indicator_cfg["stochastic"]
            if isinstance(stoch_cfg, dict):
                k, d = stochastic(
                    out,
                    k_period=stoch_cfg.get("k_period", 14),
                    d_period=stoch_cfg.get("d_period", 3),
                    smooth_k=stoch_cfg.get("smooth_k", 1)
                )
                out["stoch_k"] = k
                out["stoch_d"] = d
        
        # ADX
        if "adx" in indicator_cfg:
            adx_cfg = indicator_cfg["adx"]
            if isinstance(adx_cfg, dict):
                adx_series, plus_di, minus_di = adx(
                    out,
                    period=adx_cfg.get("period", 14)
                )
                out["adx"] = adx_series
                out["plus_di"] = plus_di
                out["minus_di"] = minus_di
        
        # Volume indicators
        if indicator_cfg.get("obv", False):
            out["obv"] = obv(out)
        
        if indicator_cfg.get("volume_delta", False):
            out["cvd"] = volume_delta(out)
        
        if indicator_cfg.get("vwap", False):
            out["vwap"] = vwap(out)
        
        # Ichimoku Cloud
        if indicator_cfg.get("ichimoku", False):
            ichimoku_data = ichimoku(out)
            for key, value in ichimoku_data.items():
                out[f"ichimoku_{key}"] = value
        
        # Regime detection
        if cfg.get("add_regime", True):
            regime_info = regime_score(out)
            out["regime"] = regime_info["regime"]
            out["regime_strength"] = regime_info["strength"]
            out["regime_confidence"] = regime_info["confidence"]
        
        # Clean up
        out = out.replace([np.inf, -np.inf], np.nan)
        
        if cfg.get("fill_na", True):
            # Forward fill, then backward fill
            out = out.ffill().bfill()
        
        if cfg.get("normalize", True):
            # Simple normalization for some columns
            numeric_cols = out.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                if col not in ["open", "high", "low", "close", "volume"]:
                    # Skip price and volume columns
                    if out[col].std() > 0:
                        out[f"{col}_norm"] = (out[col] - out[col].mean()) / out[col].std()
        
        return out
        
    except Exception as e:
        warnings.warn(f"Feature computation failed: {e}")
        return df


# ============================================================================
# Indicator Manager Class
# ============================================================================

class IndicatorManager:
    """Manager for computing and caching indicators."""
    
    def __init__(self, cache_size: int = 1000, cache_ttl: float = 300.0):
        self.cache = IndicatorCache(max_size=cache_size, ttl_seconds=cache_ttl)
        self.registry = self._build_registry()
        self.metrics = defaultdict(list)
    
    def _build_registry(self) -> Dict[str, Dict[str, Any]]:
        """Build registry of available indicators."""
        return {
            "ema": {"func": ema, "type": IndicatorType.TREND, "params": ["series", "span"]},
            "rsi": {"func": rsi, "type": IndicatorType.MOMENTUM, "params": ["close", "period"]},
            "atr": {"func": atr, "type": IndicatorType.VOLATILITY, "params": ["df", "period"]},
            "macd": {"func": macd, "type": IndicatorType.MOMENTUM, "params": ["close", "fast", "slow", "signal"]},
            "bbands": {"func": bbands, "type": IndicatorType.VOLATILITY, "params": ["close", "length", "std"]},
            "adx": {"func": adx, "type": IndicatorType.TREND, "params": ["df", "period"]},
            "stochastic": {"func": stochastic, "type": IndicatorType.MOMENTUM, "params": ["df", "k_period", "d_period"]},
            "obv": {"func": obv, "type": IndicatorType.VOLUME, "params": ["df"]},
            "volume_delta": {"func": volume_delta, "type": IndicatorType.VOLUME, "params": ["df", "method"]},
            "ichimoku": {"func": ichimoku, "type": IndicatorType.TREND, "params": ["df", "tenkan", "kijun", "senkou"]},
            "vwap": {"func": vwap, "type": IndicatorType.VOLUME, "params": ["df", "period"]},
            "regime_score": {"func": regime_score, "type": IndicatorType.TREND, "params": ["df"]},
        }
    
    def compute(self, indicator_name: str, data: pd.DataFrame, **kwargs) -> Any:
        """Compute an indicator with caching."""
        # Generate cache key
        data_hash = hash(tuple(data["close"].fillna(0).values.tobytes()))
        cache_key = self.cache._generate_key(indicator_name, data_hash, kwargs)
        
        # Check cache
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        # Compute indicator
        if indicator_name not in self.registry:
            raise ValueError(f"Unknown indicator: {indicator_name}")
        
        indicator_info = self.registry[indicator_name]
        func = indicator_info["func"]
        
        start_time = time.time()
        try:
            result = func(data, **kwargs)
            elapsed = time.time() - start_time
            
            # Cache result
            self.cache.set(cache_key, result)
            
            # Record metrics
            self.metrics[indicator_name].append(elapsed)
            
            return result
            
        except Exception as e:
            elapsed = time.time() - start_time
            self.metrics[f"{indicator_name}_error"].append(elapsed)
            raise
    
    def compute_batch(self, indicators: List[Dict[str, Any]], data: pd.DataFrame) -> Dict[str, Any]:
        """Compute multiple indicators in batch."""
        results = {}
        
        for indicator_config in indicators:
            name = indicator_config.get("name")
            if name not in self.registry:
                continue
            
            params = indicator_config.get("params", {})
            try:
                results[name] = self.compute(name, data, **params)
            except Exception as e:
                warnings.warn(f"Failed to compute indicator {name}: {e}")
                results[name] = None
        
        return results
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics."""
        metrics = {}
        for indicator, times in self.metrics.items():
            if times:
                metrics[indicator] = {
                    "count": len(times),
                    "avg_time_ms": np.mean(times) * 1000,
                    "max_time_ms": np.max(times) * 1000,
                    "min_time_ms": np.min(times) * 1000,
                }
        
        cache_stats = self.cache.get_stats()
        metrics["cache"] = cache_stats
        
        return metrics
    
    def clear_cache(self):
        """Clear indicator cache."""
        self.cache.clear()


# ============================================================================
# Signal Generation
# ============================================================================


def calculate_indicators(df, cfg=None):
    """Backwards-compatible wrapper for older modules."""
    try:
        out = compute_features(df, cfg or {})
        return out
    except Exception:
        # If feature computation fails, return df unchanged
        return df

def generate_signals(df: pd.DataFrame, 
                     indicators_config: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
    """
    Generate trading signals based on multiple indicators.
    
    Args:
        df: DataFrame with indicator columns
        indicators_config: Configuration for signal generation
    
    Returns:
        DataFrame with signal columns
    """
    if df is None or df.empty:
        return df
    
    out = df.copy()
    
    # Default signal configuration
    default_config = {
        "rsi": {"period": 14, "overbought": 70, "oversold": 30},
        "macd": {"signal": "macd_signal", "line": "macd"},
        "bbands": {"position": "bb_position", "overbought": 0.8, "oversold": 0.2},
        "stochastic": {"k": "stoch_k", "d": "stoch_d", "overbought": 80, "oversold": 20},
        "volume_confirmation": True,
        "trend_filter": True,
    }
    
    config = {**default_config, **(indicators_config or {})}
    
    try:
        # Initialize signal columns
        out["signal"] = 0  # -1: sell, 0: neutral, 1: buy
        out["signal_strength"] = 0.0
        out["signal_confidence"] = 0.0
        
        signals = []
        strengths = []
        
        # RSI signals
        if "rsi" in config and "rsi14" in out.columns:
            rsi_cfg = config["rsi"]
            rsi_values = out["rsi14"]
            
            rsi_signal = pd.Series(0, index=out.index)
            rsi_signal[rsi_values < rsi_cfg["oversold"]] = 1
            rsi_signal[rsi_values > rsi_cfg["overbought"]] = -1
            
            rsi_strength = (rsi_cfg["oversold"] - rsi_values) / rsi_cfg["oversold"]
            rsi_strength = rsi_strength.clip(-1, 1)
            
            signals.append(rsi_signal)
            strengths.append(rsi_strength.abs())
        
        # MACD signals
        if "macd" in config and all(col in out.columns for col in ["macd", "macd_signal"]):
            macd_cfg = config["macd"]
            macd_line = out["macd"]
            signal_line = out["macd_signal"]
            
            macd_signal = pd.Series(0, index=out.index)
            macd_signal[(macd_line > signal_line) & (macd_line.shift(1) <= signal_line.shift(1))] = 1
            macd_signal[(macd_line < signal_line) & (macd_line.shift(1) >= signal_line.shift(1))] = -1
            
            macd_strength = (macd_line - signal_line) / out["close"].replace(0.0, np.nan)
            
            signals.append(macd_signal)
            strengths.append(macd_strength.abs())
        
        # Bollinger Bands signals
        if "bbands" in config and "bb_position" in out.columns:
            bb_cfg = config["bbands"]
            bb_position = out["bb_position"]
            
            bb_signal = pd.Series(0, index=out.index)
            bb_signal[bb_position < bb_cfg["oversold"]] = 1
            bb_signal[bb_position > bb_cfg["overbought"]] = -1
            
            bb_strength = pd.Series(0.0, index=out.index)
            bb_strength[bb_position < bb_cfg["oversold"]] = (bb_cfg["oversold"] - bb_position) / bb_cfg["oversold"]
            bb_strength[bb_position > bb_cfg["overbought"]] = (bb_position - bb_cfg["overbought"]) / (1 - bb_cfg["overbought"])
            
            signals.append(bb_signal)
            strengths.append(bb_strength.abs())
        
        # Stochastic signals
        if "stochastic" in config and all(col in out.columns for col in ["stoch_k", "stoch_d"]):
            stoch_cfg = config["stochastic"]
            k = out["stoch_k"]
            d = out["stoch_d"]
            
            stoch_signal = pd.Series(0, index=out.index)
            stoch_signal[(k < stoch_cfg["oversold"]) & (d < stoch_cfg["oversold"]) & (k > d) & (k.shift(1) <= d.shift(1))] = 1
            stoch_signal[(k > stoch_cfg["overbought"]) & (d > stoch_cfg["overbought"]) & (k < d) & (k.shift(1) >= d.shift(1))] = -1
            
            stoch_strength = pd.Series(0.0, index=out.index)
            stoch_strength[(k < stoch_cfg["oversold"])] = (stoch_cfg["oversold"] - k) / stoch_cfg["oversold"]
            stoch_strength[(k > stoch_cfg["overbought"])] = (k - stoch_cfg["overbought"]) / (100 - stoch_cfg["overbought"])
            
            signals.append(stoch_signal)
            strengths.append(stoch_strength.abs())
        
        # Combine signals
        if signals:
            # Weighted average of signals
            combined_signal = pd.concat(signals, axis=1).mean(axis=1)
            combined_strength = pd.concat(strengths, axis=1).mean(axis=1) if strengths else pd.Series(0.0, index=out.index)
            
            # Apply threshold
            signal_threshold = 0.3
            final_signal = pd.Series(0, index=out.index)
            final_signal[combined_signal > signal_threshold] = 1
            final_signal[combined_signal < -signal_threshold] = -1
            
            out["signal"] = final_signal
            out["signal_strength"] = combined_strength
            out["signal_confidence"] = combined_strength.clip(0, 1)
        
        # Volume confirmation
        if config.get("volume_confirmation", True) and "volume" in out.columns:
            volume_avg = out["volume"].rolling(20).mean()
            volume_ratio = out["volume"] / volume_avg.replace(0.0, np.nan)
            
            # Adjust confidence based on volume
            volume_multiplier = np.where(volume_ratio > 1.0, 1.0, volume_ratio)
            out["signal_confidence"] = out["signal_confidence"] * volume_multiplier
        
        # Trend filter
        if config.get("trend_filter", True) and "regime" in out.columns:
            # Filter out signals against strong trend
            trend_filter = ~out["regime"].isin(["trend_up", "trend_down"])
            out.loc[~trend_filter, "signal"] = 0
        
        return out
        
    except Exception as e:
        warnings.warn(f"Signal generation failed: {e}")
        return df


# ============================================================================
# Test Functions
# ============================================================================

def test_indicators():
    """Test indicator calculations."""
    # Create sample data
    np.random.seed(42)
    dates = pd.date_range('2023-01-01', periods=100, freq='D')
    df = pd.DataFrame({
        'open': np.random.randn(100).cumsum() + 100,
        'high': np.random.randn(100).cumsum() + 105,
        'low': np.random.randn(100).cumsum() + 95,
        'close': np.random.randn(100).cumsum() + 100,
        'volume': np.random.randint(1000, 10000, 100)
    }, index=dates)
    
    # Test basic indicators
    print("Testing basic indicators...")
    
    # EMA
    ema_20 = ema(df['close'], 20)
    assert len(ema_20) == len(df), "EMA length mismatch"
    print(f"✓ EMA calculated: {ema_20.iloc[-1]:.2f}")
    
    # RSI
    rsi_14 = rsi(df['close'], 14)
    assert 0 <= rsi_14.iloc[-1] <= 100, "RSI out of range"
    print(f"✓ RSI calculated: {rsi_14.iloc[-1]:.2f}")
    
    # ATR
    atr_14 = atr(df, 14)
    assert atr_14.iloc[-1] >= 0, "ATR negative"
    print(f"✓ ATR calculated: {atr_14.iloc[-1]:.2f}")
    
    # MACD
    macd_line, signal_line, histogram = macd(df['close'])
    assert len(macd_line) == len(df), "MACD length mismatch"
    print(f"✓ MACD calculated: {macd_line.iloc[-1]:.2f}")
    
    # Bollinger Bands
    lower, middle, upper = bbands(df['close'])
    assert (lower <= middle).all() and (middle <= upper).all(), "BBands invalid"
    print(f"✓ Bollinger Bands calculated")
    
    # ADX
    adx_series, plus_di, minus_di = adx(df)
    assert adx_series.iloc[-1] >= 0, "ADX negative"
    print(f"✓ ADX calculated: {adx_series.iloc[-1]:.2f}")
    
    # Regime detection
    regime = regime_score(df)
    assert "regime" in regime, "Regime missing"
    print(f"✓ Regime detected: {regime['regime']}")
    
    # Feature computation
    features = compute_features(df)
    assert len(features.columns) > len(df.columns), "No features added"
    print(f"✓ Features computed: {len(features.columns)} columns")
    
    # Signal generation
    signals = generate_signals(features)
    assert "signal" in signals.columns, "Signal column missing"
    print(f"✓ Signals generated")
    
    print("\n✅ All indicator tests passed!")
    return True


if __name__ == "__main__":
    # Run tests if module is executed directly
    test_passed = test_indicators()
    if test_passed:
        print("\n🎉 Indicator module is working correctly!")
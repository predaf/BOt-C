# app/llm_router.py
from __future__ import annotations

import time
import json
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, List, Tuple, TypedDict, Protocol
from enum import Enum, IntEnum
from abc import ABC, abstractmethod
from collections import OrderedDict, defaultdict
import asyncio
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from functools import wraps


# ============================================================================
# Utility Functions
# ============================================================================

def _now() -> float:
    return time.time()


def _f(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


def _i(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return int(default)


def _b(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    s = str(x).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


def _clamp(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def _norm_symbol(sym: Any) -> str:
    return str(sym or "").strip().upper()


def _safe_get(d: Dict, *keys: str, default: Any = None) -> Any:
    """Safely get nested dictionary values."""
    current = d
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key)
        if current is None:
            return default
    return current


# ============================================================================
# Data Types and Protocols
# ============================================================================

class LogLevel(IntEnum):
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50


class LLMAdvice(TypedDict, total=False):
    allow_entries: bool
    score_mult: float
    risk_mult: float
    sentiment_score: float
    reason: str
    reasons: List[str]
    meta: Dict[str, Any]


class TradeContext(TypedDict, total=False):
    symbol: str
    price: float
    volume_24h: float
    spread_bps: float
    regime: str
    regime_strength: float
    trend: str
    indicators: Dict[str, Any]


class LLMSource(Protocol):
    """Protocol for LLM sources."""
    
    @property
    def enabled(self) -> bool:
        ...
    
    def advise(self, ctx: TradeContext) -> Optional[LLMAdvice]:
        ...


class CacheEntry(TypedDict):
    timestamp: float
    data: Any
    ttl: float


# ============================================================================
# Configuration Classes
# ============================================================================

@dataclass
class LLMSourceConfig:
    """Configuration for an LLM source."""
    enabled: bool = False
    weight: float = 1.0
    timeout_ms: float = 5000.0
    retry_count: int = 2
    retry_delay_ms: float = 100.0
    fail_open: bool = True  # If True, returns neutral on failure


@dataclass
class LLMRouterConfig:
    """Main router configuration."""
    enabled: bool = False
    budget_ms: float = 150.0
    min_score_mult: float = 0.50
    max_score_mult: float = 1.50
    min_risk_mult: float = 0.50
    max_risk_mult: float = 1.50
    sentiment_score_mult: float = 0.15
    sentiment_risk_mult: float = 0.10
    sentiment_veto_threshold: float = 0.85
    return_neutral_when_disabled: bool = False
    include_meta: bool = True
    parallel_execution: bool = True
    
    # Source configurations
    local_config: LLMSourceConfig = field(default_factory=lambda: LLMSourceConfig(enabled=True, weight=1.0))
    ollama_config: LLMSourceConfig = field(default_factory=lambda: LLMSourceConfig(enabled=False, weight=0.5))
    cloud_config: LLMSourceConfig = field(default_factory=lambda: LLMSourceConfig(enabled=False, weight=0.5))
    
    # Cloud-specific
    cloud_cache_ttl_sec: float = 60.0
    cloud_failure_policy: str = "open"  # "open" or "closed"
    
    # Dynamic configuration
    dynamic_weights: bool = False  # Adjust weights based on source reliability
    weight_decay_half_life_sec: float = 3600.0  # How fast to forget past performance


# ============================================================================
# Cache Implementation
# ============================================================================

class TTLCache:
    """Thread-safe TTL cache with size limit."""
    
    def __init__(self, max_size: int = 1000, default_ttl: float = 60.0):
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.max_size = max_size
        self.default_ttl = default_ttl
        self.lock = threading.RLock()
        self.stats = {"hits": 0, "misses": 0, "evictions": 0}
    
    def get(self, key: str) -> Optional[Any]:
        """Get item from cache if not expired."""
        with self.lock:
            if key not in self.cache:
                self.stats["misses"] += 1
                return None
            
            entry = self.cache[key]
            if _now() - entry["timestamp"] > entry["ttl"]:
                del self.cache[key]
                self.stats["misses"] += 1
                return None
            
            self.stats["hits"] += 1
            # Move to end (most recently used)
            self.cache.move_to_end(key)
            return entry["data"]
    
    def set(self, key: str, data: Any, ttl: Optional[float] = None):
        """Set item in cache with TTL."""
        with self.lock:
            self.cache[key] = {
                "timestamp": _now(),
                "data": data,
                "ttl": ttl or self.default_ttl
            }
            
            # Evict if over size limit
            if len(self.cache) > self.max_size:
                self.cache.popitem(last=False)
                self.stats["evictions"] += 1
    
    def clear(self):
        """Clear all cache entries."""
        with self.lock:
            self.cache.clear()
    
    def cleanup(self):
        """Remove expired entries."""
        with self.lock:
            now = _now()
            expired_keys = [
                key for key, entry in self.cache.items()
                if now - entry["timestamp"] > entry["ttl"]
            ]
            for key in expired_keys:
                del self.cache[key]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.lock:
            total = self.stats["hits"] + self.stats["misses"]
            hit_rate = self.stats["hits"] / total if total > 0 else 0.0
            return {
                **self.stats,
                "hit_rate": hit_rate,
                "size": len(self.cache),
                "max_size": self.max_size
            }


# ============================================================================
# Source Reliability Tracker
# ============================================================================

class SourceReliabilityTracker:
    """Tracks reliability of LLM sources for dynamic weighting."""
    
    def __init__(self, half_life_sec: float = 3600.0):
        self.half_life_sec = half_life_sec
        self.trackers: Dict[str, List[Tuple[float, bool]]] = {}  # source -> [(timestamp, success), ...]
        self.lock = threading.RLock()
    
    def record(self, source: str, success: bool):
        """Record a success or failure for a source."""
        with self.lock:
            if source not in self.trackers:
                self.trackers[source] = []
            self.trackers[source].append((_now(), success))
    
    def get_reliability(self, source: str, window_sec: float = 3600.0) -> float:
        """Get reliability score (0-1) for a source within time window."""
        with self.lock:
            if source not in self.trackers:
                return 0.5  # Neutral default
            
            now = _now()
            cutoff = now - window_sec
            events = [(t, s) for t, s in self.trackers[source] if t > cutoff]
            
            if not events:
                return 0.5
            
            # Apply exponential decay to older events
            total_weight = 0.0
            weighted_successes = 0.0
            
            for timestamp, success in events:
                age = now - timestamp
                # Exponential decay weight
                weight = 2 ** (-age / self.half_life_sec)
                total_weight += weight
                weighted_successes += weight if success else 0.0
            
            reliability = weighted_successes / total_weight if total_weight > 0 else 0.0
            return reliability
    
    def cleanup(self, max_age_sec: float = 86400.0):
        """Remove old events."""
        with self.lock:
            now = _now()
            cutoff = now - max_age_sec
            for source in list(self.trackers.keys()):
                self.trackers[source] = [
                    (t, s) for t, s in self.trackers[source] if t > cutoff
                ]
                if not self.trackers[source]:
                    del self.trackers[source]


# ============================================================================
# Structured Logger
# ============================================================================

class StructuredLogger:
    """Structured logging with levels."""
    
    def __init__(self, min_level: LogLevel = LogLevel.INFO, log_callback=None):
        self.min_level = min_level
        self.log_callback = log_callback
        self.metrics: Dict[str, Any] = defaultdict(float)
    
    def log(self, level: LogLevel, event: str, data: Dict[str, Any], symbol: str = None):
        """Log a structured event."""
        if level < self.min_level:
            return
        
        log_entry = {
            "timestamp": _now(),
            "level": level.name,
            "event": event,
            "symbol": symbol,
            "data": data,
            "source": "llm_router"
        }
        
        # Call callback if provided
        if self.log_callback:
            try:
                self.log_callback(log_entry)
            except Exception:
                pass
        
        # Also print to console in development
        if level >= LogLevel.WARNING:
            print(json.dumps(log_entry, default=str))
    
    def record_metric(self, name: str, value: float):
        """Record a performance metric."""
        self.metrics[name] = value
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get all recorded metrics."""
        return dict(self.metrics)


# ============================================================================
# LLM Router Implementation
# ============================================================================

@dataclass
class LLMRouter:
    """Combines local regime/veto + optional Ollama + optional cloud news/sentiment.
    
    Features:
    - Parallel execution of sources
    - Dynamic weighting based on reliability
    - Comprehensive caching
    - Graceful degradation
    - Detailed metrics and logging
    """
    
    # Configuration
    config: LLMRouterConfig
    logger: StructuredLogger
    
    # Sources (injected dependencies)
    local_source: Optional[LLMSource] = None
    ollama_source: Optional[LLMSource] = None
    cloud_source: Optional[LLMSource] = None
    
    # Internal state
    _cache: TTLCache = field(init=False)
    _reliability_tracker: SourceReliabilityTracker = field(init=False)
    _executor: ThreadPoolExecutor = field(init=False)
    _metrics: Dict[str, Any] = field(init=False, default_factory=dict)
    
    def __post_init__(self):
        # Initialize components
        self._cache = TTLCache(default_ttl=self.config.cloud_cache_ttl_sec)
        self._reliability_tracker = SourceReliabilityTracker(
            half_life_sec=self.config.weight_decay_half_life_sec
        )
        self._executor = ThreadPoolExecutor(max_workers=3)
        
        # Initialize metrics
        self._metrics = {
            "total_requests": 0,
            "vetos": 0,
            "timeouts": 0,
            "errors": 0,
            "avg_processing_time_ms": 0.0,
            "cache_hit_rate": 0.0,
        }
    
    # --------------------
    # Public Methods
    # --------------------
    
    def advise_trade(self, ctx: TradeContext, df=None, df_trend=None) -> Optional[LLMAdvice]:
        """Main entry point for trade advice."""
        start_time = _now()
        self._metrics["total_requests"] += 1
        
        try:
            # Check if router is enabled
            if not self._should_process():
                return self._neutral("llm_disabled") if self.config.return_neutral_when_disabled else None
            
            # Generate cache key
            cache_key = self._generate_cache_key(ctx)
            cached_result = self._cache.get(cache_key)
            if cached_result:
                self.logger.log(LogLevel.DEBUG, "cache_hit", {"key": cache_key}, ctx.get("symbol"))
                return cached_result
            
            # Execute advice logic
            result = self._execute_advice_logic(ctx)
            
            # Cache the result
            self._cache.set(cache_key, result)
            
            # Update metrics
            processing_time = (_now() - start_time) * 1000.0
            self._update_metrics(processing_time)
            
            return result
            
        except Exception as e:
            self._metrics["errors"] += 1
            self.logger.log(LogLevel.ERROR, "advise_error", {
                "error": str(e),
                "symbol": ctx.get("symbol")
            })
            
            # Fallback to neutral advice
            return self._neutral(f"error: {type(e).__name__}")
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get router metrics."""
        cache_stats = self._cache.get_stats()
        return {
            **self._metrics,
            "cache": cache_stats,
            "reliability": {
                source: self._reliability_tracker.get_reliability(source)
                for source in ["local", "ollama", "cloud"]
                if source in self._reliability_tracker.trackers
            }
        }
    
    def update_config(self, new_config: LLMRouterConfig):
        """Update configuration dynamically."""
        self.config = new_config
        self._cache.default_ttl = new_config.cloud_cache_ttl_sec
        self.logger.log(LogLevel.INFO, "config_updated", {"config": new_config.__dict__})
    
    def clear_cache(self):
        """Clear all caches."""
        self._cache.clear()
        self.logger.log(LogLevel.INFO, "cache_cleared", {})
    
    def cleanup(self):
        """Cleanup expired entries and old reliability data."""
        self._cache.cleanup()
        self._reliability_tracker.cleanup()
    
    # --------------------
    # Private Methods
    # --------------------
    
    def _should_process(self) -> bool:
        """Determine if router should process the request."""
        if not self.config.enabled:
            return False
        
        # Check if any source is enabled
        sources_enabled = [
            self.local_source and self.local_source.enabled,
            self.ollama_source and self.ollama_source.enabled,
            self.cloud_source and self.cloud_source.enabled,
        ]
        
        return any(sources_enabled)
    
    def _generate_cache_key(self, ctx: TradeContext) -> str:
        """Generate cache key from context."""
        symbol = ctx.get("symbol", "")
        regime = ctx.get("regime", "")
        strength = ctx.get("regime_strength", 0.0)
        return f"{symbol}_{regime}_{strength:.2f}"
    
    def _execute_advice_logic(self, ctx: TradeContext) -> LLMAdvice:
        """Execute the advice logic with parallel sources if configured."""
        start_time = _now()
        symbol = ctx.get("symbol", "")
        
        # Collect enabled sources
        sources = []
        if self.local_source and self.local_source.enabled:
            sources.append(("local", self.local_source, self.config.local_config))
        if self.ollama_source and self.ollama_source.enabled:
            sources.append(("ollama", self.ollama_source, self.config.ollama_config))
        if self.cloud_source and self.cloud_source.enabled:
            sources.append(("cloud", self.cloud_source, self.config.cloud_config))
        
        if not sources:
            return self._neutral("no_sources_enabled")
        
        # Execute sources
        results = {}
        errors = {}
        timings = {}
        
        if self.config.parallel_execution and len(sources) > 1:
            results, errors, timings = self._execute_parallel(sources, ctx)
        else:
            results, errors, timings = self._execute_sequential(sources, ctx)
        
        # Process results
        return self._aggregate_results(results, errors, timings, ctx, start_time)
    
    def _execute_parallel(self, sources: List[Tuple[str, LLMSource, LLMSourceConfig]], 
                         ctx: TradeContext) -> Tuple[Dict, Dict, Dict]:
        """Execute sources in parallel."""
        results = {}
        errors = {}
        timings = {}
        
        # Prepare futures
        futures = {}
        for name, source, config in sources:
            future = self._executor.submit(self._execute_source_with_timeout, name, source, ctx, config)
            futures[name] = future
        
        # Collect results
        for name, future in futures.items():
            try:
                result, timing, error = future.result(timeout=self.config.budget_ms / 1000.0)
                timings[name] = timing
                if error:
                    errors[name] = error
                elif result:
                    results[name] = result
            except TimeoutError:
                errors[name] = "timeout"
                timings[name] = self.config.budget_ms
            except Exception as e:
                errors[name] = str(e)
                timings[name] = 0.0
        
        return results, errors, timings
    
    def _execute_sequential(self, sources: List[Tuple[str, LLMSource, LLMSourceConfig]],
                          ctx: TradeContext) -> Tuple[Dict, Dict, Dict]:
        """Execute sources sequentially."""
        results = {}
        errors = {}
        timings = {}
        
        for name, source, config in sources:
            start_time = _now()
            try:
                result = self._execute_source_with_timeout_sync(name, source, ctx, config)
                timings[name] = (_now() - start_time) * 1000.0
                if result:
                    results[name] = result
            except Exception as e:
                errors[name] = str(e)
                timings[name] = (_now() - start_time) * 1000.0
        
        return results, errors, timings
    
    def _execute_source_with_timeout(self, name: str, source: LLMSource, 
                                   ctx: TradeContext, config: LLMSourceConfig) -> Tuple[Optional[LLMAdvice], float, Optional[str]]:
        """Execute a source with timeout and retries."""
        start_time = _now()
        last_error = None
        
        for attempt in range(config.retry_count):
            try:
                # Execute with timeout
                result = asyncio.run(self._async_timeout(
                    source.advise(ctx),
                    timeout=config.timeout_ms / 1000.0
                ))
                
                # Record success
                self._reliability_tracker.record(name, True)
                
                return result, (_now() - start_time) * 1000.0, None
                
            except Exception as e:
                last_error = str(e)
                if attempt < config.retry_count - 1:
                    time.sleep(config.retry_delay_ms / 1000.0)
        
        # Record failure
        self._reliability_tracker.record(name, False)
        return None, (_now() - start_time) * 1000.0, last_error
    
    def _execute_source_with_timeout_sync(self, name: str, source: LLMSource,
                                        ctx: TradeContext, config: LLMSourceConfig) -> Optional[LLMAdvice]:
        """Synchronous version for sequential execution."""
        for attempt in range(config.retry_count):
            try:
                result = source.advise(ctx)
                self._reliability_tracker.record(name, True)
                return result
            except Exception:
                if attempt < config.retry_count - 1:
                    time.sleep(config.retry_delay_ms / 1000.0)
        
        self._reliability_tracker.record(name, False)
        return None
    
    async def _async_timeout(self, coro, timeout: float):
        """Run a coroutine with timeout."""
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            raise TimeoutError(f"Operation timed out after {timeout}s")
    
    def _aggregate_results(self, results: Dict[str, LLMAdvice], errors: Dict[str, str],
                          timings: Dict[str, float], ctx: TradeContext, start_time: float) -> LLMAdvice:
        """Aggregate results from multiple sources."""
        symbol = ctx.get("symbol", "")
        
        # Check for hard vetos
        for source_name, result in results.items():
            if result and not result.get("allow_entries", True):
                self._metrics["vetos"] += 1
                self.logger.log(LogLevel.INFO, "hard_veto", {
                    "source": source_name,
                    "reason": result.get("reason", "unknown")
                }, symbol)
                return result
        
        # Aggregate scores with dynamic weights
        agg_result = self._neutral("aggregated")
        agg_result["score_mult"] = 1.0
        agg_result["risk_mult"] = 1.0
        agg_result["sentiment_score"] = 0.0
        
        all_reasons = []
        sentiment_scores = []
        
        for source_name, result in results.items():
            if not result:
                continue
            
            # Get weight
            if self.config.dynamic_weights:
                reliability = self._reliability_tracker.get_reliability(source_name)
                weight = reliability
            else:
                weight = getattr(self.config, f"{source_name}_config").weight
            
            # Aggregate scores
            if "score_mult" in result:
                agg_result["score_mult"] *= (result["score_mult"] ** weight)
            
            if "risk_mult" in result:
                agg_result["risk_mult"] *= (result["risk_mult"] ** weight)
            
            if "sentiment_score" in result:
                sentiment_scores.append((result["sentiment_score"], weight))
            
            # Collect reasons
            if "reasons" in result:
                all_reasons.extend(result["reasons"])
        
        # Calculate weighted sentiment
        if sentiment_scores:
            total_weight = sum(w for _, w in sentiment_scores)
            if total_weight > 0:
                weighted_sentiment = sum(s * w for s, w in sentiment_scores) / total_weight
                agg_result["sentiment_score"] = _clamp(weighted_sentiment, -1.0, 1.0)
        
        # Apply sentiment scaling
        sentiment = agg_result["sentiment_score"]
        agg_result["score_mult"] *= (1.0 + sentiment * self.config.sentiment_score_mult)
        agg_result["risk_mult"] *= (1.0 + sentiment * self.config.sentiment_risk_mult)
        
        # Check sentiment veto
        if abs(sentiment) >= self.config.sentiment_veto_threshold and sentiment < 0:
            agg_result["allow_entries"] = False
            agg_result["reason"] = "sentiment_veto"
            all_reasons.append("sentiment_extreme_negative")
            self._metrics["vetos"] += 1
        
        # Apply clamps
        agg_result["score_mult"] = _clamp(
            agg_result["score_mult"],
            self.config.min_score_mult,
            self.config.max_score_mult
        )
        agg_result["risk_mult"] = _clamp(
            agg_result["risk_mult"],
            self.config.min_risk_mult,
            self.config.max_risk_mult
        )
        
        # Set reasons
        agg_result["reasons"] = list(set(all_reasons))[:10]  # Deduplicate and limit
        
        # Add metadata if requested
        if self.config.include_meta:
            agg_result["meta"] = {
                "symbol": symbol,
                "sources_used": list(results.keys()),
                "errors": errors,
                "timings_ms": timings,
                "processing_time_ms": (_now() - start_time) * 1000.0,
                "weights": {
                    name: self._reliability_tracker.get_reliability(name) 
                    if self.config.dynamic_weights else 
                    getattr(self.config, f"{name}_config").weight
                    for name in results.keys()
                }
            }
        
        # Log the result
        self.logger.log(LogLevel.INFO, "advice_generated", {
            "allow_entries": agg_result["allow_entries"],
            "score_mult": agg_result["score_mult"],
            "risk_mult": agg_result["risk_mult"],
            "sentiment_score": agg_result["sentiment_score"],
            "reason": agg_result["reason"],
            "sources_count": len(results)
        }, symbol)
        
        return agg_result
    
    def _neutral(self, reason: str = "neutral") -> LLMAdvice:
        """Return neutral advice."""
        result: LLMAdvice = {
            "allow_entries": True,
            "score_mult": 1.0,
            "risk_mult": 1.0,
            "sentiment_score": 0.0,
            "reason": reason,
            "reasons": [],
        }
        
        if self.config.include_meta:
            result["meta"] = {}
        
        return result
    
    def _update_metrics(self, processing_time: float):
        """Update performance metrics."""
        # Update average processing time (exponential moving average)
        alpha = 0.1  # Smoothing factor
        old_avg = self._metrics["avg_processing_time_ms"]
        self._metrics["avg_processing_time_ms"] = (
            alpha * processing_time + (1 - alpha) * old_avg
        )
        
        # Update cache hit rate
        cache_stats = self._cache.get_stats()
        self._metrics["cache_hit_rate"] = cache_stats.get("hit_rate", 0.0)


# ============================================================================
# Factory Functions for Backward Compatibility
# ============================================================================

def from_cfg(cfg: Dict[str, Any], log: Any = None) -> LLMRouter:
    """Factory function for backward compatibility with original code."""
    
    # Parse configuration
    llm_cfg = _safe_get(cfg, "llm") or {}
    
    router_config = LLMRouterConfig(
        enabled=_b(llm_cfg.get("enabled"), False),
        budget_ms=_f(llm_cfg.get("budget_ms"), 150.0),
        min_score_mult=_f(llm_cfg.get("min_score_mult"), 0.50),
        max_score_mult=_f(llm_cfg.get("max_score_mult"), 1.50),
        min_risk_mult=_f(llm_cfg.get("min_risk_mult"), 0.50),
        max_risk_mult=_f(llm_cfg.get("max_risk_mult"), 1.50),
        sentiment_score_mult=_f(llm_cfg.get("sentiment_score_mult"), 0.15),
        sentiment_risk_mult=_f(llm_cfg.get("sentiment_risk_mult"), 0.10),
        sentiment_veto_threshold=_f(llm_cfg.get("sentiment_veto_threshold"), 0.85),
        return_neutral_when_disabled=_b(llm_cfg.get("return_neutral_when_disabled"), False),
        include_meta=_b(llm_cfg.get("include_meta"), True),
        parallel_execution=_b(llm_cfg.get("parallel_execution"), True),
        cloud_cache_ttl_sec=_f(llm_cfg.get("cloud_cache_ttl_sec"), 60.0),
        cloud_failure_policy=str(llm_cfg.get("cloud_failure_policy", "open")).lower(),
        dynamic_weights=_b(llm_cfg.get("dynamic_weights"), False),
        weight_decay_half_life_sec=_f(llm_cfg.get("weight_decay_half_life_sec"), 3600.0),
        
        local_config=LLMSourceConfig(
            enabled=_b(llm_cfg.get("local_enabled"), True),
            weight=_f(llm_cfg.get("w_local"), 1.0),
            timeout_ms=_f(llm_cfg.get("local_timeout_ms"), 5000.0),
        ),
        
        ollama_config=LLMSourceConfig(
            enabled=_b(llm_cfg.get("ollama_enabled"), False),
            weight=_f(llm_cfg.get("w_ollama"), 0.5),
            timeout_ms=_f(llm_cfg.get("ollama_timeout_ms"), 10000.0),
        ),
        
        cloud_config=LLMSourceConfig(
            enabled=_b(llm_cfg.get("cloud_enabled"), False),
            weight=_f(llm_cfg.get("w_cloud"), 0.5),
            timeout_ms=_f(llm_cfg.get("cloud_timeout_ms"), 3000.0),
        )
    )
    
    # Create logger
    logger = StructuredLogger(
        min_level=LogLevel.INFO,
        log_callback=log
    )
    
    # Import sources (deferred to avoid circular imports)
    from .llm_local import from_cfg as local_from_cfg
    from .llm_ollama import from_cfg as ollama_from_cfg
    from .llm_cloud import from_cfg as cloud_from_cfg
    
    # Create router
    router = LLMRouter(
        config=router_config,
        logger=logger,
        local_source=local_from_cfg(cfg),
        ollama_source=ollama_from_cfg(cfg),
        cloud_source=cloud_from_cfg(cfg)
    )
    
    return router


# ============================================================================
# Test Functions
# ============================================================================

def test_llm_router():
    """Test the LLM router."""
    
    # Mock sources for testing
    class MockSource:
        def __init__(self, name: str, enabled: bool = True):
            self.name = name
            self._enabled = enabled
        
        @property
        def enabled(self) -> bool:
            return self._enabled
        
        def advise(self, ctx: TradeContext) -> LLMAdvice:
            return {
                "allow_entries": True,
                "score_mult": 1.0,
                "risk_mult": 1.0,
                "sentiment_score": 0.0,
                "reason": f"{self.name}_ok",
                "reasons": [f"reason_from_{self.name}"],
            }
    
    # Create router with mock sources
    config = LLMRouterConfig(
        enabled=True,
        parallel_execution=True,
        include_meta=True
    )
    
    logger = StructuredLogger(min_level=LogLevel.DEBUG)
    
    router = LLMRouter(
        config=config,
        logger=logger,
        local_source=MockSource("local", enabled=True),
        ollama_source=MockSource("ollama", enabled=False),
        cloud_source=MockSource("cloud", enabled=True)
    )
    
    # Test context
    ctx: TradeContext = {
        "symbol": "BTCUSDT",
        "price": 50000.0,
        "regime": "trend_up",
        "regime_strength": 0.8
    }
    
    # Get advice
    advice = router.advise_trade(ctx)
    
    assert advice is not None
    assert advice["allow_entries"] == True
    assert "score_mult" in advice
    assert "risk_mult" in advice
    assert "meta" in advice
    
    print("✅ LLM Router test passed!")
    print(f"Advice: {json.dumps(advice, indent=2, default=str)}")
    
    # Test metrics
    metrics = router.get_metrics()
    print(f"Metrics: {json.dumps(metrics, indent=2)}")
    
    return True


if __name__ == "__main__":
    # Run tests if module is executed directly
    test_passed = test_llm_router()
    if test_passed:
        print("\n🎉 All tests passed!")
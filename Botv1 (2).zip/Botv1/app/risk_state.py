from __future__ import annotations

import time
import json
import threading
import traceback
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Optional, Tuple, List, Union, Callable
from enum import Enum
from datetime import datetime, timedelta
import statistics


def _now() -> float:
    return time.time()


def _f(x: Any, d: float = 0.0) -> float:
    """Safely convert to float."""
    try:
        return float(x)
    except Exception:
        return float(d)


def _i(x: Any, d: int = 0) -> int:
    """Safely convert to integer."""
    try:
        return int(x)
    except Exception:
        return int(d)


def _as_bool(x: Any, default: bool = False) -> bool:
    """Safely convert to boolean."""
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    s = str(x).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


class RiskLevel(Enum):
    """Risk levels with severity scores."""
    NORMAL = (0, "Normal operation")
    CAUTION = (1, "Elevated risk, reduced positions")
    RISK_OFF = (2, "No new entries, manage existing")
    HALT = (3, "Emergency halt, exit all positions")
    
    def __init__(self, severity: int, description: str):
        self.severity = severity
        self.description = description


class RiskFactor:
    """Individual risk factor with scoring."""
    
    def __init__(
        self,
        name: str,
        value: float,
        threshold: float,
        weight: float = 1.0,
        direction: str = "above",  # "above" or "below"
        details: Optional[Dict[str, Any]] = None
    ):
        self.name = name
        self.value = value
        self.threshold = threshold
        self.weight = weight
        self.direction = direction
        self.details = details or {}
        self.timestamp = _now()
    
    def is_triggered(self) -> bool:
        """Check if factor is triggered."""
        if self.direction == "above":
            return self.value >= self.threshold
        else:
            return self.value <= self.threshold
    
    def get_score(self) -> float:
        """Calculate risk score for this factor."""
        if not self.is_triggered():
            return 0.0
        
        if self.direction == "above":
            excess = (self.value - self.threshold) / max(1.0, self.threshold)
        else:
            excess = (self.threshold - self.value) / max(1.0, self.threshold)
        
        return min(1.0, excess) * self.weight
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "value": self.value,
            "threshold": self.threshold,
            "weight": self.weight,
            "direction": self.direction,
            "is_triggered": self.is_triggered(),
            "score": self.get_score(),
            "timestamp": self.timestamp,
            "details": self.details,
        }


@dataclass
class RiskState:
    """Complete risk state snapshot."""
    state: str = "NORMAL"          # NORMAL / CAUTION / RISK_OFF / HALT
    reason: str = "All checks passed"
    controller: str = "risk_state"
    risk_score: float = 0.0        # 0.0 to 1.0
    
    # Outputs used by engine
    risk_mult: float = 1.0         # Multiplies entry risk
    max_position_size: float = 1.0  # Maximum position size multiplier
    allow_entries: bool = True
    allow_adds: bool = True
    allow_exits: bool = True
    halt: bool = False
    
    # Factors contributing to current state
    factors: List[Dict[str, Any]] = field(default_factory=list)
    active_triggers: List[str] = field(default_factory=list)
    
    # Metadata
    timestamp: float = 0.0
    duration_seconds: float = 0.0  # How long in this state
    transitions: int = 0           # Number of state transitions
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        d = asdict(self)
        d["state_severity"] = RiskLevel[self.state].severity if hasattr(RiskLevel, self.state) else 0
        d["state_description"] = RiskLevel[self.state].description if hasattr(RiskLevel, self.state) else ""
        return d
    
    def is_safe_for_entry(self) -> bool:
        """Check if safe to enter new positions."""
        return self.allow_entries and not self.halt and self.risk_mult > 0
    
    def is_safe_for_addition(self) -> bool:
        """Check if safe to add to existing positions."""
        return self.allow_adds and not self.halt and self.risk_mult > 0


class RiskStateHistory:
    """Maintains history of risk state changes."""
    
    def __init__(self, max_entries: int = 1000):
        self.max_entries = max_entries
        self.history: List[RiskState] = []
        self._lock = threading.Lock()
    
    def add(self, state: RiskState) -> None:
        """Add state to history."""
        with self._lock:
            self.history.append(state)
            if len(self.history) > self.max_entries:
                self.history = self.history[-self.max_entries:]
    
    def get_last(self, count: int = 1) -> List[RiskState]:
        """Get last N states."""
        with self._lock:
            return self.history[-min(count, len(self.history)):]
    
    def get_by_time(self, seconds: float) -> List[RiskState]:
        """Get states from the last N seconds."""
        cutoff = _now() - seconds
        with self._lock:
            return [s for s in self.history if s.timestamp >= cutoff]
    
    def get_transitions(self) -> List[Dict[str, Any]]:
        """Get all state transitions."""
        transitions = []
        with self._lock:
            for i, state in enumerate(self.history):
                if i == 0:
                    transitions.append({
                        "from": None,
                        "to": state.state,
                        "timestamp": state.timestamp,
                        "reason": state.reason,
                    })
                elif state.state != self.history[i-1].state:
                    transitions.append({
                        "from": self.history[i-1].state,
                        "to": state.state,
                        "timestamp": state.timestamp,
                        "reason": state.reason,
                    })
        return transitions
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about risk states."""
        with self._lock:
            if not self.history:
                return {}
            
            durations = []
            state_counts = {}
            
            for i, state in enumerate(self.history):
                # Count states
                state_counts[state.state] = state_counts.get(state.state, 0) + 1
                
                # Calculate durations
                if i > 0:
                    duration = state.timestamp - self.history[i-1].timestamp
                    durations.append(duration)
            
            total_time = sum(durations) if durations else 0
            
            return {
                "total_states": len(self.history),
                "state_counts": state_counts,
                "avg_state_duration": statistics.mean(durations) if durations else 0,
                "total_time_seconds": total_time,
                "transitions": len(self.get_transitions()),
            }


class RiskSource:
    """Base class for risk sources."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.enabled = config.get("enabled", True)
        self.weight = config.get("weight", 1.0)
        self.last_check = 0.0
        self.check_interval = config.get("check_interval", 60.0)
        
    def should_check(self) -> bool:
        """Check if it's time to evaluate this source."""
        return self.enabled and (_now() - self.last_check) >= self.check_interval
    
    def evaluate(self, engine: Any) -> Optional[RiskFactor]:
        """Evaluate risk and return factor if triggered."""
        raise NotImplementedError("Subclasses must implement evaluate()")
    
    def reset(self) -> None:
        """Reset internal state."""
        self.last_check = 0.0


class DrawdownRiskSource(RiskSource):
    """Drawdown-based risk source."""
    
    def evaluate(self, engine: Any) -> Optional[RiskFactor]:
        try:
            self.last_check = _now()
            
            eq = _f(getattr(engine, "equity", None), 0.0)
            peak = _f(getattr(engine, "peak_equity", None), 0.0)
            day_start = _f(getattr(engine, "day_start_equity", None), 0.0)
            
            if eq <= 0 or peak <= 0:
                return None
            
            # Calculate various drawdowns
            dd_from_peak = (peak - eq) / peak if peak > 0 else 0.0
            dd_from_day = (day_start - eq) / day_start if day_start > 0 else 0.0
            
            # Get thresholds
            caution_threshold = self.config.get("dd_caution", 0.05)
            risk_off_threshold = self.config.get("dd_riskoff", 0.10)
            halt_threshold = self.config.get("dd_halt", 0.20)
            
            # Determine which threshold is breached
            if dd_from_peak >= halt_threshold:
                threshold = halt_threshold
                direction = "above"
            elif dd_from_peak >= risk_off_threshold:
                threshold = risk_off_threshold
                direction = "above"
            elif dd_from_peak >= caution_threshold:
                threshold = caution_threshold
                direction = "above"
            else:
                return None
            
            return RiskFactor(
                name=f"drawdown_{self.name}",
                value=dd_from_peak,
                threshold=threshold,
                weight=self.weight,
                direction=direction,
                details={
                    "equity": eq,
                    "peak_equity": peak,
                    "day_start_equity": day_start,
                    "dd_from_peak": dd_from_peak,
                    "dd_from_day": dd_from_day,
                    "caution_threshold": caution_threshold,
                    "risk_off_threshold": risk_off_threshold,
                    "halt_threshold": halt_threshold,
                }
            )
        except Exception as e:
            return None


class MarketGuardRiskSource(RiskSource):
    """MarketGuard integration risk source."""
    
    def evaluate(self, engine: Any) -> Optional[RiskFactor]:
        try:
            self.last_check = _now()
            
            mg = getattr(engine, "market_guard", None)
            if not mg or not hasattr(mg, "status"):
                return None
            
            mgs = mg.status()
            if not isinstance(mgs, dict):
                return None
            
            # Check for halt condition
            if mgs.get("halt", False):
                return RiskFactor(
                    name="market_guard_halt",
                    value=1.0,
                    threshold=0.5,
                    weight=self.weight,
                    direction="above",
                    details=mgs
                )
            
            # Check for risk off condition
            if mgs.get("risk_off", False):
                return RiskFactor(
                    name="market_guard_risk_off",
                    value=1.0,
                    threshold=0.5,
                    weight=self.weight,
                    direction="above",
                    details=mgs
                )
            
            # Check for caution condition
            if mgs.get("caution", False):
                return RiskFactor(
                    name="market_guard_caution",
                    value=1.0,
                    threshold=0.5,
                    weight=self.weight,
                    direction="above",
                    details=mgs
                )
            
            return None
        except Exception:
            return None


class ErrorRateRiskSource(RiskSource):
    """Error rate monitoring risk source."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.error_counts = []
        self.max_window = config.get("error_window", 100)
        self.error_threshold = config.get("error_threshold", 0.1)
        
    def evaluate(self, engine: Any) -> Optional[RiskFactor]:
        try:
            self.last_check = _now()
            
            # Get recent errors from engine
            error_history = getattr(engine, "error_history", [])
            if not error_history:
                return None
            
            # Calculate error rate
            window = min(self.max_window, len(error_history))
            recent_errors = error_history[-window:]
            error_rate = sum(1 for e in recent_errors if e) / window
            
            if error_rate >= self.error_threshold:
                return RiskFactor(
                    name="error_rate",
                    value=error_rate,
                    threshold=self.error_threshold,
                    weight=self.weight,
                    direction="above",
                    details={
                        "error_rate": error_rate,
                        "window_size": window,
                        "threshold": self.error_threshold,
                        "recent_errors": recent_errors[-10:],  # Last 10 errors
                    }
                )
            
            return None
        except Exception:
            return None


class VolatilityRiskSource(RiskSource):
    """Market volatility risk source."""
    
    def evaluate(self, engine: Any) -> Optional[RiskFactor]:
        try:
            self.last_check = _now()
            
            # Get volatility metrics from engine or calculate
            volatility = getattr(engine, "current_volatility", None)
            if volatility is None:
                return None
            
            threshold = self.config.get("volatility_threshold", 0.02)
            
            if volatility >= threshold:
                return RiskFactor(
                    name="volatility",
                    value=volatility,
                    threshold=threshold,
                    weight=self.weight,
                    direction="above",
                    details={
                        "volatility": volatility,
                        "threshold": threshold,
                        "source": "engine.current_volatility",
                    }
                )
            
            return None
        except Exception:
            return None


class CustomRiskSource(RiskSource):
    """Custom risk source with user-defined check function."""
    
    def __init__(self, name: str, config: Dict[str, Any], check_func: Callable[[Any], Optional[RiskFactor]]):
        super().__init__(name, config)
        self.check_func = check_func
        
    def evaluate(self, engine: Any) -> Optional[RiskFactor]:
        try:
            self.last_check = _now()
            return self.check_func(engine)
        except Exception:
            return None


class RiskStateOrchestrator:
    """Advanced risk state management with multiple sources and state machine.

    Features:
      - Multiple configurable risk sources
      - Weighted risk scoring
      - State history and statistics
      - Smooth state transitions
      - Custom risk sources
      - Persistence
    """

    def __init__(self, cfg: Dict[str, Any], log: Any = None):
        self.cfg = cfg or {}
        self.log = log
        self._lock = threading.Lock()
        
        # Current state
        self._current: RiskState = RiskState(timestamp=_now())
        self._previous: Optional[RiskState] = None
        
        # History tracking
        self.history = RiskStateHistory(
            max_entries=self._config().get("history_size", 1000)
        )
        
        # Risk sources
        self.risk_sources: Dict[str, RiskSource] = {}
        self._initialize_risk_sources()
        
        # State machine configuration
        self._state_config = self._config().get("state_thresholds", {
            "caution": 0.3,
            "risk_off": 0.6,
            "halt": 0.9,
        })
        
        # Performance metrics
        self.metrics = {
            "checks_performed": 0,
            "state_changes": 0,
            "last_check_duration": 0.0,
            "avg_check_duration": 0.0,
        }
        
        # Persistence
        self.persistence_enabled = self._config().get("persistence", {}).get("enabled", False)
        self.persistence_path = self._config().get("persistence", {}).get("path", "risk_state.json")
        
        # Load persisted state if available
        self._load_state()
        
        self._emit("info", f"RiskStateOrchestrator initialized with {len(self.risk_sources)} risk sources")

    def _config(self) -> Dict[str, Any]:
        return self.cfg.get("risk_state") or {}

    def _emit(self, level: str, msg: str, **kwargs) -> None:
        """Emit log message with optional details."""
        try:
            if self.log is None:
                return
            
            # Format message with kwargs
            if kwargs:
                details = " ".join(f"{k}={v}" for k, v in kwargs.items())
                msg = f"{msg} | {details}"
            
            log_func = getattr(self.log, level, None)
            if callable(log_func):
                log_func(msg)
            else:
                print(msg)
        except Exception:
            pass

    def _initialize_risk_sources(self) -> None:
        """Initialize configured risk sources."""
        config = self._config()
        sources_config = config.get("sources", {})
        
        # Drawdown source
        if sources_config.get("drawdown", {}).get("enabled", True):
            self.risk_sources["drawdown"] = DrawdownRiskSource(
                "drawdown",
                sources_config.get("drawdown", {})
            )
        
        # MarketGuard source
        if sources_config.get("market_guard", {}).get("enabled", True):
            self.risk_sources["market_guard"] = MarketGuardRiskSource(
                "market_guard",
                sources_config.get("market_guard", {})
            )
        
        # Error rate source
        if sources_config.get("error_rate", {}).get("enabled", False):
            self.risk_sources["error_rate"] = ErrorRateRiskSource(
                "error_rate",
                sources_config.get("error_rate", {})
            )
        
        # Volatility source
        if sources_config.get("volatility", {}).get("enabled", False):
            self.risk_sources["volatility"] = VolatilityRiskSource(
                "volatility",
                sources_config.get("volatility", {})
            )
        
        # Add custom sources from config
        custom_sources = sources_config.get("custom", {})
        for name, source_cfg in custom_sources.items():
            if source_cfg.get("enabled", False):
                # Custom sources would need a function - this is a placeholder
                # In practice, you'd register these differently
                pass

    def add_custom_source(self, name: str, source: RiskSource) -> None:
        """Add a custom risk source."""
        with self._lock:
            self.risk_sources[name] = source
            self._emit("info", f"Added custom risk source: {name}")

    def remove_source(self, name: str) -> bool:
        """Remove a risk source."""
        with self._lock:
            if name in self.risk_sources:
                del self.risk_sources[name]
                self._emit("info", f"Removed risk source: {name}")
                return True
            return False

    # ----------------------
    # Main API
    # ----------------------
    def update(self, engine: Any) -> Dict[str, Any]:
        """Compute current risk gate state."""
        start_time = _now()
        
        with self._lock:
            try:
                # Update performance metrics
                self.metrics["checks_performed"] += 1
                
                # Collect risk factors from all sources
                risk_factors = self._collect_risk_factors(engine)
                
                # Calculate overall risk score
                risk_score = self._calculate_risk_score(risk_factors)
                
                # Determine state based on score and thresholds
                new_state = self._determine_state(risk_score, risk_factors, engine)
                
                # Apply state transition rules
                final_state = self._apply_transition_rules(new_state)
                
                # Update state duration and transitions
                if final_state.state != self._current.state:
                    self._current.transitions += 1
                    final_state.duration_seconds = 0.0
                    
                    # Log state transition
                    self._log_state_transition(self._current, final_state)
                else:
                    final_state.duration_seconds = final_state.timestamp - self._current.timestamp
                
                # Update history
                self._previous = self._current
                self._current = final_state
                self.history.add(final_state)
                
                # Persist state if enabled
                if self.persistence_enabled:
                    self._save_state()
                
                # Update metrics
                check_duration = _now() - start_time
                self.metrics["last_check_duration"] = check_duration
                self.metrics["avg_check_duration"] = (
                    (self.metrics["avg_check_duration"] * (self.metrics["checks_performed"] - 1) + check_duration) /
                    self.metrics["checks_performed"]
                )
                
                if final_state.state != self._previous.state:
                    self.metrics["state_changes"] += 1
                
                return final_state.to_dict()
                
            except Exception as e:
                self._emit("error", f"Risk state update failed: {e}")
                # Return last known state in case of error
                return self._current.to_dict()

    def _collect_risk_factors(self, engine: Any) -> List[RiskFactor]:
        """Collect risk factors from all sources."""
        factors = []
        
        # Hard halt from config or engine
        if _as_bool(self._config().get("force_halt", False), False) or bool(getattr(engine, "halted", False)):
            factors.append(RiskFactor(
                name="force_halt",
                value=1.0,
                threshold=0.5,
                weight=10.0,  # High weight to ensure halt
                direction="above",
                details={"source": "config_or_engine"}
            ))
        
        # Kill switch integration
        if hasattr(engine, "kill_switch") and _as_bool(getattr(engine.kill_switch, "active", False), False):
            factors.append(RiskFactor(
                name="kill_switch",
                value=1.0,
                threshold=0.5,
                weight=10.0,
                direction="above",
                details={"source": "kill_switch"}
            ))
        
        # Evaluate all risk sources
        for name, source in self.risk_sources.items():
            if source.should_check():
                try:
                    factor = source.evaluate(engine)
                    if factor:
                        factors.append(factor)
                except Exception as e:
                    self._emit("debug", f"Risk source {name} evaluation failed: {e}")
        
        return factors

    def _calculate_risk_score(self, factors: List[RiskFactor]) -> float:
        """Calculate overall risk score from factors."""
        if not factors:
            return 0.0
        
        # Weighted average of factor scores
        total_weight = sum(f.weight for f in factors)
        if total_weight <= 0:
            return 0.0
        
        weighted_sum = sum(f.get_score() * f.weight for f in factors)
        score = weighted_sum / total_weight
        
        # Apply non-linear scaling for high risk
        if score > 0.7:
            # Accelerate score for high-risk scenarios
            score = 0.7 + (score - 0.7) * 2.0
        
        return min(1.0, max(0.0, score))

    def _determine_state(self, risk_score: float, factors: List[RiskFactor], engine: Any) -> RiskState:
        """Determine risk state based on score and factors."""
        # Base state from thresholds
        if risk_score >= self._state_config.get("halt", 0.9):
            state_name = "HALT"
            reason = "Risk score above halt threshold"
        elif risk_score >= self._state_config.get("risk_off", 0.6):
            state_name = "RISK_OFF"
            reason = "Risk score above risk-off threshold"
        elif risk_score >= self._state_config.get("caution", 0.3):
            state_name = "CAUTION"
            reason = "Risk score above caution threshold"
        else:
            state_name = "NORMAL"
            reason = "All checks passed"
        
        # Override based on specific critical factors
        critical_triggers = []
        for factor in factors:
            if factor.name in ["force_halt", "kill_switch", "market_guard_halt"]:
                state_name = "HALT"
                reason = f"Critical trigger: {factor.name}"
                critical_triggers.append(factor.name)
            elif factor.name == "market_guard_risk_off" and state_name != "HALT":
                state_name = "RISK_OFF"
                reason = f"Critical trigger: {factor.name}"
                critical_triggers.append(factor.name)
        
        # Calculate risk multiplier based on state
        risk_mult = self._calculate_risk_multiplier(state_name, risk_score)
        
        # Determine allowed actions
        allow_entries, allow_adds, allow_exits = self._determine_allowed_actions(state_name)
        
        # Prepare factors for state
        factor_dicts = [f.to_dict() for f in factors]
        active_triggers = [f.name for f in factors if f.is_triggered()]
        
        return RiskState(
            state=state_name,
            reason=reason,
            controller="risk_state",
            risk_score=risk_score,
            risk_mult=risk_mult,
            max_position_size=self._calculate_max_position_size(state_name, risk_score),
            allow_entries=allow_entries,
            allow_adds=allow_adds,
            allow_exits=allow_exits,
            halt=(state_name == "HALT"),
            factors=factor_dicts,
            active_triggers=active_triggers,
            timestamp=_now(),
            transitions=self._current.transitions,
        )

    def _calculate_risk_multiplier(self, state_name: str, risk_score: float) -> float:
        """Calculate risk multiplier based on state and score."""
        config = self._config()
        
        if state_name == "HALT":
            return config.get("halt_risk_mult", 0.0)
        elif state_name == "RISK_OFF":
            base = config.get("risk_off_risk_mult", 0.0)
            # Scale based on how far above threshold
            threshold = self._state_config.get("risk_off", 0.6)
            if risk_score > threshold:
                excess = (risk_score - threshold) / (1.0 - threshold)
                return max(0.0, base * (1.0 - excess))
            return base
        elif state_name == "CAUTION":
            base = config.get("caution_risk_mult", 0.5)
            # Scale based on risk score
            lower = self._state_config.get("caution", 0.3)
            upper = self._state_config.get("risk_off", 0.6)
            if upper > lower:
                normalized = (risk_score - lower) / (upper - lower)
                return max(0.0, min(1.0, base * (1.0 - normalized)))
            return base
        else:  # NORMAL
            return 1.0

    def _calculate_max_position_size(self, state_name: str, risk_score: float) -> float:
        """Calculate maximum position size multiplier."""
        config = self._config()
        
        if state_name == "HALT":
            return config.get("halt_max_position", 0.0)
        elif state_name == "RISK_OFF":
            return config.get("risk_off_max_position", 0.5)
        elif state_name == "CAUTION":
            base = config.get("caution_max_position", 0.8)
            # Scale down as risk increases
            lower = self._state_config.get("caution", 0.3)
            upper = self._state_config.get("risk_off", 0.6)
            if upper > lower:
                normalized = (risk_score - lower) / (upper - lower)
                return max(0.0, min(1.0, base * (1.0 - normalized * 0.5)))
            return base
        else:  # NORMAL
            return 1.0

    def _determine_allowed_actions(self, state_name: str) -> Tuple[bool, bool, bool]:
        """Determine which actions are allowed in current state."""
        config = self._config()
        
        if state_name == "HALT":
            return (
                config.get("halt_allow_entries", False),
                config.get("halt_allow_adds", False),
                config.get("halt_allow_exits", True),  # Always allow exits in halt
            )
        elif state_name == "RISK_OFF":
            return (
                config.get("risk_off_allow_entries", False),
                config.get("risk_off_allow_adds", False),
                config.get("risk_off_allow_exits", True),
            )
        elif state_name == "CAUTION":
            return (
                config.get("caution_allow_entries", True),
                config.get("caution_allow_adds", False),
                config.get("caution_allow_exits", True),
            )
        else:  # NORMAL
            return (True, True, True)

    def _apply_transition_rules(self, new_state: RiskState) -> RiskState:
        """Apply state transition rules (cooldown, hysteresis, etc.)."""
        config = self._config()
        transition_rules = config.get("transitions", {})
        
        # Minimum time in state before transitioning out
        min_state_duration = transition_rules.get("min_state_duration", {})
        current_min_duration = min_state_duration.get(self._current.state.lower(), 0.0)
        
        if (self._current.state != new_state.state and 
            self._current.duration_seconds < current_min_duration):
            # Not enough time in current state, keep current
            self._emit("debug", f"State transition blocked: {self._current.state} -> {new_state.state} "
                              f"(min duration: {current_min_duration}s, current: {self._current.duration_seconds:.1f}s)")
            return self._current
        
        # Hysteresis: require more improvement to return to better state
        severity_current = RiskLevel[self._current.state].severity if hasattr(RiskLevel, self._current.state) else 0
        severity_new = RiskLevel[new_state.state].severity if hasattr(RiskLevel, new_state.state) else 0
        
        if severity_new < severity_current:  # Moving to better state
            hysteresis = transition_rules.get("hysteresis", 0.05)
            required_improvement = self._current.risk_score - hysteresis
            
            if new_state.risk_score > required_improvement:
                # Not enough improvement, stay in current state
                self._emit("debug", f"Hysteresis blocked improvement: {self._current.state} -> {new_state.state}")
                return self._current
        
        return new_state

    def _log_state_transition(self, old_state: RiskState, new_state: RiskState) -> None:
        """Log state transition with details."""
        self._emit("info", 
                  f"Risk state transition: {old_state.state} -> {new_state.state}",
                  score=f"{new_state.risk_score:.3f}",
                  reason=new_state.reason,
                  risk_mult=f"{new_state.risk_mult:.2f}",
                  active_triggers=str(new_state.active_triggers)[:100])

    def apply_to_engine(self, engine: Any, rs: Union[RiskState, Dict[str, Any]]) -> None:
        """Propagate risk state decisions into engine instance."""
        try:
            # Normalize input
            if isinstance(rs, RiskState):
                d = rs.to_dict()
            elif isinstance(rs, dict):
                d = rs
            else:
                d = getattr(rs, "__dict__", {})
            
            risk_mult = _f(d.get("risk_mult", 1.0), 1.0)
            
            # Set engine attributes for risk sizing
            setattr(engine, "_risk_state_risk_mult", float(risk_mult))
            setattr(engine, "_risk_state_max_position", float(d.get("max_position_size", 1.0)))
            
            # Block entries/adds if requested
            setattr(engine, "_risk_state_allow_entries", bool(d.get("allow_entries", True)))
            setattr(engine, "_risk_state_allow_adds", bool(d.get("allow_adds", True)))
            setattr(engine, "_risk_state_allow_exits", bool(d.get("allow_exits", True)))
            
            # Halt flag
            if bool(d.get("halt", False)) or str(d.get("state", "")).upper() == "HALT":
                setattr(engine, "halted", True)
            
            # Also store the full state object for reference
            setattr(engine, "_risk_state_current", d)
            
        except Exception as e:
            self._emit("error", f"Failed to apply risk state to engine: {e}")

    def get_current_state(self) -> Dict[str, Any]:
        """Get current risk state."""
        with self._lock:
            return self._current.to_dict()

    def get_statistics(self) -> Dict[str, Any]:
        """Get risk state statistics."""
        with self._lock:
            history_stats = self.history.get_statistics()
            return {
                "current_state": self._current.to_dict(),
                "history_statistics": history_stats,
                "performance_metrics": self.metrics,
                "risk_sources": {
                    name: {
                        "enabled": source.enabled,
                        "weight": source.weight,
                        "last_check": source.last_check,
                    }
                    for name, source in self.risk_sources.items()
                },
                "state_thresholds": self._state_config,
            }

    def force_state(self, state: str, reason: str = "Manual override") -> bool:
        """Manually force a risk state."""
        with self._lock:
            if state not in [level.name for level in RiskLevel]:
                self._emit("error", f"Invalid risk state: {state}")
                return False
            
            new_state = RiskState(
                state=state,
                reason=reason,
                controller="manual_override",
                risk_score=1.0 if state == "HALT" else 0.8 if state == "RISK_OFF" else 0.5 if state == "CAUTION" else 0.0,
                risk_mult=self._calculate_risk_multiplier(state, 0.8),
                max_position_size=self._calculate_max_position_size(state, 0.8),
                allow_entries=state == "NORMAL",
                allow_adds=state == "NORMAL",
                allow_exits=True,
                halt=(state == "HALT"),
                factors=[{"name": "manual_override", "reason": reason}],
                active_triggers=["manual_override"],
                timestamp=_now(),
                transitions=self._current.transitions + 1,
            )
            
            self._previous = self._current
            self._current = new_state
            self.history.add(new_state)
            
            self._emit("info", f"Risk state manually forced to {state}: {reason}")
            return True

    def reset_to_normal(self) -> bool:
        """Reset risk state to NORMAL."""
        return self.force_state("NORMAL", "Manual reset to normal")

    # ----------------------
    # Persistence
    # ----------------------
    def _save_state(self) -> None:
        """Save current state to disk."""
        try:
            import os
            os.makedirs(os.path.dirname(self.persistence_path) or ".", exist_ok=True)
            
            state_data = {
                "current_state": self._current.to_dict(),
                "previous_state": self._previous.to_dict() if self._previous else None,
                "timestamp": _now(),
                "version": "1.0",
            }
            
            with open(self.persistence_path, "w", encoding="utf-8") as f:
                json.dump(state_data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            self._emit("error", f"Failed to save risk state: {e}")

    def _load_state(self) -> None:
        """Load state from disk."""
        if not self.persistence_enabled:
            return
            
        try:
            import os
            if not os.path.exists(self.persistence_path):
                return
                
            with open(self.persistence_path, "r", encoding="utf-8") as f:
                state_data = json.load(f)
            
            if "current_state" in state_data:
                current_dict = state_data["current_state"]
                # Convert dict back to RiskState
                self._current = RiskState(**current_dict)
                
            if state_data.get("previous_state"):
                prev_dict = state_data["previous_state"]
                self._previous = RiskState(**prev_dict)
                
            self._emit("info", f"Loaded risk state from {self.persistence_path}")
            
        except Exception as e:
            self._emit("error", f"Failed to load risk state: {e}")

    def clear_history(self) -> None:
        """Clear risk state history."""
        with self._lock:
            self.history = RiskStateHistory(
                max_entries=self._config().get("history_size", 1000)
            )
            self._emit("info", "Risk state history cleared")


# Factory function for easy creation
def create_risk_state_orchestrator(cfg: Dict[str, Any], log: Any = None) -> RiskStateOrchestrator:
    """Create a RiskStateOrchestrator instance with configuration."""
    return RiskStateOrchestrator(cfg, log)


# Example configuration
EXAMPLE_CONFIG = {
    "risk_state": {
        "enabled": True,
        "min_emit_sec": 10.0,
        "history_size": 1000,
        "persistence": {
            "enabled": True,
            "path": "data/risk_state.json",
        },
        "state_thresholds": {
            "caution": 0.3,
            "risk_off": 0.6,
            "halt": 0.9,
        },
        "halt_risk_mult": 0.0,
        "risk_off_risk_mult": 0.0,
        "caution_risk_mult": 0.5,
        "halt_max_position": 0.0,
        "risk_off_max_position": 0.5,
        "caution_max_position": 0.8,
        "halt_allow_entries": False,
        "halt_allow_adds": False,
        "halt_allow_exits": True,
        "risk_off_allow_entries": False,
        "risk_off_allow_adds": False,
        "risk_off_allow_exits": True,
        "caution_allow_entries": True,
        "caution_allow_adds": False,
        "caution_allow_exits": True,
        "transitions": {
            "min_state_duration": {
                "normal": 0.0,
                "caution": 300.0,    # 5 minutes
                "risk_off": 600.0,   # 10 minutes
                "halt": 900.0,       # 15 minutes
            },
            "hysteresis": 0.05,
        },
        "sources": {
            "drawdown": {
                "enabled": True,
                "weight": 1.0,
                "check_interval": 60.0,
                "dd_caution": 0.05,
                "dd_riskoff": 0.10,
                "dd_halt": 0.20,
            },
            "market_guard": {
                "enabled": True,
                "weight": 1.0,
                "check_interval": 30.0,
            },
            "error_rate": {
                "enabled": True,
                "weight": 0.5,
                "check_interval": 300.0,
                "error_window": 100,
                "error_threshold": 0.1,
            },
            "volatility": {
                "enabled": False,
                "weight": 0.3,
                "check_interval": 60.0,
                "volatility_threshold": 0.02,
            },
        },
    }
}


if __name__ == "__main__":
    import logging
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Create risk state orchestrator
    orchestrator = create_risk_state_orchestrator(EXAMPLE_CONFIG, logger)
    
    # Mock engine for testing
    class MockEngine:
        def __init__(self):
            self.equity = 10000.0
            self.peak_equity = 12000.0
            self.day_start_equity = 11000.0
            self.halted = False
            self.error_history = [False] * 90 + [True] * 10  # 10% error rate
            self.market_guard = None
        
        def equity(self):
            return self.equity
    
    engine = MockEngine()
    
    # Run a few updates
    for i in range(5):
        print(f"\n--- Update {i+1} ---")
        state = orchestrator.update(engine)
        print(f"State: {state['state']}")
        print(f"Risk Score: {state['risk_score']:.3f}")
        print(f"Risk Multiplier: {state['risk_mult']:.2f}")
        print(f"Active Triggers: {state['active_triggers']}")
        
        # Apply to engine
        orchestrator.apply_to_engine(engine, state)
        
        time.sleep(0.1)
    
    # Get statistics
    stats = orchestrator.get_statistics()
    print(f"\n--- Statistics ---")
    print(f"Checks performed: {stats['performance_metrics']['checks_performed']}")
    print(f"State changes: {stats['performance_metrics']['state_changes']}")
    print(f"Average check duration: {stats['performance_metrics']['avg_check_duration']:.3f}s")
    
    # Force a state
    orchestrator.force_state("HALT", "Test emergency")
    print(f"\n--- After force state ---")
    print(f"Current state: {orchestrator.get_current_state()['state']}")
    
    # Reset to normal
    orchestrator.reset_to_normal()
    print(f"\n--- After reset ---")
    print(f"Current state: {orchestrator.get_current_state()['state']}")
from __future__ import annotations

import os
import json
import time
import math
import threading
import shutil
import hashlib
from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, List, Union, Tuple, Callable
from datetime import datetime, date
from decimal import Decimal
from enum import Enum
import pickle
import gzip

from .utils import now_utc_iso


def _sanitize_jsonable(x: Any, max_depth: int = 10) -> Any:
    """Recursively sanitize objects for JSON persistence (NaN/Inf -> None).
    
    Args:
        x: Any object to sanitize
        max_depth: Maximum recursion depth to prevent infinite recursion
    
    Returns:
        JSON-serializable object
    """
    def _sanitize_inner(obj: Any, depth: int) -> Any:
        if depth > max_depth:
            return f"<Max recursion depth {max_depth} reached>"
            
        try:
            if obj is None or isinstance(obj, (str, int, bool)):
                return obj
                
            if isinstance(obj, float):
                return obj if math.isfinite(obj) else None
                
            if isinstance(obj, (datetime, date)):
                return obj.isoformat()
                
            if isinstance(obj, Decimal):
                return float(obj)
                
            if isinstance(obj, Enum):
                return obj.value
                
            if isinstance(obj, bytes):
                return obj.hex()
                
            if isinstance(obj, dict):
                return {str(k): _sanitize_inner(v, depth + 1) for k, v in obj.items()}
                
            if isinstance(obj, (list, tuple, set)):
                return [_sanitize_inner(v, depth + 1) for v in list(obj)]
                
            if is_dataclass(obj):
                return _sanitize_inner(asdict(obj), depth + 1)
                
            if hasattr(obj, "item") and callable(getattr(obj, "item")):
                # numpy/pandas scalar
                try:
                    return _sanitize_inner(obj.item(), depth + 1)
                except Exception:
                    pass
                    
            if hasattr(obj, "to_dict") and callable(getattr(obj, "to_dict")):
                return _sanitize_inner(obj.to_dict(), depth + 1)
                
            if hasattr(obj, "as_dict") and callable(getattr(obj, "as_dict")):
                return _sanitize_inner(obj.as_dict(), depth + 1)
                
            if hasattr(obj, "__dict__"):
                return _sanitize_inner(dict(obj.__dict__), depth + 1)
                
            if hasattr(obj, "__iter__") and not isinstance(obj, (str, bytes)):
                try:
                    return [_sanitize_inner(v, depth + 1) for v in obj]
                except Exception:
                    pass
                    
            # Try to get a string representation
            try:
                return str(obj)
            except Exception:
                return f"<Unserializable object of type {type(obj).__name__}>"
                
        except Exception as e:
            return f"<Error during sanitization: {str(e)}>"
    
    return _sanitize_inner(x, 0)


def _safe_int(x: Any, default: int) -> int:
    """Safely convert to integer with default fallback."""
    try:
        return int(x)
    except Exception:
        return int(default)


def _safe_float(x: Any, default: float) -> float:
    """Safely convert to float with default fallback."""
    try:
        return float(x)
    except Exception:
        return float(default)


def _calculate_checksum(data: bytes) -> str:
    """Calculate SHA-256 checksum for data."""
    return hashlib.sha256(data).hexdigest()


class StateManager:
    """State manager with persistence, backup, and recovery capabilities."""
    
    def __init__(
        self,
        cfg: dict,
        base_dir: str,
        log: Any,
        app_name: str = "app",
        app_version: str = "1.0.0"
    ):
        """Initialize StateManager.
        
        Args:
            cfg: Configuration dictionary with state settings
            base_dir: Base directory for state files
            log: Logger instance
            app_name: Application name for metadata
            app_version: Application version for metadata
        """
        self.cfg = cfg or {}
        self.base_dir = str(base_dir or ".")
        self.log = log
        self.app_name = str(app_name)
        self.app_version = str(app_version)

        state_cfg = (self.cfg.get("state") or {})
        rel = state_cfg.get("path") or "state.json"
        self.path = os.path.join(self.base_dir, str(rel))

        self._lock = threading.RLock()

        # Configuration options
        self._enable = bool(state_cfg.get("enable_persistence", True))
        self._backup_every_save = bool(state_cfg.get("backup_every_save", False))
        self._max_backups = _safe_int(state_cfg.get("max_backups", 50), 50)
        self._max_backup_size_mb = _safe_float(state_cfg.get("max_backup_size_mb", 1024), 1024)
        self._compression = bool(state_cfg.get("compression", False))
        self._encryption_key = state_cfg.get("encryption_key")
        self._validate_checksum = bool(state_cfg.get("validate_checksum", True))
        self._auto_recovery = bool(state_cfg.get("auto_recovery", True))
        
        # State metadata
        self.metadata = {
            "app_name": self.app_name,
            "app_version": self.app_version,
            "created": now_utc_iso(),
            "last_modified": None,
            "checksum": None,
            "size_bytes": 0,
            "backup_count": 0,
        }

        # Ensure parent dir exists
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        except Exception as e:
            self.log.warning(f"Failed to create state directory: {e}")

    # ---------------------------
    # Core save/load
    # ---------------------------
    def save(self, snapshot: Dict[str, Any], metadata: Optional[Dict[str, Any]] = None) -> bool:
        """Save state snapshot to disk.
        
        Args:
            snapshot: State data to save
            metadata: Additional metadata to include
            
        Returns:
            True if save was successful, False otherwise
        """
        if not self._enable:
            self.log.debug("State persistence is disabled")
            return False

        if snapshot is None:
            self.log.warning("Attempted to save None snapshot")
            return False

        with self._lock:
            try:
                # Prepare snapshot
                snap = dict(snapshot)
                ts = now_utc_iso()
                snap["_metadata"] = {
                    "ts": ts,
                    "app_name": self.app_name,
                    "app_version": self.app_version,
                    "save_timestamp": ts,
                    "original_metadata": metadata or {},
                }
                snap["_metadata"].update(self.metadata)

                # Sanitize to avoid JSON errors
                sanitized_snap = _sanitize_jsonable(snap)
                if not isinstance(sanitized_snap, dict):
                    self.log.error("Sanitization failed to produce a dict")
                    sanitized_snap = {"_metadata": snap["_metadata"], "state": sanitized_snap}

                # Add checksum
                json_str = json.dumps(sanitized_snap, indent=2, ensure_ascii=False, sort_keys=True)
                checksum = _calculate_checksum(json_str.encode('utf-8'))
                sanitized_snap["_metadata"]["checksum"] = checksum
                sanitized_snap["_metadata"]["size_bytes"] = len(json_str.encode('utf-8'))

                # Atomic write with backup
                tmp_path = self.path + ".tmp"
                backup_path = self.path + ".bak"
                
                # Create backup of current state if it exists
                if os.path.exists(self.path):
                    try:
                        shutil.copy2(self.path, backup_path)
                    except Exception as e:
                        self.log.warning(f"Failed to create backup: {e}")

                # Write new state
                try:
                    if self._compression:
                        with gzip.open(tmp_path, 'wt', encoding='utf-8') as f:
                            json.dump(sanitized_snap, f, indent=2, ensure_ascii=False)
                    else:
                        with open(tmp_path, 'w', encoding='utf-8') as f:
                            json.dump(sanitized_snap, f, indent=2, ensure_ascii=False)
                            f.flush()
                            os.fsync(f.fileno())
                    
                    # Replace original with new file
                    os.replace(tmp_path, self.path)
                    
                    # Update metadata
                    self.metadata.update({
                        "last_modified": ts,
                        "checksum": checksum,
                        "size_bytes": sanitized_snap["_metadata"]["size_bytes"],
                    })

                    # Optional timestamped backup
                    if self._backup_every_save:
                        backup_file = self.save_backup(sanitized_snap)
                        if backup_file:
                            self._rotate_backups()
                            self.metadata["backup_count"] = len(self.list_backups())

                    # Clean up temporary backup
                    if os.path.exists(backup_path):
                        os.remove(backup_path)

                    self.log.info(f"State saved successfully: {self.path}, size: {self.metadata['size_bytes']} bytes")
                    return True
                    
                except Exception as e:
                    # Attempt recovery if write failed
                    self.log.error(f"Failed to write state file: {e}")
                    if os.path.exists(backup_path):
                        self.log.info("Attempting recovery from backup")
                        os.replace(backup_path, self.path)
                    return False

            except Exception as e:
                self.log.exception(f"StateManager.save failed: {e}")
                return False

    def load(self, validate_checksum: Optional[bool] = None) -> Optional[Dict[str, Any]]:
        """Load state from disk.
        
        Args:
            validate_checksum: Whether to validate checksum (overrides config)
            
        Returns:
            Loaded state dict or None if failed
        """
        if validate_checksum is None:
            validate_checksum = self._validate_checksum

        with self._lock:
            try:
                if not os.path.exists(self.path):
                    self.log.info(f"No state file found at {self.path}")
                    return None

                # Load and validate state
                state = self._load_file(self.path, validate_checksum)
                if state is not None:
                    self.log.info(f"State loaded successfully from {self.path}")
                    return state
                else:
                    self.log.warning(f"Failed to load state from {self.path}")
                    
                    # Attempt auto-recovery
                    if self._auto_recovery:
                        self.log.info("Attempting auto-recovery from backup")
                        recovered = self.recover_latest_backup()
                        if recovered:
                            return recovered
                    
                    return None

            except Exception as e:
                self.log.exception(f"StateManager.load failed: {e}")
                return None

    def _load_file(self, filepath: str, validate_checksum: bool) -> Optional[Dict[str, Any]]:
        """Load and validate a single state file."""
        try:
            # Read file
            if self._compression and filepath.endswith('.gz'):
                with gzip.open(filepath, 'rt', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)

            if not isinstance(data, dict):
                self.log.error(f"Invalid state format in {filepath}")
                return None

            # Validate checksum
            if validate_checksum and "_metadata" in data:
                metadata = data.get("_metadata", {})
                stored_checksum = metadata.get("checksum")
                
                if stored_checksum:
                    # Calculate current checksum
                    temp_data = dict(data)
                    temp_data["_metadata"] = dict(metadata)
                    temp_data["_metadata"]["checksum"] = None
                    
                    json_str = json.dumps(temp_data, indent=2, ensure_ascii=False, sort_keys=True)
                    calculated_checksum = _calculate_checksum(json_str.encode('utf-8'))
                    
                    if stored_checksum != calculated_checksum:
                        self.log.error(f"Checksum mismatch in {filepath}")
                        return None

            # Update metadata
            if "_metadata" in data:
                self.metadata.update(data["_metadata"])
                self.metadata["last_modified"] = data["_metadata"].get("ts")

            return data
            
        except json.JSONDecodeError as e:
            self.log.error(f"JSON decode error in {filepath}: {e}")
            return None
        except Exception as e:
            self.log.error(f"Error loading {filepath}: {e}")
            return None

    # ---------------------------
    # Backup management
    # ---------------------------
    def _backup_dir(self) -> str:
        """Get backup directory path."""
        p = os.path.join(self.base_dir, "state_backups")
        os.makedirs(p, exist_ok=True)
        return p

    def save_backup(self, snapshot: Dict[str, Any]) -> Optional[str]:
        """Save a timestamped backup snapshot.
        
        Args:
            snapshot: State snapshot to backup
            
        Returns:
            Path to backup file or None if failed
        """
        if not self._enable:
            return None

        ts = now_utc_iso().replace(":", "").replace("-", "").replace("T", "_").replace("Z", "")
        base_name = f"state_{ts}.json"
        if self._compression:
            base_name += ".gz"
        
        fp = os.path.join(self._backup_dir(), base_name)

        with self._lock:
            try:
                # Add backup metadata
                backup_snap = dict(snapshot)
                if "_metadata" in backup_snap:
                    backup_snap["_metadata"]["backup_timestamp"] = ts
                    backup_snap["_metadata"]["backup_file"] = base_name

                tmp = fp + ".tmp"
                if self._compression:
                    with gzip.open(tmp, 'wt', encoding='utf-8') as f:
                        json.dump(backup_snap, f, indent=2, ensure_ascii=False)
                else:
                    with open(tmp, 'w', encoding='utf-8') as f:
                        json.dump(backup_snap, f, indent=2, ensure_ascii=False)
                        f.flush()
                        os.fsync(f.fileno())
                os.replace(tmp, fp)
                
                self.log.info(f"Backup saved: {fp}")
                return fp
                
            except Exception as e:
                self.log.exception(f"StateManager.save_backup failed: {e}")
                return None

    def list_backups(self, limit: int = 20, with_metadata: bool = False) -> List[Union[str, Dict[str, Any]]]:
        """List available backups.
        
        Args:
            limit: Maximum number of backups to return
            with_metadata: If True, return dicts with metadata
            
        Returns:
            List of backup file paths or metadata dicts
        """
        try:
            p = self._backup_dir()
            files = []
            
            for filename in os.listdir(p):
                if filename.endswith(".json") or filename.endswith(".json.gz"):
                    filepath = os.path.join(p, filename)
                    stat = os.stat(filepath)
                    
                    if with_metadata:
                        metadata = {
                            "path": filepath,
                            "filename": filename,
                            "size": stat.st_size,
                            "modified": stat.st_mtime,
                            "is_compressed": filename.endswith(".gz"),
                        }
                        
                        # Try to extract metadata from file
                        try:
                            if filename.endswith(".gz"):
                                with gzip.open(filepath, 'rt', encoding='utf-8') as f:
                                    data = json.load(f)
                            else:
                                with open(filepath, 'r', encoding='utf-8') as f:
                                    data = json.load(f)
                                    
                            if isinstance(data, dict) and "_metadata" in data:
                                metadata.update(data["_metadata"])
                        except Exception:
                            pass
                            
                        files.append(metadata)
                    else:
                        files.append(filepath)
            
            # Sort by modification time (newest first)
            if with_metadata:
                files.sort(key=lambda x: x.get("modified", 0), reverse=True)
            else:
                files.sort(key=os.path.getmtime, reverse=True)
                
            return files[:max(0, int(limit))]
            
        except Exception as e:
            self.log.error(f"Error listing backups: {e}")
            return []

    def _rotate_backups(self) -> None:
        """Keep only the newest N backups within size limits."""
        try:
            keep_count = max(0, int(self._max_backups))
            max_size_bytes = max(0, int(self._max_backup_size_mb * 1024 * 1024))
            
            backups = self.list_backups(limit=100000, with_metadata=True)
            
            if not backups:
                return
            
            # Sort by age (oldest first for removal)
            backups.sort(key=lambda x: x.get("modified", 0))
            
            # Calculate total size
            total_size = sum(b.get("size", 0) for b in backups)
            
            # Remove old backups if we exceed count limit
            if len(backups) > keep_count:
                for backup in backups[:len(backups) - keep_count]:
                    try:
                        os.remove(backup["path"])
                        total_size -= backup["size"]
                        self.log.debug(f"Removed old backup: {backup['filename']}")
                    except Exception as e:
                        self.log.warning(f"Failed to remove backup {backup['path']}: {e}")
            
            # Remove old backups if we exceed size limit
            backups = self.list_backups(limit=100000, with_metadata=True)
            backups.sort(key=lambda x: x.get("modified", 0))
            
            while backups and total_size > max_size_bytes:
                oldest = backups.pop(0)
                try:
                    os.remove(oldest["path"])
                    total_size -= oldest["size"]
                    self.log.debug(f"Removed large backup: {oldest['filename']} (size: {oldest['size']})")
                except Exception as e:
                    self.log.warning(f"Failed to remove backup {oldest['path']}: {e}")
                    
        except Exception as e:
            self.log.error(f"Error rotating backups: {e}")

    def load_backup(
        self, 
        timestamp: Optional[str] = None, 
        filepath: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Load a specific backup.
        
        Args:
            timestamp: Timestamp substring to match in filename
            filepath: Direct path to backup file
            
        Returns:
            Loaded backup state or None
        """
        if filepath:
            if os.path.exists(filepath):
                return self._load_file(filepath, self._validate_checksum)
            return None

        files = self.list_backups(limit=200)
        if not files:
            return None

        if timestamp:
            for fp in files:
                if str(timestamp) in os.path.basename(fp):
                    return self._load_file(fp, self._validate_checksum)

        # Load newest backup
        try:
            return self._load_file(files[0], self._validate_checksum)
        except Exception as e:
            self.log.exception(f"Failed to load newest backup: {e}")
            return None

    def recover_latest_backup(self) -> Optional[Dict[str, Any]]:
        """Recover state from the latest valid backup."""
        backups = self.list_backups(limit=10)
        
        for backup_path in backups:
            try:
                state = self._load_file(backup_path, True)
                if state:
                    # Restore this backup as current state
                    self.save(state)
                    self.log.info(f"Recovered state from backup: {backup_path}")
                    return state
            except Exception as e:
                self.log.warning(f"Failed to recover from backup {backup_path}: {e}")
                continue
        
        self.log.error("No valid backup found for recovery")
        return None

    # ---------------------------
    # State validation and maintenance
    # ---------------------------
    def validate_state(self, state: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
        """Validate state structure and integrity.
        
        Args:
            state: State to validate (loads current if None)
            
        Returns:
            (is_valid, message) tuple
        """
        if state is None:
            state = self.load(validate_checksum=False)
            if state is None:
                return False, "No state to validate"
        
        try:
            # Check basic structure
            if not isinstance(state, dict):
                return False, "State is not a dictionary"
            
            # Check required metadata
            metadata = state.get("_metadata", {})
            if not metadata:
                return False, "Missing metadata"
            
            # Validate timestamp
            ts = metadata.get("ts")
            if not ts:
                return False, "Missing timestamp"
            
            # Verify checksum if present
            if self._validate_checksum and "checksum" in metadata:
                stored_checksum = metadata["checksum"]
                temp_state = dict(state)
                temp_state["_metadata"] = dict(metadata)
                temp_state["_metadata"]["checksum"] = None
                
                json_str = json.dumps(temp_state, indent=2, ensure_ascii=False, sort_keys=True)
                calculated_checksum = _calculate_checksum(json_str.encode('utf-8'))
                
                if stored_checksum != calculated_checksum:
                    return False, f"Checksum mismatch: {stored_checksum} != {calculated_checksum}"
            
            return True, "State is valid"
            
        except Exception as e:
            return False, f"Validation error: {e}"

    def get_state_info(self) -> Dict[str, Any]:
        """Get information about current state."""
        info = {
            "path": self.path,
            "enabled": self._enable,
            "exists": os.path.exists(self.path),
            "metadata": self.metadata.copy(),
            "backup_count": len(self.list_backups()),
            "compression_enabled": self._compression,
            "auto_recovery_enabled": self._auto_recovery,
        }
        
        if os.path.exists(self.path):
            stat = os.stat(self.path)
            info.update({
                "size_bytes": stat.st_size,
                "modified_time": stat.st_mtime,
                "modified_iso": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            })
            
            # Validate state
            is_valid, message = self.validate_state()
            info["is_valid"] = is_valid
            info["validation_message"] = message
        
        return info

    def cleanup_old_backups(self, max_age_days: int = 30) -> int:
        """Remove backups older than specified days.
        
        Args:
            max_age_days: Maximum age in days
            
        Returns:
            Number of backups removed
        """
        cutoff_time = time.time() - (max_age_days * 24 * 3600)
        removed_count = 0
        
        backups = self.list_backups(limit=100000, with_metadata=True)
        
        for backup in backups:
            if backup.get("modified", 0) < cutoff_time:
                try:
                    os.remove(backup["path"])
                    removed_count += 1
                    self.log.debug(f"Removed old backup: {backup['filename']}")
                except Exception as e:
                    self.log.warning(f"Failed to remove old backup {backup['path']}: {e}")
        
        if removed_count > 0:
            self.log.info(f"Removed {removed_count} backups older than {max_age_days} days")
        
        return removed_count

    def export_state(self, export_path: str, include_backups: bool = False) -> bool:
        """Export state and optionally backups to a different location.
        
        Args:
            export_path: Directory to export to
            include_backups: Whether to include backups
            
        Returns:
            True if export successful
        """
        try:
            os.makedirs(export_path, exist_ok=True)
            
            # Export current state
            if os.path.exists(self.path):
                dest = os.path.join(export_path, os.path.basename(self.path))
                shutil.copy2(self.path, dest)
            
            # Export backups
            if include_backups:
                backup_dest = os.path.join(export_path, "state_backups")
                os.makedirs(backup_dest, exist_ok=True)
                
                backups = self.list_backups(limit=100000)
                for backup in backups:
                    shutil.copy2(backup, os.path.join(backup_dest, os.path.basename(backup)))
            
            self.log.info(f"State exported to {export_path}")
            return True
            
        except Exception as e:
            self.log.error(f"Failed to export state: {e}")
            return False

    # ---------------------------
    # Context manager and utilities
    # ---------------------------
    def __enter__(self) -> "StateManager":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def close(self) -> None:
        """Clean up resources."""
        # Nothing specific to clean up in this implementation
        pass

    def reset(self, confirm: bool = False) -> bool:
        """Reset all state data (dangerous!).
        
        Args:
            confirm: Safety flag
            
        Returns:
            True if reset successful
        """
        if not confirm:
            self.log.error("Reset requires confirm=True")
            return False
        
        with self._lock:
            try:
                # Remove state file
                if os.path.exists(self.path):
                    os.remove(self.path)
                
                # Remove backups
                backup_dir = self._backup_dir()
                if os.path.exists(backup_dir):
                    shutil.rmtree(backup_dir)
                
                # Reset metadata
                self.metadata = {
                    "app_name": self.app_name,
                    "app_version": self.app_version,
                    "created": now_utc_iso(),
                    "last_modified": None,
                    "checksum": None,
                    "size_bytes": 0,
                    "backup_count": 0,
                }
                
                self.log.warning("State has been completely reset")
                return True
                
            except Exception as e:
                self.log.error(f"Failed to reset state: {e}")
                return False


# ---------------------------
# Helper functions and factory
# ---------------------------
def create_state_manager(
    config: Optional[Dict[str, Any]] = None,
    base_dir: str = ".",
    logger: Optional[Any] = None,
    app_name: str = "StateManager",
    app_version: str = "1.0.0"
) -> StateManager:
    """Create a StateManager instance with sensible defaults."""
    
    # Create a simple logger if none provided
    if logger is None:
        import logging
        logger = logging.getLogger(__name__)
    
    # Default configuration
    default_config = {
        "state": {
            "enable_persistence": True,
            "backup_every_save": True,
            "max_backups": 50,
            "max_backup_size_mb": 1024,
            "compression": False,
            "auto_recovery": True,
            "validate_checksum": True,
        }
    }
    
    if config:
        # Merge with defaults
        if "state" in config:
            default_config["state"].update(config.get("state", {}))
        config = default_config
    else:
        config = default_config
    
    return StateManager(
        cfg=config,
        base_dir=base_dir,
        log=logger,
        app_name=app_name,
        app_version=app_version,
    )


# ---------------------------
# Example usage
# ---------------------------
if __name__ == "__main__":
    import logging
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Create state manager
    state_mgr = create_state_manager(
        base_dir="test_state",
        logger=logger,
        app_name="TestApp",
        app_version="1.0.0"
    )
    
    try:
        # Test state
        test_state = {
            "positions": [
                {"symbol": "BTC/USDT", "size": 0.5, "entry_price": 50000},
                {"symbol": "ETH/USDT", "size": 2.0, "entry_price": 2500},
            ],
            "balance": 10000.0,
            "last_update": now_utc_iso(),
            "config": {
                "risk_per_trade": 0.02,
                "max_open_positions": 5,
                "strategy": "momentum",
            }
        }
        
        # Save state
        success = state_mgr.save(test_state, metadata={"user": "test", "session": "demo"})
        print(f"Save successful: {success}")
        
        # Get state info
        info = state_mgr.get_state_info()
        print(f"State info: {json.dumps(info, indent=2)}")
        
        # Load state
        loaded = state_mgr.load()
        print(f"State loaded: {loaded is not None}")
        
        if loaded:
            print(f"Loaded positions: {len(loaded.get('positions', []))}")
            print(f"Loaded balance: {loaded.get('balance')}")
        
        # List backups
        backups = state_mgr.list_backups(limit=5)
        print(f"Backups available: {len(backups)}")
        
        # Validate state
        is_valid, message = state_mgr.validate_state(loaded)
        print(f"State valid: {is_valid} - {message}")
        
        # Export state
        state_mgr.export_state("test_export", include_backups=True)
        
    finally:
        # Cleanup
        import shutil
        if os.path.exists("test_state"):
            shutil.rmtree("test_state")
        if os.path.exists("test_export"):
            shutil.rmtree("test_export")
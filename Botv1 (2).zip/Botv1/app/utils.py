from __future__ import annotations

import os
import time
import math
import json
import random
import logging
import traceback
import threading
import queue
import urllib.request
from typing import Any, Dict, Optional, List, Union
from datetime import datetime

try:
    from logging.handlers import RotatingFileHandler
except Exception:
    RotatingFileHandler = None  # type: ignore


# -------------------------
# Time / numeric helpers
# -------------------------

def now_utc_iso() -> str:
    """UTC ISO timestamp without heavy deps.
    Example: 2026-02-01T12:34:56.789Z
    """
    t = time.time()
    sec = int(t)
    ms = int((t - sec) * 1000)
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(sec)) + f".{ms:03d}Z"


def safe_float(x: Any, default: float = float("nan")) -> float:
    """Safely convert any value to float, returning default on failure."""
    try:
        if x is None:
            return float(default)
        v = float(x)
        return v
    except Exception:
        return float(default)


def safe_int(x: Any, default: int = 0) -> int:
    """Safely convert any value to int, returning default on failure."""
    try:
        if x is None:
            return int(default)
        return int(float(x))
    except Exception:
        return int(default)


def is_finite(x: Any) -> bool:
    """Check if value is a finite number."""
    try:
        return math.isfinite(float(x))
    except Exception:
        return False


def nan_to_none(x: Any) -> Any:
    """Convert non-finite floats to None (useful for JSON)."""
    try:
        if isinstance(x, float) and (not math.isfinite(x)):
            return None
        return x
    except Exception:
        return None


def clamp(x: float, lo: float, hi: float) -> float:
    """Clamp x in [lo, hi], treating NaN as lo."""
    try:
        xv = float(x)
        if not math.isfinite(xv):
            xv = float(lo)
        return max(float(lo), min(float(hi), xv))
    except Exception:
        return float(lo)


# -------------------------
# UI Logger (bounded queue)
# -------------------------

class UILogger:
    """
    Queue-backed logger for GUI with metrics and flexible formatting.
    
    Improvements:
      - bounded queue (maxsize) to avoid memory growth
      - drop-oldest policy when full
      - metrics tracking
      - customizable formatter
    """

    def __init__(self, maxsize: int = 5000, formatter: Optional[str] = None):
        self.q: queue.Queue[str] = queue.Queue(maxsize=max(100, int(maxsize)))
        self._lock = threading.Lock()
        self.formatter = formatter or "[{level}] {timestamp}  {message}"
        
        # Metrics
        self.metrics = {
            'messages_logged': 0,
            'messages_dropped': 0,
            'queue_size': 0
        }

    def _push(self, level: str, msg: str, **kwargs) -> None:
        """Push message to queue with formatted string."""
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        formatted_msg = msg
        if kwargs:
            formatted_msg = f"{msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
        
        line = self.formatter.format(
            level=level,
            timestamp=ts,
            message=formatted_msg
        )
        
        try:
            with self._lock:
                if self.q.full():
                    # drop oldest to make room
                    try:
                        _ = self.q.get_nowait()
                        self.metrics['messages_dropped'] += 1
                    except Exception:
                        pass
                self.q.put_nowait(line)
                self.metrics['messages_logged'] += 1
                self.metrics['queue_size'] = self.q.qsize()
        except Exception:
            pass

    def debug(self, msg: str, **kwargs) -> None:
        self._push("DEBUG", msg, **kwargs)

    def info(self, msg: str, **kwargs) -> None:
        self._push("INFO", msg, **kwargs)

    def warn(self, msg: str, **kwargs) -> None:
        self._push("WARN", msg, **kwargs)

    def warning(self, msg: str, **kwargs) -> None:
        self.warn(msg, **kwargs)

    def error(self, msg: str, **kwargs) -> None:
        self._push("ERROR", msg, **kwargs)

    def critical(self, msg: str, **kwargs) -> None:
        self._push("CRITICAL", msg, **kwargs)

    def exception(self, e: BaseException, msg: str = "") -> None:
        """Log exception with optional message."""
        full_msg = f"{msg}: {repr(e)}" if msg else f"Exception: {repr(e)}"
        self.error(full_msg)
        try:
            tb = traceback.format_exc()
        except Exception:
            tb = "traceback unavailable"
        self._push("ERROR", tb)

    def get_metrics(self) -> Dict[str, int]:
        """Get current metrics snapshot."""
        with self._lock:
            self.metrics['queue_size'] = self.q.qsize()
            return self.metrics.copy()


# -------------------------
# Composite Logger
# -------------------------

class CompositeLogger:
    """
    Logger adaptor: UI + file logger.
    Compatible with logging.Logger: debug/info/warning/error/exception/critical.
    """

    def __init__(self, ui: UILogger, file_logger: logging.Logger):
        self.ui = ui
        self.f = file_logger

    def debug(self, msg: str, **kwargs) -> None:
        try:
            self.ui.debug(msg, **kwargs)
        except Exception:
            pass
        try:
            if kwargs:
                msg = f"{msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            self.f.debug(msg)
        except Exception:
            pass

    def info(self, msg: str, **kwargs) -> None:
        try:
            self.ui.info(msg, **kwargs)
        except Exception:
            pass
        try:
            if kwargs:
                msg = f"{msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            self.f.info(msg)
        except Exception:
            pass

    def warn(self, msg: str, **kwargs) -> None:
        self.warning(msg, **kwargs)

    def warning(self, msg: str, **kwargs) -> None:
        try:
            self.ui.warning(msg, **kwargs)
        except Exception:
            pass
        try:
            if kwargs:
                msg = f"{msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            self.f.warning(msg)
        except Exception:
            pass

    def error(self, msg: str, **kwargs) -> None:
        try:
            self.ui.error(msg, **kwargs)
        except Exception:
            pass
        try:
            if kwargs:
                msg = f"{msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            self.f.error(msg)
        except Exception:
            pass

    def critical(self, msg: str, **kwargs) -> None:
        try:
            self.ui.critical(msg, **kwargs)
        except Exception:
            try:
                self.ui.error(msg, **kwargs)
            except Exception:
                pass
        try:
            if kwargs:
                msg = f"{msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            self.f.critical(msg)
        except Exception:
            pass

    def exception(self, e: BaseException, msg: str = "", **kwargs) -> None:
        """Log exception with optional message and additional context."""
        try:
            self.ui.exception(e, msg)
        except Exception:
            pass
        try:
            full_msg = f"{msg}: {repr(e)}" if msg else f"Exception: {repr(e)}"
            if kwargs:
                full_msg = f"{full_msg} | " + " | ".join(f"{k}={v}" for k, v in kwargs.items())
            self.f.exception(full_msg)
        except Exception:
            try:
                self.f.error(f"Exception: {repr(e)}")
            except Exception:
                pass


# -------------------------
# File logger setup
# -------------------------

def setup_file_logger(
    log_path: str,
    *,
    name: str = "bot",
    level: int = logging.DEBUG,
    rotate: bool = True,
    max_bytes: int = 5_000_000,
    backup_count: int = 3,
    also_console: bool = False,
) -> logging.Logger:
    """
    Create a file logger without breaking other handlers.
    - Uses RotatingFileHandler when available.
    - Avoids clearing handlers of a global shared logger unexpectedly.
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False

    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)

    # Avoid duplicating handlers if called multiple times
    for h in list(logger.handlers):
        try:
            if isinstance(h, logging.FileHandler) and getattr(h, "baseFilename", "") == os.path.abspath(log_path):
                return logger
        except Exception:
            continue

    if rotate and RotatingFileHandler is not None:
        fh = RotatingFileHandler(log_path, maxBytes=int(max_bytes), backupCount=int(backup_count), encoding="utf-8")
    else:
        fh = logging.FileHandler(log_path, encoding="utf-8")

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    if also_console:
        ch = logging.StreamHandler()
        ch.setFormatter(fmt)
        logger.addHandler(ch)

    return logger


# -------------------------
# Sleep helpers
# -------------------------

def jitter_sleep_ms(ms: int, jitter: float = 0.15) -> None:
    """
    Sleep for ms with +/- jitter proportion.
    Example: ms=1000, jitter=0.15 => random in [850ms..1150ms]
    """
    try:
        base = max(0.0, float(ms) / 1000.0)
        j = max(0.0, float(jitter))
        if base <= 0:
            return
        lo = base * (1.0 - j)
        hi = base * (1.0 + j)
        time.sleep(max(0.0, random.uniform(lo, hi)))
    except Exception:
        time.sleep(max(0.0, float(ms) / 1000.0))


def make_client_order_id(prefix: str) -> str:
    """Generate exchange-safe, short-ish, unique client order ID."""
    r = random.randint(10**7, 10**8 - 1)
    return f"{prefix}-{int(time.time() * 1000)}-{r}"


# -------------------------
# Fear & Greed Index (cached with retry)
# -------------------------

_FG_CACHE = {"ts": 0.0, "val": 50}
_FG_LOCK = threading.Lock()


def _fetch_fear_greed_with_retry(
    timeout_sec: float = 3.0,
    retries: int = 2,
    backoff_factor: float = 1.5
) -> int:
    """Internal function to fetch Fear & Greed index with retry logic."""
    for attempt in range(retries + 1):
        try:
            url = "https://api.alternative.me/fng/?limit=1"
            req = urllib.request.Request(url, headers={"User-Agent": "CryptoBot/1.0"})
            with urllib.request.urlopen(req, timeout=float(timeout_sec)) as response:
                data = json.load(response)
                item0 = (data.get("data") or [{}])[0] if isinstance(data, dict) else {}
                val = int(item0.get("value") or 50)
                return int(clamp(val, 0, 100))
        except Exception as e:
            if attempt == retries:
                raise e
            time.sleep(backoff_factor ** attempt)
    return 50  # Fallback


def fetch_fear_greed(
    ttl_sec: int = 600,
    timeout_sec: float = 3.0,
    retries: int = 2,
    backoff_factor: float = 1.5
) -> int:
    """
    Fetch Fear & Greed index (0-100) via alternative.me with local TTL cache.
    
    Features:
      - TTL cache to avoid API spam/latency
      - Retry logic with exponential backoff
      - Returns 50 on error (neutral sentiment)
    """
    try:
        ttl = max(30, int(ttl_sec))
    except Exception:
        ttl = 600

    now = time.time()
    try:
        with _FG_LOCK:
            if (now - float(_FG_CACHE.get("ts", 0.0) or 0.0)) < ttl:
                return int(_FG_CACHE.get("val", 50) or 50)
    except Exception:
        pass

    val = 50
    try:
        val = _fetch_fear_greed_with_retry(timeout_sec, retries, backoff_factor)
    except Exception:
        val = 50

    try:
        with _FG_LOCK:
            _FG_CACHE["ts"] = float(now)
            _FG_CACHE["val"] = int(val)
    except Exception:
        pass

    return int(val)


# -------------------------
# Additional utility functions
# -------------------------

def format_duration(seconds: float) -> str:
    """Format duration in seconds to human-readable string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    elif seconds < 86400:
        return f"{seconds/3600:.1f}h"
    else:
        return f"{seconds/86400:.1f}d"


def parse_duration(duration_str: str) -> int:
    """Parse duration string like '1h30m' to seconds."""
    duration_str = duration_str.lower().strip()
    if duration_str.isdigit():
        return int(duration_str)
    
    seconds = 0
    current_num = ""
    
    for char in duration_str:
        if char.isdigit():
            current_num += char
        else:
            if current_num:
                num = int(current_num)
                if char == 's':
                    seconds += num
                elif char == 'm':
                    seconds += num * 60
                elif char == 'h':
                    seconds += num * 3600
                elif char == 'd':
                    seconds += num * 86400
                elif char == 'w':
                    seconds += num * 604800
                current_num = ""
    
    # Handle case where string ends with a number
    if current_num:
        seconds += int(current_num)
    
    return seconds


def get_memory_usage() -> Dict[str, float]:
    """Get current memory usage in MB (if psutil is available)."""
    try:
        import psutil
        process = psutil.Process(os.getpid())
        mem_info = process.memory_info()
        return {
            'rss_mb': mem_info.rss / 1024 / 1024,
            'vms_mb': mem_info.vms / 1024 / 1024,
            'percent': process.memory_percent()
        }
    except ImportError:
        return {'rss_mb': 0.0, 'vms_mb': 0.0, 'percent': 0.0}
    except Exception:
        return {'rss_mb': 0.0, 'vms_mb': 0.0, 'percent': 0.0}


class RateLimiter:
    """Simple rate limiter for API calls or other operations."""
    
    def __init__(self, calls_per_second: float = 1.0):
        self.calls_per_second = max(0.1, float(calls_per_second))
        self.min_interval = 1.0 / self.calls_per_second
        self.last_call = 0.0
        self.lock = threading.Lock()
    
    def wait(self) -> None:
        """Wait if necessary to maintain rate limit."""
        with self.lock:
            now = time.time()
            elapsed = now - self.last_call
            if elapsed < self.min_interval:
                time.sleep(self.min_interval - elapsed)
            self.last_call = time.time()


def truncate_string(s: str, max_len: int = 100, ellipsis: str = "...") -> str:
    """Truncate string to max length with ellipsis if needed."""
    if len(s) <= max_len:
        return s
    if len(ellipsis) >= max_len:
        return s[:max_len]
    return s[:max_len - len(ellipsis)] + ellipsis


def dict_to_safe_json(d: Dict[str, Any]) -> Dict[str, Any]:
    """Convert dictionary values to JSON-safe types (handles NaN, Infinity)."""
    def convert_value(v):
        if isinstance(v, float):
            if math.isnan(v) or math.isinf(v):
                return None
            return v
        elif isinstance(v, dict):
            return dict_to_safe_json(v)
        elif isinstance(v, (list, tuple)):
            return [convert_value(item) for item in v]
        else:
            return v
    
    return {k: convert_value(v) for k, v in d.items()}


# -------------------------
# Main execution guard
# -------------------------

if __name__ == "__main__":
    # Example usage
    print("Testing utility functions...")
    
    # Test time functions
    print(f"UTC timestamp: {now_utc_iso()}")
    
    # Test numeric functions
    print(f"Clamp 15 to [0, 10]: {clamp(15, 0, 10)}")
    print(f"Safe float 'abc': {safe_float('abc', 0.0)}")
    
    # Test logger setup
    test_logger = setup_file_logger(
        "test_log.log",
        name="test_logger",
        also_console=True
    )
    
    ui_logger = UILogger(maxsize=100)
    composite = CompositeLogger(ui_logger, test_logger)
    
    composite.info("Test message", user="test_user", action="start")
    
    # Test fear & greed
    print(f"Fear & Greed Index: {fetch_fear_greed()}")
    
    # Test duration formatting
    print(f"3600 seconds = {format_duration(3600)}")
    print(f"Parsed '1h30m' = {parse_duration('1h30m')} seconds")
    
    print("Test complete!")
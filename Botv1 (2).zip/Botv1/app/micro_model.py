from __future__ import annotations

import math
from typing import Any, Dict, List, Tuple, Optional

from .utils import clamp


def _safe_levels(levels: Any, depth: int) -> List[Tuple[float, float]]:
    out: List[Tuple[float, float]] = []
    if not levels:
        return out
    for it in list(levels)[: int(depth)]:
        try:
            px = float(it[0])
            amt = float(it[1])
            if not (px > 0 and math.isfinite(px) and math.isfinite(amt)):
                continue
            if amt <= 0:
                continue
            out.append((px, amt))
        except Exception:
            continue
    return out


def orderbook_metrics(ob: Dict[str, Any], depth: int = 10) -> Dict[str, float]:
    bids = _safe_levels(ob.get("bids"), depth)
    asks = _safe_levels(ob.get("asks"), depth)

    if not bids or not asks:
        return {
            "bid": float("nan"),
            "ask": float("nan"),
            "mid": float("nan"),
            "spread_bps": float("nan"),
            "imbalance": 0.0,
            "microprice": float("nan"),
            "bid_vol": 0.0,
            "ask_vol": 0.0,
        }

    bid = bids[0][0]
    ask = asks[0][0]
    mid = (bid + ask) / 2.0 if (bid > 0 and ask > 0) else float("nan")

    spread_bps = ((ask - bid) / mid) * 10_000 if (mid and mid > 0) else float("nan")

    bid_vol = sum(a for _, a in bids)
    ask_vol = sum(a for _, a in asks)
    denom = bid_vol + ask_vol
    imbalance = (bid_vol - ask_vol) / denom if denom > 0 else 0.0

    # microprice (orderbook imbalance weighted)
    micro = (ask * bid_vol + bid * ask_vol) / denom if denom > 0 else float("nan")

    return {
        "bid": float(bid),
        "ask": float(ask),
        "mid": float(mid),
        "spread_bps": float(spread_bps),
        "imbalance": float(imbalance),
        "microprice": float(micro),
        "bid_vol": float(bid_vol),
        "ask_vol": float(ask_vol),
    }


def maker_fill_probability(
    cfg: Dict[str, Any],
    side: str,
    distance_bps: float,
    atr_pct: float,
    imbalance: float,
) -> float:
    """
    Estimate maker fill probability.
    Improvements:
      - normalize distance by volatility (atr_pct)
      - imbalance bias optional
    """
    mm = cfg.get("micro_model") or {}
    k_d = float(mm.get("k_distance", 1.0))
    k_v = float(mm.get("k_vol", 1.0))

    # Convert ATR% to bps scale; floor to avoid div by 0
    vol_bps = max(1.0, float(atr_pct) * 10_000.0)

    # Effective distance: distance relative to volatility
    d_eff = max(0.0, float(distance_bps)) / vol_bps

    # Base probability decays with normalized distance and with absolute vol
    p = math.exp(-k_d * d_eff)
    p *= math.exp(-k_v * max(0.0, float(atr_pct)))

    if bool(mm.get("use_imbalance", True)):
        imb = float(imbalance)
        bias = 1.0 + 0.25 * (imb if side.lower() == "buy" else -imb)
        p *= clamp(bias, 0.75, 1.25)

    return float(clamp(p, 0.0, 1.0))


def expected_market_slippage_bps(
    ob: Dict[str, Any],
    side: str,
    qty: float,
    depth: int = 20,
    *,
    contract_size: Optional[float] = None,
) -> Dict[str, float]:
    """
    Estimate market slippage vs top-of-book for consuming depth.
    Returns dict with:
      - slippage_bps (float)
      - fill_ratio (0..1)
      - best (best px)
      - avg (avg execution px)
    """
    bids = _safe_levels(ob.get("bids"), depth)
    asks = _safe_levels(ob.get("asks"), depth)

    q = float(qty)
    if q <= 0 or not math.isfinite(q):
        return {"slippage_bps": float("nan"), "fill_ratio": 0.0, "best": float("nan"), "avg": float("nan")}

    # Optional conversion for futures contracts (if you use it)
    if contract_size and contract_size > 0:
        # Interpret qty as "contracts" and convert to base qty.
        q = q * float(contract_size)

    if side.lower() == "buy":
        book = asks
    else:
        book = bids

    if not book:
        return {"slippage_bps": float("nan"), "fill_ratio": 0.0, "best": float("nan"), "avg": float("nan")}

    best = float(book[0][0])
    if best <= 0:
        return {"slippage_bps": float("nan"), "fill_ratio": 0.0, "best": float("nan"), "avg": float("nan")}

    remaining = q
    cost = 0.0
    filled = 0.0

    for px, amt in book:
        take = min(remaining, amt)
        cost += take * px
        filled += take
        remaining -= take
        if remaining <= 1e-12:
            break

    if filled <= 0:
        return {"slippage_bps": float("nan"), "fill_ratio": 0.0, "best": best, "avg": float("nan")}

    avg = cost / filled
    fill_ratio = float(clamp(filled / q, 0.0, 1.0))

    if side.lower() == "buy":
        slip = (avg - best) / best * 10_000.0
    else:
        slip = (best - avg) / best * 10_000.0

    return {"slippage_bps": float(slip), "fill_ratio": float(fill_ratio), "best": float(best), "avg": float(avg)}

# app/llm_ollama.py
from __future__ import annotations

import json
import time
import threading
import re
import statistics
import hashlib
import random
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple, List, Deque
from collections import OrderedDict, deque
import concurrent.futures


# ============================================================================
# Utilități de bază
# ============================================================================

def _f(x: Any, default: float = 0.0) -> float:
    """Convert any value to float safely."""
    try:
        return float(x)
    except Exception:
        return float(default)


def _b(x: Any, default: bool = False) -> bool:
    """Convert any value to boolean safely."""
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    s = str(x).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


def _clamp(x: float, lo: float, hi: float) -> float:
    """Clamp a value between lo and hi."""
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def _is_finite(x: float) -> bool:
    """Check if a float is finite (not NaN or infinite)."""
    return (x == x) and (x not in (float("inf"), float("-inf")))


def _extract_json_from_markdown(text: str) -> str:
    """If output contains ```json ... ```, return inside block; else return original."""
    if not text:
        return ""
    t = text.strip()
    fence = "```"
    if fence not in t:
        return t
    
    # Try ```json ... ```
    idx = t.lower().find("```json")
    if idx >= 0:
        start = t.find("\n", idx)
        if start >= 0:
            end = t.find("```", start + 1)
            if end > start:
                return t[start:end].strip()
    
    # Try generic code fence
    idx = t.find("```")
    if idx >= 0:
        start = t.find("\n", idx)
        if start >= 0:
            end = t.find("```", start + 1)
            if end > start:
                return t[start:end].strip()
    return t


def _find_first_balanced_json_object(text: str) -> Optional[str]:
    """
    Find first balanced {...} object in text.
    Returns substring or None.
    """
    if not text:
        return None
    t = text
    n = len(t)
    i = 0
    while i < n:
        if t[i] != "{":
            i += 1
            continue
        depth = 0
        j = i
        in_str = False
        esc = False
        while j < n:
            ch = t[j]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        frag = t[i : j + 1]
                        return frag
            j += 1
        # no balanced object starting at i; continue search after i
        i += 1
    return None


def _try_parse_json(text: str) -> Optional[Dict[str, Any]]:
    """Parse JSON object (dict) from model output robustly."""
    if not text:
        return None

    t = _extract_json_from_markdown(text).strip()
    if not t:
        return None

    # Fast path: whole string is JSON
    try:
        obj = json.loads(t)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass

    # Balanced-braces extraction
    frag = _find_first_balanced_json_object(t)
    if frag:
        try:
            obj = json.loads(frag)
            return obj if isinstance(obj, dict) else None
        except Exception:
            return None

    return None


# ============================================================================
# Configurație cu validare
# ============================================================================

DEFAULT_SYSTEM_PROMPT = (
    "You are a risk-control assistant for an automated crypto trading bot.\n"
    "Given a trade candidate context, reply ONLY with a single JSON object.\n"
    "Schema:\n"
    "{\n"
    '  "allow_entries": true|false,\n'
    '  "score_mult": float (around 1.0),\n'
    '  "risk_mult": float (around 1.0),\n'
    '  "sentiment_score": float in [-1,1],\n'
    '  "reasons": ["short", "strings"],\n'
    '  "confidence": float in [0,1]\n'
    "}\n"
    "Do not include any other text.\n"
    "Keep reasons concise.\n"
)


@dataclass
class OllamaConfig:
    """Configuration for OllamaAdvisor with validation."""
    enabled: bool = False
    base_url: str = "http://127.0.0.1:11434"
    model: str = "llama3.2:3b"
    timeout_sec: float = 20.0
    temperature: float = 0.1
    max_tokens: int = 256
    cache_sec: float = 10.0
    min_interval_sec: float = 0.0
    max_retries: int = 2
    retry_backoff_ms: int = 120
    cooldown_on_error_sec: float = 10.0
    score_mult_min: float = 0.70
    score_mult_max: float = 1.30
    risk_mult_min: float = 0.70
    risk_mult_max: float = 1.20
    min_confidence: float = 0.0
    system_prompt: str = DEFAULT_SYSTEM_PROMPT
    include_equity: bool = False
    include_open_positions: bool = True
    max_cache_size: int = 512
    failure_threshold: int = 5
    circuit_breaker_timeout: float = 60.0

    @classmethod
    def from_dict(cls, config: Dict[str, Any]) -> "OllamaConfig":
        """Create and validate configuration from dictionary."""
        llm = config.get("llm") or {}
        sub = llm.get("ollama") or {}
        policy = llm.get("policy") or {}

        # Extract values with defaults
        enabled = _b(llm.get("enabled"), False) and _b(sub.get("enabled", True), True)
        base_url = str(sub.get("base_url") or sub.get("host") or "http://127.0.0.1:11434")
        model = str(sub.get("model") or "llama3.2:3b")
        
        # Validate base_url
        if not base_url.startswith(("http://", "https://")):
            raise ValueError("base_url must start with http:// or https://")
        
        # Validate temperature
        temperature = _f(sub.get("temperature"), 0.1)
        if temperature < 0 or temperature > 2:
            raise ValueError("temperature must be between 0 and 2")
        
        # Extract other values with validation
        timeout_sec = max(1.0, _f(sub.get("timeout_sec"), 20.0))
        max_tokens = max(1, int(sub.get("max_tokens") or 256))
        cache_sec = max(0, _f(sub.get("cache_sec"), 10.0))
        min_interval_sec = max(0, _f(sub.get("min_interval_sec"), 
                                  _f(llm.get("min_interval_sec"), 0.0)))
        
        max_retries = max(0, int(sub.get("max_retries") or llm.get("max_retries") or 2))
        retry_backoff_ms = max(0, int(sub.get("retry_backoff_ms") or 
                                     llm.get("retry_backoff_ms") or 120))
        cooldown_on_error_sec = max(0, _f(sub.get("cooldown_on_error_sec"),
                                        _f(llm.get("cooldown_on_error_sec"), 10.0)))
        
        score_mult_min = max(0, _f(policy.get("score_mult_min"), 0.70))
        score_mult_max = max(score_mult_min, _f(policy.get("score_mult_max"), 1.30))
        risk_mult_min = max(0, _f(policy.get("risk_mult_min"), 0.70))
        risk_mult_max = max(risk_mult_min, _f(policy.get("risk_mult_max"), 1.20))
        min_confidence = _clamp(_f(policy.get("min_confidence"), 0.0), 0.0, 1.0)
        
        system_prompt = str(sub.get("system_prompt") or DEFAULT_SYSTEM_PROMPT)
        
        include_equity = _b(sub.get("include_equity"), 
                           _b(llm.get("include_equity"), False))
        include_open_positions = _b(sub.get("include_open_positions"),
                                   _b(llm.get("include_open_positions"), True))
        
        max_cache_size = max(1, int(sub.get("max_cache_size") or 512))
        failure_threshold = max(1, int(sub.get("failure_threshold") or 5))
        circuit_breaker_timeout = max(1.0, _f(sub.get("circuit_breaker_timeout"), 60.0))

        return cls(
            enabled=bool(enabled),
            base_url=base_url,
            model=model,
            timeout_sec=timeout_sec,
            temperature=temperature,
            max_tokens=max_tokens,
            cache_sec=cache_sec,
            min_interval_sec=min_interval_sec,
            max_retries=max_retries,
            retry_backoff_ms=retry_backoff_ms,
            cooldown_on_error_sec=cooldown_on_error_sec,
            score_mult_min=score_mult_min,
            score_mult_max=score_mult_max,
            risk_mult_min=risk_mult_min,
            risk_mult_max=risk_mult_max,
            min_confidence=min_confidence,
            system_prompt=system_prompt,
            include_equity=include_equity,
            include_open_positions=include_open_positions,
            max_cache_size=max_cache_size,
            failure_threshold=failure_threshold,
            circuit_breaker_timeout=circuit_breaker_timeout
        )


# ============================================================================
# LRU Cache
# ============================================================================

class LRUCache:
    """LRU Cache with expiry time."""
    def __init__(self, max_size: int = 512):
        self.max_size = max_size
        self._cache = OrderedDict()
        self._lock = threading.RLock()
    
    def get(self, key: str) -> Optional[Tuple[float, Any]]:
        """Get value from cache if not expired."""
        with self._lock:
            if key in self._cache:
                until, value = self._cache[key]
                # Move to end (recently used)
                self._cache.move_to_end(key)
                return until, value
            return None
    
    def set(self, key: str, until: float, value: Any):
        """Set value in cache with expiry time."""
        with self._lock:
            self._cache[key] = (until, value)
            self._cache.move_to_end(key)
            self._cleanup()
    
    def _cleanup(self):
        """Remove expired entries and trim if needed."""
        now = time.time()
        
        # Remove expired
        keys_to_remove = []
        for key, (until, _) in list(self._cache.items()):
            if now >= until:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            self._cache.pop(key, None)
        
        # Trim if still too large
        while len(self._cache) > self.max_size:
            self._cache.popitem(last=False)
    
    def clear(self):
        """Clear all cache entries."""
        with self._lock:
            self._cache.clear()
    
    def size(self) -> int:
        """Get current cache size."""
        with self._lock:
            return len(self._cache)
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            now = time.time()
            expired = 0
            for until, _ in self._cache.values():
                if now >= until:
                    expired += 1
            
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "expired_entries": expired,
                "utilization": len(self._cache) / self.max_size if self.max_size > 0 else 0
            }


# ============================================================================
# Circuit Breaker
# ============================================================================

class CircuitBreaker:
    """Circuit breaker for handling repeated failures."""
    def __init__(self, failure_threshold: int = 5, reset_timeout: float = 60.0):
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self.failure_count = 0
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self._lock = threading.RLock()
    
    def record_success(self):
        """Record a successful execution."""
        with self._lock:
            self.failure_count = 0
            self.state = "CLOSED"
    
    def record_failure(self):
        """Record a failed execution."""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
    
    def can_execute(self) -> bool:
        """Check if execution is allowed."""
        with self._lock:
            if self.state == "CLOSED":
                return True
            
            if self.state == "OPEN":
                # Check if enough time has passed for reset
                if time.time() - self.last_failure_time > self.reset_timeout:
                    self.state = "HALF_OPEN"
                    return True
                return False
            
            # HALF_OPEN - allow one attempt for testing
            return True
    
    def get_state(self) -> str:
        """Get current circuit breaker state."""
        with self._lock:
            return self.state
    
    def stats(self) -> Dict[str, Any]:
        """Get circuit breaker statistics."""
        with self._lock:
            return {
                "state": self.state,
                "failure_count": self.failure_count,
                "last_failure_time": self.last_failure_time,
                "reset_timeout": self.reset_timeout,
                "failure_threshold": self.failure_threshold,
                "is_open": self.state == "OPEN"
            }


# ============================================================================
# Token Bucket Rate Limiter
# ============================================================================

class TokenBucketRateLimiter:
    """Token bucket rate limiter."""
    def __init__(self, tokens_per_second: float, bucket_size: int):
        self.tokens_per_second = tokens_per_second
        self.bucket_size = bucket_size
        self.tokens = bucket_size
        self.last_update = time.time()
        self._lock = threading.RLock()
    
    def can_acquire(self, tokens: int = 1) -> bool:
        """Check if tokens can be acquired."""
        with self._lock:
            now = time.time()
            elapsed = now - self.last_update
            
            # Refill tokens
            new_tokens = elapsed * self.tokens_per_second
            self.tokens = min(self.bucket_size, self.tokens + new_tokens)
            self.last_update = now
            
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False
    
    def wait_until_available(self, tokens: int = 1, timeout: float = 1.0) -> bool:
        """Wait until tokens are available."""
        start = time.time()
        while time.time() - start < timeout:
            if self.can_acquire(tokens):
                return True
            time.sleep(0.01)
        return False
    
    def stats(self) -> Dict[str, Any]:
        """Get rate limiter statistics."""
        with self._lock:
            return {
                "tokens_per_second": self.tokens_per_second,
                "bucket_size": self.bucket_size,
                "current_tokens": self.tokens,
                "utilization": 1.0 - (self.tokens / self.bucket_size) if self.bucket_size > 0 else 0,
                "last_update": self.last_update
            }


# ============================================================================
# Metrics Collector
# ============================================================================

@dataclass
class Metrics:
    """Metrics collector for monitoring."""
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    parse_errors: int = 0
    http_errors: int = 0
    rate_limit_hits: int = 0
    timeouts: int = 0
    circuit_breaker_blocks: int = 0
    
    # Latency history
    latencies_ms: Deque[float] = field(default_factory=lambda: deque(maxlen=100))
    
    # Error tracking
    recent_errors: Deque[str] = field(default_factory=lambda: deque(maxlen=20))
    
    def record_latency(self, latency_ms: float):
        """Record a latency measurement."""
        self.latencies_ms.append(latency_ms)
    
    def record_error(self, error: str):
        """Record an error."""
        self.recent_errors.append(f"{time.time()}: {error}")
    
    def get_latency_stats(self) -> Dict[str, float]:
        """Get latency statistics."""
        if not self.latencies_ms:
            return {}
        
        latencies = list(self.latencies_ms)
        try:
            p95 = statistics.quantiles(latencies, n=20)[18] if len(latencies) >= 5 else 0
            p99 = statistics.quantiles(latencies, n=100)[98] if len(latencies) >= 5 else 0
        except Exception:
            p95 = p99 = 0
        
        return {
            "avg": statistics.mean(latencies) if latencies else 0,
            "p50": statistics.median(latencies) if latencies else 0,
            "p95": p95,
            "p99": p99,
            "min": min(latencies) if latencies else 0,
            "max": max(latencies) if latencies else 0,
        }
    
    def get_success_rate(self) -> float:
        """Calculate success rate."""
        total = self.successful_calls + self.failed_calls
        return self.successful_calls / total if total > 0 else 0.0
    
    def get_cache_hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.cache_hits + self.cache_misses
        return self.cache_hits / total if total > 0 else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "total_calls": self.total_calls,
            "successful_calls": self.successful_calls,
            "failed_calls": self.failed_calls,
            "success_rate": self.get_success_rate(),
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate": self.get_cache_hit_rate(),
            "parse_errors": self.parse_errors,
            "http_errors": self.http_errors,
            "rate_limit_hits": self.rate_limit_hits,
            "timeouts": self.timeouts,
            "circuit_breaker_blocks": self.circuit_breaker_blocks,
            "latency_stats": self.get_latency_stats(),
            "recent_errors": list(self.recent_errors)[-5:],  # Last 5 errors
        }


# ============================================================================
# Main OllamaAdvisor Class
# ============================================================================

@dataclass
class OllamaAdvisor:
    """Main advisor class for Ollama integration."""
    config: OllamaConfig
    
    # Components
    cache: LRUCache = field(init=False)
    metrics: Metrics = field(default_factory=Metrics)
    circuit_breaker: CircuitBreaker = field(init=False)
    rate_limiter: Optional[TokenBucketRateLimiter] = field(default=None, init=False)
    
    # Internal state
    _down_until: float = 0.0
    _last_call_ts: float = 0.0
    _lock: threading.RLock = field(default_factory=threading.RLock)
    
    def __post_init__(self):
        """Initialize components after dataclass creation."""
        # Initialize cache
        self.cache = LRUCache(max_size=self.config.max_cache_size)
        
        # Initialize circuit breaker
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=self.config.failure_threshold,
            reset_timeout=self.config.circuit_breaker_timeout
        )
        
        # Initialize rate limiter if needed
        if self.config.min_interval_sec > 0:
            tokens_per_second = 1.0 / self.config.min_interval_sec
            self.rate_limiter = TokenBucketRateLimiter(
                tokens_per_second=tokens_per_second,
                bucket_size=5  # Allow small burst
            )
    
    def _endpoint(self) -> str:
        """Get the generate endpoint URL."""
        return self.config.base_url.rstrip("/") + "/api/generate"
    
    def _tags_endpoint(self) -> str:
        """Get the tags endpoint URL."""
        return self.config.base_url.rstrip("/") + "/api/tags"
    
    def stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        with self._lock:
            base_stats = {
                "enabled": bool(self.config.enabled),
                "base_url": str(self.config.base_url),
                "model": str(self.config.model),
                "config": {
                    "timeout_sec": float(self.config.timeout_sec),
                    "temperature": float(self.config.temperature),
                    "cache_sec": float(self.config.cache_sec),
                    "min_interval_sec": float(self.config.min_interval_sec),
                },
                "down_until_ts": float(self._down_until),
                "last_call_ts": float(self._last_call_ts),
            }
            
            # Merge all metrics
            all_stats = {
                **base_stats,
                **self.metrics.to_dict(),
                "cache_stats": self.cache.stats(),
                "circuit_breaker": self.circuit_breaker.stats(),
                "rate_limiter": self.rate_limiter.stats() if self.rate_limiter else None,
            }
            return all_stats
    
    def healthcheck(self) -> bool:
        """Check if Ollama server is reachable."""
        try:
            import requests
            r = requests.get(self._tags_endpoint(), 
                           timeout=min(5.0, float(self.config.timeout_sec)))
            return bool(r.ok)
        except Exception:
            return False
    
    def _neutral(self, reason: str) -> Dict[str, Any]:
        """Return a neutral/default response."""
        return {
            "allow_entries": True,
            "score_mult": 1.0,
            "risk_mult": 1.0,
            "sentiment_score": 0.0,
            "confidence": 0.0,
            "reason": str(reason),
            "reasons": [],
            "timestamp": time.time(),
        }
    
    def _validate_and_sanitize_context(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and sanitize context for safety."""
        sanitized = {}
        
        # Required fields
        required_fields = ["symbol", "side", "price"]
        for field in required_fields:
            if field not in ctx:
                raise ValueError(f"Missing required field: {field}")
        
        # Sanitize symbol (only alphanumeric and :, -, _)
        symbol = str(ctx.get("symbol", "")).strip().upper()
        if not re.match(r'^[A-Z0-9:\-_]+$', symbol):
            raise ValueError(f"Invalid symbol format: {symbol}")
        sanitized["symbol"] = symbol
        
        # Validate side
        side = str(ctx.get("side", "")).lower()
        if side not in ("buy", "sell", "long", "short"):
            raise ValueError(f"Invalid side: {side}")
        sanitized["side"] = side
        
        # Validate price
        price = _f(ctx.get("price"), 0.0)
        if price <= 0:
            raise ValueError(f"Invalid price: {price}")
        sanitized["price"] = price
        
        # Optional fields with validation
        optional_fields = {
            "signal": str,
            "strength": float,
            "trend": str,
            "atr_pct": float,
            "spread_bps": float,
            "vol_24h_usd": float,
            "funding": float,
            "risk_per_trade": float,
            "timeframe": str,
            "signal_timeframe": str,
        }
        
        for field, field_type in optional_fields.items():
            if field in ctx:
                try:
                    if field_type == float:
                        sanitized[field] = _f(ctx[field])
                    else:
                        sanitized[field] = field_type(ctx[field])
                except Exception:
                    pass  # Skip invalid optional fields
        
        return sanitized
    
    def _build_cache_key(self, ctx: Dict[str, Any]) -> str:
        """Build a cache key from context."""
        sym = ctx.get("symbol", "")
        side = ctx.get("side", "")
        tf = ctx.get("timeframe") or ctx.get("signal_timeframe") or ""
        
        # Create deterministic key
        key_data = f"{sym}|{side}|{tf}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]
    
    def _build_prompt(self, ctx: Dict[str, Any]) -> str:
        """Build prompt from context."""
        # Keep prompt compact and stable
        safe = {
            "symbol": ctx.get("symbol"),
            "side": ctx.get("side"),
            "price": ctx.get("price"),
            "signal": ctx.get("signal"),
            "strength": ctx.get("strength"),
            "trend": ctx.get("trend"),
            "atr_pct": ctx.get("atr_pct"),
            "spread_bps": ctx.get("spread_bps"),
            "vol_24h_usd": ctx.get("vol_24h_usd"),
            "funding": ctx.get("funding"),
            "risk_per_trade": ctx.get("risk_per_trade"),
        }
        
        if self.config.include_open_positions:
            safe["open_positions"] = ctx.get("open_positions")
        if self.config.include_equity:
            safe["equity"] = ctx.get("equity")
        
        return (
            (self.config.system_prompt or DEFAULT_SYSTEM_PROMPT).strip()
            + "\n\nCONTEXT:\n"
            + json.dumps(safe, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
            + "\n\nREPLY_JSON_ONLY.\n"
        )
    
    def _sleep_backoff_with_jitter(self, attempt: int) -> None:
        """Exponential backoff with jitter to avoid thundering herd."""
        try:
            base = max(0, int(self.config.retry_backoff_ms))
            # Exponential backoff with cap
            delay_ms = min(2000, base * (2 ** max(0, attempt - 1)))
            
            # Add jitter (±20%)
            jitter = random.uniform(0.8, 1.2)
            actual_delay_ms = delay_ms * jitter
            
            time.sleep(actual_delay_ms / 1000.0)
        except Exception:
            time.sleep(0.1)  # Fallback
    
    def _normalize_obj(self, obj: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize and validate response from model."""
        allow = bool(obj.get("allow_entries", True))

        score_mult = _f(obj.get("score_mult", 1.0), 1.0)
        risk_mult = _f(obj.get("risk_mult", 1.0), 1.0)
        sent = _f(obj.get("sentiment_score", 0.0), 0.0)
        conf = _f(obj.get("confidence", 0.0), 0.0)

        if not _is_finite(score_mult):
            score_mult = 1.0
        if not _is_finite(risk_mult):
            risk_mult = 1.0
        if not _is_finite(sent):
            sent = 0.0
        if not _is_finite(conf):
            conf = 0.0

        score_mult = _clamp(float(score_mult), 
                           float(self.config.score_mult_min), 
                           float(self.config.score_mult_max))
        risk_mult = _clamp(float(risk_mult), 
                          float(self.config.risk_mult_min), 
                          float(self.config.risk_mult_max))
        sent = _clamp(float(sent), -1.0, 1.0)
        conf = _clamp(float(conf), 0.0, 1.0)

        reasons = obj.get("reasons")
        if not isinstance(reasons, list):
            reasons = []
        reasons = [str(x).strip()[:120] for x in reasons if str(x).strip()][:8]

        # Apply min_confidence gate
        if float(conf) < float(self.config.min_confidence):
            return {
                "allow_entries": True,
                "score_mult": 1.0,
                "risk_mult": 1.0,
                "sentiment_score": float(sent),
                "confidence": float(conf),
                "reason": "ollama_low_confidence",
                "reasons": reasons,
                "timestamp": time.time(),
            }

        # Strict veto semantics
        if not allow:
            return {
                "allow_entries": False,
                "score_mult": 0.0,
                "risk_mult": 0.0,
                "sentiment_score": float(sent),
                "confidence": float(conf),
                "reason": "ollama_veto",
                "reasons": reasons or ["ollama_veto"],
                "timestamp": time.time(),
            }

        return {
            "allow_entries": True,
            "score_mult": float(score_mult),
            "risk_mult": float(risk_mult),
            "sentiment_score": float(sent),
            "confidence": float(conf),
            "reason": "ollama_ok",
            "reasons": reasons,
            "timestamp": time.time(),
        }
    
    def _process_single(self, ctx: Dict[str, Any], cache_key: str) -> Dict[str, Any]:
        """Process a single context (internal method)."""
        now = time.time()
        
        # Check cache
        cache_hit = self.cache.get(cache_key)
        if cache_hit:
            until, value = cache_hit
            if now < until:
                self.metrics.cache_hits += 1
                return dict(value)
            else:
                self.metrics.cache_misses += 1
        else:
            self.metrics.cache_misses += 1
        
        # Build prompt
        prompt = self._build_prompt(ctx)
        payload = {
            "model": self.config.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": float(self.config.temperature),
                "num_predict": int(self.config.max_tokens),
            },
        }
        
        # Retry loop
        last_exc = None
        import requests
        
        for attempt in range(max(1, int(self.config.max_retries) + 1)):
            t1 = time.time()
            try:
                r = requests.post(self._endpoint(), json=payload, 
                                timeout=float(self.config.timeout_sec))
                latency_ms = (time.time() - t1) * 1000.0
                self.metrics.record_latency(latency_ms)
                
                if not r.ok:
                    self.metrics.http_errors += 1
                    self.metrics.record_error(f"HTTP {r.status_code}")
                    
                    # Cooldown on server errors
                    if int(r.status_code) >= 500:
                        with self._lock:
                            self._down_until = time.time() + float(self.config.cooldown_on_error_sec)
                    
                    # Retry on 5xx
                    if int(r.status_code) >= 500 and attempt < int(self.config.max_retries):
                        self._sleep_backoff_with_jitter(attempt)
                        continue
                    
                    return self._neutral(f"ollama_http_{r.status_code}")
                
                # Parse response
                data = r.json() if r.headers.get("content-type", "").startswith("application/json") else None
                text = ""
                if isinstance(data, dict):
                    text = str(data.get("response") or "")
                else:
                    text = str(r.text or "")
                
                obj = _try_parse_json(text)
                if not obj:
                    self.metrics.parse_errors += 1
                    self.metrics.record_error("Parse failed")
                    
                    # Retry once for parse failure
                    if attempt < int(self.config.max_retries):
                        self._sleep_backoff_with_jitter(attempt)
                        continue
                    return self._neutral("ollama_parse_fail")
                
                out = self._normalize_obj(obj)
                
                # Store in cache
                until = time.time() + float(self.config.cache_sec)
                self.cache.set(cache_key, until, dict(out))
                
                # Record success
                self.metrics.successful_calls += 1
                self.circuit_breaker.record_success()
                
                return out
                
            except requests.exceptions.Timeout:
                self.metrics.timeouts += 1
                self.metrics.record_error("Request timeout")
                
                if attempt < int(self.config.max_retries):
                    self._sleep_backoff_with_jitter(attempt)
                    continue
                last_exc = "Timeout"
                break
                
            except Exception as e:
                self.metrics.record_error(f"{type(e).__name__}: {str(e)[:100]}")
                last_exc = e
                
                # Record failure in circuit breaker
                self.circuit_breaker.record_failure()
                
                # Set cooldown
                with self._lock:
                    self._down_until = time.time() + float(self.config.cooldown_on_error_sec)
                
                # Retry on exception
                if attempt < int(self.config.max_retries):
                    self._sleep_backoff_with_jitter(attempt)
                    continue
                break
        
        # Final fallback
        self.metrics.failed_calls += 1
        return self._neutral("ollama_exception" if last_exc is not None else "ollama_error")
    
    def advise(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Main method to get advice for a trading context."""
        # Update metrics
        self.metrics.total_calls += 1
        
        # Check if enabled
        if not self.config.enabled:
            return self._neutral("ollama_disabled")
        
        # Check circuit breaker
        if not self.circuit_breaker.can_execute():
            self.metrics.circuit_breaker_blocks += 1
            return self._neutral("circuit_breaker_open")
        
        # Check rate limiter
        if self.rate_limiter and not self.rate_limiter.can_acquire():
            self.metrics.rate_limit_hits += 1
            return self._neutral("ollama_rate_limited")
        
        # Validate and sanitize context
        try:
            sanitized_ctx = self._validate_and_sanitize_context(ctx)
        except ValueError as e:
            return self._neutral(f"invalid_context: {str(e)[:50]}")
        
        # Check global cooldown
        now = time.time()
        with self._lock:
            if now < float(self._down_until):
                # Try cache first
                cache_key = self._build_cache_key(sanitized_ctx)
                cache_hit = self.cache.get(cache_key)
                if cache_hit:
                    until, value = cache_hit
                    if now < until:
                        self.metrics.cache_hits += 1
                        return dict(value)
                return self._neutral("ollama_down_cooldown")
        
        # Process the request
        cache_key = self._build_cache_key(sanitized_ctx)
        result = self._process_single(sanitized_ctx, cache_key)
        
        # Update last call timestamp
        with self._lock:
            self._last_call_ts = time.time()
        
        return result
    
    def advise_with_timeout(self, ctx: Dict[str, Any], timeout: Optional[float] = None) -> Dict[str, Any]:
        """Advise with explicit timeout for blocking operations."""
        timeout = timeout or self.config.timeout_sec
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self.advise, ctx)
            try:
                result = future.result(timeout=timeout)
                return result
            except concurrent.futures.TimeoutError:
                self.metrics.timeouts += 1
                return self._neutral("ollama_timeout")
    
    def batch_advise(self, contexts: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """Process multiple contexts efficiently."""
        if not self.config.enabled:
            return {"results": [self._neutral("ollama_disabled") for _ in contexts]}
        
        results = []
        
        # Pre-compute cache keys
        cache_keys = []
        for ctx in contexts:
            try:
                sanitized = self._validate_and_sanitize_context(ctx)
                cache_keys.append(self._build_cache_key(sanitized))
            except ValueError:
                cache_keys.append(None)
        
        # Check cache for all
        now = time.time()
        for i, (ctx, cache_key) in enumerate(zip(contexts, cache_keys)):
            if cache_key is None:
                results.append(self._neutral("invalid_context"))
                continue
            
            cache_hit = self.cache.get(cache_key)
            if cache_hit:
                until, value = cache_hit
                if now < until:
                    self.metrics.cache_hits += 1
                    results.append(dict(value))
                else:
                    results.append(None)
            else:
                results.append(None)
        
        # Process only those not in cache
        for i, (ctx, cached_result, cache_key) in enumerate(zip(contexts, results, cache_keys)):
            if cached_result is None and cache_key is not None:
                try:
                    sanitized = self._validate_and_sanitize_context(ctx)
                    results[i] = self._process_single(sanitized, cache_key)
                except ValueError:
                    results[i] = self._neutral("invalid_context")
        
        return {"results": results}
    
    def clear_cache(self):
        """Clear the cache."""
        self.cache.clear()
    
    def reset_metrics(self):
        """Reset all metrics."""
        self.metrics = Metrics()
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=self.config.failure_threshold,
            reset_timeout=self.config.circuit_breaker_timeout
        )


# ============================================================================
# Factory Function
# ============================================================================

def from_cfg(cfg: Dict[str, Any]) -> OllamaAdvisor:
    """Create OllamaAdvisor from configuration dictionary."""
    config = OllamaConfig.from_dict(cfg)
    return OllamaAdvisor(config=config)


# ============================================================================
# Optional: OpenTelemetry integration (if available)
# ============================================================================

try:
    from opentelemetry import trace
    from opentelemetry.trace import Status, StatusCode
    
    tracer = trace.get_tracer(__name__)
    
    def advise_with_tracing(advisor: OllamaAdvisor, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Wrapper for advise with OpenTelemetry tracing."""
        with tracer.start_as_current_span("ollama.advise") as span:
            span.set_attribute("symbol", ctx.get("symbol", ""))
            span.set_attribute("side", ctx.get("side", ""))
            span.set_attribute("price", ctx.get("price", 0))
            
            try:
                result = advisor.advise(ctx)
                span.set_status(Status(StatusCode.OK))
                span.set_attribute("allow_entries", result.get("allow_entries", False))
                span.set_attribute("score_mult", result.get("score_mult", 1.0))
                span.set_attribute("risk_mult", result.get("risk_mult", 1.0))
                span.set_attribute("confidence", result.get("confidence", 0.0))
                span.set_attribute("reason", result.get("reason", ""))
                return result
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                return advisor._neutral("ollama_error")
    
    # Monkey patch if needed
    # OllamaAdvisor.advise_with_tracing = advise_with_tracing
    
except ImportError:
    # OpenTelemetry not available, provide dummy function
    def advise_with_tracing(advisor: OllamaAdvisor, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback if OpenTelemetry is not available."""
        return advisor.advise(ctx)
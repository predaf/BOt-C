from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Callable
import time
import json


@dataclass
class AlertRule:
    id: str
    symbol: str
    kind: str  # "price_cross" | "volume_over" | "price_change_percent" | "rsi_overbought" | ...
    params: Dict[str, Any]
    severity: str = "info"  # info|warn|critical
    enabled: bool = True
    cooldown_sec: int = 300  # throttling
    last_fired_ts: float = 0.0
    fired_count: int = 0
    # For edge triggering
    last_state: Optional[bool] = None
    # New fields for enhanced features
    max_retries: int = 3
    retry_count: int = 0
    escalation_level: str = "primary"  # primary → secondary → manager
    direction: str = "above"  # For price_cross: "above" or "below"


class AlertSystem:
    """
    Enhanced alert engine with:
    - Multiple alert types
    - Persistence
    - Retry and escalation
    - Symbol-level throttling
    - Performance monitoring
    - Alert templates
    - Testing utilities
    """

    def __init__(self, notifier: Any, log: Any):
        self.notifier = notifier
        self.log = log
        self._rules: Dict[str, AlertRule] = {}  # id -> rule
        self._symbol_cooldowns: Dict[str, float] = {}
        
        # Performance metrics
        self._metrics = {
            "total_ticks": 0,
            "total_alerts": 0,
            "rule_evaluations": 0,
            "start_time": time.time()
        }
        
        # Alert templates
        self._templates = {
            "price_cross": {
                "above": "📈 {symbol} crossed above {level} at {price:.2f}",
                "below": "📉 {symbol} crossed below {level} at {price:.2f}"
            },
            "volume_over": "📊 {symbol} volume spike: {volume:.0f} > {threshold:.0f}",
            "price_change_percent": "📈 {symbol} changed {change_percent:+.1f}% from {reference_price:.2f} to {price:.2f}",
            "default": "⚠️ Alert: {symbol} - {kind}"
        }

    # ----------------------------
    # Public: setup / CRUD
    # ----------------------------
    def setup_price_alerts(self, symbol: str, price_levels: List[float], 
                          direction: str = "above", severity: str = "info") -> Dict[str, Any]:
        """
        Backwards-compatible builder.
        Registers rules: price_cross for each level.
        """
        levels = [float(x) for x in price_levels]
        created: List[str] = []
        for lvl in levels:
            rid = f"{symbol}:price_cross:{lvl}:{direction}"
            self._rules[rid] = AlertRule(
                id=rid,
                symbol=symbol,
                kind="price_cross",
                params={"level": float(lvl)},
                severity=severity,
                cooldown_sec=300,
                direction=direction
            )
            created.append(rid)
        return {"symbol": symbol, "levels": levels, "created": created}

    def setup_volume_alerts(self, symbol: str, volume_threshold: float, 
                           severity: str = "warn") -> Dict[str, Any]:
        """
        Backwards-compatible builder.
        Registers rule: volume_over.
        """
        thr = float(volume_threshold)
        rid = f"{symbol}:volume_over:{thr}"
        self._rules[rid] = AlertRule(
            id=rid,
            symbol=symbol,
            kind="volume_over",
            params={"threshold": thr},
            severity=severity,
            cooldown_sec=600,
        )
        return {"symbol": symbol, "volume_threshold": thr, "created": [rid]}
    
    def setup_price_change_alert(self, symbol: str, percent_threshold: float, 
                               reference_price: float, severity: str = "warn") -> Dict[str, Any]:
        """
        Setup alert for price change percentage.
        """
        rid = f"{symbol}:price_change_percent:{percent_threshold}"
        self._rules[rid] = AlertRule(
            id=rid,
            symbol=symbol,
            kind="price_change_percent",
            params={
                "percent_threshold": float(percent_threshold),
                "reference_price": float(reference_price)
            },
            severity=severity,
            cooldown_sec=300,
        )
        return {"symbol": symbol, "percent_threshold": percent_threshold, "created": [rid]}

    def list_rules(self, symbol: Optional[str] = None, 
                  enabled_only: bool = False) -> List[Dict[str, Any]]:
        out = []
        for r in self._rules.values():
            if symbol and r.symbol != symbol:
                continue
            if enabled_only and not r.enabled:
                continue
            out.append(asdict(r))
        return out

    def remove_rule(self, rule_id: str) -> bool:
        return self._rules.pop(rule_id, None) is not None

    def set_enabled(self, rule_id: str, enabled: bool) -> bool:
        r = self._rules.get(rule_id)
        if not r:
            return False
        r.enabled = bool(enabled)
        return True

    # ----------------------------
    # Public: evaluation
    # ----------------------------
    def process_tick(self, symbol: str, *, price: Optional[float] = None, 
                    volume: Optional[float] = None, ts: Optional[float] = None) -> List[Dict[str, Any]]:
        """
        Call this from your engine loop with latest price/volume.
        Returns list of fired alerts payloads.
        """
        now = float(ts if ts is not None else time.time())
        fired: List[Dict[str, Any]] = []
        
        # Update metrics
        self._metrics["total_ticks"] += 1
        
        # Global symbol cooldown check (prevent alert storms)
        if symbol in self._symbol_cooldowns:
            if now - self._symbol_cooldowns[symbol] < 60:  # 60 second global cooldown
                return fired

        for r in self._rules.values():
            if not r.enabled or r.symbol != symbol:
                continue

            self._metrics["rule_evaluations"] += 1
            should_fire = self._evaluate_rule(r, price=price, volume=volume)
            if should_fire is None:
                continue

            # Edge-triggering: if last_state is None -> init; else fire only on False->True
            if r.last_state is None:
                r.last_state = bool(should_fire)
                continue

            edge = (r.last_state is False) and (should_fire is True)
            r.last_state = bool(should_fire)

            if not edge:
                continue

            # Throttle/cooldown
            if r.last_fired_ts and (now - r.last_fired_ts) < float(r.cooldown_sec):
                continue

            r.last_fired_ts = now
            r.fired_count += 1
            r.retry_count = 0  # Reset retry count on successful fire

            payload = {
                "rule_id": r.id,
                "symbol": r.symbol,
                "kind": r.kind,
                "severity": r.severity,
                "ts": now,
                "params": r.params,
                "observed": {"price": price, "volume": volume},
                "count": r.fired_count,
                "message": self._format_alert_message(r, price, volume),
            }

            fired.append(payload)
            self._emit(payload)

        if fired:
            self._symbol_cooldowns[symbol] = now
            self._metrics["total_alerts"] += len(fired)

        return fired

    # ----------------------------
    # Enhanced Internals
    # ----------------------------
    def _evaluate_rule(self, r: AlertRule, *, price: Optional[float], 
                      volume: Optional[float]) -> Optional[bool]:
        if r.kind == "price_cross":
            if price is None:
                return None
            level = float(r.params.get("level", 0.0))
            direction = getattr(r, "direction", "above")
            
            if direction == "above":
                return float(price) >= level
            else:
                return float(price) <= level

        if r.kind == "volume_over":
            if volume is None:
                return None
            thr = float(r.params.get("threshold", 0.0))
            return float(volume) >= thr
        
        if r.kind == "price_change_percent":
            if price is None or "reference_price" not in r.params:
                return None
            reference_price = float(r.params["reference_price"])
            if reference_price == 0:
                return None
            change_percent = ((price - reference_price) / reference_price) * 100
            threshold = float(r.params.get("percent_threshold", 5.0))
            return abs(change_percent) >= threshold

        # Unknown rule kind: never fire, but keep safe
        return None

    def _try_notify(self, payload: Dict[str, Any]) -> bool:
        """Try to send notification, return success status"""
        try:
            n = self.notifier
            if not n:
                return False
            # common method names
            for fn_name in ("send", "notify", "push"):
                fn = getattr(n, fn_name, None)
                if callable(fn):
                    fn(payload)
                    return True
        except Exception:
            pass
        return False

    def _escalate_alert(self, payload: Dict[str, Any]) -> None:
        """Handle alert escalation when retries fail"""
        rule_id = payload["rule_id"]
        rule = self._rules.get(rule_id)
        if not rule:
            return
        
        escalation_msg = f"[ESCALATION] Alert {rule_id} failed after {rule.max_retries} retries"
        try:
            if self.log:
                self.log(f"{escalation_msg}. Current level: {rule.escalation_level}")
        except Exception:
            pass
        
        # In a real system, you would implement escalation logic here
        # e.g., send to different notifier, email admin, etc.

    def _emit(self, payload: Dict[str, Any]) -> None:
        # Log
        try:
            if self.log:
                self.log(f"[ALERT] {payload['severity'].upper()} {payload['symbol']} {payload['kind']} - {payload.get('message', '')}")
        except Exception:
            pass

        # Notify with retry logic
        rule_id = payload["rule_id"]
        rule = self._rules.get(rule_id)
        
        if not rule:
            return
        
        success = self._try_notify(payload)
        
        if not success and rule.retry_count < rule.max_retries:
            rule.retry_count += 1
            # Implement retry logic with exponential backoff
            backoff_time = min(2 ** rule.retry_count, 30)  # Cap at 30 seconds
            time.sleep(backoff_time)
            success = self._try_notify(payload)
        
        if not success:
            self._escalate_alert(payload)

    def _format_alert_message(self, rule: AlertRule, price: Optional[float], 
                             volume: Optional[float]) -> str:
        """Format alert message using templates"""
        if rule.kind == "price_cross":
            template = self._templates.get("price_cross", {})
            direction = getattr(rule, "direction", "above")
            message_template = template.get(direction, self._templates["default"])
            return message_template.format(
                symbol=rule.symbol,
                level=rule.params.get("level", 0),
                price=price or 0
            )
        
        elif rule.kind == "volume_over":
            message_template = self._templates.get("volume_over", self._templates["default"])
            return message_template.format(
                symbol=rule.symbol,
                volume=volume or 0,
                threshold=rule.params.get("threshold", 0)
            )
        
        elif rule.kind == "price_change_percent":
            message_template = self._templates.get("price_change_percent", self._templates["default"])
            reference_price = rule.params.get("reference_price", 0)
            change_percent = 0
            if reference_price and price:
                change_percent = ((price - reference_price) / reference_price) * 100
            return message_template.format(
                symbol=rule.symbol,
                change_percent=change_percent,
                reference_price=reference_price,
                price=price or 0
            )
        
        return self._templates["default"].format(
            symbol=rule.symbol,
            kind=rule.kind
        )

    # ----------------------------
    # Persistence Methods
    # ----------------------------
    def save_rules(self, filepath: str) -> bool:
        """Save rules to JSON file"""
        try:
            data = [asdict(rule) for rule in self._rules.values()]
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            return True
        except Exception as e:
            try:
                if self.log:
                    self.log(f"Failed to save rules: {e}")
            except Exception:
                pass
            return False

    def load_rules(self, filepath: str) -> bool:
        """Load rules from JSON file"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            
            for rule_data in data:
                # Convert string values back to appropriate types
                rule_data['last_fired_ts'] = float(rule_data.get('last_fired_ts', 0))
                rule_data['fired_count'] = int(rule_data.get('fired_count', 0))
                rule_data['enabled'] = bool(rule_data.get('enabled', True))
                rule_data['cooldown_sec'] = int(rule_data.get('cooldown_sec', 300))
                rule_data['max_retries'] = int(rule_data.get('max_retries', 3))
                rule_data['retry_count'] = int(rule_data.get('retry_count', 0))
                
                rule = AlertRule(**rule_data)
                self._rules[rule.id] = rule
            
            return True
        except Exception as e:
            try:
                if self.log:
                    self.log(f"Failed to load rules: {e}")
            except Exception:
                pass
            return False

    # ----------------------------
    # Testing Utilities
    # ----------------------------
    def test_rule(self, rule_id: str, test_price: Optional[float] = None, 
                 test_volume: Optional[float] = None) -> bool:
        """Test if a rule would fire with given values"""
        rule = self._rules.get(rule_id)
        if not rule:
            return False
        
        # Temporarily reset cooldown for testing
        original_last_fired = rule.last_fired_ts
        original_last_state = rule.last_state
        rule.last_fired_ts = 0
        rule.last_state = None
        
        result = self._evaluate_rule(rule, price=test_price, volume=test_volume)
        
        # Restore original state
        rule.last_fired_ts = original_last_fired
        rule.last_state = original_last_state
        
        return bool(result)
    
    def simulate_tick(self, symbol: str, price: float, volume: float = 0) -> List[Dict[str, Any]]:
        """Simulate a tick for testing without actual notifications"""
        # Temporarily replace notifier with a dummy
        original_notifier = self.notifier
        self.notifier = None
        
        result = self.process_tick(symbol, price=price, volume=volume)
        
        # Restore notifier
        self.notifier = original_notifier
        
        return result

    # ----------------------------
    # Metrics and Monitoring
    # ----------------------------
    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        uptime = time.time() - self._metrics["start_time"]
        active_rules = len([r for r in self._rules.values() if r.enabled])
        
        return {
            **self._metrics,
            "uptime_seconds": uptime,
            "alerts_per_second": self._metrics["total_alerts"] / uptime if uptime > 0 else 0,
            "ticks_per_second": self._metrics["total_ticks"] / uptime if uptime > 0 else 0,
            "active_rules": active_rules,
            "total_rules": len(self._rules),
            "symbol_cooldowns": len(self._symbol_cooldowns)
        }
    
    def reset_metrics(self) -> None:
        """Reset performance metrics (keep rules)"""
        self._metrics = {
            "total_ticks": 0,
            "total_alerts": 0,
            "rule_evaluations": 0,
            "start_time": time.time()
        }
        self._symbol_cooldowns.clear()
    
    def get_rule_stats(self, rule_id: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a specific rule"""
        rule = self._rules.get(rule_id)
        if not rule:
            return None
        
        return {
            "id": rule.id,
            "fired_count": rule.fired_count,
            "last_fired": rule.last_fired_ts,
            "last_fired_human": time.ctime(rule.last_fired_ts) if rule.last_fired_ts else "Never",
            "cooldown_remaining": max(0, rule.cooldown_sec - (time.time() - rule.last_fired_ts)) if rule.last_fired_ts else 0,
            "enabled": rule.enabled,
            "retry_count": rule.retry_count,
            "last_state": rule.last_state
        }

    # ----------------------------
    # Batch Operations
    # ----------------------------
    def enable_all_rules(self, symbol: Optional[str] = None) -> int:
        """Enable all rules (optionally for a specific symbol)"""
        count = 0
        for rule in self._rules.values():
            if symbol and rule.symbol != symbol:
                continue
            if not rule.enabled:
                rule.enabled = True
                count += 1
        return count
    
    def disable_all_rules(self, symbol: Optional[str] = None) -> int:
        """Disable all rules (optionally for a specific symbol)"""
        count = 0
        for rule in self._rules.values():
            if symbol and rule.symbol != symbol:
                continue
            if rule.enabled:
                rule.enabled = False
                count += 1
        return count
    
    def reset_rule_cooldowns(self, symbol: Optional[str] = None) -> int:
        """Reset cooldowns for all rules (optionally for a specific symbol)"""
        count = 0
        for rule in self._rules.values():
            if symbol and rule.symbol != symbol:
                continue
            if rule.last_fired_ts > 0:
                rule.last_fired_ts = 0
                count += 1
        return count

    # ----------------------------
    # Utility Methods
    # ----------------------------
    def clear_symbol_cooldown(self, symbol: str) -> None:
        """Clear the global cooldown for a symbol"""
        self._symbol_cooldowns.pop(symbol, None)
    
    def get_active_symbols(self) -> List[str]:
        """Get list of symbols with active rules"""
        symbols = set()
        for rule in self._rules.values():
            if rule.enabled:
                symbols.add(rule.symbol)
        return list(symbols)
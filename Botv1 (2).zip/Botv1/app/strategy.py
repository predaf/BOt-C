from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple, Union, Callable
from enum import Enum
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

from .indicators import ema, rsi, atr, donchian, regime_score, macd, bbands, volume_delta
from .utils import clamp


class SignalAction(Enum):
    BUY = "buy"
    SELL = "sell"
    HOLD = "hold"
    CLOSE = "close"  # New: Close existing position
    REDUCE = "reduce"  # New: Reduce position size


@dataclass
class Signal:
    symbol: str
    action: str  # buy|sell|hold|close|reduce
    strength: float = 0.0
    reason: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    confidence: float = 0.0  # 0-1 confidence score
    priority: int = 0  # Priority level (0=low, 5=high)

    def to_dict(self) -> Dict[str, Any]:
        """Convert signal to dictionary for serialization."""
        return {
            "symbol": self.symbol,
            "action": self.action,
            "strength": float(self.strength),
            "reason": str(self.reason),
            "confidence": float(self.confidence),
            "priority": int(self.priority),
            "timestamp": self.timestamp.isoformat(),
            "details": self.details,
        }


def _as_int(x: Any, default: int) -> int:
    """Safely convert to integer."""
    try:
        return int(x)
    except Exception:
        return int(default)


def _as_float(x: Any, default: float) -> float:
    """Safely convert to float."""
    try:
        v = float(x)
        return v
    except Exception:
        return float(default)


def _as_bool(x: Any, default: bool) -> bool:
    """Safely convert to boolean."""
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        return bool(x)
    if isinstance(x, str):
        return x.lower() in ("true", "yes", "1", "on")
    return bool(default)


class StrategyEngine:
    """
    Multi-signal rules engine (spot-friendly) with enhanced features.
    
    Features:
      - Multiple indicator voting system
      - Risk-aware signal generation
      - Multi-timeframe analysis
      - Volatility-adjusted signals
      - Sentiment integration
      - Pattern detection
      - Confidence scoring
    """

    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log
        self._signal_history: Dict[str, List[Signal]] = {}
        self._market_state_cache: Dict[str, Dict[str, Any]] = {}
        self._last_compute_time: Dict[str, datetime] = {}
        
        # Initialize components
        self._init_components()
        
    def _init_components(self) -> None:
        """Initialize strategy components from config."""
        self.strategy_config = self.cfg.get("strategies", {}) or {}
        self.risk_config = self.cfg.get("risk", {}) or {}
        self.signal_config = self.cfg.get("signal_thresholds", {}) or {}
        
        # Component weights
        self.component_weights = {
            "ema_cross": _as_float(self.strategy_config.get("ema_cross", {}).get("weight", 1.0), 1.0),
            "rsi_reversion": _as_float(self.strategy_config.get("rsi_reversion", {}).get("weight", 0.8), 0.8),
            "donchian": _as_float(self.strategy_config.get("donchian_breakout", {}).get("weight", 0.9), 0.9),
            "momentum": _as_float(self.strategy_config.get("momentum_filter", {}).get("weight", 0.4), 0.4),
            "macd_vote": _as_float(self.strategy_config.get("macd_vote", {}).get("weight", 0.6), 0.6),
            "bb_vote": _as_float(self.strategy_config.get("bb_vote", {}).get("weight", 0.4), 0.4),
            "cvd_div": _as_float(self.strategy_config.get("cvd_divergence", {}).get("weight", 0.5), 0.5),
            "fng_bias": _as_float(self.strategy_config.get("fng_bias", {}).get("weight", 0.2), 0.2),
            "sentiment": _as_float(self.cfg.get("sentiment", {}).get("weight", 0.0), 0.0),
            "regime": _as_float(self.strategy_config.get("regime_weight", 0.25), 0.25),
            "trend_bias": _as_float(self.strategy_config.get("trend_bias", {}).get("weight", 0.2), 0.2),
        }
        
        # Thresholds
        self.buy_threshold = _as_float(self.signal_config.get("buy", 1.0), 1.0)
        self.sell_threshold = _as_float(self.signal_config.get("sell", -1.0), -1.0)
        self.hold_threshold = _as_float(self.signal_config.get("hold", 0.3), 0.3)
        
        # Risk parameters
        self.atr_period = _as_int(self.risk_config.get("atr_period", 14), 14)
        self.atr_pct_high = _as_float(self.risk_config.get("volatility_throttle", {}).get("atr_pct_high", 0.06), 0.06)
        self.atr_pct_hold = _as_float(self.risk_config.get("volatility_throttle", {}).get("atr_pct_hold", 0.12), 0.12)
        self.vol_dampen_mult = _as_float(self.risk_config.get("volatility_throttle", {}).get("dampen_mult", 0.65), 0.65)
        
        # Signal persistence
        self.min_bars_required = _as_int(self.strategy_config.get("min_bars_required", 80), 80)
        self.signal_history_size = _as_int(self.strategy_config.get("signal_history_size", 50), 50)
        
    # -----------------------------
    # Logging helpers
    # -----------------------------
    def _log_warn(self, msg: str) -> None:
        """Log warning message."""
        try:
            if hasattr(self.log, "warning"):
                self.log.warning(f"[Strategy] {msg}")
            elif hasattr(self.log, "warn"):
                self.log.warn(f"[Strategy] {msg}")  # type: ignore
            else:
                self.log.info(f"[Strategy] {msg}")  # type: ignore
        except Exception:
            pass

    def _log_debug(self, msg: str) -> None:
        """Log debug message."""
        try:
            if hasattr(self.log, "debug"):
                self.log.debug(f"[Strategy] {msg}")
        except Exception:
            pass

    # -----------------------------
    # Data validation and cleaning
    # -----------------------------
    def _safe_series(self, s: Any) -> Optional[pd.Series]:
        """Safely convert to pandas Series."""
        try:
            if s is None:
                return None
            if isinstance(s, pd.Series):
                return s
            if isinstance(s, (list, tuple, np.ndarray)):
                return pd.Series(s)
            return pd.Series([s])
        except Exception:
            return None

    def _clean_ohlcv(self, df: pd.DataFrame) -> Optional[pd.DataFrame]:
        """Coerce numeric OHLCV and drop rows with bad values."""
        if df is None or not isinstance(df, pd.DataFrame) or len(df) == 0:
            return None

        required = ("close", "high", "low", "volume")
        for c in required:
            if c not in df.columns:
                return None

        d = df.copy()
        
        # Convert to numeric
        for c in ("open", "high", "low", "close", "volume"):
            if c in d.columns:
                d[c] = pd.to_numeric(d[c], errors="coerce")
                
        # Add derived columns
        if "open" in d.columns and "close" in d.columns:
            d["returns"] = d["close"].pct_change()
            d["range"] = (d["high"] - d["low"]) / d["close"]
            
        # Remove invalid data
        d = d.replace([np.inf, -np.inf], np.nan)
        d = d.dropna(subset=["close", "high", "low", "volume"])
        
        # Basic sanity checks
        d = d[d["close"] > 0]
        d = d[d["high"] > 0]
        d = d[d["low"] > 0]
        d = d[d["volume"] >= 0]
        
        return d if len(d) > 0 else None

    def _validate_data_sufficiency(self, df: pd.DataFrame, min_bars: int = 50) -> bool:
        """Validate if data has sufficient bars for analysis."""
        if df is None or len(df) < min_bars:
            return False
            
        # Check for recent data
        if hasattr(df.index, 'dtype'):
            # Assuming datetime index
            if isinstance(df.index, pd.DatetimeIndex):
                recent_threshold = datetime.now() - timedelta(hours=24)
                recent_data = df.index[-1] > recent_threshold
                return recent_data
        return True

    # -----------------------------
    # Indicator computations
    # -----------------------------
    def _compute_atr_pct(self, df: pd.DataFrame, last: float) -> Optional[float]:
        """Return ATR% (ATR/price) with multiple fallback methods."""
        try:
            a = None
            
            # Try different atr function signatures
            signatures = [
                lambda: atr(df, self.atr_period),
                lambda: atr(df),
                lambda: atr(df["high"], df["low"], df["close"], self.atr_period),
            ]
            
            for sig in signatures:
                try:
                    a = sig()
                    if a is not None:
                        break
                except Exception:
                    continue
                    
            a = self._safe_series(a)
            if a is None or len(a) < 2:
                return None
                
            atr_last = float(a.iloc[-1])
            if not np.isfinite(atr_last) or last <= 0:
                return None
                
            return float(atr_last / last)
            
        except Exception as e:
            self._log_debug(f"ATR computation error: {e}")
            return None

    def _compute_regime(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Compute market regime with enhanced classification."""
        out: Dict[str, Any] = {
            "score": 0.0, 
            "label": "unknown",
            "confidence": 0.0,
            "trend_strength": 0.0,
        }
        
        try:
            # Compute base regime score
            r = regime_score(df)
            
            if isinstance(r, (int, float, np.number)) and np.isfinite(float(r)):
                rv = float(r)
                out["score"] = rv
                
                # Enhanced classification
                if rv >= 0.5:
                    out["label"] = "strong_uptrend"
                    out["confidence"] = min(1.0, abs(rv))
                elif rv >= 0.2:
                    out["label"] = "weak_uptrend"
                    out["confidence"] = min(0.7, abs(rv))
                elif rv <= -0.5:
                    out["label"] = "strong_downtrend"
                    out["confidence"] = min(1.0, abs(rv))
                elif rv <= -0.2:
                    out["label"] = "weak_downtrend"
                    out["confidence"] = min(0.7, abs(rv))
                else:
                    out["label"] = "range"
                    out["confidence"] = 0.3
                    
                # Compute trend strength
                close = df["close"].astype(float)
                if len(close) >= 50:
                    sma20 = close.rolling(20).mean().iloc[-1]
                    sma50 = close.rolling(50).mean().iloc[-1]
                    price = close.iloc[-1]
                    if price > 0:
                        trend_strength = abs(sma20 - sma50) / price
                        out["trend_strength"] = float(clamp(trend_strength * 100, 0.0, 1.0))
                        
            else:
                out["label"] = str(r) if r else "unknown"
                
        except Exception as e:
            self._log_debug(f"Regime computation error: {e}")
            
        return out

    def _compute_volume_profile(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Compute volume profile analysis."""
        try:
            volume = df["volume"].astype(float)
            close = df["close"].astype(float)
            
            if len(volume) < 20:
                return {"profile": "insufficient_data"}
                
            # Volume trend
            vol_ma20 = volume.rolling(20).mean().iloc[-1]
            vol_ma50 = volume.rolling(50).mean().iloc[-1]
            vol_trend = 1.0 if vol_ma20 > vol_ma50 else -1.0
            
            # Volume vs price
            price_change = close.pct_change().iloc[-5:].mean()
            volume_change = volume.pct_change().iloc[-5:].mean()
            
            # Volume clusters
            high_volume_zones = volume[volume > volume.quantile(0.75)]
            
            return {
                "volume_trend": vol_trend,
                "price_volume_correlation": np.corrcoef(close[-20:], volume[-20:])[0, 1] if len(close) >= 20 else 0.0,
                "volume_ratio": float(vol_ma20 / max(vol_ma50, 1e-9)),
                "high_volume_zones": len(high_volume_zones),
                "avg_volume": float(volume.mean()),
            }
        except Exception:
            return {"profile": "error"}

    # -----------------------------
    # Signal components
    # -----------------------------
    def _compute_ema_cross_signal(self, close: pd.Series, config: Dict[str, Any], extras: Dict[str, Any]) -> float:
        """Compute EMA crossover signal."""
        try:
            if not _as_bool(config.get("enabled", True), True):
                return 0.0
                
            fast_period = _as_int(config.get("fast", 12), 12)
            slow_period = _as_int(config.get("slow", 26), 26)
            weight = _as_float(config.get("weight", 1.0), 1.0)
            
            if len(close) < max(fast_period, slow_period) + 2:
                return 0.0
                
            fast_ema = ema(close, fast_period)
            slow_ema = ema(close, slow_period)
            
            if fast_ema is None or slow_ema is None:
                return 0.0
                
            fast_ema = self._safe_series(fast_ema)
            slow_ema = self._safe_series(slow_ema)
            
            if fast_ema is None or slow_ema is None or len(fast_ema) < 2 or len(slow_ema) < 2:
                return 0.0
                
            # Current and previous values
            fast_now = float(fast_ema.iloc[-1])
            fast_prev = float(fast_ema.iloc[-2])
            slow_now = float(slow_ema.iloc[-1])
            slow_prev = float(slow_ema.iloc[-2])
            
            # Store values
            extras["ema_fast"] = fast_now
            extras["ema_slow"] = slow_now
            extras["ema_spread"] = (fast_now - slow_now) / slow_now if slow_now != 0 else 0.0
            
            # Crossover detection
            if fast_prev <= slow_prev and fast_now > slow_now:
                return weight  # Bullish crossover
            elif fast_prev >= slow_prev and fast_now < slow_now:
                return -weight  # Bearish crossover
                
        except Exception as e:
            self._log_debug(f"EMA cross error: {e}")
            
        return 0.0

    def _compute_rsi_signal(self, close: pd.Series, config: Dict[str, Any], extras: Dict[str, Any]) -> float:
        """Compute RSI reversion signal."""
        try:
            if not _as_bool(config.get("enabled", True), True):
                return 0.0
                
            period = _as_int(config.get("period", 14), 14)
            weight = _as_float(config.get("weight", 0.8), 0.8)
            buy_below = _as_float(config.get("buy_below", 30), 30.0)
            sell_above = _as_float(config.get("sell_above", 70), 70.0)
            
            if len(close) < period + 2:
                return 0.0
                
            rsi_vals = rsi(close, period)
            if rsi_vals is None:
                return 0.0
                
            rsi_vals = self._safe_series(rsi_vals)
            if rsi_vals is None or len(rsi_vals) == 0:
                return 0.0
                
            rsi_now = float(rsi_vals.iloc[-1])
            extras["rsi"] = rsi_now
            
            # RSI divergence check
            if len(close) >= 20:
                price_slope = float(close.iloc[-1] / close.iloc[-10] - 1.0)
                rsi_slope = float(rsi_vals.iloc[-1] / rsi_vals.iloc[-10] - 1.0)
                if price_slope > 0 and rsi_slope < 0:
                    extras["rsi_divergence"] = "bearish"
                elif price_slope < 0 and rsi_slope > 0:
                    extras["rsi_divergence"] = "bullish"
            
            # Signal generation
            if rsi_now < buy_below:
                # Oversold - bullish
                oversold_strength = (buy_below - rsi_now) / buy_below
                return weight * clamp(oversold_strength, 0.0, 1.0)
            elif rsi_now > sell_above:
                # Overbought - bearish
                overbought_strength = (rsi_now - sell_above) / (100 - sell_above)
                return -weight * clamp(overbought_strength, 0.0, 1.0)
                
        except Exception as e:
            self._log_debug(f"RSI error: {e}")
            
        return 0.0

    def _compute_macd_signal(self, close: pd.Series, config: Dict[str, Any], extras: Dict[str, Any]) -> float:
        """Compute MACD signal."""
        try:
            if not _as_bool(config.get("enabled", False), False):
                return 0.0
                
            fast = _as_int(config.get("fast", 12), 12)
            slow = _as_int(config.get("slow", 26), 26)
            signal = _as_int(config.get("signal", 9), 9)
            weight = _as_float(config.get("weight", 0.6), 0.6)
            
            if len(close) < slow + signal:
                return 0.0
                
            macd_line, signal_line, histogram = macd(close, fast, slow, signal)
            
            if macd_line is None or signal_line is None:
                return 0.0
                
            macd_line = self._safe_series(macd_line)
            signal_line = self._safe_series(signal_line)
            
            if macd_line is None or signal_line is None:
                return 0.0
                
            macd_now = float(macd_line.iloc[-1])
            signal_now = float(signal_line.iloc[-1])
            macd_prev = float(macd_line.iloc[-2]) if len(macd_line) >= 2 else 0.0
            
            extras["macd"] = macd_now
            extras["macd_signal"] = signal_now
            extras["macd_histogram"] = macd_now - signal_now
            
            # Signal logic
            if macd_now > signal_now and macd_prev <= signal_now:
                return weight  # Bullish crossover
            elif macd_now < signal_now and macd_prev >= signal_now:
                return -weight  # Bearish crossover
                
        except Exception as e:
            self._log_debug(f"MACD error: {e}")
            
        return 0.0

    def _compute_bb_signal(self, close: pd.Series, config: Dict[str, Any], extras: Dict[str, Any]) -> float:
        """Compute Bollinger Bands signal."""
        try:
            if not _as_bool(config.get("enabled", False), False):
                return 0.0
                
            length = _as_int(config.get("length", 20), 20)
            std = _as_float(config.get("std", 2.0), 2.0)
            weight = _as_float(config.get("weight", 0.4), 0.4)
            
            if len(close) < length:
                return 0.0
                
            mid, upper, lower = bbands(close, length, std)
            
            if mid is None or upper is None or lower is None:
                return 0.0
                
            mid = self._safe_series(mid)
            upper = self._safe_series(upper)
            lower = self._safe_series(lower)
            
            if mid is None or upper is None or lower is None:
                return 0.0
                
            close_now = float(close.iloc[-1])
            upper_now = float(upper.iloc[-1])
            lower_now = float(lower.iloc[-1])
            mid_now = float(mid.iloc[-1])
            
            extras["bb_mid"] = mid_now
            extras["bb_upper"] = upper_now
            extras["bb_lower"] = lower_now
            extras["bb_width"] = (upper_now - lower_now) / mid_now if mid_now != 0 else 0.0
            extras["bb_position"] = (close_now - lower_now) / (upper_now - lower_now) if upper_now != lower_now else 0.5
            
            # Signal logic
            if close_now < lower_now:
                # Below lower band - oversold
                return weight
            elif close_now > upper_now:
                # Above upper band - overbought
                return -weight
                
        except Exception as e:
            self._log_debug(f"Bollinger Bands error: {e}")
            
        return 0.0

    def _compute_donchian_signal(self, df: pd.DataFrame, config: Dict[str, Any], extras: Dict[str, Any]) -> float:
        """Compute Donchian breakout signal."""
        try:
            if not _as_bool(config.get("enabled", True), True):
                return 0.0
                
            lookback = _as_int(config.get("lookback", 20), 20)
            weight = _as_float(config.get("weight", 0.9), 0.9)
            
            if len(df) < lookback + 2:
                return 0.0
                
            upper, lower = donchian(df, lookback)
            
            if upper is None or lower is None:
                return 0.0
                
            upper = self._safe_series(upper)
            lower = self._safe_series(lower)
            
            if upper is None or lower is None or len(upper) < 2 or len(lower) < 2:
                return 0.0
                
            close_now = float(df["close"].iloc[-1])
            upper_now = float(upper.iloc[-1])
            lower_now = float(lower.iloc[-1])
            upper_prev = float(upper.iloc[-2])
            lower_prev = float(lower.iloc[-2])
            
            extras["donchian_upper"] = upper_now
            extras["donchian_lower"] = lower_now
            extras["donchian_width"] = (upper_now - lower_now) / close_now if close_now != 0 else 0.0
            
            # Breakout detection
            if close_now > upper_prev:
                return weight  # Breakout up
            elif close_now < lower_prev:
                return -weight  # Breakout down
                
        except Exception as e:
            self._log_debug(f"Donchian error: {e}")
            
        return 0.0

    def _compute_momentum_signal(self, close: pd.Series, config: Dict[str, Any], extras: Dict[str, Any]) -> float:
        """Compute momentum signal."""
        try:
            if not _as_bool(config.get("enabled", True), True):
                return 0.0
                
            lookback = _as_int(config.get("lookback", 10), 10)
            weight = _as_float(config.get("weight", 0.4), 0.4)
            min_return = _as_float(config.get("min_return", 0.01), 0.01)
            
            if len(close) < lookback + 2:
                return 0.0
                
            momentum = float(close.iloc[-1] / close.iloc[-lookback] - 1.0)
            extras["momentum"] = momentum
            
            # Rate of Change
            roc = momentum * 100
            extras["roc"] = roc
            
            if momentum > min_return:
                return weight * clamp(momentum / (min_return * 2), 0.0, 1.0)
            elif momentum < -min_return:
                return -weight * clamp(abs(momentum) / (min_return * 2), 0.0, 1.0)
                
        except Exception as e:
            self._log_debug(f"Momentum error: {e}")
            
        return 0.0

    def _compute_cvd_signal(self, df: pd.DataFrame, extras: Dict[str, Any]) -> float:
        """Compute CVD (Cumulative Volume Delta) signal."""
        try:
            if len(df) < 20:
                return 0.0
                
            cvd = volume_delta(df)
            if cvd is None:
                return 0.0
                
            cvd = self._safe_series(cvd)
            if cvd is None or len(cvd) < 12:
                return 0.0
                
            close = df["close"].astype(float)
            
            # Slopes
            price_slope = float(close.iloc[-1] - close.iloc[-10])
            cvd_slope = float(cvd.iloc[-1] - cvd.iloc[-10])
            
            extras["cvd"] = float(cvd.iloc[-1])
            extras["cvd_slope"] = cvd_slope
            extras["price_slope"] = price_slope
            
            # Divergence detection
            if price_slope > 0 and cvd_slope < 0:
                return -0.5  # Bearish divergence
            elif price_slope < 0 and cvd_slope > 0:
                return 0.5  # Bullish divergence
                
        except Exception as e:
            self._log_debug(f"CVD error: {e}")
            
        return 0.0

    def _compute_sentiment_signal(self, sentiment_score: Optional[float], extras: Dict[str, Any]) -> float:
        """Compute sentiment signal."""
        try:
            weight = self.component_weights.get("sentiment", 0.0)
            if weight == 0.0 or sentiment_score is None:
                return 0.0
                
            s = float(sentiment_score)
            if not np.isfinite(s):
                s = 0.0
                
            # Normalize to [-1, 1]
            if 0.0 <= s <= 1.0:
                s = (s * 2.0) - 1.0
            s = clamp(s, -1.0, 1.0)
            
            extras["sentiment_score"] = s
            return weight * s
            
        except Exception:
            return 0.0

    def _compute_fng_signal(self, fng_index: int, extras: Dict[str, Any]) -> float:
        """Compute Fear & Greed Index signal."""
        try:
            weight = self.component_weights.get("fng_bias", 0.2)
            if weight == 0.0:
                return 0.0
                
            fng = int(fng_index)
            extras["fng"] = fng
            
            # Extreme fear = bullish, extreme greed = bearish
            if fng < 25:
                return weight  # Extreme fear
            elif fng > 75:
                return -weight  # Extreme greed
                
        except Exception:
            return 0.0

    # -----------------------------
    # Signal aggregation
    # -----------------------------
    def _aggregate_signals(
        self,
        component_signals: Dict[str, float],
        raw_score: float,
        trend_bias: float,
        atr_pct: Optional[float],
        regime_label: str,
        trend_strength: float
    ) -> Tuple[float, str, Dict[str, Any]]:
        """Aggregate component signals into final score with adjustments."""
        
        # Apply MTF dampening if trend disagrees
        mtf_config = self.strategy_config.get("mtf_confirm", {})
        mtf_dampen = False
        
        if _as_bool(mtf_config.get("enabled", True), True):
            dampen_mult = _as_float(mtf_config.get("dampen_mult", 0.55), 0.55)
            
            # Dampen if going against higher timeframe trend
            if trend_bias < 0 and raw_score > 0:
                raw_score *= dampen_mult
                mtf_dampen = True
            elif trend_bias > 0 and raw_score < 0:
                raw_score *= dampen_mult
                mtf_dampen = True
        
        # Apply volatility adjustments
        vol_adjustment = 1.0
        if atr_pct is not None:
            if atr_pct >= self.atr_pct_hold:
                # Too volatile - force hold
                return 0.0, "hold", {"vol_throttle": "hold"}
            elif atr_pct >= self.atr_pct_high:
                # High volatility - dampen signal
                vol_adjustment = self.vol_dampen_mult
        
        # Apply trend strength adjustment
        trend_adjustment = 1.0
        if regime_label in ("range", "sideways") and trend_strength < 0.3:
            # Weak trend in ranging market - reduce signal strength
            trend_adjustment = 0.7
        
        final_score = raw_score * vol_adjustment * trend_adjustment
        final_score = clamp(final_score, -2.0, 2.0)
        
        # Determine action
        if final_score >= self.buy_threshold:
            action = "buy"
        elif final_score <= self.sell_threshold:
            action = "sell"
        elif abs(final_score) < self.hold_threshold:
            action = "hold"
        else:
            # Weak signal
            if final_score > 0:
                action = "hold"  # Weak buy -> hold
            else:
                action = "hold"  # Weak sell -> hold
        
        # Generate reason
        top_signals = sorted(
            [(k, v) for k, v in component_signals.items() if abs(v) > 0.1],
            key=lambda x: abs(x[1]),
            reverse=True
        )[:3]
        
        reasons = []
        for signal_name, value in top_signals:
            if value > 0:
                reasons.append(f"{signal_name}+")
            else:
                reasons.append(f"{signal_name}-")
        
        reason = " | ".join(reasons) if reasons else "no_strong_signals"
        
        # Additional adjustments
        adjustments = {
            "mtf_dampen": mtf_dampen,
            "vol_adjustment": vol_adjustment,
            "trend_adjustment": trend_adjustment,
            "final_score": final_score,
        }
        
        return final_score, action, adjustments

    def _calculate_confidence(
        self,
        component_signals: Dict[str, float],
        score: float,
        regime_label: str,
        trend_strength: float,
        atr_pct: Optional[float]
    ) -> float:
        """Calculate confidence score (0-1) for the signal."""
        
        confidence_factors = []
        
        # 1. Signal agreement (consensus)
        positive_signals = sum(1 for v in component_signals.values() if v > 0.1)
        negative_signals = sum(1 for v in component_signals.values() if v < -0.1)
        total_signals = len([v for v in component_signals.values() if abs(v) > 0.1])
        
        if total_signals > 0:
            agreement = max(positive_signals, negative_signals) / total_signals
            confidence_factors.append(agreement * 0.3)  # 30% weight
        
        # 2. Signal strength
        strength_factor = min(abs(score) / max(abs(self.buy_threshold), abs(self.sell_threshold)), 1.0)
        confidence_factors.append(strength_factor * 0.3)  # 30% weight
        
        # 3. Trend/market regime
        if regime_label in ("strong_uptrend", "strong_downtrend"):
            confidence_factors.append(0.2)  # 20% for strong trend
        elif regime_label in ("weak_uptrend", "weak_downtrend"):
            confidence_factors.append(0.1)  # 10% for weak trend
        
        # 4. Volatility (lower volatility = higher confidence)
        if atr_pct is not None:
            vol_confidence = max(0.0, 1.0 - (atr_pct / self.atr_pct_high))
            confidence_factors.append(vol_confidence * 0.2)  # 20% weight
        
        confidence = sum(confidence_factors)
        return clamp(confidence, 0.0, 1.0)

    def _pick_tactic_hints(
        self,
        score: float,
        trend_bias: float,
        trend_strength: float,
        atr_pct: Optional[float],
        regime_label: str,
    ) -> Dict[str, Any]:
        """Generate execution hints based on market conditions."""
        
        hints: Dict[str, Any] = {
            "tactic": "",
            "allow_dca": False,
            "allow_pyramid": False,
            "exec_pref": "",
            "aggressiveness": "normal",
            "risk_adjustment": 1.0,
        }
        
        # Default execution preference
        hints["exec_pref"] = self.cfg.get("execution", {}).get("type", "maker_limit") or "maker_limit"
        
        # High volatility scenario
        if atr_pct is not None and atr_pct >= self.atr_pct_high:
            hints["tactic"] = "high_vol_event"
            hints["allow_dca"] = False
            hints["allow_pyramid"] = False
            hints["exec_pref"] = "twap"
            hints["aggressiveness"] = "conservative"
            hints["risk_adjustment"] = 0.5
            return hints
        
        # Strong trend following
        if trend_strength >= 0.6 and abs(score) > 1.0:
            hints["tactic"] = "trend_follow"
            hints["allow_pyramid"] = True
            hints["allow_dca"] = False
            hints["aggressiveness"] = "aggressive"
            hints["risk_adjustment"] = 1.2
            return hints
        
        # Range/reversion scenario
        if regime_label in ("range", "sideways") and trend_strength <= 0.3:
            hints["tactic"] = "range_reversion"
            hints["allow_dca"] = True
            hints["allow_pyramid"] = False
            hints["aggressiveness"] = "conservative"
            hints["risk_adjustment"] = 0.8
            return hints
        
        # Weak trend
        if 0.3 < trend_strength < 0.6:
            hints["tactic"] = "trend_aware"
            hints["allow_dca"] = True
            hints["allow_pyramid"] = False
            hints["aggressiveness"] = "normal"
            hints["risk_adjustment"] = 1.0
        
        # Breakout scenario
        if regime_label in ("strong_uptrend", "strong_downtrend") and abs(score) > 1.5:
            hints["tactic"] = "breakout"
            hints["allow_pyramid"] = True
            hints["allow_dca"] = False
            hints["aggressiveness"] = "aggressive"
            hints["risk_adjustment"] = 1.3
        
        return hints

    # -----------------------------
    # Main compute method
    # -----------------------------
    def compute(
        self,
        df: pd.DataFrame,
        df_trend: Optional[pd.DataFrame],
        symbol: str,
        fng_index: int = 50,
        sentiment_score: Optional[float] = None,
        position_info: Optional[Dict[str, Any]] = None,
    ) -> Signal:
        """
        Compute trading signal based on multiple indicators and factors.
        
        Args:
            df: Primary timeframe OHLCV data
            df_trend: Higher timeframe data for trend analysis
            symbol: Trading symbol
            fng_index: Fear & Greed Index (0-100)
            sentiment_score: Sentiment score (-1 to 1 or 0 to 1)
            position_info: Current position information (optional)
            
        Returns:
            Signal object with action, strength, and details
        """
        
        # Update last compute time
        self._last_compute_time[symbol] = datetime.now()
        
        # Data validation and cleaning
        df = self._clean_ohlcv(df)
        if df is None or len(df) < self.min_bars_required:
            return Signal(symbol, "hold", 0.0, "insufficient_bars")
        
        if df_trend is not None:
            df_trend = self._clean_ohlcv(df_trend)
        
        try:
            close = df["close"].astype(float)
            last_price = float(close.iloc[-1])
            if not np.isfinite(last_price) or last_price <= 0:
                return Signal(symbol, "hold", 0.0, "invalid_price")
        except Exception as e:
            self._log_warn(f"Data error for {symbol}: {e}")
            return Signal(symbol, "hold", 0.0, "data_error")
        
        # Initialize tracking structures
        component_signals: Dict[str, float] = {}
        reasons: List[str] = []
        extras: Dict[str, Any] = {}
        audit: List[Dict[str, Any]] = []
        
        # Track signal contributions
        def _track_signal(name: str, value: float, reason: Optional[str] = None):
            component_signals[name] = component_signals.get(name, 0.0) + value
            if reason and abs(value) > 0.1:
                reasons.append(reason)
            audit.append({
                "component": name,
                "value": float(value),
                "reason": reason or "",
                "timestamp": datetime.now().isoformat()
            })
        
        # --- Compute market context ---
        regime = self._compute_regime(df)
        extras.update(regime)
        
        atr_pct = self._compute_atr_pct(df, last_price)
        if atr_pct is not None:
            extras["atr_pct"] = float(atr_pct)
        
        # Volume profile
        volume_profile = self._compute_volume_profile(df)
        extras["volume_profile"] = volume_profile
        
        # --- Compute component signals ---
        
        # 1. Technical indicators
        ema_signal = self._compute_ema_cross_signal(
            close, 
            self.strategy_config.get("ema_cross", {}), 
            extras
        )
        _track_signal("ema_cross", ema_signal, 
                     "EMA crossover" if ema_signal != 0 else None)
        
        rsi_signal = self._compute_rsi_signal(
            close,
            self.strategy_config.get("rsi_reversion", {}),
            extras
        )
        _track_signal("rsi_reversion", rsi_signal,
                     "RSI reversion" if rsi_signal != 0 else None)
        
        macd_signal = self._compute_macd_signal(
            close,
            self.strategy_config.get("macd_vote", {}),
            extras
        )
        _track_signal("macd_vote", macd_signal,
                     "MACD signal" if macd_signal != 0 else None)
        
        bb_signal = self._compute_bb_signal(
            close,
            self.strategy_config.get("bb_vote", {}),
            extras
        )
        _track_signal("bb_vote", bb_signal,
                     "Bollinger Bands" if bb_signal != 0 else None)
        
        donchian_signal = self._compute_donchian_signal(
            df,
            self.strategy_config.get("donchian_breakout", {}),
            extras
        )
        _track_signal("donchian", donchian_signal,
                     "Donchian breakout" if donchian_signal != 0 else None)
        
        momentum_signal = self._compute_momentum_signal(
            close,
            self.strategy_config.get("momentum_filter", {}),
            extras
        )
        _track_signal("momentum", momentum_signal,
                     "Momentum" if momentum_signal != 0 else None)
        
        cvd_signal = self._compute_cvd_signal(df, extras)
        _track_signal("cvd_div", cvd_signal,
                     "CVD divergence" if cvd_signal != 0 else None)
        
        # 2. External factors
        sentiment_signal = self._compute_sentiment_signal(sentiment_score, extras)
        _track_signal("sentiment", sentiment_signal,
                     "Sentiment" if sentiment_signal != 0 else None)
        
        fng_signal = self._compute_fng_signal(fng_index, extras)
        _track_signal("fng_bias", fng_signal,
                     "F&G Index" if fng_signal != 0 else None)
        
        # 3. Regime contribution
        regime_score_val = regime.get("score", 0.0)
        regime_weight = self.component_weights.get("regime", 0.25)
        regime_signal = regime_weight * regime_score_val
        _track_signal("regime", regime_signal, f"Regime {regime_score_val:+.2f}")
        
        # 4. Trend bias (higher timeframe)
        trend_bias = 0.0
        trend_strength = 0.0
        
        if df_trend is not None and len(df_trend) >= 50:
            try:
                t_close = df_trend["close"].astype(float)
                t_ema20 = ema(t_close, 20)
                t_ema50 = ema(t_close, 50)
                
                if t_ema20 is not None and t_ema50 is not None:
                    t_ema20 = self._safe_series(t_ema20)
                    t_ema50 = self._safe_series(t_ema50)
                    
                    if t_ema20 is not None and t_ema50 is not None:
                        ema20_val = float(t_ema20.iloc[-1])
                        ema50_val = float(t_ema50.iloc[-1])
                        trend_bias = 1.0 if ema20_val > ema50_val else -1.0
                        
                        # Calculate trend strength
                        price = float(t_close.iloc[-1])
                        trend_strength_val = abs(ema20_val - ema50_val) / max(price, 1e-9)
                        trend_strength = clamp(trend_strength_val * 50.0, 0.0, 1.0)
                        
                        extras["trend_bias"] = trend_bias
                        extras["trend_strength"] = trend_strength
                        
                        # Add trend bias signal
                        trend_weight = self.component_weights.get("trend_bias", 0.2)
                        trend_signal = trend_weight * trend_bias
                        _track_signal("trend_bias", trend_signal, 
                                     f"Trend bias {trend_bias:+.1f}")
            except Exception as e:
                self._log_debug(f"Trend bias error: {e}")
        
        # --- Aggregate signals ---
        raw_score = sum(component_signals.values())
        
        final_score, action, adjustments = self._aggregate_signals(
            component_signals,
            raw_score,
            trend_bias,
            atr_pct,
            regime.get("label", "unknown"),
            trend_strength
        )
        
        # Handle volatility hold
        if action == "hold" and adjustments.get("vol_throttle") == "hold":
            return Signal(
                symbol=symbol,
                action="hold",
                strength=0.0,
                reason="volatility_hold",
                details={
                    "symbol": symbol,
                    "price": last_price,
                    "score_raw": float(raw_score),
                    "score": 0.0,
                    "components": component_signals,
                    "extras": extras,
                    "audit": audit,
                    "adjustments": adjustments,
                    "hints": {
                        "tactic": "high_vol_hold",
                        "allow_dca": False,
                        "allow_pyramid": False,
                        "exec_pref": "twap",
                        "aggressiveness": "conservative",
                        "risk_adjustment": 0.5,
                    },
                },
            )
        
        # Calculate signal strength
        denom = max(1e-9, max(abs(self.buy_threshold), abs(self.sell_threshold)))
        strength = clamp(abs(final_score) / denom, 0.0, 1.0)
        
        # Calculate confidence
        confidence = self._calculate_confidence(
            component_signals,
            final_score,
            regime.get("label", "unknown"),
            trend_strength,
            atr_pct
        )
        
        # Generate execution hints
        hints = self._pick_tactic_hints(
            final_score,
            trend_bias,
            trend_strength,
            atr_pct,
            regime.get("label", "unknown"),
        )
        
        # Position-aware adjustments
        if position_info:
            current_action = action
            position_size = position_info.get("size", 0.0)
            position_pnl = position_info.get("pnl_pct", 0.0)
            
            # If we have a position and signal contradicts, consider close/reduce
            if position_size > 0:
                if current_action == "sell":
                    # Strong sell signal with existing long position
                    if strength > 0.7:
                        action = "close"
                        reasons.append("close_long_due_to_strong_sell")
                    elif strength > 0.4:
                        action = "reduce"
                        reasons.append("reduce_long_due_to_sell_signal")
                        
                # Take profit logic
                if position_pnl > 0.05 and strength < 0.3:  # 5% profit, weak signal
                    action = "reduce"
                    reasons.append("take_profit_partial")
                    
            elif position_size < 0:  # Short position
                if current_action == "buy":
                    if strength > 0.7:
                        action = "close"
                        reasons.append("close_short_due_to_strong_buy")
                    elif strength > 0.4:
                        action = "reduce"
                        reasons.append("reduce_short_due_to_buy_signal")
        
        # Final reason string
        top_reasons = reasons[:5] if reasons else ["no_strong_signals"]
        reason_str = " | ".join(top_reasons)
        
        # Build details
        details = {
            "symbol": symbol,
            "price": last_price,
            "score_raw": float(raw_score),
            "score": float(final_score),
            "strength": float(strength),
            "confidence": float(confidence),
            "buy_threshold": float(self.buy_threshold),
            "sell_threshold": float(self.sell_threshold),
            "hold_threshold": float(self.hold_threshold),
            "components": component_signals,
            "extras": extras,
            "audit": audit,
            "adjustments": adjustments,
            "hints": hints,
            "timestamp": datetime.now().isoformat(),
            "position_info": position_info or {},
        }
        
        # Calculate priority (0-5)
        priority = 0
        if abs(final_score) > 1.5:
            priority = 3
        if confidence > 0.7:
            priority += 1
        if regime.get("label", "").startswith("strong_"):
            priority += 1
        
        # Store in history
        signal = Signal(
            symbol=symbol,
            action=action,
            strength=strength,
            reason=reason_str,
            details=details,
            confidence=confidence,
            priority=priority,
        )
        
        self._add_to_history(symbol, signal)
        
        return signal
    
    def _add_to_history(self, symbol: str, signal: Signal) -> None:
        """Add signal to history for tracking."""
        if symbol not in self._signal_history:
            self._signal_history[symbol] = []
        
        self._signal_history[symbol].append(signal)
        
        # Keep history size limited
        if len(self._signal_history[symbol]) > self.signal_history_size:
            self._signal_history[symbol] = self._signal_history[symbol][-self.signal_history_size:]
    
    # -----------------------------
    # Advanced analytics methods
    # -----------------------------
    def compute_mtf_confluence(
        self, 
        df_5m: pd.DataFrame, 
        df_15m: pd.DataFrame, 
        df_1h: pd.DataFrame, 
        df_4h: pd.DataFrame
    ) -> Dict[str, Any]:
        """Compute multi-timeframe confluence score."""
        
        def _score_tf(df: pd.DataFrame, tf_name: str) -> float:
            df_clean = self._clean_ohlcv(df)
            if df_clean is None or len(df_clean) < 50:
                return 0.0
                
            close = df_clean["close"].astype(float)
            
            # EMA alignment
            try:
                ema20 = ema(close, 20)
                ema50 = ema(close, 50)
                
                if ema20 is None or ema50 is None:
                    return 0.0
                    
                ema20_val = float(ema20.iloc[-1])
                ema50_val = float(ema50.iloc[-1])
                ema_score = 1.0 if ema20_val > ema50_val else -1.0
                
                # RSI alignment
                rsi_val = rsi(close, 14)
                if rsi_val is not None:
                    rsi_val = float(rsi_val.iloc[-1])
                    rsi_score = 1.0 if rsi_val > 55 else (-1.0 if rsi_val < 45 else 0.0)
                else:
                    rsi_score = 0.0
                
                return ema_score + rsi_score
                
            except Exception:
                return 0.0
        
        scores = {
            "5m": _score_tf(df_5m, "5m"),
            "15m": _score_tf(df_15m, "15m"),
            "1h": _score_tf(df_1h, "1h"),
            "4h": _score_tf(df_4h, "4h"),
        }
        
        total_score = sum(scores.values())
        confluence = total_score / len(scores) if scores else 0.0
        
        return {
            "score": float(total_score),
            "confluence": float(confluence),
            "timeframes": scores,
            "alignment": "bullish" if confluence > 0.5 else ("bearish" if confluence < -0.5 else "neutral"),
        }
    
    def detect_market_structure(self, df: pd.DataFrame, lookback: int = 20) -> Dict[str, Any]:
        """Detect market structure (higher highs/lows, support/resistance)."""
        
        df_clean = self._clean_ohlcv(df)
        if df_clean is None or len(df_clean) < lookback + 5:
            return {"structure": "insufficient_data"}
        
        highs = df_clean["high"].astype(float).tail(lookback).values
        lows = df_clean["low"].astype(float).tail(lookback).values
        
        # Higher highs/lows detection
        hh = highs[-1] > highs[0]
        hl = lows[-1] > lows[0]
        
        # Lower highs/lows detection
        lh = highs[-1] < highs[0]
        ll = lows[-1] < lows[0]
        
        if hh and hl:
            structure = "uptrend"
        elif lh and ll:
            structure = "downtrend"
        elif hh and ll:
            structure = "broadening"
        elif lh and hl:
            structure = "compression"
        else:
            structure = "range"
        
        # Support/resistance levels
        recent_highs = highs[-10:]
        recent_lows = lows[-10:]
        
        resistance = float(np.max(recent_highs))
        support = float(np.min(recent_lows))
        
        return {
            "structure": structure,
            "higher_highs": bool(hh),
            "higher_lows": bool(hl),
            "lower_highs": bool(lh),
            "lower_lows": bool(ll),
            "resistance": resistance,
            "support": support,
            "range_width": (resistance - support) / support if support > 0 else 0.0,
        }
    
    def detect_divergences(
        self, 
        df: pd.DataFrame, 
        indicator: str = "RSI",
        lookback: int = 20
    ) -> Dict[str, Any]:
        """Detect divergences between price and indicator."""
        
        df_clean = self._clean_ohlcv(df)
        if df_clean is None or len(df_clean) < lookback + 10:
            return {"divergence": "insufficient_data"}
        
        close = df_clean["close"].astype(float)
        
        if indicator.upper() == "RSI":
            indicator_vals = rsi(close, 14)
        elif indicator.upper() == "MACD":
            macd_line, _, _ = macd(close, 12, 26, 9)
            indicator_vals = macd_line
        else:
            return {"divergence": "unsupported_indicator"}
        
        if indicator_vals is None:
            return {"divergence": "indicator_error"}
        
        indicator_vals = self._safe_series(indicator_vals)
        if indicator_vals is None or len(indicator_vals) < lookback:
            return {"divergence": "insufficient_indicator_data"}
        
        # Compare price and indicator slopes
        price_start = float(close.iloc[-lookback])
        price_end = float(close.iloc[-1])
        ind_start = float(indicator_vals.iloc[-lookback])
        ind_end = float(indicator_vals.iloc[-1])
        
        price_slope = price_end - price_start
        ind_slope = ind_end - ind_start
        
        divergences = []
        
        # Regular divergence
        if price_slope > 0 and ind_slope < 0:
            divergences.append({
                "type": "regular_bearish",
                "strength": min(1.0, abs(ind_slope) / max(abs(price_slope), 1e-9)),
            })
        elif price_slope < 0 and ind_slope > 0:
            divergences.append({
                "type": "regular_bullish",
                "strength": min(1.0, abs(ind_slope) / max(abs(price_slope), 1e-9)),
            })
        
        # Hidden divergence (for trend continuation)
        if price_slope < 0 and ind_slope < 0 and abs(ind_slope) > abs(price_slope) * 1.5:
            divergences.append({
                "type": "hidden_bearish",
                "strength": min(1.0, abs(ind_slope) / max(abs(price_slope), 1e-9)),
            })
        elif price_slope > 0 and ind_slope > 0 and abs(ind_slope) > abs(price_slope) * 1.5:
            divergences.append({
                "type": "hidden_bullish",
                "strength": min(1.0, abs(ind_slope) / max(abs(price_slope), 1e-9)),
            })
        
        return {
            "divergences": divergences,
            "price_slope": float(price_slope),
            "indicator_slope": float(ind_slope),
            "indicator": indicator,
        }
    
    def detect_chart_patterns(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Detect basic chart patterns."""
        
        df_clean = self._clean_ohlcv(df)
        if df_clean is None or len(df_clean) < 50:
            return {"patterns": []}
        
        close = df_clean["close"].astype(float)
        high = df_clean["high"].astype(float)
        low = df_clean["low"].astype(float)
        
        patterns = []
        
        # Simple pattern detection logic
        recent_close = close.tail(20).values
        recent_high = high.tail(20).values
        recent_low = low.tail(20).values
        
        # Double top/bottom detection
        if len(recent_high) >= 10:
            peaks, _ = find_peaks(recent_high, distance=5)
            if len(peaks) >= 2:
                if abs(recent_high[peaks[-1]] - recent_high[peaks[-2]]) / recent_high[peaks[-2]] < 0.02:
                    patterns.append({"type": "double_top", "confidence": 0.6})
        
        if len(recent_low) >= 10:
            valleys, _ = find_peaks(-recent_low, distance=5)
            if len(valleys) >= 2:
                if abs(recent_low[valleys[-1]] - recent_low[valleys[-2]]) / recent_low[valleys[-2]] < 0.02:
                    patterns.append({"type": "double_bottom", "confidence": 0.6})
        
        # Trendline break detection
        if len(recent_close) >= 15:
            x = np.arange(len(recent_close))
            slope, intercept = np.polyfit(x, recent_close, 1)
            trendline = slope * x + intercept
            
            # Check if price breaks trendline
            last_deviation = recent_close[-1] - trendline[-1]
            prev_deviation = recent_close[-5] - trendline[-5]
            
            if slope > 0 and last_deviation < 0 and prev_deviation > 0:
                patterns.append({"type": "uptrend_break", "confidence": 0.7})
            elif slope < 0 and last_deviation > 0 and prev_deviation < 0:
                patterns.append({"type": "downtrend_break", "confidence": 0.7})
        
        return {"patterns": patterns}
    
    def trend_strength(self, df: pd.DataFrame, df_trend: Optional[pd.DataFrame] = None) -> float:
        """Calculate trend strength (0-1)."""
        
        df_clean = self._clean_ohlcv(df)
        if df_clean is None or len(df_clean) < 60:
            return 0.0
        
        close = df_clean["close"].astype(float)
        
        # Method 1: EMA distance
        ema20 = ema(close, 20)
        ema50 = ema(close, 50)
        
        if ema20 is None or ema50 is None:
            return 0.0
        
        ema20_val = float(ema20.iloc[-1])
        ema50_val = float(ema50.iloc[-1])
        price = float(close.iloc[-1])
        
        ema_dist = abs(ema20_val - ema50_val) / max(price, 1e-9)
        strength1 = clamp(ema_dist * 50.0, 0.0, 1.0)
        
        # Method 2: ADX-like calculation
        if len(close) >= 14:
            high = df_clean["high"].astype(float)
            low = df_clean["low"].astype(float)
            
            tr = np.maximum(
                high - low,
                np.maximum(
                    abs(high - close.shift(1)),
                    abs(low - close.shift(1))
                )
            )
            
            atr_val = tr.rolling(14).mean().iloc[-1]
            if atr_val > 0:
                price_range = (high.rolling(14).max() - low.rolling(14).min()).iloc[-1]
                strength2 = clamp(price_range / (atr_val * 14), 0.0, 1.0)
            else:
                strength2 = 0.0
        else:
            strength2 = 0.0
        
        # Method 3: Higher timeframe trend strength
        strength3 = 0.0
        if df_trend is not None:
            df_trend_clean = self._clean_ohlcv(df_trend)
            if df_trend_clean is not None and len(df_trend_clean) >= 50:
                t_close = df_trend_clean["close"].astype(float)
                t_ema20 = ema(t_close, 20)
                t_ema50 = ema(t_close, 50)
                
                if t_ema20 is not None and t_ema50 is not None:
                    t_ema20_val = float(t_ema20.iloc[-1])
                    t_ema50_val = float(t_ema50.iloc[-1])
                    t_price = float(t_close.iloc[-1])
                    
                    t_dist = abs(t_ema20_val - t_ema50_val) / max(t_price, 1e-9)
                    strength3 = clamp(t_dist * 50.0, 0.0, 1.0)
        
        # Combine strengths
        weights = [0.4, 0.4, 0.2]  # Weights for each method
        total_strength = (strength1 * weights[0] + strength2 * weights[1] + strength3 * weights[2])
        
        return float(clamp(total_strength, 0.0, 1.0))
    
    # -----------------------------
    # Utility methods
    # -----------------------------
    def get_signal_history(self, symbol: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent signal history for a symbol."""
        if symbol not in self._signal_history:
            return []
        
        history = self._signal_history[symbol][-limit:]
        return [signal.to_dict() for signal in history]
    
    def get_market_state(self, symbol: str) -> Dict[str, Any]:
        """Get current market state for a symbol."""
        if symbol in self._market_state_cache:
            cache_age = datetime.now() - self._last_compute_time.get(symbol, datetime.min)
            if cache_age.total_seconds() < 300:  # 5 minute cache
                return self._market_state_cache[symbol]
        
        return {}
    
    def reset_history(self, symbol: Optional[str] = None) -> None:
        """Reset signal history."""
        if symbol:
            if symbol in self._signal_history:
                self._signal_history[symbol] = []
        else:
            self._signal_history.clear()


# Helper function for pattern detection
def find_peaks(data: np.ndarray, distance: int = 1) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Simple peak detection."""
    peaks = []
    properties = {}
    
    if len(data) < 3:
        return np.array(peaks), properties
    
    for i in range(1, len(data) - 1):
        if data[i] > data[i-1] and data[i] > data[i+1]:
            peaks.append(i)
    
    return np.array(peaks), properties
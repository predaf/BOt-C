from __future__ import annotations

import copy
import json
import time
import os
import tempfile
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional, Union, Set, Callable
from dataclasses import dataclass, field
from datetime import datetime
import logging
from enum import Enum
from contextlib import contextmanager
import yaml  # pip install pyyaml


# Enum pentru tipurile de backup
class BackupStrategy(Enum):
    """Strategii pentru gestionarea backup-urilor."""
    ROTATE = "rotate"  # Rotire cu număr limitat de backup-uri
    TIME_BASED = "time_based"  # Backup-uri bazate pe timp
    UNLIMITED = "unlimited"  # Toate backup-urile sunt păstrate


# Structură pentru rezultatele validării
@dataclass
class ValidationResult:
    """Rezultatul validării unei configurații."""
    ok: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    validated_keys: List[str] = field(default_factory=list)
    
    def add_error(self, message: str, key: Optional[str] = None) -> None:
        """Adaugă o eroare cu cheie opțională."""
        if key:
            self.errors.append(f"{key}: {message}")
        else:
            self.errors.append(message)
        self.ok = False
    
    def add_warning(self, message: str, key: Optional[str] = None) -> None:
        """Adaugă un warning cu cheie opțională."""
        if key:
            self.warnings.append(f"{key}: {message}")
        else:
            self.warnings.append(message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertește la dicționar."""
        return {
            "ok": self.ok,
            "errors": self.errors,
            "warnings": self.warnings,
            "validated_keys": self.validated_keys
        }


# Configurație pentru ConfigManager
@dataclass
class ConfigManagerConfig:
    """Configurație pentru ConfigManager."""
    # Backup settings
    backup_dir: str = "config_backups"
    max_backups: int = 10  # Pentru strategia ROTATE
    backup_strategy: BackupStrategy = BackupStrategy.ROTATE
    keep_backup_hours: int = 168  # 7 zile pentru TIME_BASED
    
    # Validation settings
    validate_on_load: bool = True
    validate_on_save: bool = True
    
    # Security settings
    redact_secrets: bool = True
    secret_key_patterns: Tuple[str, ...] = field(default_factory=lambda: (
        "key", "secret", "token", "password", "passphrase", 
        "api_key", "apikey", "bearer", "private", "auth", "credential"
    ))
    
    # File settings
    default_encoding: str = "utf-8"
    auto_create_dirs: bool = True
    
    # Merge settings
    default_merge_strategy: str = "deep"  # deep, shallow, overwrite


class ConfigManager:
    """
    Manager robust pentru configurații cu:
    - Validare extensibilă
    - Backup atomic cu diferite strategii
    - Merge inteligent (deep/shallow)
    - Diff detaliat
    - Redactare automată a secretelor
    - Support pentru JSON și YAML
    - Lock pentru operațiuni concurente
    - Versioning și rollback
    """
    
    def __init__(
        self, 
        initial_config: Optional[Dict[str, Any]] = None,
        config_path: Optional[Union[str, Path]] = None,
        logger: Optional[logging.Logger] = None,
        base_dir: Optional[Union[str, Path]] = None,
        config: Optional[ConfigManagerConfig] = None
    ):
        """
        Initializează ConfigManager.
        
        Args:
            initial_config: Configurație inițială (opțional)
            config_path: Calea către fișierul de configurație (opțional)
            logger: Logger personalizat (opțional)
            base_dir: Director de bază (opțional)
            config: Configurație pentru manager (opțional)
        """
        self.config = config or ConfigManagerConfig()
        self.logger = logger or logging.getLogger(__name__)
        self.base_dir = Path(base_dir or Path.cwd())
        self._lock_file = self.base_dir / ".config_manager.lock"
        
        # Validatori custom
        self._validators: Dict[str, Callable] = {}
        
        # Inițializează configurația
        self._config_data: Dict[str, Any] = {}
        
        # Încarcă din fișier dacă este specificat
        if config_path:
            loaded = self.load_config_file(config_path)
            if loaded:
                self._config_data = loaded
            elif initial_config:
                self._config_data = initial_config.copy()
        elif initial_config:
            self._config_data = initial_config.copy()
        
        # Asigură directorul de backup
        if self.config.auto_create_dirs:
            self._ensure_backup_dir()
    
    def _ensure_backup_dir(self) -> None:
        """Asigură existența directorului de backup."""
        backup_path = self.base_dir / self.config.backup_dir
        backup_path.mkdir(parents=True, exist_ok=True)
    
    # ==================== Public API ====================
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Obține o valoare din configurație folosind dot notation.
        
        Example: get("exchange.api_key") -> value
        """
        keys = key.split(".")
        current = self._config_data
        
        for k in keys:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return default
        
        return current
    
    def set(self, key: str, value: Any, create_missing: bool = True) -> bool:
        """
        Setează o valoare în configurație folosind dot notation.
        
        Args:
            key: Cheia în dot notation
            value: Valoarea de setat
            create_missing: Dacă să creeze structuri intermediare lipsă
            
        Returns:
            True dacă a reușit, False altfel
        """
        keys = key.split(".")
        current = self._config_data
        
        # Navighează până la penultima cheie
        for i, k in enumerate(keys[:-1]):
            if k not in current:
                if create_missing:
                    current[k] = {}
                    current = current[k]
                else:
                    return False
            elif isinstance(current[k], dict):
                current = current[k]
            else:
                if create_missing:
                    current[k] = {}
                    current = current[k]
                else:
                    return False
        
        # Setează valoarea
        current[keys[-1]] = value
        return True
    
    def update(
        self,
        updates: Dict[str, Any],
        strategy: str = "deep",
        validate: bool = True,
        create_backup: bool = True
    ) -> Dict[str, Any]:
        """
        Actualizează configurația cu noile valori.
        
        Args:
            updates: Dicționar cu actualizări
            strategy: Strategia de merge (deep, shallow, overwrite)
            validate: Dacă să valideze configurația actualizată
            create_backup: Dacă să creeze backup înainte de actualizare
            
        Returns:
            Dicționar cu rezultatul operației
        """
        with self._lock():
            old_config = copy.deepcopy(self._config_data)
            backup_path = None
            
            try:
                # Creează backup dacă este necesar
                if create_backup:
                    backup_path = self._create_backup(old_config, label="before_update")
                
                # Validează actualizările
                if validate:
                    validation = self.validate_updates(updates, strategy)
                    if not validation.ok:
                        return {
                            "ok": False,
                            "error": "Validation failed",
                            "validation": validation.to_dict(),
                            "backup_path": backup_path
                        }
                
                # Aplică actualizările
                if strategy == "overwrite":
                    self._config_data.update(updates)
                elif strategy == "shallow":
                    for k, v in updates.items():
                        if k in self._config_data and isinstance(self._config_data[k], dict) and isinstance(v, dict):
                            self._config_data[k].update(v)
                        else:
                            self._config_data[k] = v
                else:  # deep
                    self._config_data = self._deep_merge(self._config_data, updates)
                
                # Calculează diferențele
                diff = self._compute_diff(old_config, self._config_data)
                
                return {
                    "ok": True,
                    "backup_path": backup_path,
                    "diff": diff,
                    "config_hash": self._compute_config_hash(),
                    "timestamp": datetime.now().isoformat()
                }
                
            except Exception as e:
                # Rollback în caz de eroare
                self._config_data = old_config
                self.logger.error(f"Update failed, rolled back: {e}")
                
                return {
                    "ok": False,
                    "error": str(e),
                    "backup_path": backup_path,
                    "rolled_back": True
                }
    
    def validate_updates(
        self, 
        updates: Dict[str, Any], 
        strategy: str = "deep"
    ) -> ValidationResult:
        """
        Validează actualizările fără a le aplica.
        
        Args:
            updates: Actualizările de validat
            strategy: Strategia de merge pentru simulare
            
        Returns:
            Rezultatul validării
        """
        result = ValidationResult(ok=True)
        
        # Validează structura de bază
        if not isinstance(updates, dict):
            result.add_error("Updates must be a dictionary")
            return result
        
        # Creează o copie pentru simulare
        test_config = copy.deepcopy(self._config_data)
        
        if strategy == "overwrite":
            test_config.update(updates)
        elif strategy == "shallow":
            for k, v in updates.items():
                if k in test_config and isinstance(test_config[k], dict) and isinstance(v, dict):
                    test_config[k].update(v)
                else:
                    test_config[k] = v
        else:  # deep
            test_config = self._deep_merge(test_config, updates)
        
        # Validează configurația simulată
        return self.validate_config(test_config)
    
    def validate_config(self, config: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """
        Validează o configurație.
        
        Args:
            config: Configurația de validat (dacă None, validează configurația curentă)
            
        Returns:
            Rezultatul validării
        """
        cfg = config if config is not None else self._config_data
        result = ValidationResult(ok=True)
        
        if not isinstance(cfg, dict):
            result.add_error("Configuration must be a dictionary")
            return result
        
        # Validare de bază
        self._validate_structure(cfg, result)
        
        # Aplică validatori custom
        self._run_custom_validators(cfg, result)
        
        # Adaugă cheile validate
        result.validated_keys = list(cfg.keys())
        
        return result
    
    def register_validator(self, key: str, validator: Callable[[Any, str], Tuple[bool, str]]) -> None:
        """
        Înregistrează un validator custom pentru o cheie specifică.
        
        Args:
            key: Cheia pentru care se aplică validatorul
            validator: Funcție care primește (value, key) și returnează (is_valid, message)
        """
        self._validators[key] = validator
    
    def load_config_file(
        self, 
        file_path: Union[str, Path], 
        validate: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Încarcă configurația dintr-un fișier.
        
        Args:
            file_path: Calea către fișier
            validate: Dacă să valideze configurația încărcată
            
        Returns:
            Configurația încărcată sau None dacă a eșuat
        """
        path = Path(file_path)
        
        if not path.exists():
            self.logger.error(f"Config file not found: {path}")
            return None
        
        try:
            with open(path, 'r', encoding=self.config.default_encoding) as f:
                if path.suffix.lower() in ('.yaml', '.yml'):
                    config = yaml.safe_load(f)
                else:  # Presupunem JSON
                    config = json.load(f)
            
            if validate and self.config.validate_on_load:
                validation = self.validate_config(config)
                if not validation.ok:
                    self.logger.error(f"Config validation failed: {validation.errors}")
                    return None
            
            # Creează backup al configurației vechi
            if self._config_data:
                self._create_backup(self._config_data, label="before_load")
            
            self._config_data = config
            self.logger.info(f"Config loaded from {path}")
            
            return config
            
        except Exception as e:
            self.logger.error(f"Failed to load config from {path}: {e}")
            return None
    
    def save_config_file(
        self, 
        file_path: Union[str, Path], 
        redact_secrets: Optional[bool] = None,
        validate: bool = True
    ) -> bool:
        """
        Salvează configurația curentă într-un fișier.
        
        Args:
            file_path: Calea către fișier
            redact_secrets: Dacă să redacteze secretele (None pentru default din config)
            validate: Dacă să valideze înainte de salvare
            
        Returns:
            True dacă a reușit, False altfel
        """
        if validate and self.config.validate_on_save:
            validation = self.validate_config()
            if not validation.ok:
                self.logger.error(f"Cannot save invalid config: {validation.errors}")
                return False
        
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Pregătește configurația pentru salvare
        save_config = copy.deepcopy(self._config_data)
        
        if redact_secrets if redact_secrets is not None else self.config.redact_secrets:
            save_config = self._redact_secrets(save_config)
        
        try:
            # Scrie atomic
            self._atomic_write(
                path, 
                save_config,
                redact_secrets=False  # Deja redactat dacă era cazul
            )
            
            self.logger.info(f"Config saved to {path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to save config to {path}: {e}")
            return False
    
    def create_backup(self, label: str = "manual") -> Optional[str]:
        """
        Creează un backup manual al configurației curente.
        
        Args:
            label: Eticheta pentru backup
            
        Returns:
            Calea către backup sau None dacă a eșuat
        """
        return self._create_backup(self._config_data, label)
    
    def list_backups(self) -> List[Dict[str, Any]]:
        """
        Listează toate backup-urile disponibile.
        
        Returns:
            Lista cu informații despre backup-uri
        """
        backup_dir = self.base_dir / self.config.backup_dir
        backups = []
        
        if not backup_dir.exists():
            return backups
        
        for file_path in backup_dir.glob("config_*.json"):
            try:
                stat = file_path.stat()
                backups.append({
                    "path": str(file_path),
                    "name": file_path.name,
                    "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime),
                    "created": datetime.fromtimestamp(stat.st_ctime)
                })
            except Exception as e:
                self.logger.warning(f"Could not read backup info for {file_path}: {e}")
        
        # Sortează după data modificării (cele mai noi prima)
        backups.sort(key=lambda x: x["modified"], reverse=True)
        return backups
    
    def restore_backup(self, backup_path: Union[str, Path], validate: bool = True) -> Dict[str, Any]:
        """
        Restaurează configurația dintr-un backup.
        
        Args:
            backup_path: Calea către fișierul de backup
            validate: Dacă să valideze configurația restaurată
            
        Returns:
            Rezultatul operației
        """
        path = Path(backup_path)
        
        if not path.exists():
            return {"ok": False, "error": f"Backup file not found: {path}"}
        
        try:
            with open(path, 'r', encoding=self.config.default_encoding) as f:
                backup_config = json.load(f)
            
            # Validează configurația de backup
            if validate:
                validation = self.validate_config(backup_config)
                if not validation.ok:
                    return {
                        "ok": False, 
                        "error": "Backup validation failed",
                        "validation": validation.to_dict()
                    }
            
            # Creează backup al configurației curente înainte de restaurare
            current_backup = self._create_backup(self._config_data, label="before_restore")
            
            # Restaurează
            old_config = self._config_data
            self._config_data = backup_config
            
            return {
                "ok": True,
                "restored_from": str(path),
                "previous_backup": current_backup,
                "config_hash": self._compute_config_hash(),
                "diff": self._compute_diff(old_config, self._config_data)
            }
            
        except Exception as e:
            return {"ok": False, "error": f"Failed to restore backup: {e}"}
    
    def cleanup_old_backups(self) -> Dict[str, Any]:
        """
        Curăță backup-urile vechi conform strategiei configurate.
        
        Returns:
            Rezultatul operației cu numărul de fișiere șterse
        """
        if self.config.backup_strategy == BackupStrategy.UNLIMITED:
            return {"ok": True, "cleaned": 0, "strategy": "unlimited"}
        
        backup_dir = self.base_dir / self.config.backup_dir
        if not backup_dir.exists():
            return {"ok": True, "cleaned": 0, "strategy": "no_backup_dir"}
        
        backups = self.list_backups()
        deleted = 0
        
        if self.config.backup_strategy == BackupStrategy.ROTATE:
            # Șterge backup-urile mai vechi decât max_backups
            if len(backups) > self.config.max_backups:
                for backup in backups[self.config.max_backups:]:
                    try:
                        Path(backup["path"]).unlink()
                        deleted += 1
                    except Exception as e:
                        self.logger.warning(f"Failed to delete old backup {backup['path']}: {e}")
        
        elif self.config.backup_strategy == BackupStrategy.TIME_BASED:
            # Șterge backup-urile mai vechi decât keep_backup_hours
            cutoff_time = time.time() - (self.config.keep_backup_hours * 3600)
            for backup in backups:
                if backup["modified"].timestamp() < cutoff_time:
                    try:
                        Path(backup["path"]).unlink()
                        deleted += 1
                    except Exception as e:
                        self.logger.warning(f"Failed to delete old backup {backup['path']}: {e}")
        
        return {
            "ok": True,
            "cleaned": deleted,
            "strategy": self.config.backup_strategy.value,
            "remaining": len(backups) - deleted
        }
    
    def get_diff(self, other_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculează diferențele dintre configurația curentă și alta.
        
        Args:
            other_config: Cealaltă configurație
            
        Returns:
            Dicționar cu diferențele
        """
        return self._compute_diff(self._config_data, other_config)
    
    def export_config(
        self, 
        format: str = "json",
        redact_secrets: Optional[bool] = None
    ) -> Optional[str]:
        """
        Exportă configurația într-un string.
        
        Args:
            format: Formatul de export (json, yaml)
            redact_secrets: Dacă să redacteze secretele
            
        Returns:
            Configurația exportată ca string sau None dacă a eșuat
        """
        export_config = copy.deepcopy(self._config_data)
        
        if redact_secrets if redact_secrets is not None else self.config.redact_secrets:
            export_config = self._redact_secrets(export_config)
        
        try:
            if format.lower() == "yaml":
                return yaml.dump(export_config, default_flow_style=False, sort_keys=False)
            else:  # json
                return json.dumps(export_config, indent=2, sort_keys=False)
        except Exception as e:
            self.logger.error(f"Failed to export config: {e}")
            return None
    
    # ==================== Proprietăți ====================
    
    @property
    def data(self) -> Dict[str, Any]:
        """Returnează o copie a configurației curente."""
        return copy.deepcopy(self._config_data)
    
    @property
    def config_hash(self) -> str:
        """Returnează hash-ul configurației curente."""
        return self._compute_config_hash()
    
    # ==================== Metode private ====================
    
    def _validate_structure(self, config: Dict[str, Any], result: ValidationResult) -> None:
        """Validează structura de bază a configurației."""
        # Verifică top-level keys (exemplu - adaptează la nevoile tale)
        required_top_level = {"exchange", "risk"}
        for key in required_top_level:
            if key not in config:
                result.add_warning(f"Missing recommended top-level key: {key}")
        
        # Validări specifice pentru exchange
        if "exchange" in config:
            exchange = config["exchange"]
            if not isinstance(exchange, dict):
                result.add_error("exchange must be a dictionary", "exchange")
            else:
                if "id" in exchange and not isinstance(exchange["id"], str):
                    result.add_error("exchange.id must be a string", "exchange.id")
                if "enable_futures" in exchange and not isinstance(exchange["enable_futures"], bool):
                    result.add_error("exchange.enable_futures must be boolean", "exchange.enable_futures")
        
        # Validări specifice pentru risk
        if "risk" in config:
            risk = config["risk"]
            if not isinstance(risk, dict):
                result.add_error("risk must be a dictionary", "risk")
            else:
                rpt = risk.get("risk_per_trade")
                if rpt is not None:
                    if not isinstance(rpt, (int, float)):
                        result.add_error("risk.risk_per_trade must be a number", "risk.risk_per_trade")
                    elif rpt <= 0 or rpt > 0.2:
                        result.add_warning(
                            f"risk.risk_per_trade is {rpt} (expected 0 < x <= 0.2)", 
                            "risk.risk_per_trade"
                        )
                
                mop = risk.get("max_open_positions")
                if mop is not None and (not isinstance(mop, int) or mop < 0):
                    result.add_error("risk.max_open_positions must be integer >= 0", "risk.max_open_positions")
    
    def _run_custom_validators(self, config: Dict[str, Any], result: ValidationResult) -> None:
        """Execută validatori custom înregistrați."""
        for key, validator in self._validators.items():
            if key in config:
                is_valid, message = validator(config[key], key)
                if not is_valid:
                    result.add_error(message, key)
    
    def _deep_merge(self, base: Dict[str, Any], overlay: Dict[str, Any]) -> Dict[str, Any]:
        """
        Face merge recursiv al overlay în base.
        """
        if not isinstance(base, dict) or not isinstance(overlay, dict):
            return copy.deepcopy(overlay)
        
        result = copy.deepcopy(base)
        
        for key, value in overlay.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = copy.deepcopy(value)
        
        return result
    
    def _compute_diff(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculează diferențe detaliate între două configurații.
        """
        def collect_paths(d: Dict[str, Any], prefix: str = "") -> Dict[str, Any]:
            paths = {}
            for k, v in d.items():
                full_path = f"{prefix}.{k}" if prefix else k
                if isinstance(v, dict):
                    paths.update(collect_paths(v, full_path))
                else:
                    paths[full_path] = v
            return paths
        
        old_paths = collect_paths(old)
        new_paths = collect_paths(new)
        
        added = [k for k in new_paths if k not in old_paths]
        removed = [k for k in old_paths if k not in new_paths]
        changed = []
        changes_detail = {}
        
        for k in set(old_paths.keys()) & set(new_paths.keys()):
            if old_paths[k] != new_paths[k]:
                changed.append(k)
                changes_detail[k] = {
                    "old": old_paths[k],
                    "new": new_paths[k]
                }
        
        return {
            "added": added,
            "removed": removed,
            "changed": changed,
            "changes_detail": changes_detail,
            "total_changes": len(added) + len(removed) + len(changed)
        }
    
    def _redact_secrets(self, obj: Any) -> Any:
        """
        Redactează recursiv valorile care ar putea fi secrete.
        """
        if isinstance(obj, dict):
            result = {}
            for k, v in obj.items():
                if any(pattern in str(k).lower() for pattern in self.config.secret_key_patterns):
                    result[k] = "***REDACTED***"
                else:
                    result[k] = self._redact_secrets(v)
            return result
        elif isinstance(obj, list):
            return [self._redact_secrets(item) for item in obj]
        else:
            return obj
    
    def _create_backup(self, config: Dict[str, Any], label: str) -> Optional[str]:
        """
        Creează un backup atomic al configurației.
        """
        try:
            self._ensure_backup_dir()
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_dir = self.base_dir / self.config.backup_dir
            backup_path = backup_dir / f"config_{label}_{timestamp}.json"
            
            # Creează o versiune redactată pentru backup
            backup_config = copy.deepcopy(config)
            if self.config.redact_secrets:
                backup_config = self._redact_secrets(backup_config)
            
            # Scrie atomic
            self._atomic_write(backup_path, backup_config, redact_secrets=False)
            
            # Curăță backup-urile vechi
            self.cleanup_old_backups()
            
            return str(backup_path)
            
        except Exception as e:
            self.logger.error(f"Failed to create backup: {e}")
            return None
    
    def _atomic_write(
        self, 
        path: Path, 
        config: Dict[str, Any],
        redact_secrets: bool = False
    ) -> None:
        """
        Scrie atomic un fișier de configurație.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Pregătește conținutul
        if redact_secrets:
            config = self._redact_secrets(config)
        
        content = json.dumps(config, indent=2, sort_keys=False)
        
        # Scrie într-un fișier temporar mai întâi
        fd, temp_path = tempfile.mkstemp(
            prefix=f"{path.name}.",
            suffix=".tmp",
            dir=str(path.parent)
        )
        
        try:
            with os.fdopen(fd, 'w', encoding=self.config.default_encoding) as f:
                f.write(content)
                f.flush()
                os.fsync(f.fileno())
            
            # Înlocuiește fișierul vechi
            os.replace(temp_path, str(path))
            
        finally:
            # Curăță fișierul temporar dacă a rămas
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except Exception:
                    pass
    
    def _compute_config_hash(self) -> str:
        """
        Calculează un hash pentru configurația curentă.
        """
        config_str = json.dumps(self._config_data, sort_keys=True)
        return hashlib.sha256(config_str.encode()).hexdigest()[:16]
    
    @contextmanager
    def _lock(self):
        """
        Context manager pentru lock-uri simple la nivel de fișier.
        """
        lock_acquired = False
        max_retries = 3
        retry_delay = 0.1
        
        for attempt in range(max_retries):
            try:
                # Încearcă să creeze fișierul lock exclusiv
                fd = os.open(self._lock_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.close(fd)
                lock_acquired = True
                break
            except FileExistsError:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                else:
                    raise TimeoutError(f"Could not acquire lock after {max_retries} attempts")
        
        try:
            yield
        finally:
            if lock_acquired and self._lock_file.exists():
                try:
                    self._lock_file.unlink()
                except Exception:
                    pass


# ==================== Funcții utilitare ====================

def create_config_manager(
    config_path: Optional[Union[str, Path]] = None,
    default_config: Optional[Dict[str, Any]] = None,
    **kwargs
) -> ConfigManager:
    """
    Funcție utilitară pentru a crea un ConfigManager.
    
    Args:
        config_path: Calea către fișierul de configurație
        default_config: Configurația implicită dacă fișierul nu există
        **kwargs: Argumente suplimentare pentru ConfigManager
    
    Returns:
        Instanța ConfigManager
    """
    # Configurație implicită dacă nu este specificată
    if default_config is None:
        default_config = {
            "exchange": {
                "id": "binance",
                "enable_futures": False
            },
            "risk": {
                "risk_per_trade": 0.02,
                "max_open_positions": 3
            },
            "execution": {
                "timeout": 30
            }
        }
    
    # Dacă există fișier de configurație, încearcă să-l încarci
    if config_path and Path(config_path).exists():
        return ConfigManager(config_path=config_path, **kwargs)
    else:
        # Creează fișierul de configurație cu valorile implicite
        if config_path:
            manager = ConfigManager(initial_config=default_config, **kwargs)
            manager.save_config_file(config_path)
            return manager
        else:
            return ConfigManager(initial_config=default_config, **kwargs)


# ==================== Exemplu de utilizare ====================

if __name__ == "__main__":
    # Configurează logging
    logging.basicConfig(level=logging.INFO)
    
    # Creează un ConfigManager
    config_data = {
        "exchange": {
            "id": "binance",
            "api_key": "my_secret_key_123",
            "api_secret": "super_secret_456",
            "enable_futures": True
        },
        "risk": {
            "risk_per_trade": 0.02,
            "max_open_positions": 3
        },
        "strategy": {
            "name": "momentum",
            "params": {
                "lookback": 20,
                "threshold": 1.5
            }
        }
    }
    
    # Exemplu 1: ConfigManager simplu
    print("=== Exemplu 1: ConfigManager simplu ===")
    manager = ConfigManager(initial_config=config_data)
    
    # Obține o valoare
    api_key = manager.get("exchange.api_key")
    print(f"API Key (redacted in real usage): {api_key[:10]}...")
    
    # Actualizează o valoare
    result = manager.update({"exchange": {"enable_futures": False}})
    print(f"Update result: {result['ok']}")
    
    # Creează backup
    backup_path = manager.create_backup("example")
    print(f"Backup created at: {backup_path}")
    
    # Exportă configurația (cu redactare)
    exported = manager.export_config(redact_secrets=True)
    print(f"Exported config (first 200 chars):\n{exported[:200]}...")
    
    # Exemplu 2: Cu fișier
    print("\n=== Exemplu 2: Cu fișier ===")
    
    # Creează un fișier temporar pentru exemplu
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(config_data, f)
        temp_file = f.name
    
    try:
        file_manager = ConfigManager(config_path=temp_file)
        print(f"Config loaded from file. Hash: {file_manager.config_hash}")
        
        # Listează backup-uri
        backups = file_manager.list_backups()
        print(f"Number of backups: {len(backups)}")
        
    finally:
        # Curăță fișierul temporar
        os.unlink(temp_file)
    
    print("\nConfigManager demo completed.")
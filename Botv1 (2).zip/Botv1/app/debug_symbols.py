# test_debug_symbols.py
"""Unit tests for debug_symbols.py"""

import pytest
from unittest.mock import Mock, patch
from pathlib import Path
from debug_symbols import (
    MarketType,
    MarketInfo,
    MarketSummary,
    is_quote_matching,
    MarketType,
    summarize_markets,
    print_market_table,
)


class TestMarketType:
    """Test MarketType enum and methods."""
    
    def test_from_dict_spot(self):
        """Test detecting spot market."""
        data = {"symbol": "BTC/USDT"}
        assert MarketType.from_dict(data) == MarketType.SPOT
    
    def test_from_dict_swap(self):
        """Test detecting swap market."""
        data = {"symbol": "BTC/USDT:USDT", "swap": True}
        assert MarketType.from_dict(data) == MarketType.SWAP
    
    def test_from_dict_future(self):
        """Test detecting future market."""
        data = {"symbol": "BTC/USDT-2406", "future": True}
        assert MarketType.from_dict(data) == MarketType.FUTURE
        
        data2 = {"symbol": "BTC/USDT-2406", "contract": True}
        assert MarketType.from_dict(data2) == MarketType.FUTURE


class TestMarketInfo:
    """Test MarketInfo dataclass."""
    
    def test_from_dict(self):
        """Test creating MarketInfo from dictionary."""
        data = {
            "symbol": "BTC/USDT",
            "active": True,
            "base": "BTC",
            "quote": "USDT",
            "swap": True,
            "linear": True,
            "inverse": False,
            "contractSize": 1.0,
            "precision": {"price": 2, "amount": 6},
            "limits": {"amount": {"min": 0.001, "max": 100}}
        }
        
        market = MarketInfo.from_dict(data)
        
        assert market.symbol == "BTC/USDT"
        assert market.market_type == MarketType.SWAP
        assert market.active is True
        assert market.base == "BTC"
        assert market.quote == "USDT"
        assert market.is_contract is True
        assert market.linear is True
        assert market.inverse is False
        assert market.contract_size == 1.0
        assert market.precision_price == 2
        assert market.precision_amount == 6
        assert market.min_amount == 0.001
        assert market.max_amount == 100
    
    def test_from_dict_missing_fields(self):
        """Test with missing optional fields."""
        data = {"symbol": "ETH/USDT"}
        
        market = MarketInfo.from_dict(data)
        
        assert market.symbol == "ETH/USDT"
        assert market.market_type == MarketType.SPOT
        assert market.active is True  # default
        assert market.base == ""
        assert market.quote == ""
        assert market.is_contract is False
        assert market.linear is False
        assert market.inverse is False
        assert market.contract_size is None
        assert market.precision_price is None
        assert market.precision_amount is None
        assert market.min_amount is None
        assert market.max_amount is None


class TestQuoteMatching:
    """Test quote matching function."""
    
    def test_is_quote_matching_by_quote_field(self):
        """Test matching by quote field."""
        market = {"quote": "USDT", "symbol": "BTC/USDT"}
        assert is_quote_matching(market, "USDT") is True
        assert is_quote_matching(market, "BTC") is False
    
    def test_is_quote_matching_by_symbol_slash(self):
        """Test matching by symbol with slash."""
        market = {"symbol": "BTC/USDT"}
        assert is_quote_matching(market, "USDT") is True
    
    def test_is_quote_matching_by_symbol_no_slash(self):
        """Test matching by symbol without slash."""
        market = {"symbol": "BTCUSDT"}
        assert is_quote_matching(market, "USDT") is True
    
    def test_is_quote_matching_case_insensitive(self):
        """Test case insensitive matching."""
        market = {"symbol": "btc/usdt"}
        assert is_quote_matching(market, "USDT") is True
        assert is_quote_matching(market, "usdt") is True
    
    def test_is_quote_matching_false_positive(self):
        """Test avoiding false positives."""
        market = {"symbol": "USDT"}
        # Should not match because symbol is exactly the quote
        assert is_quote_matching(market, "USDT") is True
        
        market2 = {"symbol": "TUSD"}
        assert is_quote_matching(market2, "USDT") is False


class TestMarketSummary:
    """Test market summary functions."""
    
    def test_summarize_markets(self):
        """Test market summarization."""
        markets = {
            "BTC/USDT": {"symbol": "BTC/USDT", "active": True},
            "ETH/USDT": {"symbol": "ETH/USDT", "active": False},
            "BTC/BUSD": {"symbol": "BTC/BUSD", "active": True},
            "BTC/USDT:USDT": {"symbol": "BTC/USDT:USDT", "active": True, "swap": True},
        }
        
        summary = summarize_markets(markets, "USDT")
        
        assert summary.total == 4
        assert summary.active == 3
        assert summary.inactive == 1
        assert summary.quote_total == 3  # BTC/USDT, ETH/USDT, BTC/USDT:USDT
        assert summary.quote_spot == 2  # BTC/USDT, ETH/USDT
        assert summary.quote_futures_total == 1  # BTC/USDT:USDT
        assert summary.quote_swap == 1
        assert summary.quote_future == 0
    
    def test_summary_to_dict(self):
        """Test summary conversion to dictionary."""
        summary = MarketSummary(
            total=100,
            active=80,
            inactive=20,
            quote_total=60,
            quote_spot=40,
            quote_futures_total=20,
            quote_swap=15,
            quote_future=5
        )
        
        summary_dict = summary.to_dict()
        
        assert summary_dict["total"] == 100
        assert summary_dict["quote_total"] == 60
        assert summary_dict["quote_swap"] == 15
        assert len(summary_dict) == 8  # All fields


class TestOutputFormatting:
    """Test output formatting functions."""
    
    def test_print_market_table_empty(self, capsys):
        """Test table printing with empty list."""
        print_market_table([], limit=10)
        captured = capsys.readouterr()
        assert "No markets match the criteria" in captured.out
    
    def test_print_market_table_with_markets(self, capsys):
        """Test table printing with markets."""
        markets = [
            MarketInfo(
                symbol="BTC/USDT",
                market_type=MarketType.SPOT,
                active=True,
                base="BTC",
                quote="USDT",
                is_contract=False,
                linear=False,
                inverse=False,
                contract_size=None,
                precision_price=2,
                precision_amount=6,
                min_amount=0.001,
                max_amount=100
            )
        ]
        
        print_market_table(markets, limit=10)
        captured = capsys.readouterr()
        
        assert "Symbol" in captured.out
        assert "BTC/USDT" in captured.out
        assert "spot" in captured.out


class TestArgumentValidation:
    """Test argument validation."""
    
    @patch('debug_symbols.log')
    def test_validate_args_conflicting(self, mock_log):
        """Test validation of conflicting arguments."""
        from debug_symbols import validate_args
        
        class Args:
            futures_only = True
            spot_only = True
            active_only = False
            inactive_only = False
            type = "all"
            limit = 30
        
        args = Args()
        result = validate_args(args)
        
        assert result is False
        mock_log.error.assert_called()
    
    def test_validate_args_valid(self):
        """Test validation of valid arguments."""
        from debug_symbols import validate_args
        
        class Args:
            futures_only = False
            spot_only = False
            active_only = True
            inactive_only = False
            type = "all"
            limit = 30
        
        args = Args()
        result = validate_args(args)
        
        assert result is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
from __future__ import annotations

import os
import sys
import time
import socket
import platform
from pathlib import Path
from typing import Any, Dict, Tuple, Optional, List
from dataclasses import dataclass, field
from enum import Enum

# Optional: pkg version utilities (prefer importlib.metadata, fallback to pkg_resources)
try:
    from importlib.metadata import version as _pkg_version, PackageNotFoundError  # py3.8+
    _HAVE_IMPORTLIB_METADATA = True
except Exception:
    _HAVE_IMPORTLIB_METADATA = False
    _pkg_version = None
    PackageNotFoundError = Exception  # type: ignore

try:
    import pkg_resources  # provided by setuptools in most envs
except Exception:
    pkg_resources = None  # type: ignore


class CheckSeverity(Enum):
    """Severity levels for preflight checks."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class PreflightCheck:
    """Individual preflight check result."""
    name: str
    severity: CheckSeverity
    passed: bool
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    remediation: Optional[str] = None
    requires_action: bool = False


@dataclass
class PreflightReport:
    """Comprehensive preflight report."""
    overall_passed: bool
    mode: str
    exchange: str
    checks: List[PreflightCheck]
    critical_failures: int = 0
    errors: int = 0
    warnings: int = 0
    timestamp: float = field(default_factory=time.time)
    environment_info: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary for serialization."""
        return {
            "overall_passed": self.overall_passed,
            "mode": self.mode,
            "exchange": self.exchange,
            "checks": [
                {
                    "name": c.name,
                    "severity": c.severity.value,
                    "passed": c.passed,
                    "message": c.message,
                    "details": c.details,
                    "remediation": c.remediation,
                    "requires_action": c.requires_action,
                }
                for c in self.checks
            ],
            "summary": {
                "total_checks": len(self.checks),
                "passed": sum(1 for c in self.checks if c.passed),
                "failed": sum(1 for c in self.checks if not c.passed),
                "critical_failures": self.critical_failures,
                "errors": self.errors,
                "warnings": self.warnings,
            },
            "timestamp": self.timestamp,
            "environment_info": self.environment_info,
        }

    def get_failed_checks(self) -> List[PreflightCheck]:
        return [c for c in self.checks if not c.passed]

    def get_critical_failures(self) -> List[PreflightCheck]:
        return [c for c in self.checks if (not c.passed and c.severity == CheckSeverity.CRITICAL)]


def _as_bool(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        return bool(x)
    return str(x).strip().lower() in ("1", "true", "yes", "y", "on", "enabled")


def _as_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except (ValueError, TypeError):
        return float(default)


def _as_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except (ValueError, TypeError):
        return int(default)


def _ensure_dir(dir_path: str) -> Tuple[bool, Optional[str]]:
    """Ensure directory exists."""
    try:
        p = Path(dir_path)
        p.mkdir(parents=True, exist_ok=True)
        return True, None
    except Exception as e:
        return False, str(e)


def _is_writable_dir(dir_path: str) -> Tuple[bool, Optional[str]]:
    """Check if directory is writable."""
    try:
        p = Path(dir_path)
        p.mkdir(parents=True, exist_ok=True)
        test = p / ".write_test.tmp"

        try:
            test.write_text("test", encoding="utf-8")
        except Exception as e:
            return False, f"Cannot write to directory: {e}"

        try:
            content = test.read_text(encoding="utf-8")
            if content != "test":
                return False, "Write test failed: content mismatch"
        except Exception as e:
            return False, f"Cannot read from directory: {e}"

        try:
            test.unlink()
        except Exception:
            pass

        return True, None
    except Exception as e:
        return False, f"Directory check failed: {e}"


def _get_exchange_env_keys(exchange_id: str) -> Tuple[str, str, str]:
    ex = str(exchange_id or "").strip().upper()
    exchange_env_map = {
        "BINANCE": ("BINANCE_API_KEY", "BINANCE_API_SECRET", "BINANCE_TESTNET"),
        "BYBIT": ("BYBIT_API_KEY", "BYBIT_API_SECRET", "BYBIT_TESTNET"),
        "COINBASE": ("COINBASE_API_KEY", "COINBASE_API_SECRET", "COINBASE_SANDBOX"),
        "KUCOIN": ("KUCOIN_API_KEY", "KUCOIN_API_SECRET", "KUCOIN_SANDBOX"),
        "OKX": ("OKX_API_KEY", "OKX_API_SECRET", "OKX_SANDBOX"),
    }
    default_key = f"{ex}_API_KEY"
    default_secret = f"{ex}_API_SECRET"
    default_testnet = f"{ex}_TESTNET"
    return exchange_env_map.get(ex, (default_key, default_secret, default_testnet))


def _check_port_available(host: str, port: int) -> bool:
    """Check if a port is available for binding."""
    try_host = host
    if host.strip().lower() == "localhost":
        try_host = "127.0.0.1"
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((try_host, port))
        sock.close()
        return True
    except Exception:
        return False


def _validate_api_key_format(api_key: str, exchange: str) -> Tuple[bool, Optional[str]]:
    if not api_key or len(api_key) < 20:
        return False, "API key is too short"

    ex = exchange.lower()
    if ex == "binance":
        # Binance keys are typically long alphanumerics; avoid overfitting.
        if len(api_key) < 32:
            return False, "Binance API key seems too short (expected >= 32 chars)"
    elif ex == "bybit":
        if len(api_key) < 20:
            return False, "Bybit API key seems too short"
    return True, None


def _get_installed_version(pkg: str) -> Optional[str]:
    """Return installed package version or None."""
    if _HAVE_IMPORTLIB_METADATA and _pkg_version is not None:
        try:
            return _pkg_version(pkg)
        except PackageNotFoundError:
            return None
        except Exception:
            pass
    if pkg_resources is not None:
        try:
            return pkg_resources.get_distribution(pkg).version
        except Exception:
            return None
    return None


def _ver_ge(installed: str, minimum: str) -> bool:
    """Compare versions robustly using pkg_resources if available, else string fallback."""
    if pkg_resources is not None:
        try:
            a = pkg_resources.parse_version(installed)
            b = pkg_resources.parse_version(minimum)
            return a >= b
        except Exception:
            pass
    # Fallback (not perfect but better than crashing)
    return installed >= minimum


def _check_dependency_versions() -> List[Tuple[str, str, str, bool]]:
    """
    Check required dependencies are installed and meet minimum versions.
    NOTE: Avoid max-version locks to prevent false warnings when users upgrade.
    """
    requirements = [
        ("ccxt", "4.0.0"),
        ("pandas", "1.5.0"),
        ("numpy", "1.21.0"),
        ("sqlalchemy", "1.4.0"),
        ("websockets", "10.0.0"),
    ]
    results = []
    for pkg, min_version in requirements:
        v = _get_installed_version(pkg)
        if v is None:
            results.append((pkg, "not installed", min_version, False))
        else:
            results.append((pkg, v, min_version, _ver_ge(v, min_version)))
    return results


class PreflightValidator:
    """Enhanced preflight validation with comprehensive checks."""

    def __init__(self, cfg: Dict[str, Any], base_dir: str, log: Any):
        self.cfg = cfg or {}
        self.base_dir = Path(base_dir)
        self.log = log
        self.checks: List[PreflightCheck] = []
        self.mode = str(self.cfg.get("mode", "paper")).strip().lower()
        self.exchange = str(self.cfg.get("exchange", "binance")).strip().lower()

    def add_check(self, check: PreflightCheck) -> None:
        self.checks.append(check)

    def _safe_log(self, level: str, msg: str) -> None:
        try:
            if hasattr(self.log, level):
                getattr(self.log, level)(msg)
            elif hasattr(self.log, "info"):
                self.log.info(msg)
        except Exception:
            print(f"[preflight:{level}] {msg}", file=sys.stderr)

    def log_check(self, check: PreflightCheck) -> None:
        if not check.passed:
            if check.severity in (CheckSeverity.ERROR, CheckSeverity.CRITICAL):
                self._safe_log("error", f"[preflight] FAILED: {check.name} - {check.message}")
                if check.remediation:
                    self._safe_log("warning", f"[preflight] Remediation: {check.remediation}")
            else:
                self._safe_log("warning", f"[preflight] WARNING: {check.name} - {check.message}")
        else:
            self._safe_log("debug", f"[preflight] PASSED: {check.name}")

    def run_all_checks(self, live_flag_ok: bool) -> PreflightReport:
        self._check_configuration_structure()
        self._check_mode_validity()
        self._check_filesystem_permissions()
        self._check_exchange_configuration()
        self._check_risk_configuration()
        self._check_api_configuration()
        self._check_database_configuration()
        self._check_dependencies()
        self._check_network_configuration()
        self._check_security_settings()

        if self.mode == "live":
            self._check_live_mode_requirements(live_flag_ok)

        self._check_resource_limits()
        return self._generate_report()

    def _check_configuration_structure(self) -> None:
        # Strictly required: mode, exchange. Optional: paths.
        required_keys = ["mode", "exchange"]
        optional_keys = ["paths"]

        if not isinstance(self.cfg, dict):
            self.add_check(PreflightCheck(
                name="config_type",
                severity=CheckSeverity.CRITICAL,
                passed=False,
                message="Config must be a dictionary",
                remediation="Ensure config is loaded as a dict",
                requires_action=True,
            ))
            return

        for k in required_keys:
            if k not in self.cfg:
                self.add_check(PreflightCheck(
                    name=f"config_key_{k}",
                    severity=CheckSeverity.CRITICAL,
                    passed=False,
                    message=f"Missing required config key: {k}",
                    remediation=f"Add '{k}' to configuration",
                    requires_action=True,
                ))
            else:
                self.add_check(PreflightCheck(
                    name=f"config_key_{k}",
                    severity=CheckSeverity.INFO,
                    passed=True,
                    message=f"Config key '{k}' present",
                ))

        for k in optional_keys:
            if k not in self.cfg:
                self.add_check(PreflightCheck(
                    name=f"config_optional_{k}",
                    severity=CheckSeverity.INFO,
                    passed=True,
                    message=f"Optional config key '{k}' not present (defaults will be used)",
                ))
            else:
                self.add_check(PreflightCheck(
                    name=f"config_optional_{k}",
                    severity=CheckSeverity.INFO,
                    passed=True,
                    message=f"Optional config key '{k}' present",
                ))

    def _check_mode_validity(self) -> None:
        valid_modes = {"paper", "live", "backtest", "sandbox"}
        if self.mode not in valid_modes:
            self.add_check(PreflightCheck(
                name="mode_validity",
                severity=CheckSeverity.CRITICAL,
                passed=False,
                message=f"Invalid mode: {self.mode}. Valid: {', '.join(sorted(valid_modes))}",
                remediation=f"Set mode to one of: {', '.join(sorted(valid_modes))}",
                requires_action=True,
            ))
        else:
            self.add_check(PreflightCheck(
                name="mode_validity",
                severity=CheckSeverity.INFO,
                passed=True,
                message=f"Mode is valid: {self.mode}",
                details={"mode": self.mode},
            ))

    def _check_filesystem_permissions(self) -> None:
        paths_to_check = []

        paths = self.cfg.get("paths", {})
        if isinstance(paths, dict):
            for key in ("log_file", "trades_csv", "metrics_csv"):
                if key in paths:
                    path = self.base_dir / str(paths[key])
                    paths_to_check.append((f"paths.{key}", str(path.parent)))

        state = self.cfg.get("state", {})
        if isinstance(state, dict) and "path" in state:
            path = self.base_dir / str(state["path"])
            paths_to_check.append(("state.path", str(path.parent)))

        sqlite = self.cfg.get("sqlite", {})
        if isinstance(sqlite, dict) and "path" in sqlite:
            path = self.base_dir / str(sqlite["path"])
            paths_to_check.append(("sqlite.path", str(path.parent)))

        for name, dir_path in paths_to_check:
            ok, err = _ensure_dir(dir_path)
            if not ok:
                self.add_check(PreflightCheck(
                    name=f"fs_create_{name}",
                    severity=CheckSeverity.ERROR,
                    passed=False,
                    message=f"Cannot create directory for {name}: {dir_path} ({err})",
                    remediation="Check permissions or choose a different path",
                    requires_action=True,
                ))
                continue

            writable, werr = _is_writable_dir(dir_path)
            self.add_check(PreflightCheck(
                name=f"fs_writable_{name}",
                severity=CheckSeverity.ERROR if not writable else CheckSeverity.INFO,
                passed=writable,
                message=werr or f"Directory is writable: {dir_path}",
                details={"dir": dir_path, "name": name},
                remediation="Fix directory permissions or choose a different location" if not writable else None,
                requires_action=not writable,
            ))

    def _check_exchange_configuration(self) -> None:
        supported_exchanges = {
            "binance", "bybit", "coinbase", "kucoin", "okx",
            "gate", "huobi", "kraken", "bitget", "mexc"
        }

        if self.exchange not in supported_exchanges:
            self.add_check(PreflightCheck(
                name="exchange_support",
                severity=CheckSeverity.WARNING,
                passed=False,
                message=f"Exchange '{self.exchange}' may not be fully supported",
                details={"supported_exchanges": sorted(supported_exchanges)},
                remediation=f"Consider one of: {', '.join(sorted(supported_exchanges))}",
            ))
        else:
            self.add_check(PreflightCheck(
                name="exchange_support",
                severity=CheckSeverity.INFO,
                passed=True,
                message=f"Exchange '{self.exchange}' is supported",
            ))

        enable_futures = _as_bool(self.cfg.get("enable_futures", False))
        if enable_futures:
            futures_supported = self.exchange in {"binance", "bybit", "okx", "gate", "huobi", "bitget", "mexc"}
            self.add_check(PreflightCheck(
                name="futures_support",
                severity=CheckSeverity.WARNING if not futures_supported else CheckSeverity.INFO,
                passed=futures_supported,
                message=f"Futures trading {'supported' if futures_supported else 'not supported'} on {self.exchange}",
                remediation="Disable futures or switch exchange" if not futures_supported else None,
            ))

    def _check_risk_configuration(self) -> None:
        risk = self.cfg.get("risk", {})
        if not isinstance(risk, dict):
            risk = {}

        kill_switch = risk.get("kill_switch", {})
        if not isinstance(kill_switch, dict):
            kill_switch = {}

        kill_enabled = _as_bool(kill_switch.get("enabled", True))

        self.add_check(PreflightCheck(
            name="risk_kill_switch",
            severity=CheckSeverity.CRITICAL if self.mode == "live" else CheckSeverity.WARNING,
            passed=kill_enabled,
            message=f"Kill switch {'enabled' if kill_enabled else 'disabled'}",
            details={"enabled": kill_enabled},
            remediation="Enable kill switch for live trading" if (not kill_enabled and self.mode == "live") else None,
            requires_action=(not kill_enabled and self.mode == "live"),
        ))

        max_pos_pct = _as_float(risk.get("max_position_pct", 0.0), 0.0)
        if max_pos_pct > 0:
            valid = 0.0 < max_pos_pct <= 1.0
            self.add_check(PreflightCheck(
                name="risk_max_position_pct",
                severity=CheckSeverity.ERROR if not valid else CheckSeverity.INFO,
                passed=valid,
                message=f"Max position percentage: {max_pos_pct:.1%}",
                details={"value": max_pos_pct},
                remediation="Set max_position_pct between 0 and 1" if not valid else None,
                requires_action=not valid,
            ))

        max_leverage = _as_float(risk.get("max_leverage", 1.0), 1.0)
        if max_leverage > 1.0:
            valid = 1.0 <= max_leverage <= 125.0
            self.add_check(PreflightCheck(
                name="risk_max_leverage",
                severity=CheckSeverity.ERROR if not valid else CheckSeverity.WARNING,
                passed=valid,
                message=f"Max leverage: {max_leverage}x",
                details={"value": max_leverage},
                remediation="Set max_leverage between 1 and 125" if not valid else None,
                requires_action=not valid,
            ))

        stop_loss = risk.get("stop_loss", {})
        if not isinstance(stop_loss, dict):
            stop_loss = {}
        sl_enabled = _as_bool(stop_loss.get("enabled", False))
        sl_pct = _as_float(stop_loss.get("percent", 0.0), 0.0)

        if self.mode == "live" and not sl_enabled:
            self.add_check(PreflightCheck(
                name="risk_stop_loss",
                severity=CheckSeverity.WARNING,
                passed=False,
                message="Stop loss is disabled for live trading",
                remediation="Consider enabling stop loss",
            ))
        elif sl_enabled and (sl_pct <= 0 or sl_pct >= 100):
            self.add_check(PreflightCheck(
                name="risk_stop_loss_value",
                severity=CheckSeverity.ERROR,
                passed=False,
                message=f"Invalid stop loss percentage: {sl_pct}%",
                remediation="Set stop loss between 0.1% and 99%",
                requires_action=True,
            ))

    def _check_api_configuration(self) -> None:
        api = self.cfg.get("api", {})
        if not isinstance(api, dict):
            api = {}

        host = str(api.get("host", "127.0.0.1")).strip()
        port = _as_int(api.get("port", 8080), 8080)

        valid_hosts = {"127.0.0.1", "localhost", "0.0.0.0", "::"}
        if host not in valid_hosts:
            self.add_check(PreflightCheck(
                name="api_host",
                severity=CheckSeverity.WARNING,
                passed=False,
                message=f"Unusual API host: {host}",
                details={"host": host, "valid_hosts": sorted(valid_hosts)},
                remediation=f"Use one of: {', '.join(sorted(valid_hosts))}",
            ))

        if host in ("0.0.0.0", "::") and self.mode == "live":
            allow_public = _as_bool(os.getenv("ALLOW_PUBLIC_API"), False)
            self.add_check(PreflightCheck(
                name="api_public_binding",
                severity=CheckSeverity.CRITICAL,
                passed=allow_public,
                message="API binding to public interface in LIVE mode",
                details={"host": host, "port": port},
                remediation="Set api.host=127.0.0.1 or ALLOW_PUBLIC_API=1",
                requires_action=not allow_public,
            ))

        if host in ("127.0.0.1", "localhost", "0.0.0.0"):
            port_available = _check_port_available(host, port)
            self.add_check(PreflightCheck(
                name="api_port",
                severity=CheckSeverity.ERROR if not port_available else CheckSeverity.INFO,
                passed=port_available,
                message=f"Port {port} on {host} is {'available' if port_available else 'not available'}",
                details={"host": host, "port": port},
                remediation=f"Change API port or free port {port}" if not port_available else None,
                requires_action=not port_available,
            ))

        api_key = os.getenv("BOT_API_KEY") or str(api.get("key", "")).strip()
        if not api_key and self.mode == "live":
            self.add_check(PreflightCheck(
                name="api_auth_key",
                severity=CheckSeverity.WARNING,
                passed=False,
                message="No API authentication key configured for live mode",
                remediation="Set BOT_API_KEY or api.key in config",
            ))

    def _check_database_configuration(self) -> None:
        sqlite = self.cfg.get("sqlite", {})
        if not isinstance(sqlite, dict):
            sqlite = {}
        enabled = _as_bool(sqlite.get("enabled", True))

        if not enabled:
            self.add_check(PreflightCheck(
                name="database_enabled",
                severity=CheckSeverity.WARNING,
                passed=False,
                message="SQLite database is disabled",
                remediation="Enable SQLite for persistent storage",
            ))
            return

        db_path = sqlite.get("path", "bot.db")
        full_path = self.base_dir / str(db_path)

        try:
            import sqlite3
            test_conn = sqlite3.connect(str(full_path))
            test_conn.execute("CREATE TABLE IF NOT EXISTS preflight_test (id INTEGER PRIMARY KEY)")
            test_conn.execute("DROP TABLE IF EXISTS preflight_test")
            test_conn.close()

            self.add_check(PreflightCheck(
                name="database_connectivity",
                severity=CheckSeverity.INFO,
                passed=True,
                message=f"Database accessible: {db_path}",
                details={"path": str(full_path)},
            ))
        except Exception as e:
            self.add_check(PreflightCheck(
                name="database_connectivity",
                severity=CheckSeverity.ERROR,
                passed=False,
                message=f"Cannot access database: {e}",
                details={"path": str(full_path)},
                remediation="Check permissions or choose a different db path",
                requires_action=True,
            ))

    def _check_dependencies(self) -> None:
        dep_results = _check_dependency_versions()
        for pkg, version, min_version, ok in dep_results:
            if version == "not installed":
                self.add_check(PreflightCheck(
                    name=f"dep_{pkg}",
                    severity=CheckSeverity.CRITICAL,
                    passed=False,
                    message=f"Required package '{pkg}' is not installed",
                    details={"package": pkg, "min_version": min_version},
                    remediation=f"pip install {pkg}>={min_version}",
                    requires_action=True,
                ))
            elif not ok:
                self.add_check(PreflightCheck(
                    name=f"dep_{pkg}_version",
                    severity=CheckSeverity.WARNING,
                    passed=False,
                    message=f"Package '{pkg}' version {version} may be too old (min: {min_version})",
                    details={"package": pkg, "installed": version, "min": min_version},
                    remediation=f"Upgrade: pip install -U {pkg}",
                ))
            else:
                self.add_check(PreflightCheck(
                    name=f"dep_{pkg}_version",
                    severity=CheckSeverity.INFO,
                    passed=True,
                    message=f"Package '{pkg}' version {version} OK",
                    details={"package": pkg, "version": version},
                ))

    def _check_network_configuration(self) -> None:
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=5)
            self.add_check(PreflightCheck(
                name="network_connectivity",
                severity=CheckSeverity.INFO,
                passed=True,
                message="Internet connectivity verified",
            ))
        except Exception as e:
            self.add_check(PreflightCheck(
                name="network_connectivity",
                severity=CheckSeverity.WARNING if self.mode in ("paper", "backtest") else CheckSeverity.ERROR,
                passed=False,
                message=f"No internet connectivity: {e}",
                remediation="Check network/firewall/proxy settings",
                requires_action=self.mode == "live",
            ))

        http_proxy = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
        https_proxy = os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")
        if http_proxy or https_proxy:
            self.add_check(PreflightCheck(
                name="network_proxy",
                severity=CheckSeverity.INFO,
                passed=True,
                message="Running behind proxy",
                details={"http_proxy": http_proxy, "https_proxy": https_proxy},
                remediation="Ensure proxy allows exchange endpoints",
            ))

    def _check_security_settings(self) -> None:
        debug = self.cfg.get("debug", {})
        if not isinstance(debug, dict):
            debug = {}
        trace_enabled = _as_bool(debug.get("trace_enabled", False))

        if trace_enabled and self.mode == "live":
            self.add_check(PreflightCheck(
                name="security_debug_trace",
                severity=CheckSeverity.WARNING,
                passed=False,
                message="Debug tracing is enabled in LIVE mode",
                remediation="Disable debug.trace_enabled for production",
            ))

        sensitive_keys = {"api_key", "api_secret", "password", "token", "secret"}
        found_sensitive: List[str] = []

        def _check_dict(d: Dict[str, Any], path: str = "") -> None:
            for k, v in d.items():
                if isinstance(v, dict):
                    _check_dict(v, f"{path}.{k}" if path else str(k))
                else:
                    if isinstance(k, str) and any(s in k.lower() for s in sensitive_keys):
                        sv = str(v).strip() if v is not None else ""
                        if sv and sv not in ("***", "***REDACTED***"):
                            found_sensitive.append(f"{path}.{k}" if path else k)

        if isinstance(self.cfg, dict):
            _check_dict(self.cfg)

        allow_cfg_keys = _as_bool(os.getenv("ALLOW_KEYS_IN_CONFIG"), False)

        if found_sensitive and self.mode == "live" and not allow_cfg_keys:
            self.add_check(PreflightCheck(
                name="security_sensitive_config",
                severity=CheckSeverity.CRITICAL,
                passed=False,
                message=f"Sensitive data found in config: {', '.join(found_sensitive[:3])}",
                details={"sensitive_keys": found_sensitive},
                remediation="Move sensitive data to environment variables (or set ALLOW_KEYS_IN_CONFIG=1)",
                requires_action=True,
            ))
        elif found_sensitive and self.mode == "live" and allow_cfg_keys:
            self.add_check(PreflightCheck(
                name="security_sensitive_config_allowed",
                severity=CheckSeverity.WARNING,
                passed=True,
                message="Sensitive data found in config but allowed (ALLOW_KEYS_IN_CONFIG=1)",
                details={"sensitive_keys": found_sensitive},
                remediation="Recommended: move keys to env vars for better security",
            ))

    def _check_live_mode_requirements(self, live_flag_ok: bool) -> None:
        self.add_check(PreflightCheck(
            name="live_cli_confirmation",
            severity=CheckSeverity.CRITICAL,
            passed=live_flag_ok,
            message="CLI flag confirmation for LIVE mode",
            details={"live_flag_ok": live_flag_ok},
            remediation="Use --i-understand-live-risks flag",
            requires_action=not live_flag_ok,
        ))

        live_confirm = (os.getenv("LIVE_CONFIRM") or "").strip().upper()
        valid_confirmations = {"YES", "I_UNDERSTAND", "CONFIRM", "ENABLED"}
        env_ok = live_confirm in valid_confirmations

        self.add_check(PreflightCheck(
            name="live_env_confirmation",
            severity=CheckSeverity.CRITICAL,
            passed=env_ok,
            message="Environment confirmation for LIVE mode",
            details={"LIVE_CONFIRM": live_confirm or "not set"},
            remediation="Set LIVE_CONFIRM=YES",
            requires_action=not env_ok,
        ))

        key_name, secret_name, testnet_name = _get_exchange_env_keys(self.exchange)
        api_key_env = (os.getenv(key_name) or "").strip()
        api_secret_env = (os.getenv(secret_name) or "").strip()

        keys_from_env = bool(api_key_env and api_secret_env)
        allow_cfg_keys = _as_bool(os.getenv("ALLOW_KEYS_IN_CONFIG"), False)

        if not keys_from_env:
            api_key_cfg = str(self.cfg.get("api_key") or "").strip()
            api_secret_cfg = str(self.cfg.get("api_secret") or "").strip()
            keys_from_cfg = bool(allow_cfg_keys and api_key_cfg and api_secret_cfg)

            if keys_from_cfg:
                self.add_check(PreflightCheck(
                    name="exchange_keys_source",
                    severity=CheckSeverity.WARNING,
                    passed=True,
                    message="Exchange keys loaded from config (ALLOW_KEYS_IN_CONFIG=1)",
                    details={"source": "config", "exchange": self.exchange},
                    remediation="Recommended: move keys to env vars",
                ))

                key_valid, key_msg = _validate_api_key_format(api_key_cfg, self.exchange)
                if not key_valid:
                    self.add_check(PreflightCheck(
                        name="exchange_key_format",
                        severity=CheckSeverity.ERROR,
                        passed=False,
                        message=f"API key format invalid: {key_msg}",
                        remediation="Verify API key",
                        requires_action=True,
                    ))
            else:
                self.add_check(PreflightCheck(
                    name="exchange_keys_present",
                    severity=CheckSeverity.CRITICAL,
                    passed=False,
                    message="Exchange API keys not found in environment",
                    details={"key_env": key_name, "secret_env": secret_name},
                    remediation=f"Set {key_name} and {secret_name}",
                    requires_action=True,
                ))
        else:
            self.add_check(PreflightCheck(
                name="exchange_keys_present",
                severity=CheckSeverity.INFO,
                passed=True,
                message="Exchange API keys found in environment",
                details={"source": "environment", "exchange": self.exchange},
            ))

        testnet_env = (os.getenv(testnet_name) or "").strip().upper()
        if testnet_env in ("YES", "TRUE", "1"):
            self.add_check(PreflightCheck(
                name="exchange_testnet",
                severity=CheckSeverity.WARNING,
                passed=False,
                message=f"Testnet/Sandbox mode detected for {self.exchange}",
                details={"testnet_env": testnet_name, "value": testnet_env},
                remediation="Remove testnet flag for real trading",
            ))

    def _check_resource_limits(self) -> None:
        # Memory checks via psutil if available
        try:
            import psutil  # type: ignore
            mem = psutil.virtual_memory()
            if mem.available < 512 * 1024 * 1024:
                self.add_check(PreflightCheck(
                    name="resource_memory",
                    severity=CheckSeverity.WARNING,
                    passed=False,
                    message=f"Low available memory: {mem.available / 1024 / 1024:.0f} MB",
                    details={"available_mb": mem.available / 1024 / 1024},
                    remediation="Close other apps or add more RAM",
                ))
            else:
                self.add_check(PreflightCheck(
                    name="resource_memory",
                    severity=CheckSeverity.INFO,
                    passed=True,
                    message=f"Memory OK: {mem.available / 1024 / 1024:.0f} MB available",
                ))
        except Exception:
            self.add_check(PreflightCheck(
                name="resource_memory",
                severity=CheckSeverity.INFO,
                passed=True,
                message="Memory checks skipped (psutil not available)",
            ))

        # File descriptor limits only on POSIX
        if os.name != "nt":
            try:
                import resource  # type: ignore
                soft_limit, hard_limit = resource.getrlimit(resource.RLIMIT_NOFILE)
                if soft_limit < 1024:
                    self.add_check(PreflightCheck(
                        name="resource_file_descriptors",
                        severity=CheckSeverity.WARNING,
                        passed=False,
                        message=f"Low file descriptor limit: {soft_limit}",
                        details={"soft_limit": soft_limit, "hard_limit": hard_limit},
                        remediation="Increase ulimit -n to at least 1024",
                    ))
                else:
                    self.add_check(PreflightCheck(
                        name="resource_file_descriptors",
                        severity=CheckSeverity.INFO,
                        passed=True,
                        message=f"File descriptor limit OK: {soft_limit}",
                        details={"soft_limit": soft_limit, "hard_limit": hard_limit},
                    ))
            except Exception as e:
                self.add_check(PreflightCheck(
                    name="resource_file_descriptors",
                    severity=CheckSeverity.INFO,
                    passed=True,
                    message=f"FD limit checks skipped: {e}",
                ))

    def _generate_report(self) -> PreflightReport:
        critical_failures = sum(1 for c in self.checks if (not c.passed and c.severity == CheckSeverity.CRITICAL))
        errors = sum(1 for c in self.checks if (not c.passed and c.severity == CheckSeverity.ERROR))
        warnings = sum(1 for c in self.checks if (not c.passed and c.severity == CheckSeverity.WARNING))

        overall_passed = (critical_failures == 0 and errors == 0)

        for check in self.checks:
            self.log_check(check)

        env_info = {
            "python_version": sys.version,
            "platform": platform.platform(),
            "working_directory": str(self.base_dir),
            "user": os.getenv("USER") or os.getenv("USERNAME") or "unknown",
        }

        return PreflightReport(
            overall_passed=overall_passed,
            mode=self.mode,
            exchange=self.exchange,
            checks=self.checks,
            critical_failures=critical_failures,
            errors=errors,
            warnings=warnings,
            environment_info=env_info,
        )


def preflight_or_die(
    cfg: Dict[str, Any],
    base_dir: str,
    log: Any,
    *,
    live_flag_ok: bool,
    dry_run: bool = False,
    fail_on_warnings: bool = False,
) -> Optional[PreflightReport]:
    validator = PreflightValidator(cfg, base_dir, log)
    report = validator.run_all_checks(live_flag_ok)

    should_fail = False
    failure_reasons: List[str] = []

    if not report.overall_passed:
        should_fail = True
        crit = report.get_critical_failures()
        failure_reasons.extend([f"{c.name}: {c.message}" for c in crit[:3]])

        # add top errors too (helps debugging)
        errs = [c for c in report.checks if (not c.passed and c.severity == CheckSeverity.ERROR)]
        failure_reasons.extend([f"Error: {c.name}: {c.message}" for c in errs[:3]])

    if fail_on_warnings and report.warnings > 0:
        should_fail = True
        warns = [c for c in report.checks if (not c.passed and c.severity == CheckSeverity.WARNING)]
        failure_reasons.extend([f"Warning: {c.name}: {c.message}" for c in warns[:3]])

    if should_fail and not dry_run:
        error_msg = "Preflight checks failed:\n" + "\n".join(failure_reasons)
        raise SystemExit(error_msg)

    log.info(
        f"[preflight] {'PASSED' if report.overall_passed else 'FAILED'} "
        f"(Checks: {len(report.checks)}, "
        f"Passed: {sum(1 for c in report.checks if c.passed)}, "
        f"Failed: {sum(1 for c in report.checks if not c.passed)}, "
        f"Critical: {report.critical_failures}, Errors: {report.errors}, Warnings: {report.warnings})"
    )

    return report if dry_run else None


def run_preflight_from_cli(config_path: str, base_dir: Optional[str] = None) -> int:
    import json
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)

        import logging
        logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
        log = logging.getLogger("preflight")

        if base_dir is None:
            base_dir = os.path.dirname(os.path.abspath(config_path))

        report = preflight_or_die(
            cfg=cfg,
            base_dir=base_dir,
            log=log,
            live_flag_ok=False,
            dry_run=True,
            fail_on_warnings=False,
        )

        if report:
            print("\n" + "=" * 60)
            print("PREFLIGHT CHECK REPORT")
            print("=" * 60)
            print(f"\nSummary: {'PASSED' if report.overall_passed else 'FAILED'}")
            print(f"Mode: {report.mode}")
            print(f"Exchange: {report.exchange}")
            print(f"Total Checks: {len(report.checks)}")
            print(f"Passed: {sum(1 for c in report.checks if c.passed)}")
            print(f"Failed: {sum(1 for c in report.checks if not c.passed)}")
            print(f"Critical Failures: {report.critical_failures}")
            print(f"Errors: {report.errors}")
            print(f"Warnings: {report.warnings}")

            failed = report.get_failed_checks()
            if failed:
                print(f"\nFailed Checks ({len(failed)}):")
                for check in failed:
                    print(f"  [{check.severity.value.upper()}] {check.name}: {check.message}")
                    if check.remediation:
                        print(f"     Remediation: {check.remediation}")

            print("\nEnvironment:")
            for k, v in report.environment_info.items():
                print(f"  {k}: {v}")

            print("\n" + "=" * 60)
            return 0 if report.overall_passed else 1

        return 0

    except FileNotFoundError:
        print(f"Error: Config file not found: {config_path}")
        return 1
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in config file: {e}")
        return 1
    except Exception as e:
        print(f"Error: {e}")
        return 1


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Run preflight checks")
    parser.add_argument("--config", "-c", required=True, help="Configuration file path")
    parser.add_argument("--base-dir", "-b", help="Base directory for relative paths")
    args = parser.parse_args()
    sys.exit(run_preflight_from_cli(args.config, args.base_dir))

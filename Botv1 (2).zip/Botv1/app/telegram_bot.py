from __future__ import annotations

import os
import requests
from typing import Optional

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

API_URL = os.environ.get("BOT_API_URL", "http://127.0.0.1:8000").rstrip("/")
TOKEN = os.environ.get("TELEGRAM_TOKEN", "")

def _post(path: str, payload: Optional[dict] = None) -> dict:
    r = requests.post(f"{API_URL}{path}", json=payload or {}, timeout=10)
    r.raise_for_status()
    return r.json()

def _get(path: str) -> dict:
    r = requests.get(f"{API_URL}{path}", timeout=10)
    r.raise_for_status()
    return r.json()

async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = _get("/status")
    await update.message.reply_text(str(s))

async def cmd_pause(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _post("/control/pause_entries")
    await update.message.reply_text("Entries paused.")

async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _post("/control/resume_entries")
    await update.message.reply_text("Entries resumed.")

async def cmd_panic(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _post("/control/panic_stop")
    await update.message.reply_text("Panic stop triggered.")

async def cmd_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _post("/control/stop")
    await update.message.reply_text("Engine stop requested.")

async def cmd_long(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("Usage: /long BTC/USDT [notional_usd]")
        return
    sym = context.args[0].upper()
    notional = float(context.args[1]) if len(context.args) > 1 else 0.0
    _post("/control/manual_entry", {"symbol": sym, "side": "long", "notional_usd": notional})
    await update.message.reply_text(f"Manual LONG queued for {sym} (notional_usd={notional}).")

async def cmd_short(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("Usage: /short BTC/USDT [notional_usd]")
        return
    sym = context.args[0].upper()
    notional = float(context.args[1]) if len(context.args) > 1 else 0.0
    _post("/control/manual_entry", {"symbol": sym, "side": "short", "notional_usd": notional})
    await update.message.reply_text(f"Manual SHORT queued for {sym} (notional_usd={notional}).")

def main():
    if not TOKEN:
        raise SystemExit("Set TELEGRAM_TOKEN in environment.")
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("pause", cmd_pause))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("panic", cmd_panic))
    app.add_handler(CommandHandler("stop", cmd_stop))
    app.add_handler(CommandHandler("long", cmd_long))
    app.add_handler(CommandHandler("short", cmd_short))

    app.run_polling()

if __name__ == "__main__":
    main()

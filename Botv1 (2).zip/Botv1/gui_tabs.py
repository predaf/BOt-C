from __future__ import annotations

"""GUI tab builders.

This module contains only UI construction (Notebook tabs and widgets).
All business logic and callbacks remain methods on the BotGUI instance.

Functions here attach widgets/variables onto the `gui` instance so the
rest of the application can continue to use `gui.<attr>` as before.
"""

import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

def build_tabs(gui) -> None:
    gui.nb = ttk.Notebook(gui)
    gui.nb.pack(fill="both", expand=True)

    gui.t_settings = ttk.Frame(gui.nb)
    gui.t_status = ttk.Frame(gui.nb)
    gui.t_signals = ttk.Frame(gui.nb)
    gui.t_backtest = ttk.Frame(gui.nb)
    gui.t_approvals = ttk.Frame(gui.nb)
    gui.t_logs = ttk.Frame(gui.nb)

    gui.nb.add(gui.t_settings, text="Settings")
    gui.nb.add(gui.t_status, text="Status")
    gui.nb.add(gui.t_signals, text="Signals")
    gui.nb.add(gui.t_backtest, text="Backtest")
    gui.nb.add(gui.t_approvals, text="Approvals")
    gui.nb.add(gui.t_logs, text="Logs")

    build_settings_tab(gui)
    build_status_tab(gui)
    build_signals_tab(gui)
    build_backtest_tab(gui)
    build_approvals_tab(gui)
    build_logs_tab(gui)


def build_settings_tab(gui) -> None:
    frm=gui.t_settings
    left=ttk.Frame(frm); left.pack(side="left", fill="both", expand=True, padx=12, pady=12)
    right=ttk.Frame(frm); right.pack(side="right", fill="both", expand=True, padx=12, pady=12)

    r=0
    ttk.Label(left, text="Profile").grid(row=r, column=0, sticky="w")
    gui.var_profile=tk.StringVar(value="(none)")
    gui.cmb_profile=ttk.Combobox(left, textvariable=gui.var_profile, values=["(none)","conservative","balanced","aggressive"], width=18, state="readonly")
    gui.cmb_profile.grid(row=r, column=1, sticky="w")
    ttk.Button(left, text="Apply", command=gui._apply_profile).grid(row=r, column=2, padx=8)
    r+=1

    ttk.Label(left, text="Mode").grid(row=r, column=0, sticky="w")
    gui.var_mode=tk.StringVar()
    ttk.Combobox(left, textvariable=gui.var_mode, values=["paper","live"], width=12, state="readonly").grid(row=r, column=1, sticky="w")
    r+=1

    ttk.Label(left, text="Exchange").grid(row=r, column=0, sticky="w")
    gui.var_exchange=tk.StringVar()
    ttk.Combobox(left, textvariable=gui.var_exchange, values=["binance","bybit"], width=12, state="readonly").grid(row=r, column=1, sticky="w")
    r+=1

    ttk.Label(left, text="API Key").grid(row=r, column=0, sticky="w")
    gui.ent_key=ttk.Entry(left, width=52); gui.ent_key.grid(row=r, column=1, sticky="w", columnspan=2)
    r+=1
    ttk.Label(left, text="API Secret").grid(row=r, column=0, sticky="w")
    gui.ent_secret=ttk.Entry(left, width=52, show="*"); gui.ent_secret.grid(row=r, column=1, sticky="w", columnspan=2)
    r+=1

    ttk.Label(left, text="Scan interval (sec)").grid(row=r, column=0, sticky="w")
    gui.var_scan=tk.IntVar()
    ttk.Spinbox(left, from_=5, to=120, increment=5, textvariable=gui.var_scan, width=12).grid(row=r, column=1, sticky="w")
    r+=1

    ttk.Label(left, text="Execution").grid(row=r, column=0, sticky="w")
    gui.var_exec=tk.StringVar()
    ttk.Combobox(left, textvariable=gui.var_exec, values=["market","maker_limit","smart_limit"], width=14, state="readonly").grid(row=r, column=1, sticky="w")
    r+=1

    gui.var_post=tk.BooleanVar()
    ttk.Checkbutton(left, text="Post-only", variable=gui.var_post).grid(row=r, column=1, sticky="w")
    r+=1

    gui.var_allow_fb=tk.BooleanVar()
    ttk.Checkbutton(left, text="Allow market fallback", variable=gui.var_allow_fb).grid(row=r, column=1, sticky="w")
    r+=1

    ttk.Label(left, text="Whitelist").grid(row=r, column=0, sticky="nw")
    gui.txt_w=tk.Text(left, height=7, width=36); gui.txt_w.grid(row=r, column=1, sticky="w", columnspan=2)
    r+=1

    ttk.Label(left, text="Blacklist").grid(row=r, column=0, sticky="nw")
    gui.txt_b=tk.Text(left, height=7, width=36); gui.txt_b.grid(row=r, column=1, sticky="w", columnspan=2)
    r+=1

    rr=0
    ttk.Label(right, text="Local-only API / Approvals", font=("Segoe UI", 11, "bold")).grid(row=rr, column=0, columnspan=2, sticky="w"); rr+=1
    gui.var_require_appr=tk.BooleanVar()
    ttk.Checkbutton(right, text="Require approvals in LIVE", variable=gui.var_require_appr).grid(row=rr, column=1, sticky="w"); rr+=1

    gui.var_api=tk.BooleanVar()
    ttk.Checkbutton(right, text="Start local API (127.0.0.1:8000)", variable=gui.var_api).grid(row=rr, column=1, sticky="w"); rr+=1

    btn=ttk.Frame(frm); btn.pack(side="bottom", fill="x", padx=12, pady=12)
    ttk.Button(btn, text="Save config", command=gui._save_from_ui).pack(side="left")
    ttk.Button(btn, text="Load config", command=gui._load_cfg).pack(side="left", padx=8)
    ttk.Button(btn, text="Export trades CSV", command=gui._export_trades).pack(side="left", padx=8)

    gui.btn_start=ttk.Button(btn, text="START", command=gui._start)
    gui.btn_stop=ttk.Button(btn, text="STOP", command=gui._stop, state="disabled")
    gui.btn_stop.pack(side="right")
    gui.btn_start.pack(side="right", padx=8)


def build_status_tab(gui) -> None:
    frm=gui.t_status
    top=ttk.Frame(frm); top.pack(fill="x", padx=12, pady=10)
    gui.lbl_run=ttk.Label(top, text="Running: NO"); gui.lbl_run.pack(side="left", padx=8)
    gui.lbl_eq=ttk.Label(top, text="Equity: -"); gui.lbl_eq.pack(side="left", padx=8)
    gui.lbl_halt=ttk.Label(top, text="Halted: -"); gui.lbl_halt.pack(side="left", padx=8)
    gui.lbl_pause=ttk.Label(top, text="Entries paused: -"); gui.lbl_pause.pack(side="left", padx=8)

    cols=("symbol","qty","entry","stop","tp")
    gui.tree_pos=ttk.Treeview(frm, columns=cols, show="headings", height=18)
    for c in cols:
        gui.tree_pos.heading(c, text=c); gui.tree_pos.column(c, width=210, anchor="w")
    gui.tree_pos.pack(fill="both", expand=True, padx=12, pady=10)

    ttk.Label(frm, text="Pending orders").pack(anchor="w", padx=12)
    cols_o=("id","symbol","side","type","qty","price","status")
    gui.tree_ord=ttk.Treeview(frm, columns=cols_o, show="headings", height=8)
    for c in cols_o:
        gui.tree_ord.heading(c, text=c)
        gui.tree_ord.column(c, width=210, anchor="w")
    gui.tree_ord.pack(fill="x", expand=False, padx=12, pady=(6,10))


    ctrl=ttk.Frame(frm); ctrl.pack(fill="x", padx=12, pady=10)
    ttk.Button(ctrl, text="Close ALL", command=gui._close_all).pack(side="left")
    ttk.Button(ctrl, text="Pause entries", command=gui._pause_entries).pack(side="left", padx=8)
    ttk.Button(ctrl, text="Resume entries", command=gui._resume_entries).pack(side="left", padx=8)


def build_signals_tab(gui) -> None:
    frm = gui.t_signals

    top = ttk.Frame(frm)
    top.pack(fill="x", padx=10, pady=8)

    ttk.Button(top, text="Refresh now", command=gui._refresh_signals).pack(side="left")
    ttk.Button(top, text="Export signals CSV", command=gui._export_signals_csv).pack(side="left", padx=8)

    gui.lbl_sig = ttk.Label(top, text="Signals: n/a")
    gui.lbl_sig.pack(side="right")

    body = ttk.Frame(frm)
    body.pack(fill="both", expand=True, padx=10, pady=8)

    cols = ("ts", "symbol", "action", "strength", "price", "reason")
    gui.sig_tree = ttk.Treeview(body, columns=cols, show="headings", height=12)
    for c in cols:
        gui.sig_tree.heading(c, text=c)
        gui.sig_tree.column(c, width=140 if c in ("ts","reason") else 100, anchor="w")
    gui.sig_tree.column("reason", width=420, anchor="w")
    gui.sig_tree.pack(side="left", fill="both", expand=True)

    sc = ttk.Scrollbar(body, orient="vertical", command=gui.sig_tree.yview)
    gui.sig_tree.configure(yscrollcommand=sc.set)
    sc.pack(side="left", fill="y")

    right = ttk.Frame(body)
    right.pack(side="left", fill="both", expand=False, padx=(10,0))

    ttk.Label(right, text="Explain").pack(anchor="w")
    gui.sig_explain = tk.Text(right, height=16, width=60)
    gui.sig_explain.pack(fill="both", expand=True)

    gui.sig_tree.bind("<<TreeviewSelect>>", gui._on_select_signal)

    gui._signals_cache = []
    gui.after(1000, gui._refresh_signals)


def build_backtest_tab(gui) -> None:
    frm = gui.t_backtest

    top = ttk.Frame(frm)
    top.pack(fill="x", padx=10, pady=8)

    # Symbols input
    ttk.Label(top, text="Symbols (comma-separated)").pack(side="left")
    gui.var_bt_symbols = tk.StringVar(value=gui._default_bt_symbols())
    ent = ttk.Entry(top, textvariable=gui.var_bt_symbols, width=55)
    ent.pack(side="left", padx=6)

    ttk.Label(top, text="Bars").pack(side="left", padx=(10,0))
    gui.var_bt_bars = tk.IntVar(value=int(gui.cfg.get("auto_opt", {}).get("backtest_bars", 1500) or 1500))
    ttk.Entry(top, textvariable=gui.var_bt_bars, width=8).pack(side="left", padx=6)

    ttk.Label(top, text="Signal TF").pack(side="left", padx=(10,0))
    gui.var_bt_tf = tk.StringVar(value=str(gui.cfg.get("signal_timeframe","5m")))
    ttk.Combobox(top, textvariable=gui.var_bt_tf, width=6, values=("1m","3m","5m","15m","30m","1h","2h","4h","1d"), state="readonly").pack(side="left", padx=6)

    ttk.Label(top, text="Trend TF").pack(side="left", padx=(10,0))
    gui.var_bt_trend_tf = tk.StringVar(value=str(gui.cfg.get("trend_timeframe","15m")))
    ttk.Combobox(top, textvariable=gui.var_bt_trend_tf, width=6, values=("5m","15m","30m","1h","2h","4h","1d"), state="readonly").pack(side="left", padx=6)

    gui.var_bt_use_wfo = tk.BooleanVar(value=False)
    ttk.Checkbutton(top, text="Walk-forward optimize (WFO light)", variable=gui.var_bt_use_wfo).pack(side="left", padx=(12,0))

    btns = ttk.Frame(frm)
    btns.pack(fill="x", padx=10, pady=(0,8))

    gui.btn_bt_run = ttk.Button(btns, text="Run", command=gui._bt_start_run)
    gui.btn_bt_run.pack(side="left")

    gui.btn_bt_opt = ttk.Button(btns, text="Optimize (global)", command=gui._bt_start_global_opt)
    gui.btn_bt_opt.pack(side="left", padx=8)

    gui.btn_bt_cancel = ttk.Button(btns, text="Cancel", command=gui._bt_cancel_run, state="disabled")
    gui.btn_bt_cancel.pack(side="left", padx=8)

    ttk.Button(btns, text="Export results CSV", command=gui._bt_export_csv).pack(side="left", padx=8)

    gui.lbl_bt = ttk.Label(btns, text="Backtest: idle")
    gui.lbl_bt.pack(side="right")

    body = ttk.Frame(frm)
    body.pack(fill="both", expand=True, padx=10, pady=8)

    cols = ("symbol","trades","win_rate","return_pct","max_dd","profit_factor","equity_end","note")
    gui.bt_tree = ttk.Treeview(body, columns=cols, show="headings", height=18)
    for c in cols:
        gui.bt_tree.heading(c, text=c)
        gui.bt_tree.column(c, width=120 if c not in ("note",) else 420, anchor="w")
    gui.bt_tree.column("symbol", width=120)
    gui.bt_tree.column("trades", width=70, anchor="e")
    gui.bt_tree.column("win_rate", width=90, anchor="e")
    gui.bt_tree.column("return_pct", width=90, anchor="e")
    gui.bt_tree.column("max_dd", width=90, anchor="e")
    gui.bt_tree.column("profit_factor", width=90, anchor="e")
    gui.bt_tree.column("equity_end", width=110, anchor="e")

    ysb = ttk.Scrollbar(body, orient="vertical", command=gui.bt_tree.yview)
    gui.bt_tree.configure(yscroll=ysb.set)
    gui.bt_tree.pack(side="left", fill="both", expand=True)
    ysb.pack(side="right", fill="y")

    gui._bt_results = []
    gui._bt_running = False
    gui._bt_cancel_flag = False
    gui._bt_mode = "run"
    gui._bt_thread = None


def build_approvals_tab(gui) -> None:
    frm=gui.t_approvals
    ttk.Label(frm, text="Pending approvals (approve/reject). If LIVE approvals are enabled, BUY entries will wait here.").pack(anchor="w", padx=12, pady=10)
    cols=("id","created","symbol","side","qty","price_ref","status")
    gui.tree_app=ttk.Treeview(frm, columns=cols, show="headings", height=18)
    for c in cols:
        gui.tree_app.heading(c, text=c); gui.tree_app.column(c, width=240, anchor="w")
    gui.tree_app.pack(fill="both", expand=True, padx=12, pady=10)

    btn=ttk.Frame(frm); btn.pack(fill="x", padx=12, pady=10)
    ttk.Button(btn, text="Approve", command=gui._approve).pack(side="left")
    ttk.Button(btn, text="Reject", command=gui._reject).pack(side="left", padx=8)
    ttk.Button(btn, text="Refresh", command=gui._refresh_approvals).pack(side="left", padx=8)


def build_logs_tab(gui) -> None:
    frm=gui.t_logs
    gui.txt=tk.Text(frm, height=50)
    gui.txt.pack(fill="both", expand=True, padx=12, pady=12)
    gui.txt.configure(state="disabled")

# Live-readiness report (file-by-file)

This report lists the concrete changes applied to make the project safer and more reproducible for LIVE deployments.

## 1) `config.json`
**Problem:** contained real API keys/secrets and mixed paper/live concerns.

**Fix:**
- `api_key`/`api_secret` scrubbed.
- defaults kept as `mode: paper`.
- `sandbox:false` (paper should use real market data by default; testnet is explicit now).

## 2) `config.live.template.json`
New template for LIVE deployments:
- `mode: live`
- `approvals.enabled=true` + `approvals.require_for_live=true` (safer default)
- runtime artifacts written under `runtime/`:
  - logs: `runtime/logs/bot.log`
  - state: `runtime/state.json`
  - sqlite: `runtime/bot.db`

## 3) `config.testnet.template.json`
Same as the LIVE template but with:
- `sandbox:true`
- `bybit_testnet:true`

## 4) `.env` and `.env.example`
**Problem:** `.env` contained real keys.

**Fix:**
- `.env` scrubbed.
- `.env.example` expanded with LIVE safety flags:
  - `LIVE_CONFIRM`
  - `SANDBOX`
  - `ALLOW_PUBLIC_API`
  - `ALLOW_KEYS_IN_CONFIG`

## 5) `app/exchange.py`
**Problem:** `sandbox` / `testnet` flags existed in config but were not actually applied.

**Fix:**
- Added best-effort sandbox enabling immediately after exchange instantiation:
  - calls `set_sandbox_mode(True)` or `setSandboxMode(True)` when `SANDBOX=1` or `config.sandbox=true`.
- Keeps existing futures/spot defaultType logic.

## 6) `app/preflight.py` (NEW)
**Purpose:** hard safety checks before starting in LIVE.

Checks:
- Requires `--i-understand-live-risks` for LIVE headless.
- Requires `LIVE_CONFIRM=YES` (or `I_UNDERSTAND` / `CONFIRM`).
- Prefers keys from env; allows config keys only if `ALLOW_KEYS_IN_CONFIG=1`.
- Ensures kill switch is enabled.
- Refuses public API bind (`0.0.0.0`/`::`) unless `ALLOW_PUBLIC_API=1`.
- Creates parent directories for log/state/db paths.

## 7) `app/run.py`
**Fix:** integrated `preflight_or_die()` right after logger setup so LIVE can’t start without explicit confirmation.

## 8) `crypto_bot_gui.py`
**Fix:** strengthened `_validate_live()`:
- requires `LIVE_CONFIRM=YES` for LIVE
- checks kill-switch enabled
- blocks public API bind unless `ALLOW_PUBLIC_API=1`
- still supports config keys or env keys

## 9) `Dockerfile.headless` + `docker-compose.prod.yml` (NEW)
**Purpose:** stable headless deployment on VPS.
- non-root user
- persistent runtime volume `./runtime:/app/runtime`
- localhost-only port bindings by default

## 10) Cleanup
Removed:
- stray text output files that could contain sensitive data
- `__pycache__` artifacts


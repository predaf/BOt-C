# run_api.py
from __future__ import annotations
import os, threading

import uvicorn

from app.config import load_config, apply_env_overrides
from app.utils import UILogger, CompositeLogger, setup_file_logger
from app.records import TradeRecorder
from app.engine import TradingEngine
from app.api import create_app

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    cfg_path = os.path.join(base_dir, "config.json")

    cfg = load_config(cfg_path, {})
    cfg = apply_env_overrides(cfg)

    ui = UILogger()
    log = CompositeLogger(ui, setup_file_logger(os.path.join(base_dir, cfg.get("paths", {}).get("log_file", "logs/bot.log"))))
    rec = TradeRecorder()

    engine = TradingEngine(cfg, log, rec, base_dir=base_dir)
    t = threading.Thread(target=engine.loop, daemon=True)
    t.start()

    api_cfg = cfg.get("api", {}) or {}
    host = str(api_cfg.get("host", "127.0.0.1"))
    port = int(api_cfg.get("port", 8000))

    app = create_app(engine)
    uvicorn.run(app, host=host, port=port, log_level="info")

if __name__ == "__main__":
    main()

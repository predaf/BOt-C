from app.health import HealthMonitor

class L:
    def info(self,*a,**k): pass
    def warning(self,*a,**k): pass
    def warn(self,*a,**k): pass
    def error(self,*a,**k): pass
    def debug(self,*a,**k): pass

hm = HealthMonitor({}, L())
import app.health as h
print("health file =", h.__file__)
print("has _lock =", hasattr(hm, "_lock"))
print("lock type =", type(getattr(hm, "_lock", None)).__name__)
try:
    _ = hm.last_state
    print("last_state access ok = True")
except Exception as e:
    print("last_state access ok = False:", type(e).__name__, e)
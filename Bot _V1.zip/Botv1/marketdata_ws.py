"""Compatibility shim.

Some tests or older modules import `store_sqlite` from project root.
The actual implementation lives in `app.store_sqlite`.
"""

# Compatibility shim
from app.marketdata_ws import *  # noqa: F401,F403


__all__ = ["SQLiteStore", "_safe_float", "_safe_int", "_sanitize_jsonable"]

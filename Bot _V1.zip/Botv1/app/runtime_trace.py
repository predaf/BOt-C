# test_runtime_trace.py
import time
import threading
import pytest
from collections import deque
from unittest.mock import Mock, patch

from runtime_trace import (
    hit, reset, snapshot, top,
    _now_wall, _now_mono, _prune_keys_if_needed, _window_rate_for
)


def test_now_functions():
    """Test time functions."""
    wall_time = _now_wall()
    mono_time = _now_mono()
    
    assert isinstance(wall_time, float)
    assert isinstance(mono_time, float)
    assert wall_time > 0
    assert mono_time > 0
    
    # Test that monotonic time increases
    time1 = _now_mono()
    time.sleep(0.001)
    time2 = _now_mono()
    assert time2 > time1


def test_basic_hit_counting():
    """Test basic event counting."""
    # Reset all counters
    reset()
    
    # Record some hits
    hit("event_a")
    hit("event_a", n=2)
    hit("event_b")
    
    # Get snapshot
    snap = snapshot(include_rates=False)
    
    assert snap["total_events"] == 4  # 1 + 2 + 1
    assert snap["distinct_keys"] == 2
    assert snap["counts"]["event_a"] == 3
    assert snap["counts"]["event_b"] == 1
    
    # Test with zero or negative n
    hit("event_c", n=0)  # Should be treated as n=1
    hit("event_d", n=-5)  # Should be treated as n=1
    
    snap2 = snapshot(include_rates=False)
    assert snap2["counts"].get("event_c", 0) == 1
    assert snap2["counts"].get("event_d", 0) == 1
    
    # Test empty name
    hit("")  # Should be ignored
    snap3 = snapshot(include_rates=False)
    # Count should not change
    assert snap3["total_events"] == snap2["total_events"]


def test_timestamps():
    """Test that timestamps are recorded correctly."""
    reset()
    
    before = _now_wall()
    hit("test_event")
    after = _now_wall()
    
    snap = snapshot(include_rates=False)
    
    assert "test_event" in snap["last_ts"]
    event_time = snap["last_ts"]["test_event"]
    
    assert before <= event_time <= after
    
    # Check age
    snap_with_rates = snapshot(include_rates=True)
    age = snap_with_rates["last_age_sec"]["test_event"]
    assert 0 <= age <= (after - before) + 0.1  # Allow small tolerance


def test_ema_rate_calculation():
    """Test EMA rate estimation."""
    reset()
    
    # First hit should initialize rate
    hit("test_rate", ema_alpha=0.5)
    snap = snapshot(include_rates=True)
    assert snap["rate_ema_per_sec"]["test_rate"] == 0.0  # First hit, no rate yet
    
    # Small delay then second hit
    time.sleep(0.1)
    hit("test_rate", ema_alpha=0.5)
    snap2 = snapshot(include_rates=True)
    
    rate = snap2["rate_ema_per_sec"]["test_rate"]
    assert rate > 0.0  # Should have a positive rate
    
    # Hit multiple times quickly
    for _ in range(5):
        hit("test_rate", ema_alpha=0.5)
    
    snap3 = snapshot(include_rates=True)
    rate3 = snap3["rate_ema_per_sec"]["test_rate"]
    # Rate should be higher after multiple quick hits
    assert rate3 > rate
    
    # Test alpha bounds
    hit("test_alpha_low", ema_alpha=-0.1)  # Should be clamped to 0.0
    hit("test_alpha_high", ema_alpha=1.5)  # Should be clamped to 1.0
    
    # Alpha 0.0 should not update rate from initial value
    reset("test_alpha_zero")
    hit("test_alpha_zero", ema_alpha=0.0)
    time.sleep(0.01)
    hit("test_alpha_zero", ema_alpha=0.0, n=10)
    snap_alpha = snapshot(include_rates=True)
    # With alpha=0, rate should remain at initial value (0.0)
    assert snap_alpha["rate_ema_per_sec"]["test_alpha_zero"] == 0.0


def test_window_rate_tracking():
    """Test sliding window rate tracking."""
    reset()
    
    # Enable recent tracking
    hit("window_event", track_recent=True, recent_window_sec=1.0)
    
    # Get initial snapshot
    snap = snapshot(include_rates=True, window_rate_sec=1.0)
    window_rate = snap["rate_window_per_sec"]["window_event"]
    assert window_rate == 0.0  # Only 1 hit, can't calculate rate
    
    # Add more hits quickly
    for i in range(5):
        hit("window_event", track_recent=True, recent_window_sec=1.0)
    
    snap2 = snapshot(include_rates=True, window_rate_sec=1.0)
    window_rate2 = snap2["rate_window_per_sec"]["window_event"]
    # Should have positive rate
    assert window_rate2 > 0.0
    
    # Wait for window to expire
    time.sleep(1.1)  # Slightly more than window
    
    # Rate should drop (hits are now outside window)
    snap3 = snapshot(include_rates=True, window_rate_sec=1.0)
    window_rate3 = snap3["rate_window_per_sec"]["window_event"]
    assert window_rate3 == 0.0  # All hits expired
    
    # Test with different window sizes
    reset("window_test2")
    for _ in range(10):
        hit("window_test2", track_recent=True, recent_window_sec=2.0)
        time.sleep(0.05)
    
    # With 2-second window, should still see hits
    snap4 = snapshot(include_rates=True, window_rate_sec=2.0)
    rate4 = snap4["rate_window_per_sec"]["window_test2"]
    assert rate4 > 0.0
    
    # Test window_rate_for function directly
    rate_direct = _window_rate_for("window_test2", 2.0)
    assert rate_direct == rate4
    
    # Test with deque that has less than 2 hits
    reset("single_hit")
    hit("single_hit", track_recent=True)
    rate_single = _window_rate_for("single_hit", 1.0)
    assert rate_single == 0.0


def test_prune_keys():
    """Test key pruning to prevent memory leaks."""
    # Reset and fill with many keys
    reset()
    
    # Create more keys than max
    max_keys = 10
    for i in range(15):
        hit(f"event_{i}", max_keys=max_keys)
    
    # Check that we have at most max_keys
    snap = snapshot(include_rates=False)
    assert snap["distinct_keys"] <= max_keys
    
    # The oldest keys should be pruned
    # Since we added sequentially, event_0 through event_4 should be pruned
    for i in range(5):
        assert f"event_{i}" not in snap["counts"]
    
    # Newer keys should still exist
    for i in range(10, 15):
        assert f"event_{i}" in snap["counts"]
    
    # Test with max_keys = 0 (no limit)
    reset()
    for i in range(100):
        hit(f"unlimited_{i}", max_keys=0)
    
    snap_unlimited = snapshot(include_rates=False)
    assert snap_unlimited["distinct_keys"] == 100
    
    # Test with negative max_keys (should be treated as no limit)
    reset()
    for i in range(50):
        hit(f"negative_limit_{i}", max_keys=-5)
    
    snap_negative = snapshot(include_rates=False)
    assert snap_negative["distinct_keys"] == 50


def test_reset_function():
    """Test reset functionality."""
    # Add some events
    hit("to_reset_a")
    hit("to_reset_b")
    hit("to_keep")
    
    # Reset specific event
    reset("to_reset_a")
    
    snap = snapshot(include_rates=False)
    assert "to_reset_a" not in snap["counts"]
    assert "to_reset_b" in snap["counts"]
    assert "to_keep" in snap["counts"]
    
    # Reset all
    reset()
    
    snap_all = snapshot(include_rates=False)
    assert snap_all["total_events"] == 0
    assert snap_all["distinct_keys"] == 0
    assert not snap_all["counts"]
    
    # Test resetting non-existent key (should not crash)
    reset("non_existent_key")


def test_top_function():
    """Test top-N queries."""
    reset()
    
    # Create events with different frequencies
    hit("common", n=10)
    hit("medium", n=5)
    hit("rare", n=1)
    
    # Also add events with recent tracking for rate-based queries
    for i in range(20):
        hit("fast_event", track_recent=True)
        if i % 2 == 0:
            hit("faster_event", track_recent=True)
        time.sleep(0.001)  # Small delay
    
    # Test by count
    top_by_count = top(3, by="count")
    assert len(top_by_count) == 3
    # Should be sorted by count descending
    assert top_by_count[0][0] == "common"  # 10 hits
    assert top_by_count[0][1] == 10.0
    assert top_by_count[1][0] == "medium"  # 5 hits
    assert top_by_count[1][1] == 5.0
    
    # Test by recent (most recently hit)
    top_by_recent = top(5, by="recent")
    assert len(top_by_recent) == 5
    # Most recent should be one of the last events we hit
    # Since we don't know exact order due to timing, just check structure
    for name, timestamp in top_by_recent:
        assert isinstance(name, str)
        assert isinstance(timestamp, float)
    
    # Test by rate (EMA)
    top_by_rate = top(2, by="rate")
    assert len(top_by_rate) == 2
    # Rates should be in descending order
    if len(top_by_rate) > 1:
        assert top_by_rate[0][1] >= top_by_rate[1][1]
    
    # Test by window_rate
    top_by_window = top(2, by="window_rate", window_rate_sec=1.0)
    assert len(top_by_window) == 2
    
    # Test with n larger than available events
    top_all = top(100, by="count")
    snap = snapshot(include_rates=False)
    assert len(top_all) == snap["distinct_keys"]
    
    # Test invalid 'by' parameter (should default to "count")
    top_default = top(2, by="invalid_criterion")
    assert len(top_default) == 2
    # Should still work, defaulting to count


def test_snapshot_completeness():
    """Test snapshot includes all expected fields."""
    reset()
    
    # Add some events with different settings
    hit("event1", track_recent=True)
    hit("event2", track_recent=False)
    
    # Snapshot without rates
    snap_no_rates = snapshot(include_rates=False)
    
    expected_keys = {"started_ts", "uptime_sec", "total_events", "distinct_keys", "counts", "last_ts"}
    assert set(snap_no_rates.keys()) == expected_keys
    
    # Check types
    assert isinstance(snap_no_rates["started_ts"], float)
    assert isinstance(snap_no_rates["uptime_sec"], float)
    assert isinstance(snap_no_rates["total_events"], int)
    assert isinstance(snap_no_rates["distinct_keys"], int)
    assert isinstance(snap_no_rates["counts"], dict)
    assert isinstance(snap_no_rates["last_ts"], dict)
    
    # Snapshot with rates
    snap_with_rates = snapshot(include_rates=True)
    
    expected_keys_with_rates = expected_keys.union({"rate_ema_per_sec", "rate_window_per_sec", "last_age_sec"})
    assert set(snap_with_rates.keys()) == expected_keys_with_rates
    
    # Check rate structures
    assert isinstance(snap_with_rates["rate_ema_per_sec"], dict)
    assert isinstance(snap_with_rates["rate_window_per_sec"], dict)
    assert isinstance(snap_with_rates["last_age_sec"], dict)
    
    # All events should have rate entries
    for event in snap_with_rates["counts"]:
        assert event in snap_with_rates["rate_ema_per_sec"]
        assert event in snap_with_rates["rate_window_per_sec"]
        assert event in snap_with_rates["last_age_sec"]


def test_uptime_calculation():
    """Test that uptime is calculated correctly."""
    reset()
    
    snap1 = snapshot(include_rates=False)
    uptime1 = snap1["uptime_sec"]
    
    assert uptime1 >= 0.0
    
    # Wait and check uptime increases
    time.sleep(0.1)
    snap2 = snapshot(include_rates=False)
    uptime2 = snap2["uptime_sec"]
    
    assert uptime2 > uptime1
    assert uptime2 - uptime1 >= 0.09  # Should be close to 0.1s


def test_recent_hits_deque_management():
    """Test that recent hits deque is properly managed."""
    reset()
    
    # Track with small window and maxlen
    event_name = "deque_test"
    maxlen = 5
    window = 0.5
    
    # Add more hits than maxlen
    for i in range(10):
        hit(event_name, track_recent=True, recent_maxlen=maxlen, recent_window_sec=window)
        time.sleep(0.01)
    
    # Deque should be bounded by maxlen
    from runtime_trace import _recent_hits
    with _recent_hits.get("_lock"):  # Access the module's lock
        deque_obj = _recent_hits.get(event_name)
        assert deque_obj is not None
        assert len(deque_obj) <= maxlen
        
        # Check that old hits outside window are pruned
        # Since we slept between hits and window is 0.5s,
        # all hits should still be in window
        current_time = _now_mono()
        for hit_time in deque_obj:
            assert current_time - hit_time <= window + 0.1  # Allow small tolerance
    
    # Wait for window to expire
    time.sleep(window + 0.1)
    
    # Add one more hit to trigger pruning
    hit(event_name, track_recent=True, recent_maxlen=maxlen, recent_window_sec=window)
    
    # Now deque should have only 1 hit (the new one)
    with _recent_hits.get("_lock"):
        deque_obj = _recent_hits.get(event_name)
        assert len(deque_obj) == 1


def test_thread_safety():
    """Test that the module is thread-safe."""
    reset()
    
    errors = []
    hit_counts = {}
    
    def worker(worker_id, event_name, num_hits):
        try:
            for i in range(num_hits):
                hit(f"{event_name}_{worker_id}")
                time.sleep(0.001)  # Small delay to increase interleaving
        except Exception as e:
            errors.append(e)
    
    # Create multiple threads hitting different events
    threads = []
    for i in range(5):
        t = threading.Thread(target=worker, args=(i, "thread_event", 20))
        threads.append(t)
    
    # Start all threads
    for t in threads:
        t.start()
    
    # Wait for all threads to complete
    for t in threads:
        t.join()
    
    # No errors should occur
    assert len(errors) == 0
    
    # Check that all hits were counted
    snap = snapshot(include_rates=False)
    total_expected = 5 * 20  # 5 threads * 20 hits each
    assert snap["total_events"] == total_expected
    
    # Check that we have 5 distinct events
    distinct_events = sum(1 for key in snap["counts"] if key.startswith("thread_event_"))
    assert distinct_events == 5
    
    # Test concurrent access to snapshot (should not crash)
    snapshot_results = []
    
    def snapshot_worker():
        try:
            snapshot_results.append(snapshot(include_rates=True))
        except Exception as e:
            errors.append(e)
    
    # Create threads that call snapshot concurrently
    snapshot_threads = []
    for _ in range(10):
        t = threading.Thread(target=snapshot_worker)
        snapshot_threads.append(t)
    
    for t in snapshot_threads:
        t.start()
    
    for t in snapshot_threads:
        t.join()
    
    assert len(errors) == 0
    assert len(snapshot_results) == 10


def test_performance_benchmark():
    """Benchmark performance of hit() function."""
    reset()
    
    num_events = 1000
    num_hits_per_event = 10
    
    start_time = _now_mono()
    
    for i in range(num_events):
        for j in range(num_hits_per_event):
            hit(f"perf_event_{i}")
    
    end_time = _now_mono()
    elapsed = end_time - start_time
    
    total_hits = num_events * num_hits_per_event
    hits_per_second = total_hits / elapsed if elapsed > 0 else 0
    
    print(f"\nPerformance benchmark:")
    print(f"  Total hits: {total_hits}")
    print(f"  Elapsed time: {elapsed:.3f} seconds")
    print(f"  Hits per second: {hits_per_second:.0f}")
    
    # Verify counts
    snap = snapshot(include_rates=False)
    assert snap["total_events"] == total_hits
    assert snap["distinct_keys"] == num_events
    
    # Performance should be reasonable (at least 1000 hits/sec on most machines)
    assert hits_per_second > 1000, f"Performance too low: {hits_per_second} hits/sec"


def test_edge_cases():
    """Test various edge cases."""
    reset()
    
    # Very long event names
    long_name = "x" * 1000
    hit(long_name)
    
    snap = snapshot(include_rates=False)
    assert long_name in snap["counts"]
    
    # Special characters in event names
    special_names = ["event/with/slashes", "event.with.dots", "event-with-dashes", "event with spaces"]
    for name in special_names:
        hit(name)
    
    snap2 = snapshot(include_rates=False)
    for name in special_names:
        assert name in snap2["counts"]
    
    # Unicode event names
    unicode_names = ["事件", "सिग्नल", "😂"]
    for name in unicode_names:
        hit(name)
    
    snap3 = snapshot(include_rates=False)
    for name in unicode_names:
        assert name in snap3["counts"]
    
    # Test with very small and very large n values
    hit("small_n", n=1)
    hit("large_n", n=1000000)
    
    snap4 = snapshot(include_rates=False)
    assert snap4["counts"]["small_n"] == 1
    assert snap4["counts"]["large_n"] == 1000000


# Mock-based tests
def test_module_state_isolation():
    """Test that module state is isolated (global but reset clears it)."""
    # This test verifies that reset() actually clears module state
    from runtime_trace import _counts, _last_wall, _last_mono, _rate_ema, _rate_last_mono, _recent_hits
    
    # Add some data
    hit("test_isolation")
    
    # Check that module state was updated
    assert len(_counts) > 0
    
    # Reset
    reset()
    
    # Check that module state was cleared
    assert len(_counts) == 0
    assert len(_last_wall) == 0
    assert len(_last_mono) == 0
    assert len(_rate_ema) == 0
    assert len(_rate_last_mono) == 0
    assert len(_recent_hits) == 0


def test_singleton_behavior():
    """Test that the module acts as a singleton."""
    # Import the module again to check it's the same instance
    import importlib
    import runtime_trace
    
    # Reload module
    runtime_trace_reloaded = importlib.reload(runtime_trace)
    
    # Add event via original module
    runtime_trace.hit("via_original")
    
    # Check via reloaded module
    snap = runtime_trace_reloaded.snapshot(include_rates=False)
    assert "via_original" in snap["counts"]
    
    # Reset via reloaded module
    runtime_trace_reloaded.reset()
    
    # Check via original module
    snap2 = runtime_trace.snapshot(include_rates=False)
    assert snap2["total_events"] == 0
    
    # Clean up
    runtime_trace.reset()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
# app/self_tuner.py
from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, Optional


class SelfTuner:
    """
    Lightweight, safe self-tuner that adjusts a small set of parameters based on recent performance.

    This is intentionally conservative:
      - It only tunes within configured bounds.
      - It writes suggestions to disk; engine can choose to apply immediately or on next restart.
    """

    def __init__(self, cfg: Dict[str, Any], log: Any, base_dir: Optional[str] = None):
        self.cfg = cfg or {}
        self.log = log
        self.base_dir = base_dir or os.getcwd()
        self.path = os.path.join(self.base_dir, "logs", "self_tuner_suggestions.json")
        self._last_ts = 0.0
        self._interval = float(self.cfg.get("self_tuner", {}).get("interval_sec", 120.0))

        os.makedirs(os.path.dirname(self.path), exist_ok=True)

    def tick(self, engine: Any) -> None:
        """Called periodically by the engine."""
        now = time.time()
        if (now - self._last_ts) < self._interval:
            return
        self._last_ts = now

        try:
            # minimal signals
            stats = {}
            if hasattr(engine, "get_perf_stats") and callable(getattr(engine, "get_perf_stats")):
                stats = engine.get_perf_stats() or {}
            # If no stats, do nothing
            if not isinstance(stats, dict) or not stats:
                return

            # Example conservative tuning: adjust maker_offset_bps based on fill ratio
            exec_cfg = (engine.cfg or {}).get("execution", {})
            mo = float(exec_cfg.get("maker_offset_bps", 2.0))
            fill = float(stats.get("fill_ratio", 0.0)) if "fill_ratio" in stats else None

            suggestion = {}
            if fill is not None:
                if fill < 0.10:
                    suggestion["execution.maker_offset_bps"] = min(10.0, mo + 0.5)
                elif fill > 0.60:
                    suggestion["execution.maker_offset_bps"] = max(0.0, mo - 0.5)

            if suggestion:
                payload = {"ts": now, "suggestion": suggestion, "stats": stats}
                with open(self.path, "w", encoding="utf-8") as f:
                    json.dump(payload, f, indent=2)
                if self.log:
                    try:
                        self.log.info(f"[self_tuner] wrote suggestions: {suggestion}")
                    except Exception:
                        pass
        except Exception:
            # self_tuner must never crash the engine
            return

from __future__ import annotations

import time
import uuid
import threading
import json
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Optional, List, Tuple, Callable, Set
from enum import Enum
from collections import defaultdict, deque
import hashlib
import logging
from datetime import datetime

# Configure logger
logger = logging.getLogger(__name__)

# Optional numpy (fallback safe)
try:
    import numpy as np  # type: ignore
except Exception:
    class _NP:
        @staticmethod
        def mean(values):
            values = list(values) if values else []
            return (sum(values) / len(values)) if values else 0.0
    np = _NP()  # type: ignore


class OrderStatus(str, Enum):
    """Enhanced order status enumeration."""
    # Initial states
    PENDING = "pending"
    SUBMITTING = "submitting"

    # Active states
    OPEN = "open"
    PARTIALLY_FILLED = "partial"

    # Terminal states
    FILLED = "filled"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REJECTED = "rejected"
    FAILED = "failed"
    UNKNOWN_CLOSED = "unknown_closed"

    # Warning states
    STALE_PENDING = "stale_pending"
    STALE_OPEN = "stale_open"
    SUSPECTED_FILLED = "suspected_filled"
    SUSPECTED_CANCELLED = "suspected_cancelled"

    # Risk states
    EXCEEDED_SLIPPAGE = "exceeded_slippage"
    EXCEEDED_TIMEOUT = "exceeded_timeout"
    EXCEEDED_RETRIES = "exceeded_retries"

    @property
    def is_terminal(self) -> bool:
        return self in {
            OrderStatus.FILLED,
            OrderStatus.CANCELLED,
            OrderStatus.EXPIRED,
            OrderStatus.REJECTED,
            OrderStatus.FAILED,
            OrderStatus.UNKNOWN_CLOSED,
        }

    @property
    def is_active(self) -> bool:
        return self in {
            OrderStatus.OPEN,
            OrderStatus.PARTIALLY_FILLED,
            OrderStatus.PENDING,
            OrderStatus.SUBMITTING,
        }

    @property
    def is_warning(self) -> bool:
        return self in {
            OrderStatus.STALE_PENDING,
            OrderStatus.STALE_OPEN,
            OrderStatus.SUSPECTED_FILLED,
            OrderStatus.SUSPECTED_CANCELLED,
            OrderStatus.EXCEEDED_SLIPPAGE,
            OrderStatus.EXCEEDED_TIMEOUT,
            OrderStatus.EXCEEDED_RETRIES,
        }

    @property
    def can_retry(self) -> bool:
        return self in {
            OrderStatus.FAILED,
            OrderStatus.REJECTED,
            OrderStatus.EXPIRED,
        }


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"
    TAKE_PROFIT = "take_profit"
    TAKE_PROFIT_LIMIT = "take_profit_limit"
    TRAILING_STOP = "trailing_stop"


class TimeInForce(str, Enum):
    GTC = "GTC"
    IOC = "IOC"
    FOK = "FOK"
    DAY = "DAY"
    GTD = "GTD"


class OrderEventType(str, Enum):
    CREATED = "created"
    SUBMITTED = "submitted"
    ACCEPTED = "accepted"
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REJECTED = "rejected"
    FAILED = "failed"
    UPDATED = "updated"
    RETRY_ATTEMPT = "retry_attempt"
    RETRY_SUCCESS = "retry_success"
    RETRY_FAILED = "retry_failed"
    WARNING = "warning"
    ERROR = "error"
    TIMEOUT = "timeout"
    SYNCED = "synced"


@dataclass
class OrderFill:
    fill_id: str
    order_id: str
    symbol: str
    side: str
    quantity: float
    price: float
    fee_amount: float
    fee_currency: str
    timestamp: float
    exchange_timestamp: Optional[float] = None
    trade_id: Optional[str] = None
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["timestamp_iso"] = datetime.fromtimestamp(self.timestamp).isoformat()
        if self.exchange_timestamp:
            data["exchange_timestamp_iso"] = datetime.fromtimestamp(self.exchange_timestamp).isoformat()
        return data


@dataclass
class OrderEvent:
    event_id: str
    order_id: str
    event_type: OrderEventType
    timestamp: float
    from_status: Optional[OrderStatus]
    to_status: Optional[OrderStatus]
    details: Dict[str, Any] = field(default_factory=dict)
    user_data: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["event_type"] = self.event_type.value
        data["from_status"] = self.from_status.value if self.from_status else None
        data["to_status"] = self.to_status.value if self.to_status else None
        data["timestamp_iso"] = datetime.fromtimestamp(self.timestamp).isoformat()
        return data


@dataclass
class OrderState:
    order_id: str
    client_order_id: str
    exchange_order_id: Optional[str] = None

    symbol: str = ""
    side: str = ""  # buy/sell
    order_type: OrderType = OrderType.LIMIT
    time_in_force: TimeInForce = TimeInForce.GTC
    created_ts: float = field(default_factory=time.time)
    updated_ts: float = field(default_factory=time.time)

    requested_qty: float = 0.0
    filled_qty: float = 0.0
    remaining_qty: float = 0.0
    average_fill_price: float = 0.0
    last_fill_price: float = 0.0

    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    trigger_price: Optional[float] = None

    total_fee: float = 0.0
    fee_currency: str = ""

    status: OrderStatus = OrderStatus.PENDING
    status_reason: str = ""

    retry_count: int = 0
    max_retries: int = 3
    last_retry_ts: Optional[float] = None

    expires_at: Optional[float] = None
    timeout_sec: float = 300.0

    max_slippage_pct: float = 1.0
    max_slippage_absolute: Optional[float] = None

    strategy_id: str = ""
    signal_id: str = ""
    reason: str = ""

    tags: List[str] = field(default_factory=list)
    meta: Dict[str, Any] = field(default_factory=dict)
    exchange_meta: Dict[str, Any] = field(default_factory=dict)

    execution_latency_ms: Optional[float] = None
    fill_latency_ms: Optional[float] = None

    def update(self, **kwargs) -> None:
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.updated_ts = time.time()

    def calculate_remaining(self) -> None:
        self.remaining_qty = max(0.0, float(self.requested_qty) - float(self.filled_qty))

    def is_filled(self) -> bool:
        if self.status == OrderStatus.FILLED:
            return True
        if self.requested_qty <= 0:
            return False
        return self.filled_qty >= self.requested_qty

    def is_expired(self) -> bool:
        return bool(self.expires_at and time.time() > self.expires_at)

    def is_timed_out(self) -> bool:
        elapsed = time.time() - self.created_ts
        return elapsed > self.timeout_sec and self.status.is_active

    def get_slippage(self, current_price: float) -> float:
        if not self.average_fill_price or not current_price:
            return 0.0
        if self.side == "buy":
            return ((self.average_fill_price - current_price) / current_price) * 100.0
        return ((current_price - self.average_fill_price) / self.average_fill_price) * 100.0

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["order_type"] = self.order_type.value
        data["time_in_force"] = self.time_in_force.value
        data["status"] = self.status.value
        data["is_filled"] = self.is_filled()
        data["is_expired"] = self.is_expired()
        data["is_timed_out"] = self.is_timed_out()
        data["age_sec"] = time.time() - self.created_ts
        data["created_ts_iso"] = datetime.fromtimestamp(self.created_ts).isoformat()
        data["updated_ts_iso"] = datetime.fromtimestamp(self.updated_ts).isoformat()
        if self.expires_at:
            data["expires_at_iso"] = datetime.fromtimestamp(self.expires_at).isoformat()
        return data


class OrderDeduplicator:
    """Advanced order deduplication with multiple strategies."""

    def __init__(self, window_sec: float = 3.0, max_entries: int = 10000):
        self.window_sec = float(window_sec)
        self.max_entries = int(max_entries)
        self.entries: Dict[str, Dict[str, Any]] = {}
        self.lock = threading.RLock()
        self.hit_count = 0
        self.miss_count = 0

    def generate_key(
        self,
        symbol: str,
        side: str,
        order_type: OrderType,
        quantity: float,
        price: Optional[float],
        strategy_id: str,
        signal_id: str,
    ) -> str:
        price_part = f"{float(price):.8f}" if price is not None else "None"
        key_data = (
            f"{symbol}:{side}:{order_type.value}:"
            f"{float(quantity):.8f}:{price_part}:{strategy_id}:{signal_id}"
        )
        return hashlib.sha256(key_data.encode("utf-8")).hexdigest()[:32]

    def check_and_record(
        self,
        key: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[Dict[str, Any]]]:
        with self.lock:
            now = time.time()

            # cleanup old
            to_remove = [k for k, e in self.entries.items() if now - float(e.get("timestamp", 0.0)) > self.window_sec]
            for k in to_remove:
                self.entries.pop(k, None)

            if key in self.entries:
                self.hit_count += 1
                return True, self.entries[key]

            self.entries[key] = {"timestamp": now, "metadata": metadata or {}, "key": key}

            if len(self.entries) > self.max_entries:
                # drop ~10% oldest
                oldest = sorted(self.entries.keys(), key=lambda k: self.entries[k]["timestamp"])[: max(1, self.max_entries // 10)]
                for k in oldest:
                    self.entries.pop(k, None)

            self.miss_count += 1
            return False, None

    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            total = self.hit_count + self.miss_count
            return {
                "total_entries": len(self.entries),
                "hit_count": self.hit_count,
                "miss_count": self.miss_count,
                "hit_ratio": self.hit_count / max(1, total),
                "window_sec": self.window_sec,
            }


class OrderLifecycleManager:
    """
    Enhanced Order Lifecycle Manager with tracking, dedupe, retries and sync.
    """

    def __init__(self, cfg: Dict[str, Any], log: Any = None):
        self.cfg = cfg or {}
        self.log = log or logger

        self.lock = threading.RLock()

        # Core storage
        self.orders: Dict[str, OrderState] = {}
        self.order_fills: Dict[str, List[OrderFill]] = defaultdict(list)
        self.order_events: Dict[str, List[OrderEvent]] = defaultdict(list)

        # Indexes
        self.symbol_index: Dict[str, Set[str]] = defaultdict(set)
        self.status_index: Dict[OrderStatus, Set[str]] = defaultdict(set)
        self.strategy_index: Dict[str, Set[str]] = defaultdict(set)

        # Deduplication
        self.deduplicator = OrderDeduplicator(
            window_sec=self._get_config("dedupe_window_sec", 3.0),
            max_entries=self._get_config("dedupe_max_entries", 10000),
        )

        # Sync
        self.last_sync_ts: float = 0.0
        self.sync_lock = threading.RLock()

        # Callbacks
        self.event_callbacks: List[Callable[[OrderEvent], None]] = []

        # Stats
        self.stats = {
            "orders_created": 0,
            "orders_filled": 0,
            "orders_cancelled": 0,
            "orders_failed": 0,
            "total_volume": 0.0,
            "total_fees": 0.0,
            "avg_execution_latency": 0.0,
            "sync_count": 0,
        }

        self.performance_stats = {
            "sync_durations": deque(maxlen=100),
            "event_processing_durations": deque(maxlen=100),
            "dedupe_hit_rates": deque(maxlen=100),
        }

        self._init_from_config()
        self.log.info(f"OrderLifecycleManager initialized with mode={self.cfg.get('mode', 'paper')}")

    def _get_lifecycle_config(self) -> Dict[str, Any]:
        ex = self.cfg.get("execution") or {}
        if isinstance(ex, dict):
            lc = ex.get("lifecycle") or {}
            if isinstance(lc, dict):
                return lc
        return {}

    def _get_config(self, key: str, default: Any) -> Any:
        lc = self._get_lifecycle_config()
        return lc.get(key, default)

    def _init_from_config(self) -> None:
        lifecycle_cfg = self._get_lifecycle_config()
        self.retention_hours = int(lifecycle_cfg.get("retention_hours", 24))
        self.sync_interval_sec = float(lifecycle_cfg.get("sync_interval_sec", 15.0))
        self.max_pending_sec = float(lifecycle_cfg.get("max_pending_sec", 45.0))
        self.max_open_sec = float(lifecycle_cfg.get("max_open_sec", 120.0))
        self.auto_cancel_timeout = bool(lifecycle_cfg.get("auto_cancel_timeout", True))
        self.enable_fallback_fetch = bool(lifecycle_cfg.get("enable_fallback_fetch", True))
        self.max_fallback_fetch = int(lifecycle_cfg.get("max_fallback_fetch", 20))
        self.enable_auto_retry = bool(lifecycle_cfg.get("enable_auto_retry", True))
        self.max_auto_retries = int(lifecycle_cfg.get("max_auto_retries", 3))

    def register_event_callback(self, callback: Callable[[OrderEvent], None]) -> None:
        self.event_callbacks.append(callback)

    # ---------- internal helpers

    def _create_event(
        self,
        order_id: str,
        event_type: OrderEventType,
        from_status: Optional[OrderStatus] = None,
        to_status: Optional[OrderStatus] = None,
        details: Optional[Dict[str, Any]] = None,
        user_data: Optional[str] = None,
    ) -> OrderEvent:
        t0 = time.time()
        event = OrderEvent(
            event_id=f"evt_{uuid.uuid4().hex[:16]}",
            order_id=order_id,
            event_type=event_type,
            timestamp=t0,
            from_status=from_status,
            to_status=to_status,
            details=details or {},
            user_data=user_data,
        )

        self.order_events[order_id].append(event)
        if len(self.order_events[order_id]) > 1000:
            self.order_events[order_id] = self.order_events[order_id][-1000:]

        for cb in list(self.event_callbacks):
            try:
                cb(event)
            except Exception as e:
                self.log.error(f"Error in event callback: {e}")

        self.performance_stats["event_processing_durations"].append(time.time() - t0)
        return event

    def _update_indexes(
        self,
        order_id: str,
        old_state: Optional[OrderState],
        new_state: Optional[OrderState],
    ) -> None:
        if old_state is not None:
            self.symbol_index[old_state.symbol].discard(order_id)
            self.status_index[old_state.status].discard(order_id)
            if old_state.strategy_id:
                self.strategy_index[old_state.strategy_id].discard(order_id)

        if new_state is not None:
            self.symbol_index[new_state.symbol].add(order_id)
            self.status_index[new_state.status].add(order_id)
            if new_state.strategy_id:
                self.strategy_index[new_state.strategy_id].add(order_id)

    def _validate_status_transition(self, from_status: OrderStatus, to_status: OrderStatus) -> bool:
        if from_status.is_terminal:
            return False

        if from_status == to_status:
            return True

        if from_status == OrderStatus.PENDING:
            return to_status in {
                OrderStatus.SUBMITTING,
                OrderStatus.OPEN,
                OrderStatus.FAILED,
                OrderStatus.REJECTED,
                OrderStatus.STALE_PENDING,
                OrderStatus.CANCELLED,
                OrderStatus.EXPIRED,
            }

        if from_status == OrderStatus.SUBMITTING:
            return to_status in {
                OrderStatus.OPEN,
                OrderStatus.FAILED,
                OrderStatus.REJECTED,
                OrderStatus.PARTIALLY_FILLED,
                OrderStatus.CANCELLED,
                OrderStatus.EXPIRED,
            }

        if from_status == OrderStatus.OPEN:
            return to_status in {
                OrderStatus.PARTIALLY_FILLED,
                OrderStatus.FILLED,
                OrderStatus.CANCELLED,
                OrderStatus.EXPIRED,
                OrderStatus.STALE_OPEN,
                OrderStatus.SUSPECTED_FILLED,
                OrderStatus.SUSPECTED_CANCELLED,
            }

        if from_status == OrderStatus.PARTIALLY_FILLED:
            return to_status in {
                OrderStatus.FILLED,
                OrderStatus.CANCELLED,
                OrderStatus.EXPIRED,
                OrderStatus.STALE_OPEN,
                OrderStatus.SUSPECTED_FILLED,
                OrderStatus.SUSPECTED_CANCELLED,
            }

        # warning states -> allow moving to active/terminal based on sync reality
        if from_status.is_warning:
            return to_status in {
                OrderStatus.OPEN,
                OrderStatus.PARTIALLY_FILLED,
                OrderStatus.FILLED,
                OrderStatus.CANCELLED,
                OrderStatus.EXPIRED,
                OrderStatus.UNKNOWN_CLOSED,
                OrderStatus.REJECTED,
                OrderStatus.FAILED,
            }

        return True

    def _get_event_type_for_status_change(self, new_status: OrderStatus) -> OrderEventType:
        mapping = {
            OrderStatus.PENDING: OrderEventType.CREATED,
            OrderStatus.SUBMITTING: OrderEventType.SUBMITTED,
            OrderStatus.OPEN: OrderEventType.ACCEPTED,
            OrderStatus.PARTIALLY_FILLED: OrderEventType.PARTIALLY_FILLED,
            OrderStatus.FILLED: OrderEventType.FILLED,
            OrderStatus.CANCELLED: OrderEventType.CANCELLED,
            OrderStatus.EXPIRED: OrderEventType.EXPIRED,
            OrderStatus.REJECTED: OrderEventType.REJECTED,
            OrderStatus.FAILED: OrderEventType.FAILED,
            OrderStatus.STALE_PENDING: OrderEventType.WARNING,
            OrderStatus.STALE_OPEN: OrderEventType.WARNING,
            OrderStatus.SUSPECTED_FILLED: OrderEventType.WARNING,
            OrderStatus.SUSPECTED_CANCELLED: OrderEventType.WARNING,
            OrderStatus.EXCEEDED_SLIPPAGE: OrderEventType.WARNING,
            OrderStatus.EXCEEDED_TIMEOUT: OrderEventType.TIMEOUT,
            OrderStatus.EXCEEDED_RETRIES: OrderEventType.ERROR,
            OrderStatus.UNKNOWN_CLOSED: OrderEventType.WARNING,
        }
        return mapping.get(new_status, OrderEventType.UPDATED)

    def _update_order_status(
        self,
        order_id: str,
        new_status: OrderStatus,
        reason: str = "",
        details: Optional[Dict[str, Any]] = None,
    ) -> bool:
        with self.lock:
            order = self.orders.get(order_id)
            if not order:
                return False

            old_status = order.status
            if old_status == new_status:
                return False

            if not self._validate_status_transition(old_status, new_status):
                self.log.warning(
                    f"Invalid status transition for order {order_id}: {old_status.value} -> {new_status.value}"
                )
                return False

            # update status + reason
            order.status = new_status
            order.status_reason = reason
            order.updated_ts = time.time()

            # update status index only (symbol/strategy unchanged here)
            self.status_index[old_status].discard(order_id)
            self.status_index[new_status].add(order_id)

            # event
            self._create_event(
                order_id=order_id,
                event_type=self._get_event_type_for_status_change(new_status),
                from_status=old_status,
                to_status=new_status,
                details={
                    "reason": reason,
                    "old_status": old_status.value,
                    "new_status": new_status.value,
                    **(details or {}),
                },
            )

            # stats
            if new_status == OrderStatus.FILLED:
                self.stats["orders_filled"] += 1
            elif new_status == OrderStatus.CANCELLED:
                self.stats["orders_cancelled"] += 1
            elif new_status == OrderStatus.FAILED:
                self.stats["orders_failed"] += 1

            self.log.info(f"Order {order_id} status: {old_status.value} -> {new_status.value}")
            return True

    # ---------- public API

    def create_order(
        self,
        symbol: str,
        side: str,
        order_type: OrderType,
        quantity: float,
        price: Optional[float] = None,
        *,
        client_order_id: Optional[str] = None,
        strategy_id: str = "",
        signal_id: str = "",
        reason: str = "",
        time_in_force: TimeInForce = TimeInForce.GTC,
        expires_at: Optional[float] = None,
        timeout_sec: float = 300.0,
        max_retries: int = 3,
        max_slippage_pct: float = 1.0,
        tags: Optional[List[str]] = None,
        meta: Optional[Dict[str, Any]] = None,
        dedupe: bool = True,
    ) -> OrderState:
        order_id = client_order_id or f"ord_{uuid.uuid4().hex[:16]}"

        if dedupe:
            dedupe_key = self.deduplicator.generate_key(
                symbol=symbol,
                side=side,
                order_type=order_type,
                quantity=quantity,
                price=price,
                strategy_id=strategy_id,
                signal_id=signal_id,
            )
            is_dup, existing = self.deduplicator.check_and_record(
                dedupe_key,
                metadata={"order_id": order_id, "symbol": symbol, "side": side},
            )
            if is_dup and existing:
                ex_oid = (existing.get("metadata") or {}).get("order_id")
                if ex_oid and ex_oid in self.orders:
                    self.log.warning(f"Duplicate order detected key={dedupe_key} -> returning existing {ex_oid}")
                    return self.orders[ex_oid]

        limit_price = None
        stop_price = None
        if order_type in (OrderType.LIMIT, OrderType.STOP_LIMIT, OrderType.TAKE_PROFIT_LIMIT):
            limit_price = price
        if order_type in (OrderType.STOP, OrderType.STOP_LIMIT, OrderType.TAKE_PROFIT, OrderType.TAKE_PROFIT_LIMIT):
            stop_price = price

        order = OrderState(
            order_id=order_id,
            client_order_id=order_id,
            symbol=symbol,
            side=str(side).lower(),
            order_type=order_type,
            time_in_force=time_in_force,
            requested_qty=float(quantity),
            remaining_qty=float(quantity),
            limit_price=limit_price,
            stop_price=stop_price,
            expires_at=expires_at,
            timeout_sec=float(timeout_sec),
            max_retries=int(max_retries),
            max_slippage_pct=float(max_slippage_pct),
            strategy_id=strategy_id,
            signal_id=signal_id,
            reason=reason,
            tags=list(tags or []),
            meta=dict(meta or {}),
        )

        with self.lock:
            self.orders[order_id] = order
            self._update_indexes(order_id, None, order)
            self.stats["orders_created"] += 1

        self._create_event(
            order_id=order_id,
            event_type=OrderEventType.CREATED,
            to_status=OrderStatus.PENDING,
            details={
                "symbol": symbol,
                "side": side,
                "order_type": order_type.value,
                "quantity": float(quantity),
                "price": float(price) if price is not None else None,
                "strategy_id": strategy_id,
                "signal_id": signal_id,
            },
        )

        self.log.info(f"Order created: {order_id} ({symbol} {side} {quantity})")
        return order

    def mark_submitting(self, order_id: str) -> bool:
        return self._update_order_status(order_id, OrderStatus.SUBMITTING, reason="Submitting to exchange")

    def mark_accepted(self, order_id: str, exchange_order_id: str) -> bool:
        with self.lock:
            order = self.orders.get(order_id)
            if not order:
                return False
            order.exchange_order_id = exchange_order_id
            order.execution_latency_ms = (time.time() - order.created_ts) * 1000.0
        return self._update_order_status(order_id, OrderStatus.OPEN, reason="Accepted by exchange")

    def mark_cancelled(self, order_id: str, reason: str = "User requested", source: str = "user") -> bool:
        return self._update_order_status(order_id, OrderStatus.CANCELLED, reason=f"{source}: {reason}")

    def mark_rejected(self, order_id: str, reason: str, exchange_reason: Optional[str] = None) -> bool:
        details = {"exchange_reason": exchange_reason} if exchange_reason else {}
        return self._update_order_status(order_id, OrderStatus.REJECTED, reason=reason, details=details)

    def mark_failed(
        self,
        order_id: str,
        reason: str,
        error_details: Optional[Dict[str, Any]] = None,
        can_retry: bool = True,
    ) -> bool:
        with self.lock:
            order = self.orders.get(order_id)
            if not order:
                return False

            if can_retry and order.retry_count < order.max_retries:
                order.retry_count += 1
                order.last_retry_ts = time.time()

                self._create_event(
                    order_id=order_id,
                    event_type=OrderEventType.RETRY_ATTEMPT,
                    details={
                        "retry_count": order.retry_count,
                        "max_retries": order.max_retries,
                        "reason": reason,
                        "error": error_details,
                    },
                )
                # back to pending for retry
                return self._update_order_status(
                    order_id,
                    OrderStatus.PENDING,
                    reason=f"Retry {order.retry_count}/{order.max_retries}: {reason}",
                    details=error_details,
                )

        return self._update_order_status(
            order_id,
            OrderStatus.FAILED,
            reason=f"Failed after retries: {reason}",
            details=error_details,
        )

    # ---------- exchange sync/update

    def _safe_enum_order_type(self, v: Any) -> OrderType:
        s = str(v or "limit").strip().lower()
        for t in OrderType:
            if t.value == s:
                return t
        # common aliases from exchanges
        aliases = {
            "limit": OrderType.LIMIT,
            "market": OrderType.MARKET,
            "stop": OrderType.STOP,
            "stop_limit": OrderType.STOP_LIMIT,
            "take_profit": OrderType.TAKE_PROFIT,
            "take_profit_limit": OrderType.TAKE_PROFIT_LIMIT,
            "trailing_stop": OrderType.TRAILING_STOP,
        }
        return aliases.get(s, OrderType.LIMIT)

    def _map_exchange_status(self, exchange_status: str) -> Optional[OrderStatus]:
        status_map = {
            "open": OrderStatus.OPEN,
            "new": OrderStatus.OPEN,
            "pending": OrderStatus.PENDING,
            "partially_filled": OrderStatus.PARTIALLY_FILLED,
            "partial": OrderStatus.PARTIALLY_FILLED,
            "filled": OrderStatus.FILLED,
            "canceled": OrderStatus.CANCELLED,
            "cancelled": OrderStatus.CANCELLED,
            "expired": OrderStatus.EXPIRED,
            "rejected": OrderStatus.REJECTED,
            "failed": OrderStatus.FAILED,
        }
        s = (exchange_status or "").strip().lower()
        if not s:
            return None
        return status_map.get(s)

    def update_from_exchange(self, exchange_order: Dict[str, Any], source: str = "sync") -> bool:
        try:
            exchange_id = str(exchange_order.get("id") or "")
            client_id = str(exchange_order.get("clientOrderId") or exchange_order.get("clientOrderID") or "")

            # find existing by exchange id or client id
            with self.lock:
                order_id: Optional[str] = None
                for oid, order in self.orders.items():
                    if (exchange_id and order.exchange_order_id == exchange_id) or (client_id and order.client_order_id == client_id):
                        order_id = oid
                        break

                if not order_id:
                    # create minimal new order
                    order_id = client_id or exchange_id
                    if not order_id:
                        return False

                    symbol = str(exchange_order.get("symbol") or "")
                    side = str(exchange_order.get("side") or "").lower()
                    otype = self._safe_enum_order_type(exchange_order.get("type", "limit"))

                    ts_ms = exchange_order.get("timestamp")
                    created_ts = time.time()
                    if ts_ms is not None:
                        try:
                            created_ts = float(ts_ms) / 1000.0
                        except Exception:
                            created_ts = time.time()

                    new_order = OrderState(
                        order_id=order_id,
                        client_order_id=client_id or order_id,
                        exchange_order_id=exchange_id or None,
                        symbol=symbol,
                        side=side,
                        order_type=otype,
                        created_ts=created_ts,
                        updated_ts=time.time(),
                    )
                    self.orders[order_id] = new_order
                    self._update_indexes(order_id, None, new_order)

                order = self.orders[order_id]
                old_filled = float(order.filled_qty)
                old_status = order.status

                # status mapping
                ex_status = str(exchange_order.get("status") or exchange_order.get("state") or "").lower()
                mapped = self._map_exchange_status(ex_status)

                # qty fields (ccxt-like)
                filled_qty = float(exchange_order.get("filled") or 0.0)
                remaining_qty = float(exchange_order.get("remaining") or 0.0)
                amount = exchange_order.get("amount")
                try:
                    amount_f = float(amount) if amount is not None else None
                except Exception:
                    amount_f = None

                # handle 'closed' explicitly (ccxt can give 'closed' for filled or canceled)
                if ex_status == "closed":
                    if amount_f and filled_qty >= amount_f and amount_f > 0:
                        mapped = OrderStatus.FILLED
                    else:
                        mapped = OrderStatus.CANCELLED

                # update quantities
                if filled_qty > 0 or remaining_qty > 0:
                    order.filled_qty = filled_qty
                    order.remaining_qty = remaining_qty

                avg_price = exchange_order.get("average")
                if avg_price:
                    try:
                        order.average_fill_price = float(avg_price)
                    except Exception:
                        pass

                # set exchange ids/meta
                if exchange_id:
                    order.exchange_order_id = exchange_id
                order.exchange_meta = dict(exchange_order)
                order.updated_ts = time.time()

            # status update (outside lock is ok; method uses lock)
            if mapped and mapped != old_status:
                self._update_order_status(
                    order_id=order_id,
                    new_status=mapped,
                    reason=f"Exchange {source}",
                    details={"exchange_status": ex_status},
                )

            # record delta fills correctly
            if filled_qty > old_filled:
                delta = filled_qty - old_filled
                px = order.average_fill_price
                if not px:
                    try:
                        px = float(exchange_order.get("price") or 0.0)
                    except Exception:
                        px = 0.0
                if delta > 0 and px > 0:
                    self.record_fill(
                        order_id=order_id,
                        quantity=delta,
                        price=px,
                        fee_amount=0.0,
                        fee_currency="",
                        trade_id=str(exchange_order.get("tradeId") or "") or None,
                    )

            self._create_event(
                order_id=order_id,
                event_type=OrderEventType.SYNCED,
                details={"source": source, "exchange_status": ex_status},
            )
            return True

        except Exception as e:
            self.log.error(f"Error updating from exchange: {e}")
            return False

    def record_fill(
        self,
        order_id: str,
        quantity: float,
        price: float,
        fee_amount: float,
        fee_currency: str,
        trade_id: Optional[str] = None,
        exchange_timestamp: Optional[float] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Optional[OrderFill]:
        with self.lock:
            order = self.orders.get(order_id)
            if not order:
                return None

            fill = OrderFill(
                fill_id=f"fill_{uuid.uuid4().hex[:16]}",
                order_id=order_id,
                symbol=order.symbol,
                side=order.side,
                quantity=float(quantity),
                price=float(price),
                fee_amount=float(fee_amount),
                fee_currency=str(fee_currency or ""),
                timestamp=time.time(),
                exchange_timestamp=exchange_timestamp,
                trade_id=trade_id,
                meta=dict(meta or {}),
            )
            self.order_fills[order_id].append(fill)

            order.filled_qty += float(quantity)
            order.calculate_remaining()
            order.last_fill_price = float(price)

            # average
            if order.filled_qty > 0:
                total_value = sum(f.quantity * f.price for f in self.order_fills[order_id])
                order.average_fill_price = total_value / order.filled_qty

            order.total_fee += float(fee_amount)
            if fee_currency:
                order.fee_currency = str(fee_currency)
            order.updated_ts = time.time()

            # stats
            self.stats["total_volume"] += float(quantity) * float(price)
            self.stats["total_fees"] += float(fee_amount)

        # status transitions
        if order.requested_qty > 0 and order.filled_qty >= order.requested_qty:
            self._update_order_status(order_id, OrderStatus.FILLED, reason="Order completely filled")
        else:
            self._update_order_status(order_id, OrderStatus.PARTIALLY_FILLED, reason="Order partially filled")

        self._create_event(
            order_id=order_id,
            event_type=OrderEventType.PARTIALLY_FILLED if order.remaining_qty > 0 else OrderEventType.FILLED,
            details={
                "fill_id": fill.fill_id,
                "quantity": float(quantity),
                "price": float(price),
                "fee": float(fee_amount),
                "trade_id": trade_id,
            },
        )

        self.log.info(
            f"Fill recorded for order {order_id}: {quantity} @ {price} "
            f"(filled: {order.filled_qty}/{order.requested_qty})"
        )
        return fill

    # ---------- queries

    def get_order(self, order_id: str) -> Optional[Dict[str, Any]]:
        with self.lock:
            order = self.orders.get(order_id)
            if not order:
                return None
            result = order.to_dict()
            fills = list(self.order_fills.get(order_id, []))
            events = list(self.order_events.get(order_id, []))

        result["fills"] = [f.to_dict() for f in fills]
        result["events"] = [e.to_dict() for e in events[-10:]]
        result["performance"] = {
            "avg_fill_latency": self._calculate_avg_fill_latency(order_id),
            "slippage_vs_limit": self._calculate_slippage_vs_limit(order),
            "execution_quality": self._calculate_execution_quality(order),
        }
        return result

    def find_orders(
        self,
        symbol: Optional[str] = None,
        status: Optional[OrderStatus] = None,
        strategy_id: Optional[str] = None,
        side: Optional[str] = None,
        min_age_sec: Optional[float] = None,
        max_age_sec: Optional[float] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        with self.lock:
            if symbol:
                candidate_ids = set(self.symbol_index.get(symbol, set()))
            elif status:
                candidate_ids = set(self.status_index.get(status, set()))
            elif strategy_id:
                candidate_ids = set(self.strategy_index.get(strategy_id, set()))
            else:
                candidate_ids = set(self.orders.keys())

            now = time.time()
            out: List[Dict[str, Any]] = []
            for oid in candidate_ids:
                order = self.orders.get(oid)
                if not order:
                    continue
                age = now - order.created_ts
                if side and order.side != side:
                    continue
                if min_age_sec is not None and age < min_age_sec:
                    continue
                if max_age_sec is not None and age > max_age_sec:
                    continue
                if status and order.status != status:
                    continue
                out.append(order.to_dict())
                if len(out) >= limit:
                    break

        out.sort(key=lambda x: x["created_ts"], reverse=True)
        return out

    def get_order_summary(self) -> Dict[str, Any]:
        with self.lock:
            total_orders = len(self.orders)
            status_counts: Dict[str, int] = {}
            total_volume = 0.0
            total_fees = 0.0
            active_orders = 0

            for order in self.orders.values():
                status_counts[order.status.value] = status_counts.get(order.status.value, 0) + 1
                if order.status.is_active:
                    active_orders += 1
                px = order.average_fill_price or order.limit_price or 0.0
                total_volume += float(order.filled_qty) * float(px)
                total_fees += float(order.total_fee)

            sync_durs = list(self.performance_stats["sync_durations"])
            event_durs = list(self.performance_stats["event_processing_durations"])

        return {
            "total_orders": total_orders,
            "active_orders": active_orders,
            "status_counts": status_counts,
            "total_volume": total_volume,
            "total_fees": total_fees,
            "avg_order_value": total_volume / max(1, total_orders),
            "deduplication_stats": self.deduplicator.get_stats(),
            "performance_stats": {
                "avg_sync_duration": float(np.mean(sync_durs)) if sync_durs else 0.0,
                "avg_event_processing": float(np.mean(event_durs)) if event_durs else 0.0,
            },
        }

    def detect_issues(self) -> Dict[str, List[Dict[str, Any]]]:
        issues = {
            "stale_pending": [],
            "stale_open": [],
            "timed_out": [],
            "exceeded_slippage": [],
            "unknown_status": [],
            "missing_exchange_id": [],
        }

        now = time.time()
        mode = str(self.cfg.get("mode", "paper")).lower()

        with self.lock:
            for _, order in self.orders.items():
                age = now - order.created_ts
                if order.status == OrderStatus.PENDING and age > self.max_pending_sec:
                    issues["stale_pending"].append(order.to_dict())
                if order.status == OrderStatus.OPEN and age > self.max_open_sec:
                    issues["stale_open"].append(order.to_dict())
                if order.is_timed_out():
                    issues["timed_out"].append(order.to_dict())
                if mode == "live" and order.status.is_active and not order.exchange_order_id:
                    issues["missing_exchange_id"].append(order.to_dict())
                if order.status == OrderStatus.UNKNOWN_CLOSED:
                    issues["unknown_status"].append(order.to_dict())

        return issues

    # ---------- maintenance / sync

    def detect_stuck(self, max_age_sec: Optional[float] = None) -> List[Dict[str, Any]]:
        """Return a list of 'stuck' lifecycle entries.

        HealthMonitor expects this method. A stuck order is one that remained too long
        in PENDING/OPEN according to lifecycle thresholds.

        Args:
            max_age_sec: optional override. If provided, only return orders older than this.
        """
        try:
            issues = self.detect_issues()
            stuck = []
            for k in ("stale_pending", "stale_open"):
                v = issues.get(k) if isinstance(issues, dict) else None
                if isinstance(v, list):
                    stuck.extend(v)

            if max_age_sec is None:
                return stuck

            now = time.time()
            out = []
            for o in stuck:
                if not isinstance(o, dict):
                    continue
                # best-effort age compute
                created = (
                    o.get("created_ts")
                    or o.get("ts")
                    or o.get("timestamp")
                    or o.get("created")
                )
                try:
                    created_f = float(created)
                except Exception:
                    created_f = None
                if created_f is None:
                    # include unknown age only if threshold is very small? -> skip
                    continue
                if (now - created_f) >= float(max_age_sec):
                    out.append(o)
            return out
        except Exception:
            return []


    def cleanup_old_orders(self, retention_hours: Optional[int] = None) -> int:
        retention = int(retention_hours or self.retention_hours)
        cutoff = time.time() - (retention * 3600)
        removed = 0

        with self.lock:
            for oid in list(self.orders.keys()):
                order = self.orders.get(oid)
                if not order:
                    continue
                if order.status.is_terminal and order.updated_ts < cutoff:
                    self._update_indexes(oid, order, None)
                    self.orders.pop(oid, None)
                    self.order_fills.pop(oid, None)
                    self.order_events.pop(oid, None)
                    removed += 1

        self.log.info(f"Cleaned up {removed} old orders (retention={retention}h)")
        return removed

    def sync_with_exchange(self, engine: Any, force: bool = False) -> Dict[str, Any]:
        start_time = time.time()

        with self.sync_lock:
            now = time.time()
            if not force and (now - self.last_sync_ts) < self.sync_interval_sec:
                return {"skipped": True, "reason": "within_sync_interval"}

            self.last_sync_ts = now

            # housekeeping
            self.cleanup_old_orders()
            self._handle_stale_orders()

            sync_results: Dict[str, Any] = {}
            if str(self.cfg.get("mode", "paper")).lower() == "live":
                sync_results = self._sync_with_exchange_live(engine)

            dur = time.time() - start_time
            self.performance_stats["sync_durations"].append(dur)
            self.stats["sync_count"] += 1

            issues = self.detect_issues()
            issues_found = sum(len(v) for v in issues.values())

            return {
                "success": True,
                "duration": dur,
                "orders_synced": sync_results.get("synced", 0),
                "issues_found": issues_found,
                "issues": issues,
                "stats": self.get_order_summary(),
            }

    def _sync_with_exchange_live(self, engine: Any) -> Dict[str, Any]:
        client = getattr(engine, "client", None)
        if not client:
            return {"error": "no_client"}

        synced = 0
        errors: List[str] = []

        try:
            open_orders = []
            if hasattr(client, "fetch_open_orders"):
                try:
                    open_orders = client.fetch_open_orders(None, None, 200) or []
                except TypeError:
                    open_orders = client.fetch_open_orders(limit=200) or []

                for ex_order in open_orders:
                    if self.update_from_exchange(ex_order, source="open_orders"):
                        synced += 1

            self._check_disappeared_orders(client)
            if self.enable_fallback_fetch:
                self._fetch_specific_orders(client)

        except Exception as e:
            errors.append(str(e))
            self.log.error(f"Error during exchange sync: {e}")

        return {"synced": synced, "errors": errors}

    def _check_disappeared_orders(self, client: Any) -> None:
        now = time.time()
        with self.lock:
            active = [o for o in self.orders.values() if o.status.is_active and o.exchange_order_id]

        for order in active:
            if now - order.updated_ts > self.sync_interval_sec * 2:
                self._update_order_status(
                    order_id=order.order_id,
                    new_status=OrderStatus.SUSPECTED_FILLED,
                    reason="Not seen in recent exchange sync",
                )

    def _fetch_specific_orders(self, client: Any) -> None:
        if not hasattr(client, "fetch_order"):
            return

        with self.lock:
            to_verify = [
                o for o in self.orders.values()
                if o.status in {OrderStatus.SUSPECTED_FILLED, OrderStatus.SUSPECTED_CANCELLED, OrderStatus.UNKNOWN_CLOSED}
                and o.exchange_order_id
            ][: self.max_fallback_fetch]

        for order in to_verify:
            try:
                ex_order = client.fetch_order(order.exchange_order_id, order.symbol)
                if ex_order:
                    self.update_from_exchange(ex_order, source="fetch_order")
            except Exception as e:
                self.log.debug(f"Could not fetch order {order.order_id}: {e}")

    def _handle_stale_orders(self) -> None:
        now = time.time()
        with self.lock:
            items = list(self.orders.items())

        for oid, order in items:
            age = now - order.created_ts
            if order.status == OrderStatus.PENDING and age > self.max_pending_sec:
                self._update_order_status(oid, OrderStatus.STALE_PENDING, reason=f"Pending {age:.1f}s > {self.max_pending_sec}s")
            if order.status == OrderStatus.OPEN and age > self.max_open_sec:
                self._update_order_status(oid, OrderStatus.STALE_OPEN, reason=f"Open {age:.1f}s > {self.max_open_sec}s")

    # ---------- analytics helpers

    def _calculate_avg_fill_latency(self, order_id: str) -> Optional[float]:
        with self.lock:
            fills = list(self.order_fills.get(order_id, []))
            order = self.orders.get(order_id)
        if not fills or not order:
            return None
        latencies = [(f.timestamp - order.created_ts) for f in fills]
        return (sum(latencies) / len(latencies)) if latencies else None

    def _calculate_slippage_vs_limit(self, order: OrderState) -> Optional[float]:
        if not order.average_fill_price or not order.limit_price:
            return None
        if order.side == "buy":
            return ((order.average_fill_price - order.limit_price) / order.limit_price) * 100.0
        return ((order.limit_price - order.average_fill_price) / order.average_fill_price) * 100.0

    def _calculate_execution_quality(self, order: OrderState) -> Dict[str, Any]:
        if order.status != OrderStatus.FILLED:
            return {"status": "not_filled"}
        quality = {
            "status": "filled",
            "completion_time": order.updated_ts - order.created_ts,
            "fills_count": len(self.order_fills.get(order.order_id, [])),
            "average_slippage": self._calculate_slippage_vs_limit(order),
        }
        rating = "good"
        if quality["completion_time"] > order.timeout_sec / 2:
            rating = "slow"
        sl = quality["average_slippage"]
        if sl is not None and abs(sl) > order.max_slippage_pct:
            rating = "poor"
        quality["rating"] = rating
        return quality

    # ---------- export/import

    def export_orders(self, format: str = "json") -> str:
        with self.lock:
            orders_data = [o.to_dict() for o in self.orders.values()]

        if format == "json":
            return json.dumps(orders_data, indent=2, default=str)
        if format == "csv":
            import csv
            import io
            output = io.StringIO()
            if orders_data:
                writer = csv.DictWriter(output, fieldnames=orders_data[0].keys())
                writer.writeheader()
                writer.writerows(orders_data)
            return output.getvalue()
        raise ValueError(f"Unsupported format: {format}")

    def import_orders(self, data: str, format: str = "json") -> int:
        imported = 0
        try:
            if format != "json":
                raise ValueError("Only json import supported in this implementation")

            orders_list = json.loads(data)
            if not isinstance(orders_list, list):
                return 0

            with self.lock:
                for od in orders_list:
                    order = OrderState(
                        order_id=od["order_id"],
                        client_order_id=od.get("client_order_id") or od["order_id"],
                        symbol=od.get("symbol", ""),
                        side=str(od.get("side", "")).lower(),
                        order_type=OrderType(od.get("order_type", "limit")),
                        time_in_force=TimeInForce(od.get("time_in_force", "GTC")),
                        created_ts=float(od.get("created_ts", time.time())),
                        updated_ts=float(od.get("updated_ts", time.time())),
                        status=OrderStatus(od.get("status", "pending")),
                    )
                    self.orders[order.order_id] = order
                    self._update_indexes(order.order_id, None, order)
                    imported += 1
        except Exception as e:
            self.log.error(f"Error importing orders: {e}")
        return imported

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, List
import math
import os
import hmac
import time
import uuid
import logging
from datetime import datetime

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from starlette.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import psutil

print("[BOOT] API FILE =", __file__)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global app start time for uptime calculation
app_start_time = time.time()


class ControlRequest(BaseModel):
    symbol: Optional[str] = None
    action: str
    side: Optional[str] = None
    qty: Optional[float] = None
    reason: Optional[str] = None


# -------------------------
# JSON safety (NaN/Inf)
# -------------------------
def _sanitize_jsonable(x: Any) -> Any:
    """Recursively sanitize data so Starlette JSONResponse doesn't crash on NaN/Inf.

    Starlette uses json.dumps(..., allow_nan=False), so any NaN/Inf must be removed.
    We convert non-finite floats to None and coerce numpy/pandas scalars to python types.
    """
    try:
        if x is None or isinstance(x, (str, int, bool)):
            return x
        if isinstance(x, float):
            return x if math.isfinite(x) else None
        # numpy / pandas scalars
        if hasattr(x, "item") and callable(getattr(x, "item")):
            try:
                return _sanitize_jsonable(x.item())
            except Exception:
                pass
        if isinstance(x, dict):
            return {str(k): _sanitize_jsonable(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [_sanitize_jsonable(v) for v in x]
        if isinstance(x, set):
            return [_sanitize_jsonable(v) for v in sorted(list(x))]
        if is_dataclass(x):
            return _sanitize_jsonable(asdict(x))
        if hasattr(x, "to_dict") and callable(getattr(x, "to_dict")):
            return _sanitize_jsonable(x.to_dict())
        if hasattr(x, "as_dict") and callable(getattr(x, "as_dict")):
            return _sanitize_jsonable(x.as_dict())
        if hasattr(x, "__dict__"):
            return _sanitize_jsonable(dict(x.__dict__))
        return str(x)
    except Exception:
        return str(x)


class SafeJSONResponse(JSONResponse):
    """JSONResponse that never crashes on NaN/Inf floats."""
    def render(self, content: Any) -> bytes:
        return super().render(_sanitize_jsonable(content))


# -------------------------
# Helpers
# -------------------------
_SECRET_HINTS = ("key", "secret", "token", "password", "passphrase", "apikey", "api_key", "bearer")


def _redact_secrets(obj: Any) -> Any:
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            lk = str(k).lower()
            if any(h in lk for h in _SECRET_HINTS):
                out[k] = "***REDACTED***"
            else:
                out[k] = _redact_secrets(v)
        return out
    if isinstance(obj, list):
        return [_redact_secrets(x) for x in obj]
    return obj


def _model_to_dict(m: Any) -> Dict[str, Any]:
    """Works with Pydantic v1 (dict) and v2 (model_dump)."""
    if m is None:
        return {}
    if hasattr(m, "model_dump") and callable(getattr(m, "model_dump")):
        return m.model_dump()
    if hasattr(m, "dict") and callable(getattr(m, "dict")):
        return m.dict()
    return dict(m)


def _obj_to_dict(x: Any) -> Dict[str, Any]:
    """Best-effort conversion to JSONable dict; never throws."""
    if x is None:
        return {}
    try:
        if hasattr(x, "to_dict") and callable(getattr(x, "to_dict")):
            v = x.to_dict()
            return v if isinstance(v, dict) else {"value": v}
        if hasattr(x, "as_dict") and callable(getattr(x, "as_dict")):
            v = x.as_dict()
            return v if isinstance(v, dict) else {"value": v}
        if is_dataclass(x):
            v = asdict(x)
            return v if isinstance(v, dict) else {"value": v}
        if isinstance(x, dict):
            return x
        if hasattr(x, "__dict__"):
            d = dict(x.__dict__)
            for k, v in list(d.items()):
                if isinstance(v, set):
                    d[k] = sorted(list(v))
            return d
        return {"value": str(x)}
    except Exception:
        return {"value": str(x)}


# -------------------------
# Validation and Configuration
# -------------------------
def validate_config():
    """Validate required configuration at startup."""
    required_vars = []
    
    # Check if in live mode
    if os.getenv("BOT_MODE", "paper").lower() == "live":
        required_vars = ["BOT_API_KEY"]
    
    missing = [var for var in required_vars if not os.getenv(var)]
    if missing:
        raise ValueError(f"Missing required environment variables: {missing}")
    
    logger.info("Configuration validation passed")


# -------------------------
# App factory
# -------------------------
def create_app(engine) -> FastAPI:
    validate_config()
    
    app = FastAPI(
        title="Crypto Bot Local API",
        version="v8",
        description="API for managing crypto trading bot operations",
        contact={
            "name": "Support",
            "email": "support@example.com",
        },
        license_info={
            "name": "MIT",
            "url": "https://opensource.org/licenses/MIT",
        },
        default_response_class=SafeJSONResponse,
    )

    # -------------------------
    # CORS Middleware
    # -------------------------
    cors_origins = os.getenv("CORS_ORIGINS", "*").split(",")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def ok(data: Any = None, **kw) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"ok": True}
        if data is not None:
            payload["data"] = data
        payload.update(kw)
        return payload

    def fail(detail: str, **kw) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"ok": False, "detail": detail}
        payload.update(kw)
        return payload

    # -------------------------
    # Exception normalization
    # -------------------------
    @app.exception_handler(HTTPException)
    async def http_exc_handler(request: Request, exc: HTTPException):
        return SafeJSONResponse(
            content=fail(str(exc.detail)),
            status_code=exc.status_code,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exc_handler(request: Request, exc: RequestValidationError):
        return SafeJSONResponse(
            content=fail("Validation error", errors=exc.errors()),
            status_code=422,
        )

    @app.exception_handler(Exception)
    async def unhandled_exc_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return SafeJSONResponse(
            content=fail(f"Unhandled error: {type(exc).__name__}: {exc}"),
            status_code=500,
        )

    # -------------------------
    # Middleware: request id + latency + logging
    # -------------------------
    @app.middleware("http")
    async def add_request_id_and_timing(request: Request, call_next):
        rid = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        t0 = time.time()
        
        # Log request
        logger.info(f"Request started: {request.method} {request.url} (ID: {rid})")
        
        # Check content length
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > 10 * 1024 * 1024:  # 10MB
            raise HTTPException(status_code=413, detail="Payload too large")
        
        response = await call_next(request)
        dt_ms = int((time.time() - t0) * 1000)
        
        # Add headers
        response.headers["X-Request-ID"] = rid
        response.headers["X-Response-Time-ms"] = str(dt_ms)
        
        # Add cache headers for static data
        if request.url.path in ["/config", "/capabilities", "/_routes"]:
            response.headers["Cache-Control"] = "public, max-age=300"
        
        logger.info(f"Request finished: {request.method} {request.url} (ID: {rid}) took {dt_ms}ms")
        return response

    # -------------------------
    # Auth helper
    # -------------------------
    def _collect_allowed_keys() -> List[str]:
        cfg = getattr(engine, "cfg", {}) or {}
        api_cfg = (cfg.get("api") or {})
        keys: List[str] = []

        # env single
        k1 = (os.getenv("BOT_API_KEY") or "").strip()
        if k1:
            keys.append(k1)

        # env multiple
        km = (os.getenv("BOT_API_KEYS") or "").strip()
        if km:
            for part in km.split(","):
                p = part.strip()
                if p:
                    keys.append(p)

        # config single
        ck = str(api_cfg.get("key", "") or "").strip()
        if ck:
            keys.append(ck)

        # config multiple
        cks = api_cfg.get("keys")
        if isinstance(cks, list):
            for item in cks:
                s = str(item or "").strip()
                if s:
                    keys.append(s)

        # dedupe keep order
        seen = set()
        out = []
        for k in keys:
            if k not in seen:
                out.append(k)
                seen.add(k)
        return out

    def _require_write_auth(request: Request) -> bool:
        """Protect write endpoints in LIVE mode.

        - In paper mode: allow.
        - In live mode: require API key (X-API-Key or Authorization: Bearer).
        - If no key configured in live mode -> 403 disabled.
        """
        cfg = getattr(engine, "cfg", {}) or {}
        mode = str(cfg.get("mode", "paper")).lower().strip()
        if mode != "live":
            return True

        allowed = _collect_allowed_keys()
        if not allowed:
            raise HTTPException(
                status_code=403,
                detail="Write endpoints disabled in LIVE mode (set BOT_API_KEY/BOT_API_KEYS or api.key/api.keys).",
            )

        got = (request.headers.get("X-API-Key") or "").strip()
        if not got:
            auth = (request.headers.get("Authorization") or "").strip()
            if auth.lower().startswith("bearer "):
                got = auth[7:].strip()

        # constant-time compare against all allowed keys
        for k in allowed:
            if hmac.compare_digest(got, k):
                return True

        raise HTTPException(status_code=401, detail="Unauthorized")

    # -------------------------
    # Status fallback
    # -------------------------
    def _engine_status_fallback() -> Dict[str, Any]:
        try:
            cfg = getattr(engine, "cfg", {}) or {}
            mode = str(cfg.get("mode", "paper")).lower().strip()

            running = bool(getattr(engine, "running", False) or getattr(engine, "_running", False))
            paused = bool(getattr(engine, "paused", False) or getattr(engine, "_paused", False))

            risk_state = getattr(engine, "risk_state", None)
            if hasattr(risk_state, "state"):
                risk_state = getattr(risk_state, "state")

            watchlist = getattr(engine, "watchlist", None) or []
            pending = getattr(engine, "pending_orders", None) or getattr(engine, "pending", None) or []

            positions = getattr(engine, "positions", None) or getattr(engine, "live_positions", None)
            positions_count = len(positions) if isinstance(positions, (list, dict)) else 0

            caps = _obj_to_dict(getattr(engine, "capabilities", None))

            return {
                "mode": mode,
                "running": running,
                "paused": paused,
                "risk_state": risk_state,
                "watchlist_size": len(watchlist) if isinstance(watchlist, list) else 0,
                "positions_count": positions_count,
                "pending_count": len(pending) if isinstance(pending, list) else 0,
                "exchange": str(cfg.get("exchange", "")),
                # cfg["exchange"] is normally a string (e.g. "binance"); keep this robust
                "enable_futures": bool(cfg.get("enable_futures", False)),
                "capabilities": caps,
            }
        except Exception as e:
            return {"mode": "unknown", "running": False, "paused": False, "error": f"{type(e).__name__}: {e}"}

    # -------------------------
    # System health helpers
    # -------------------------
    def get_memory_usage() -> Dict[str, Any]:
        """Get memory usage statistics."""
        process = psutil.Process()
        mem_info = process.memory_info()
        return {
            "rss_mb": mem_info.rss / 1024 / 1024,
            "vms_mb": mem_info.vms / 1024 / 1024,
            "percent": process.memory_percent(),
            "system_available_mb": psutil.virtual_memory().available / 1024 / 1024,
            "system_total_mb": psutil.virtual_memory().total / 1024 / 1024,
        }

    def check_exchange_connection() -> bool:
        """Check if exchange connection is alive."""
        try:
            ws = getattr(engine, "ws", None)
            if ws and hasattr(ws, "is_connected"):
                return ws.is_connected()
            return True
        except Exception:
            return False

    def check_database_connection() -> bool:
        """Check if database connection is alive."""
        try:
            store = getattr(engine, "store", None)
            if store and hasattr(store, "check_connection"):
                return store.check_connection()
            return True
        except Exception:
            return False

    # ---------------------------------
    # Core endpoints
    # ---------------------------------
    @app.get("/status")
    def status():
        if hasattr(engine, "status") and callable(getattr(engine, "status")):
            try:
                return ok(engine.status())
            except Exception as e:
                return ok(_engine_status_fallback(), warning=f"engine.status() failed: {type(e).__name__}: {e}")
        return ok(_engine_status_fallback())

    @app.get("/capabilities")
    def capabilities():
        return ok(_obj_to_dict(getattr(engine, "capabilities", None)))

    @app.get("/portfolio")
    def portfolio():
        ps = getattr(engine, "portfolio_snapshotter", None)
        if ps is None:
            return ok({})
        for name in ("snapshot", "get_snapshot", "build_snapshot", "as_dict", "to_dict"):
            fn = getattr(ps, name, None)
            if callable(fn):
                return ok(fn())
        for attr in ("last", "last_snapshot", "state", "data"):
            v = getattr(ps, attr, None)
            if v is not None:
                return ok(v if isinstance(v, dict) else getattr(v, "__dict__", {"repr": str(v)}))
        return ok({})

    @app.get("/decisions")
    def decisions(limit: int = 200):
        store = getattr(engine, "store", None)
        if store is None:
            return ok([])
        fn = getattr(store, "list_decisions", None)
        if callable(fn):
            return ok(fn(limit=int(limit)))
        return ok([])

    # Trace
    def _trace_tail(tb: Any, limit: int, since_ts: float):
        if tb is None:
            return [], {"enabled": False, "reason": "trace buffer not initialized"}

        # Prefer your canonical API
        if float(since_ts or 0.0) > 0 and hasattr(tb, "since") and callable(getattr(tb, "since")):
            items = tb.since(float(since_ts), limit=int(limit))
        elif hasattr(tb, "tail") and callable(getattr(tb, "tail")):
            items = tb.tail(int(limit))
        else:
            # generic fallback
            items = list(getattr(tb, "items", tb))  # tb.items or iterable
            items = items[-int(limit):]

        stats = tb.stats() if hasattr(tb, "stats") and callable(getattr(tb, "stats")) else {"enabled": True}
        return items, stats

    @app.get("/trace")
    def trace(limit: int = 400, since_ts: float = 0.0):
        tb = getattr(engine, "trace", None)
        items, stats = _trace_tail(tb, int(limit), float(since_ts or 0.0))
        return ok(items, stats=stats)

    @app.get("/trace_stats")
    def trace_stats():
        tb = getattr(engine, "trace", None)
        if tb is None:
            return ok({"enabled": False})
        if hasattr(tb, "stats") and callable(getattr(tb, "stats")):
            return ok(tb.stats())
        return ok({"enabled": True})

    @app.get("/reasons")
    def reasons(symbol: Optional[str] = None):
        reasons_map = getattr(engine, "watchlist_reasons", {}) or {}
        if symbol:
            return ok(reasons_map.get(symbol, {}), symbol=symbol)
        return ok(reasons_map)

    # -------------------------
    # Signals (robust discovery + always list for /signals)
    # -------------------------
    def _looks_like_symbol(s: str) -> bool:
        if not isinstance(s, str):
            return False
        return ("/" in s) and (("USDT" in s) or (":" in s) or ("PERP" in s))

    def _normalize_symbols(x: Any) -> List[str]:
        """Normalize possible symbol containers into list[str]."""
        if x is None:
            return []
        if isinstance(x, dict):
            x = list(x.keys())
        if isinstance(x, (set, tuple)):
            x = list(x)
        if not isinstance(x, list):
            return []
        out: List[str] = []
        for it in x:
            if isinstance(it, str) and _looks_like_symbol(it):
                out.append(it)
        # dedupe keep order
        seen = set()
        uniq = []
        for s in out:
            if s not in seen:
                uniq.append(s)
                seen.add(s)
        return uniq

    def _discover_symbols_from_engine() -> List[str]:
        """Best-effort: find a symbol universe inside engine without knowing attribute names."""
        # 1) common names first
        common_attrs = [
            "pairs",
            "_pairs",
            "watchlist",
            "symbols",
            "selected_pairs",
            "selected_symbols",
            "universe",
            "symbol_universe",
            "ws_symbols",
            "_ws_symbols",
            "_symbols",
            "_watchlist",
            "watchlist_symbols",
        ]
        for a in common_attrs:
            wl = _normalize_symbols(getattr(engine, a, None))
            if wl:
                return wl

        # 1b) MarketDataWS symbols (engine.ws._symbols or engine.ws.symbols)
        try:
            ws = getattr(engine, "ws", None)
            if ws is not None:
                wl = _normalize_symbols(getattr(ws, "_symbols", None) or getattr(ws, "symbols", None))
                if wl:
                    return wl
        except Exception:
            pass

        # 2) use watchlist_reasons keys if available
        reasons_map = getattr(engine, "watchlist_reasons", None)
        wl = _normalize_symbols(reasons_map)
        if wl:
            return wl

        # 3) scan engine attributes for list/set/tuple of strings that look like symbols
        best: List[str] = []
        try:
            for name in dir(engine):
                if name.startswith("__"):
                    continue
                if name.lower() in ("exchange", "client", "ws", "store", "db", "logger"):
                    continue
                try:
                    v = getattr(engine, name, None)
                except Exception:
                    continue

                if isinstance(v, dict):
                    cand = _normalize_symbols(v)
                elif isinstance(v, (list, set, tuple)):
                    cand = _normalize_symbols(v)
                else:
                    continue

                if 5 <= len(cand) <= 500 and len(cand) > len(best):
                    best = cand
        except Exception:
            pass

        return best

    def _get_signals_payload(symbol: Optional[str] = None):
        """
        Always returns:
        - for /signals (symbol=None): a LIST with one row per symbol in universe
        - for /signals?symbol=... : a single dict for that symbol
        If engine has real signals, they override placeholders.
        """

        # ---- 1) Gather real signals into a dict: {symbol: row_dict} ----
        sig_map: Dict[str, Dict[str, Any]] = {}

        def _ingest_list(items: Any):
            if not isinstance(items, list):
                return
            for it in items:
                if isinstance(it, dict) and it.get("symbol"):
                    sig_map[str(it["symbol"])] = it

        def _ingest_dict(d: Any):
            if not isinstance(d, dict):
                return
            for k, v in d.items():
                if isinstance(v, dict):
                    sym = str(v.get("symbol") or k)
                    sig_map[sym] = v

        # Prefer engine helpers, but DO NOT early-return on empty
        try:
            if hasattr(engine, "get_last_signals") and callable(getattr(engine, "get_last_signals")):
                res = engine.get_last_signals(limit=200)
                if isinstance(res, dict):
                    _ingest_dict(res)
                elif isinstance(res, list):
                    _ingest_list(res)
        except Exception:
            pass

        try:
            if hasattr(engine, "get_signals_latest") and callable(getattr(engine, "get_signals_latest")):
                res = engine.get_signals_latest()
                if isinstance(res, dict):
                    _ingest_dict(res)
                elif isinstance(res, list):
                    _ingest_list(res)
        except Exception:
            pass

        # In-memory last_signals
        try:
            mem = getattr(engine, "last_signals", None)
            if isinstance(mem, dict):
                _ingest_dict(mem)
        except Exception:
            pass

        # ---- 2) Universe symbols (guaranteed by your debug) ----
        universe = _discover_symbols_from_engine()
        now = time.time()

        def _placeholder(sym: str) -> Dict[str, Any]:
            return {
                "symbol": sym,
                "action": "watch",
                "strength": 0.0,
                "price": None,
                "reason": "universe (no signals yet)",
                "ts": now,
                # keep also these for other consumers:
                "signal": "WATCH",
                "score": 0.0,
                "side": None,
            }


        # If a specific symbol requested: return real signal if exists, else placeholder
        if symbol:
            s = str(symbol)
            return sig_map.get(s) or _placeholder(s)

        # /signals: return full list universe, overridden by real signals
        out: List[Dict[str, Any]] = []
        for sym in universe:
            out.append(sig_map.get(sym) or _placeholder(sym))

        # Optional: include extra signals for symbols not in universe (rare)
        for sym, row in sig_map.items():
            if sym not in set(universe):
                out.append(row)

        return out
    
    def _normalize_signal_row_for_gui(row: Dict[str, Any]) -> Dict[str, Any]:
        """
        Ensure GUI expected keys exist:
        ts, symbol, action, strength, price, reason
        Also keep original keys (signal/score/etc) for other consumers.
        """
        if not isinstance(row, dict):
            return {}

        out = dict(row)

        # symbol
        sym = out.get("symbol")
        if sym is None and out.get("sym") is not None:
            sym = out.get("sym")
        out["symbol"] = sym

        # ts
        ts = out.get("ts")
        if ts is None:
            # allow created_ts / timestamp
            ts = out.get("created_ts", out.get("timestamp"))
        out["ts"] = ts

        # action: prefer explicit action, else map signal->action
        if "action" not in out or out.get("action") in (None, ""):
            sig = out.get("signal")
            if isinstance(sig, str) and sig:
                out["action"] = sig.lower()
            else:
                # if side exists without signal, still show something
                out["action"] = "watch"

        # strength: prefer explicit strength, else map score->strength
        if "strength" not in out or out.get("strength") is None:
            sc = out.get("score")
            if sc is None:
                sc = out.get("confidence", 0.0)
            try:
                out["strength"] = float(sc or 0.0)
            except Exception:
                out["strength"] = 0.0

        # price: keep if exists, else None (GUI can show blank)
        if "price" not in out:
            out["price"] = None

        # reason: ensure string
        if "reason" not in out:
            out["reason"] = ""

        return out


    @app.get("/debug/symbol_universe")
    def debug_symbol_universe():
        """Debug helper: shows where the API sees the symbol universe."""
        ws = getattr(engine, "ws", None)
        out = {
            "pairs_len": len(getattr(engine, "pairs", []) or []) if isinstance(getattr(engine, "pairs", None), list) else None,
            "watchlist_len": len(getattr(engine, "watchlist", []) or []) if isinstance(getattr(engine, "watchlist", None), list) else None,
            "ws_symbols_len": len(getattr(ws, "_symbols", []) or []) if ws is not None and isinstance(getattr(ws, "_symbols", None), list) else None,
            "reasons_len": len((getattr(engine, "watchlist_reasons", {}) or {})) if isinstance(getattr(engine, "watchlist_reasons", None), dict) else None,
            "last_signals_type": type(getattr(engine, "last_signals", None)).__name__,
            "universe": _discover_symbols_from_engine()[:100],
        }
        return ok(out)

    @app.get("/signals")
    def signals(symbol: Optional[str] = None):
        payload = _get_signals_payload(symbol=symbol)

        # payload can be dict (single) or list
        if isinstance(payload, dict):
            payload = _normalize_signal_row_for_gui(payload)
        elif isinstance(payload, list):
            payload = [_normalize_signal_row_for_gui(x) for x in payload if isinstance(x, dict)]

        return ok(payload, symbol=symbol)


    @app.get("/last_signal")
    def last_signal(symbol: Optional[str] = None):
        data = _get_signals_payload(symbol=symbol)
        if symbol:
            return ok(data, symbol=symbol)
        if isinstance(data, list) and data:
            return ok(data[0], symbol=None)
        return ok({}, symbol=None)

    @app.get("/health")
    def health():
        h = None
        if getattr(engine, "health", None) is not None:
            h = getattr(engine.health, "last_state", None)
        return ok(_obj_to_dict(h))

    @app.get("/health/detailed")
    def detailed_health():
        """Detailed health check with all dependencies."""
        checks = {
            "api": True,
            "timestamp": datetime.now().isoformat(),
            "engine_running": getattr(engine, "running", False),
            "engine_paused": getattr(engine, "paused", False),
            "exchange_connected": check_exchange_connection(),
            "database_connected": check_database_connection(),
            "memory_usage": get_memory_usage(),
            "uptime_seconds": time.time() - app_start_time,
            "python_version": os.getenv("PYTHON_VERSION", "unknown"),
            "environment": os.getenv("ENVIRONMENT", "development"),
        }
        
        # Calculate overall health status
        critical_checks = ["engine_running", "exchange_connected"]
        all_critical_ok = all(checks[check] for check in critical_checks if check in checks)
        checks["overall_healthy"] = all_critical_ok
        
        return ok(checks)

    # ---------------------------------
    # Write endpoints
    # ---------------------------------
    @app.post("/api/system/stop", dependencies=[Depends(_require_write_auth)])
    def stop():
        if hasattr(engine, "stop") and callable(getattr(engine, "stop")):
            engine.stop()
        return ok({"stopped": True})

    @app.post("/api/system/reconcile", dependencies=[Depends(_require_write_auth)])
    def reconcile():
        out = engine.reconcile_with_exchange() if hasattr(engine, "reconcile_with_exchange") else {}
        return ok(out)

    @app.post("/control", dependencies=[Depends(_require_write_auth)])
    def control(req: ControlRequest):
        if not hasattr(engine, "control") or not callable(getattr(engine, "control")):
            return fail("engine.control() not implemented")
        res = engine.control(**_model_to_dict(req))
        return ok(res)

    @app.post("/control/manual_entry", dependencies=[Depends(_require_write_auth)])
    def manual_entry(req: ControlRequest):
        if not hasattr(engine, "manual_entry") or not callable(getattr(engine, "manual_entry")):
            return fail("engine.manual_entry() not implemented")
        res = engine.manual_entry(**_model_to_dict(req))
        return ok(res)

    # ---------------------------------
    # Read-only state for UI
    # ---------------------------------
    def _call_engine_snapshot(method_names: List[str], fallback_attrs: List[str]):
        for name in method_names:
            fn = getattr(engine, name, None)
            if callable(fn):
                return fn()
        for attr in fallback_attrs:
            v = getattr(engine, attr, None)
            if v is not None:
                return v
        return []

    @app.get("/positions")
    def positions():
        data = _call_engine_snapshot(
            method_names=["get_positions_snapshot", "positions_snapshot", "get_positions", "get_open_positions"],
            fallback_attrs=["positions", "live_positions"],
        )
        return ok(data)

    @app.get("/pending")
    def pending():
        data = _call_engine_snapshot(
            method_names=["get_pending_snapshot", "pending_snapshot", "get_pending_orders"],
            fallback_attrs=["pending_orders", "pending"],
        )
        return ok(data)

    @app.get("/trades")
    def trades(limit: int = 200):
        fn = getattr(engine, "get_trades", None)
        if callable(fn):
            return ok(fn(limit=int(limit)))
        v = getattr(engine, "trades", None) or getattr(engine, "trade_history", None) or []
        return ok(v[-int(limit):] if isinstance(v, list) else v)

    @app.get("/metrics")
    def metrics():
        fn = getattr(engine, "get_metrics_snapshot", None)
        if callable(fn):
            return ok(fn())
        v = getattr(engine, "metrics", None) or {}
        return ok(v)

    @app.get("/config")
    def config():
        if hasattr(engine, "get_public_config") and callable(getattr(engine, "get_public_config")):
            return ok(engine.get_public_config())
        return ok(_redact_secrets(getattr(engine, "cfg", {}) or {}))

    @app.get("/state")
    def state():
        if hasattr(engine, "_snapshot") and callable(getattr(engine, "_snapshot")):
            return ok(engine._snapshot())
        return ok({"state": "snapshot_not_available"})

    @app.get("/_routes")
    def _routes():
        return ok(
            [
                {"path": r.path, "name": r.name, "methods": sorted(list(r.methods or []))}
                for r in app.router.routes
            ]
        )

    # -------------------------
    # Shutdown event handler
    # -------------------------
    @app.on_event("shutdown")
    def shutdown_event():
        logger.info("API shutting down")
        # Cleanup resources
        if hasattr(engine, "cleanup"):
            try:
                engine.cleanup()
            except Exception as e:
                logger.error(f"Error during engine cleanup: {e}")
        
        logger.info("API shutdown complete")

    # Debug boot prints at the end (after routes are registered)
    print("[BOOT] API FILE =", __file__)
    print("[BOOT] API has /signals ?", any(getattr(r, "path", "") == "/signals" for r in app.router.routes))
    
    logger.info(f"API started successfully with {len(app.router.routes)} routes")
    logger.info(f"CORS origins: {cors_origins}")

    return app
from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional, Tuple, List

try:
    import requests
except Exception:  # pragma: no cover
    requests = None  # type: ignore


def _f(x: Any, d: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(d)


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(float(lo), min(float(hi), float(x)))


def _as_int(x: Any, d: int) -> int:
    try:
        return int(x)
    except Exception:
        return int(d)


class NewsSentiment:
    """
    News/sentiment adapter using CryptoPanic.

    Improvements vs placeholder:
      - robust cache (TTL) + stale-if-error fallback
      - light retry/backoff on 429/5xx
      - recency weighting (decay)
      - optional per-asset sentiment
      - explain/status for UI/trace
      - safe behavior when requests is missing
    """

    def __init__(self) -> None:
        self._cache: Dict[str, Any] = {}
        self._ts: float = 0.0
        self._last_err: str = ""
        self._last_http: int = 0

        # Tunables via env (safe defaults)
        self.ttl_sec: int = _as_int(os.environ.get("NEWS_CACHE_TTL_SEC", "300"), 300)
        self.timeout_sec: float = float(os.environ.get("NEWS_HTTP_TIMEOUT_SEC", "10") or 10.0)
        self.max_items: int = _as_int(os.environ.get("NEWS_MAX_ITEMS", "30"), 30)

        # Recency half-life (hours) for decay weighting
        self.half_life_hours: float = float(os.environ.get("NEWS_HALF_LIFE_HOURS", "6") or 6.0)

    # -------------------------
    # HTTP fetch
    # -------------------------
    def _fetch_cryptopanic_http(self, token: str) -> Dict[str, Any]:
        if requests is None:
            raise RuntimeError("requests not installed")

        url = "https://cryptopanic.com/api/v1/posts/"
        params = {"auth_token": token, "public": "true"}

        # light retry/backoff for transient errors
        last_exc: Optional[Exception] = None
        for attempt in range(2):
            try:
                r = requests.get(url, params=params, timeout=float(self.timeout_sec))
                self._last_http = int(getattr(r, "status_code", 0) or 0)

                # retry on 429/5xx
                if self._last_http in (429, 500, 502, 503, 504):
                    time.sleep(0.35 + 0.5 * attempt)
                    continue

                r.raise_for_status()
                return r.json()  # type: ignore
            except Exception as e:
                last_exc = e
                time.sleep(0.2 + 0.4 * attempt)

        raise last_exc or RuntimeError("cryptopanic fetch failed")

    def fetch_cryptopanic(self, *, force: bool = False) -> Optional[Dict[str, Any]]:
        token = os.environ.get("CRYPTOPANIC_TOKEN", "").strip()
        if not token:
            self._last_err = "CRYPTOPANIC_TOKEN missing"
            return None

        now = time.time()
        if (not force) and self._cache and (now - float(self._ts)) < float(self.ttl_sec):
            return self._cache

        # try fetch; if fails, serve stale cache
        try:
            data = self._fetch_cryptopanic_http(token)
            if isinstance(data, dict):
                self._cache = data
                self._ts = now
                self._last_err = ""
                return self._cache
            self._last_err = "invalid response type"
            return self._cache or None
        except Exception as e:
            self._last_err = f"{type(e).__name__}: {e}"
            # stale-if-error: return cache if present
            return self._cache or None

    # -------------------------
    # scoring
    # -------------------------
    def _item_age_hours(self, it: Dict[str, Any]) -> float:
        """
        CryptoPanic typically includes 'published_at' like '2024-..Z'.
        We do not parse timestamps strictly here to keep dependencies minimal.
        If missing, assume recent.
        """
        # Minimal heuristic:
        # If there is "created_at" numeric or "timestamp" use it; otherwise 0.
        # If you want perfect timestamp parsing, we can add datetime.fromisoformat with fixups.
        ts = it.get("timestamp") or it.get("ts")
        if isinstance(ts, (int, float)) and ts > 0:
            age = max(0.0, (time.time() - float(ts)) / 3600.0)
            return age
        return 0.0

    def _weight(self, age_hours: float) -> float:
        hl = max(0.25, float(self.half_life_hours))
        # exponential decay: weight halves every half-life
        return 0.5 ** (float(age_hours) / hl)

    def sentiment_score(self, symbol: Optional[str] = None, *, explain: bool = False) -> Any:
        """
        Return sentiment score in [-1, 1].
        If symbol is provided (e.g. BTC/USDT), tries per-asset scoring using item 'currencies/coins' field if present.
        If explain=True returns dict with details for UI/trace.
        """
        data = self.fetch_cryptopanic()
        if not data:
            return {"score": 0.0, "reason": "no_data"} if explain else 0.0

        items = data.get("results") or []
        if not isinstance(items, list) or not items:
            return {"score": 0.0, "reason": "empty"} if explain else 0.0

        base = None
        if symbol:
            s = str(symbol).upper().strip()
            # BTC/USDT -> BTC
            if "/" in s:
                base = s.split("/", 1)[0]
            elif "-" in s:
                base = s.split("-", 1)[0]
            else:
                base = s

        total_w = 0.0
        total_s = 0.0
        used: List[Dict[str, Any]] = []

        for it in items[: max(1, int(self.max_items))]:
            if not isinstance(it, dict):
                continue

            # optional per-asset filter
            if base:
                coins = it.get("currencies") or it.get("coins") or it.get("assets")
                if isinstance(coins, list):
                    syms = set()
                    for c in coins:
                        if isinstance(c, dict):
                            sym = c.get("code") or c.get("symbol") or c.get("name")
                            if sym:
                                syms.add(str(sym).upper())
                        elif isinstance(c, str):
                            syms.add(c.upper())
                    if base.upper() not in syms and len(syms) > 0:
                        continue
                # if coins missing, keep it (better than dropping all)

            votes = it.get("votes") or {}
            pos = _f(votes.get("positive", 0.0), 0.0)
            neg = _f(votes.get("negative", 0.0), 0.0)
            imp = _f(votes.get("important", 0.0), 0.0)
            lol = _f(votes.get("lol", 0.0), 0.0)

            # core sentiment: positives - negatives; important adds weight; lol slightly reduces confidence
            raw = (pos - neg) + 0.25 * imp - 0.10 * lol

            age_h = self._item_age_hours(it)
            w = self._weight(age_h)

            total_s += float(raw) * float(w)
            total_w += float(w)

            if explain:
                used.append(
                    {
                        "title": it.get("title"),
                        "raw": float(raw),
                        "w": float(w),
                        "pos": float(pos),
                        "neg": float(neg),
                        "important": float(imp),
                        "lol": float(lol),
                    }
                )

        if total_w <= 0:
            score = 0.0
        else:
            # normalize: map raw weighted score to [-1,1] via tanh-like clamp
            # scale factor chosen to avoid saturating too easily
            score = _clamp(total_s / (25.0 * total_w), -1.0, 1.0)

        if not explain:
            return float(score)

        return {
            "score": float(score),
            "base": base,
            "items_used": len(used),
            "cache_age_sec": float(time.time() - float(self._ts)) if self._ts else None,
            "last_http": int(self._last_http),
            "last_error": str(self._last_err),
            "top_items": used[:10],
        }

    def status(self) -> Dict[str, Any]:
        return {
            "enabled": bool(os.environ.get("CRYPTOPANIC_TOKEN", "").strip() != ""),
            "cache_ts": float(self._ts),
            "cache_age_sec": float(time.time() - float(self._ts)) if self._ts else None,
            "ttl_sec": int(self.ttl_sec),
            "timeout_sec": float(self.timeout_sec),
            "max_items": int(self.max_items),
            "half_life_hours": float(self.half_life_hours),
            "last_http": int(self._last_http),
            "last_error": str(self._last_err),
            "requests_installed": bool(requests is not None),
        }

from __future__ import annotations

import copy
import json
import os
import random
import time
import math
import threading
import hashlib
import pickle
from typing import Any, Dict, Optional, Tuple, List, Union, Callable
from dataclasses import dataclass, asdict, field
from enum import Enum
from datetime import datetime, timedelta
import logging


def _f(x: Any, d: float = 0.0) -> float:
    """Safely convert to float, handling NaN/Inf."""
    try:
        v = float(x)
        if math.isnan(v) or math.isinf(v):
            return float(d)
        return v
    except Exception:
        return float(d)


def _i(x: Any, d: int = 0) -> int:
    """Safely convert to integer."""
    try:
        return int(x)
    except Exception:
        return int(d)


def _clamp(x: float, lo: float, hi: float) -> float:
    """Clamp value between bounds."""
    return max(lo, min(hi, x))


def _utc_day_key(ts: Optional[float] = None) -> str:
    """Get UTC day key in YYYY-MM-DD format."""
    return time.strftime("%Y-%m-%d", time.gmtime(ts or time.time()))


class MutationType(Enum):
    """Types of mutations for parameter tuning."""
    MULTIPLICATIVE = "multiplicative"
    ADDITIVE = "additive"
    RANDOM = "random"
    BAYESIAN = "bayesian"


class EvaluationResult:
    """Result of a configuration evaluation."""
    
    def __init__(
        self,
        score: float = 0.0,
        drawdown: float = 0.0,
        sharpe: float = 0.0,
        win_rate: float = 0.0,
        trade_count: int = 0,
        metrics: Optional[Dict[str, float]] = None,
    ):
        self.score = score
        self.drawdown = drawdown
        self.sharpe = sharpe
        self.win_rate = win_rate
        self.trade_count = trade_count
        self.metrics = metrics or {}
        self.timestamp = time.time()
        self.valid = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "score": self.score,
            "drawdown": self.drawdown,
            "sharpe": self.sharpe,
            "win_rate": self.win_rate,
            "trade_count": self.trade_count,
            "metrics": self.metrics,
            "timestamp": self.timestamp,
            "valid": self.valid,
        }


@dataclass
class MutationCandidate:
    """Candidate configuration mutation."""
    path: str
    old_value: float
    new_value: float
    mutation_type: MutationType
    score: float = 0.0
    drawdown: float = 0.0
    improvement: float = 0.0
    accepted: bool = False
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "path": self.path,
            "old_value": self.old_value,
            "new_value": self.new_value,
            "mutation_type": self.mutation_type.value,
            "score": self.score,
            "drawdown": self.drawdown,
            "improvement": self.improvement,
            "accepted": self.accepted,
            "timestamp": self.timestamp,
        }


@dataclass
class TuningStats:
    """Statistics for self-tuning."""
    total_runs: int = 0
    successful_mutations: int = 0
    rejected_mutations: int = 0
    total_improvement: float = 0.0
    best_score: float = -float('inf')
    worst_score: float = float('inf')
    avg_evaluation_time: float = 0.0
    last_run_time: float = 0.0
    mutation_counts: Dict[str, int] = field(default_factory=dict)
    
    def record_run(self, accepted: bool, improvement: float, score: float, eval_time: float):
        """Record a tuning run."""
        self.total_runs += 1
        self.last_run_time = time.time()
        self.avg_evaluation_time = (
            (self.avg_evaluation_time * (self.total_runs - 1) + eval_time) / self.total_runs
        )
        
        if accepted:
            self.successful_mutations += 1
            self.total_improvement += improvement
            self.best_score = max(self.best_score, score)
        else:
            self.rejected_mutations += 1
        
        self.worst_score = min(self.worst_score, score)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_runs": self.total_runs,
            "successful_mutations": self.successful_mutations,
            "rejected_mutations": self.rejected_mutations,
            "total_improvement": self.total_improvement,
            "best_score": self.best_score,
            "worst_score": self.worst_score,
            "avg_evaluation_time": self.avg_evaluation_time,
            "last_run_time": self.last_run_time,
            "mutation_counts": self.mutation_counts,
        }


class ConfigurationManager:
    """Manages configuration with path-based access."""
    
    @staticmethod
    def get_path(d: Dict[str, Any], path: str) -> Any:
        """Get value at dotted path."""
        keys = str(path).split(".")
        cur = d
        
        for key in keys:
            if not isinstance(cur, dict) or key not in cur:
                return None
            cur = cur[key]
        
        return cur
    
    @staticmethod
    def set_path(d: Dict[str, Any], path: str, value: Any) -> bool:
        """Set value at dotted path."""
        keys = str(path).split(".")
        cur = d
        
        for key in keys[:-1]:
            if not isinstance(cur, dict):
                return False
            if key not in cur:
                cur[key] = {}
            cur = cur[key]
        
        if not isinstance(cur, dict):
            return False
        
        cur[keys[-1]] = value
        return True
    
    @staticmethod
    def path_exists(d: Dict[str, Any], path: str) -> bool:
        """Check if path exists in configuration."""
        keys = str(path).split(".")
        cur = d
        
        for key in keys:
            if not isinstance(cur, dict) or key not in cur:
                return False
            cur = cur[key]
        
        return True
    
    @staticmethod
    def validate_numeric_path(d: Dict[str, Any], path: str) -> bool:
        """Validate that path points to a numeric value."""
        value = ConfigurationManager.get_path(d, path)
        
        try:
            float(value)
            return True
        except (TypeError, ValueError):
            return False


class SelfTuner:
    """Advanced controlled self-tuning for numeric parameters.

    Features:
      - Multiple mutation strategies (multiplicative, additive, random, bayesian)
      - Sophisticated scoring with multiple metrics
      - Adaptive mutation rates based on performance
      - Robust persistence and recovery
      - Comprehensive statistics and monitoring
    """

    def __init__(self, cfg: Dict[str, Any], log: Any, base_dir: str = "."):
        self.cfg = cfg or {}
        self.log = log
        self.base_dir = str(base_dir or ".")
        self._lock = threading.RLock()

        # Runtime state
        self._last_run_ts: float = 0.0
        self._last_good_profile: Optional[Dict[str, Any]] = None
        self._changes_today: int = 0
        self._day_key: str = ""
        
        # Statistics
        self.stats = TuningStats()
        self.history: List[MutationCandidate] = []
        self.evaluation_history: List[EvaluationResult] = []
        
        # RNG with optional seeding
        self._rng = random.Random()
        
        # Mutation strategy
        self.mutation_strategy: MutationType = MutationType.MULTIPLICATIVE
        
        # Adaptive learning
        self._learning_rate: float = 0.1
        self._exploration_rate: float = 0.3
        
        # Cache for expensive evaluations
        self._evaluation_cache: Dict[str, EvaluationResult] = {}
        self._cache_max_size: int = 100
        
        # Performance monitoring
        self._performance_trend: List[float] = []
        self._max_trend_length: int = 100
        
        # Load persisted state
        self._load_state()

    # -------- Public API --------

    def tick(self, engine: Any) -> None:
        """Best-effort hook called from engine loop."""
        try:
            self.maybe_run(engine)
        except Exception as e:
            self.log.error(f"SelfTuner tick failed: {e}")

    def maybe_run(self, engine: Any) -> Optional[Dict[str, Any]]:
        """Run self-tuning if conditions are met."""
        with self._lock:
            try:
                # Update configuration reference
                self.cfg = getattr(engine, "cfg", self.cfg) or self.cfg
                
                # Check if we should run
                if not self._should_run(engine):
                    return None
                
                # Reset daily budget on UTC day boundary
                self._reset_daily_budget()
                
                # Check daily budget
                if not self._check_daily_budget():
                    return None
                
                # Check interval
                if not self._check_interval():
                    return None
                
                # Update last run timestamp
                self._last_run_ts = time.time()
                
                # Run evaluation
                result = self._evaluate_and_mutate(engine)
                
                # Persist state
                self._persist_state()
                
                return result
                
            except Exception as e:
                self.log.error(f"SelfTuner run failed: {e}")
                return None

    def rollback(self, engine: Any) -> bool:
        """Rollback to last known good configuration."""
        with self._lock:
            try:
                # Try to load last good profile
                profile = self._load_last_good_profile()
                
                if not profile:
                    self.log.warning("No good profile found for rollback")
                    return False
                
                # Apply profile to engine
                if self._apply_profile(engine, profile):
                    self.log.info("Successfully rolled back to last good profile")
                    
                    # Update local reference
                    self.cfg = copy.deepcopy(profile)
                    
                    # Record rollback
                    self._store_decision(engine, "rollback", {
                        "success": True,
                        "timestamp": time.time(),
                        "profile_source": "last_good"
                    })
                    
                    return True
                else:
                    self.log.error("Failed to apply rollback profile")
                    return False
                    
            except Exception as e:
                self.log.error(f"Rollback failed: {e}")
                return False

    def get_stats(self) -> Dict[str, Any]:
        """Get tuning statistics."""
        with self._lock:
            return {
                "stats": self.stats.to_dict(),
                "history_count": len(self.history),
                "evaluation_count": len(self.evaluation_history),
                "current_day_key": self._day_key,
                "changes_today": self._changes_today,
                "last_run": self._last_run_ts,
                "cache_size": len(self._evaluation_cache),
                "performance_trend_length": len(self._performance_trend),
            }

    def reset_stats(self) -> None:
        """Reset all statistics."""
        with self._lock:
            self.stats = TuningStats()
            self.history.clear()
            self.evaluation_history.clear()
            self._performance_trend.clear()
            self._evaluation_cache.clear()

    # -------- Configuration Evaluation --------

    def evaluate_configuration(self, engine: Any, cfg: Dict[str, Any]) -> EvaluationResult:
        """Evaluate a configuration using multiple metrics."""
        start_time = time.time()
        
        try:
            # Check cache first
            cfg_hash = self._hash_configuration(cfg)
            if cfg_hash in self._evaluation_cache:
                return self._evaluation_cache[cfg_hash]
            
            # Calculate metrics
            micro_score = self._micro_evaluation(engine, cfg)
            realized_score = self._realized_pnl_score(engine, cfg)
            drawdown_score = self._drawdown_score(engine, cfg)
            sharpe_score = self._sharpe_score(engine, cfg)
            
            # Combine scores with weights from config
            weights = self._get_evaluation_weights()
            
            combined_score = (
                weights.get("micro", 0.4) * micro_score +
                weights.get("realized", 0.3) * realized_score +
                weights.get("sharpe", 0.2) * sharpe_score -
                weights.get("drawdown", 0.5) * drawdown_score
            )
            
            # Create result
            result = EvaluationResult(
                score=combined_score,
                drawdown=drawdown_score,
                sharpe=sharpe_score,
                win_rate=self._calculate_win_rate(engine),
                trade_count=self._get_trade_count(engine),
                metrics={
                    "micro_score": micro_score,
                    "realized_score": realized_score,
                    "drawdown_score": drawdown_score,
                    "sharpe_score": sharpe_score,
                }
            )
            
            # Cache result
            self._cache_evaluation_result(cfg_hash, result)
            
            # Record evaluation time
            eval_time = time.time() - start_time
            self.log.debug(f"Evaluation completed in {eval_time:.2f}s, score: {combined_score:.4f}")
            
            return result
            
        except Exception as e:
            self.log.error(f"Configuration evaluation failed: {e}")
            return EvaluationResult(valid=False)

    def _micro_evaluation(self, engine: Any, cfg: Dict[str, Any]) -> float:
        """Perform micro backtest evaluation."""
        st_cfg = cfg.get("self_tuner", {})
        mcfg = st_cfg.get("micro_eval", {})
        
        if not mcfg.get("enabled", True):
            return 0.0
        
        # Time budget
        start_time = time.time()
        max_eval_sec = mcfg.get("max_eval_sec", 3.0)
        
        try:
            # Try to import required modules
            try:
                from .backtest_micro import micro_backtest
                from .indicators import atr
            except ImportError:
                self.log.warning("Micro backtest modules not available")
                return 0.0
            
            # Get symbols
            symbols = self._get_evaluation_symbols(engine, mcfg)
            if not symbols:
                return 0.0
            
            # Evaluation parameters
            timeframe = self._get_timeframe(engine, cfg)
            limit = mcfg.get("ohlcv_limit", 800)
            include_sides = mcfg.get("include_sides", ["long", "short"])
            
            scores = []
            fail_count = 0
            max_fails = mcfg.get("max_symbols_fail", 3)
            
            for symbol in symbols:
                # Check time budget
                if time.time() - start_time > max_eval_sec:
                    break
                
                try:
                    # Fetch OHLCV data
                    df = self._fetch_ohlcv(engine, symbol, timeframe, limit)
                    if df is None or len(df) < 120:
                        fail_count += 1
                        if fail_count >= max_fails:
                            return 0.0
                        continue
                    
                    # Calculate ATR
                    atr_series = atr(df, 14)
                    atr_val = float(atr_series.iloc[-1]) if atr_series is not None and len(atr_series) > 0 else 0.0
                    
                    if atr_val <= 0:
                        fail_count += 1
                        if fail_count >= max_fails:
                            return 0.0
                        continue
                    
                    # Evaluate sides
                    side_scores = []
                    for side in include_sides:
                        # Create configuration copy for backtest
                        backtest_cfg = copy.deepcopy(cfg)
                        backtest_cfg.setdefault("decision_factor", {}).setdefault("backtest", {})
                        backtest_cfg["decision_factor"]["backtest"].update({
                            "enabled": True,
                            "bars": min(600, max(200, limit)),
                            "horizon_bars": 60,
                            "min_signal_strength": 0.0,
                        })
                        
                        # Run micro backtest
                        result = micro_backtest(df, side=side, atr_val=atr_val, signal_strength=2.0, cfg=backtest_cfg)
                        
                        if getattr(result, "enabled", False):
                            score = getattr(result, "best_score", 0.0) or 0.0
                            side_scores.append(float(score))
                    
                    if side_scores:
                        if mcfg.get("take_best_side", True):
                            scores.append(max(side_scores))
                        else:
                            scores.append(sum(side_scores) / len(side_scores))
                    else:
                        fail_count += 1
                        if fail_count >= max_fails:
                            return 0.0
                            
                except Exception as e:
                    self.log.debug(f"Symbol {symbol} evaluation failed: {e}")
                    fail_count += 1
                    if fail_count >= max_fails:
                        return 0.0
                    continue
            
            if not scores:
                return 0.0
            
            # Calculate robust average (trimmed mean)
            if len(scores) >= 5:
                scores.sort()
                scores = scores[1:-1]
            
            return sum(scores) / len(scores)
            
        except Exception as e:
            self.log.error(f"Micro evaluation failed: {e}")
            return 0.0

    def _realized_pnl_score(self, engine: Any, cfg: Dict[str, Any]) -> float:
        """Calculate score based on realized PnL."""
        try:
            scale = float(cfg.get("self_tuner", {}).get("realized_scale", 0.001))
            window = int(cfg.get("self_tuner", {}).get("realized_trades_window", 200))
            
            total_pnl = 0.0
            
            # Check paper trading PnL
            paper = getattr(engine, "paper", None)
            if paper:
                total_pnl += float(getattr(paper, "realized_pnl_gross", 0.0) or 0.0)
            
            # Check recent trades
            rec = getattr(engine, "rec", None)
            if rec and getattr(rec, "trades", None):
                trades = rec.trades[-window:]
                for trade in trades:
                    total_pnl += float(getattr(trade, "realized_pnl", 0.0) or 0.0)
            
            return total_pnl * scale
            
        except Exception as e:
            self.log.debug(f"Realized PnL score calculation failed: {e}")
            return 0.0

    def _drawdown_score(self, engine: Any, cfg: Dict[str, Any]) -> float:
        """Calculate drawdown score."""
        try:
            peak = float(getattr(engine, "peak_equity", 0.0) or 0.0)
            equity = float(engine.equity())
            
            if peak > 0:
                return max(0.0, (peak - equity) / peak)
            return 0.0
            
        except Exception:
            return 0.0

    def _sharpe_score(self, engine: Any, cfg: Dict[str, Any]) -> float:
        """Calculate Sharpe ratio score."""
        try:
            # This is a simplified version
            returns = getattr(engine, "returns_history", [])
            if len(returns) < 2:
                return 0.0
            
            avg_return = sum(returns) / len(returns)
            std_return = math.sqrt(sum((r - avg_return) ** 2 for r in returns) / len(returns))
            
            if std_return > 0:
                return avg_return / std_return * math.sqrt(252)  # Annualized
            return 0.0
            
        except Exception:
            return 0.0

    def _calculate_win_rate(self, engine: Any) -> float:
        """Calculate win rate from recent trades."""
        try:
            rec = getattr(engine, "rec", None)
            if rec and getattr(rec, "trades", None):
                recent = rec.trades[-100:]  # Last 100 trades
                if not recent:
                    return 0.0
                
                wins = sum(1 for t in recent if float(getattr(t, "realized_pnl", 0.0) or 0.0) > 0)
                return wins / len(recent)
            return 0.0
        except Exception:
            return 0.0

    def _get_trade_count(self, engine: Any) -> int:
        """Get total trade count."""
        try:
            rec = getattr(engine, "rec", None)
            if rec and getattr(rec, "trades", None):
                return len(rec.trades)
            return 0
        except Exception:
            return 0

    # -------- Mutation Strategies --------

    def generate_mutation(self, cfg: Dict[str, Any]) -> Optional[MutationCandidate]:
        """Generate a mutation candidate."""
        st = cfg.get("self_tuner", {})
        allowed_paths = st.get("allowed_paths", [])
        
        if not allowed_paths:
            return None
        
        # Select path
        path = random.choice(allowed_paths)
        
        # Get current value
        current_value = ConfigurationManager.get_path(cfg, path)
        
        try:
            current_float = float(current_value)
            if math.isnan(current_float) or math.isinf(current_float):
                return None
        except (TypeError, ValueError):
            return None
        
        # Get bounds
        min_val, max_val = self._get_value_bounds(st, path, current_float)
        
        # Generate new value based on strategy
        new_value = self._apply_mutation_strategy(current_float, st, min_val, max_val)
        
        # Ensure we have a valid change
        if abs(new_value - current_float) < 1e-12:
            return None
        
        # Clamp to bounds
        new_value = _clamp(new_value, min_val, max_val)
        
        return MutationCandidate(
            path=path,
            old_value=current_float,
            new_value=new_value,
            mutation_type=self.mutation_strategy,
        )

    def _apply_mutation_strategy(self, current: float, config: Dict[str, Any], 
                                min_val: float, max_val: float) -> float:
        """Apply mutation strategy to generate new value."""
        delta = float(config.get("delta", 0.05))
        
        if self.mutation_strategy == MutationType.MULTIPLICATIVE:
            # Multiplicative mutation
            min_mult = float(config.get("min_mult", 0.5))
            max_mult = float(config.get("max_mult", 1.5))
            
            mult = 1.0 + self._rng.uniform(-delta, delta)
            mult = _clamp(mult, min_mult, max_mult)
            
            return current * mult
            
        elif self.mutation_strategy == MutationType.ADDITIVE:
            # Additive mutation
            max_abs_change = abs(current) * delta
            change = self._rng.uniform(-max_abs_change, max_abs_change)
            
            return current + change
            
        elif self.mutation_strategy == MutationType.RANDOM:
            # Random within bounds
            return self._rng.uniform(min_val, max_val)
            
        elif self.mutation_strategy == MutationType.BAYESIAN:
            # Simple Bayesian optimization (simplified)
            # In practice, you'd want a more sophisticated implementation
            mean = current
            stddev = abs(current) * delta * 0.5
            
            new_value = self._rng.gauss(mean, stddev)
            return _clamp(new_value, min_val, max_val)
            
        else:
            # Default to multiplicative
            mult = 1.0 + self._rng.uniform(-delta, delta)
            return current * mult

    def _get_value_bounds(self, config: Dict[str, Any], path: str, current: float) -> Tuple[float, float]:
        """Get bounds for a parameter."""
        # Default bounds
        min_val = float(config.get("min_value", -float('inf')))
        max_val = float(config.get("max_value", float('inf')))
        
        # Per-path bounds
        path_bounds = config.get("path_bounds", {})
        if path in path_bounds:
            bounds = path_bounds[path]
            if isinstance(bounds, (list, tuple)) and len(bounds) >= 2:
                min_val = float(bounds[0])
                max_val = float(bounds[1])
        
        # Ensure min <= max
        if min_val > max_val:
            min_val, max_val = max_val, min_val
        
        return min_val, max_val

    # -------- Decision Making --------

    def _evaluate_and_mutate(self, engine: Any) -> Optional[Dict[str, Any]]:
        """Evaluate current configuration and apply mutation if beneficial."""
        start_time = time.time()
        
        # Evaluate current configuration
        current_eval = self.evaluate_configuration(engine, self.cfg)
        self.evaluation_history.append(current_eval)
        
        # Generate and evaluate candidates
        candidates = self._generate_candidates(engine, self.cfg)
        
        if not candidates:
            self._store_decision(engine, "no_valid_candidates", {
                "score": current_eval.score,
                "timestamp": time.time(),
            })
            return None
        
        # Find best candidate
        best_candidate = None
        best_improvement = -float('inf')
        
        for candidate in candidates:
            # Apply mutation to temporary configuration
            temp_cfg = copy.deepcopy(self.cfg)
            if not ConfigurationManager.set_path(temp_cfg, candidate.path, candidate.new_value):
                continue
            
            # Evaluate candidate
            candidate_eval = self.evaluate_configuration(engine, temp_cfg)
            
            # Calculate improvement
            improvement = candidate_eval.score - current_eval.score
            candidate.improvement = improvement
            candidate.score = candidate_eval.score
            candidate.drawdown = candidate_eval.drawdown
            
            # Check acceptance criteria
            if self._should_accept_candidate(candidate, current_eval, candidate_eval):
                if improvement > best_improvement:
                    best_improvement = improvement
                    best_candidate = candidate
        
        # Apply best candidate if found
        if best_candidate:
            return self._apply_candidate(engine, best_candidate, current_eval)
        else:
            eval_time = time.time() - start_time
            self.stats.record_run(False, 0.0, current_eval.score, eval_time)
            
            self._store_decision(engine, "no_acceptable_candidates", {
                "score": current_eval.score,
                "candidates_evaluated": len(candidates),
                "timestamp": time.time(),
            })
            
            return None

    def _should_accept_candidate(self, candidate: MutationCandidate,
                               current_eval: EvaluationResult,
                               candidate_eval: EvaluationResult) -> bool:
        """Determine if candidate should be accepted."""
        config = self.cfg.get("self_tuner", {})
        
        min_improvement = float(config.get("min_improvement", 0.01))
        max_dd_increase = float(config.get("max_dd_increase", 0.02))
        
        # Check minimum improvement
        if candidate.improvement < min_improvement:
            return False
        
        # Check drawdown increase
        dd_increase = candidate_eval.drawdown - current_eval.drawdown
        if dd_increase > max_dd_increase:
            return False
        
        # Additional checks can be added here
        # (e.g., maximum absolute drawdown, win rate, etc.)
        
        return True

    def _apply_candidate(self, engine: Any, candidate: MutationCandidate,
                        current_eval: EvaluationResult) -> Dict[str, Any]:
        """Apply candidate mutation."""
        # Apply to configuration
        if not ConfigurationManager.set_path(self.cfg, candidate.path, candidate.new_value):
            self.log.error(f"Failed to apply mutation to path: {candidate.path}")
            return None
        
        # Update engine configuration if different
        engine_cfg = getattr(engine, "cfg", None)
        if engine_cfg is not self.cfg and isinstance(engine_cfg, dict):
            ConfigurationManager.set_path(engine_cfg, candidate.path, candidate.new_value)
        
        # Update state
        candidate.accepted = True
        self.history.append(candidate)
        self._changes_today += 1
        self._last_good_profile = copy.deepcopy(self.cfg)
        
        # Update performance trend
        self._update_performance_trend(candidate.score)
        
        # Record statistics
        eval_time = time.time() - self._last_run_ts
        self.stats.record_run(True, candidate.improvement, candidate.score, eval_time)
        
        # Update mutation counts
        mut_type = candidate.mutation_type.value
        self.stats.mutation_counts[mut_type] = self.stats.mutation_counts.get(mut_type, 0) + 1
        
        # Log acceptance
        self.log.info(
            f"SelfTuner accepted mutation: {candidate.path} = "
            f"{candidate.old_value:.6g} -> {candidate.new_value:.6g} "
            f"(score: {current_eval.score:.4f} -> {candidate.score:.4f}, "
            f"improvement: {candidate.improvement:.4f})"
        )
        
        # Store decision
        result = {
            "accepted": True,
            "path": candidate.path,
            "old_value": candidate.old_value,
            "new_value": candidate.new_value,
            "mutation_type": candidate.mutation_type.value,
            "improvement": candidate.improvement,
            "current_score": current_eval.score,
            "new_score": candidate.score,
            "changes_today": self._changes_today,
            "timestamp": time.time(),
        }
        
        self._store_decision(engine, "mutation_accepted", result)
        
        # Persist profile
        self._persist_profile(self._last_good_profile, "last_good_profile")
        
        return result

    def _generate_candidates(self, engine: Any, cfg: Dict[str, Any]) -> List[MutationCandidate]:
        """Generate mutation candidates."""
        config = cfg.get("self_tuner", {})
        num_candidates = config.get("candidates_per_run", 3)
        
        candidates = []
        attempts = 0
        max_attempts = num_candidates * 5
        
        while len(candidates) < num_candidates and attempts < max_attempts:
            candidate = self.generate_mutation(cfg)
            if candidate:
                candidates.append(candidate)
            attempts += 1
        
        return candidates

    # -------- Helper Methods --------

    def _should_run(self, engine: Any) -> bool:
        """Check if self-tuner should run."""
        # Check if enabled
        config = self.cfg.get("self_tuner", {})
        if not config.get("enabled", False):
            return False
        
        # Check risk state
        risk_state = getattr(engine, "risk_state", None)
        if risk_state:
            current_state = getattr(risk_state, "current", None)
            if current_state and getattr(current_state, "state", None) in ("RISK_OFF", "HALT"):
                return False
        
        return True

    def _reset_daily_budget(self) -> None:
        """Reset daily mutation budget."""
        day_key = _utc_day_key()
        if day_key != self._day_key:
            self._day_key = day_key
            self._changes_today = 0
            self.log.debug(f"Daily budget reset for {day_key}")

    def _check_daily_budget(self) -> bool:
        """Check daily mutation budget."""
        max_changes = self.cfg.get("self_tuner", {}).get("max_changes_per_day", 3)
        return self._changes_today < max_changes

    def _check_interval(self) -> bool:
        """Check if enough time has passed since last run."""
        interval = float(self.cfg.get("self_tuner", {}).get("interval_sec", 6 * 3600))
        jitter = float(self.cfg.get("self_tuner", {}).get("interval_jitter_sec", 60.0))
        
        # Apply jitter
        jitter_amount = self._rng.uniform(-abs(jitter), abs(jitter)) if jitter > 0 else 0.0
        effective_interval = max(1.0, interval + jitter_amount)
        
        time_since_last = time.time() - self._last_run_ts
        return time_since_last >= effective_interval

    def _get_evaluation_weights(self) -> Dict[str, float]:
        """Get evaluation weight configuration."""
        config = self.cfg.get("self_tuner", {})
        weights = config.get("evaluation_weights", {})
        
        return {
            "micro": weights.get("micro", 0.4),
            "realized": weights.get("realized", 0.3),
            "sharpe": weights.get("sharpe", 0.2),
            "drawdown": weights.get("drawdown", 0.5),
        }

    def _get_evaluation_symbols(self, engine: Any, config: Dict[str, Any]) -> List[str]:
        """Get symbols for evaluation."""
        sample_size = config.get("sample_symbols", 5)
        
        # Try to get symbols from engine
        symbols = []
        for attr in ["pairs", "watchlist", "symbols"]:
            val = getattr(engine, attr, None)
            if isinstance(val, list) and val:
                symbols = val
                break
        
        if not symbols:
            return []
        
        # Sample symbols
        if len(symbols) <= sample_size:
            return symbols
        
        return self._rng.sample(symbols, sample_size)

    def _get_timeframe(self, engine: Any, cfg: Dict[str, Any]) -> str:
        """Get timeframe for evaluation."""
        # Try engine config first
        engine_cfg = getattr(engine, "cfg", {})
        timeframe = engine_cfg.get("signal_timeframe", cfg.get("signal_timeframe", "5m"))
        return str(timeframe)

    def _fetch_ohlcv(self, engine: Any, symbol: str, timeframe: str, limit: int):
        """Fetch OHLCV data."""
        client = getattr(engine, "client", None)
        if client and hasattr(client, "fetch_ohlcv_df"):
            return client.fetch_ohlcv_df(symbol, timeframe=timeframe, limit=limit)
        return None

    def _hash_configuration(self, cfg: Dict[str, Any]) -> str:
        """Create hash for configuration caching."""
        # Create a simplified representation for hashing
        simplified = {}
        
        # Only include tunable parameters
        tunable_paths = cfg.get("self_tuner", {}).get("allowed_paths", [])
        
        for path in tunable_paths:
            value = ConfigurationManager.get_path(cfg, path)
            if value is not None:
                simplified[path] = value
        
        # Convert to JSON and hash
        json_str = json.dumps(simplified, sort_keys=True)
        return hashlib.md5(json_str.encode()).hexdigest()

    def _cache_evaluation_result(self, key: str, result: EvaluationResult):
        """Cache evaluation result."""
        if len(self._evaluation_cache) >= self._cache_max_size:
            # Remove oldest entry
            oldest_key = min(self._evaluation_cache.items(), key=lambda x: x[1].timestamp)[0]
            del self._evaluation_cache[oldest_key]
        
        self._evaluation_cache[key] = result

    def _update_performance_trend(self, score: float):
        """Update performance trend."""
        self._performance_trend.append(score)
        if len(self._performance_trend) > self._max_trend_length:
            self._performance_trend.pop(0)

    # -------- Persistence --------

    def _persist_state(self):
        """Persist current state."""
        config = self.cfg.get("self_tuner", {})
        persistence = config.get("persistence", {})
        
        if not persistence.get("enabled", True):
            return
        
        if not persistence.get("save_every_run", True):
            return
        
        self._save_state()

    def _save_state(self):
        """Save state to disk."""
        try:
            state_path = self._get_state_path()
            
            state = {
                "timestamp": time.time(),
                "day_key": self._day_key,
                "changes_today": self._changes_today,
                "last_run_ts": self._last_run_ts,
                "stats": self.stats.to_dict(),
                "history": [c.to_dict() for c in self.history[-100:]],  # Keep last 100
                "performance_trend": self._performance_trend,
                "metadata": {
                    "version": "1.0",
                    "app": "SelfTuner",
                }
            }
            
            # Save last good profile separately
            if self._last_good_profile:
                profile_path = self._get_profile_path("last_good_profile")
                self._save_json(self._last_good_profile, profile_path)
            
            # Save state
            self._save_json(state, state_path)
            
        except Exception as e:
            self.log.error(f"Failed to save state: {e}")

    def _load_state(self):
        """Load state from disk."""
        try:
            state_path = self._get_state_path()
            
            if not os.path.exists(state_path):
                return
            
            state = self._load_json(state_path)
            
            if not state:
                return
            
            # Load basic state
            self._day_key = state.get("day_key", "")
            self._changes_today = state.get("changes_today", 0)
            self._last_run_ts = state.get("last_run_ts", 0.0)
            
            # Load statistics
            stats_data = state.get("stats", {})
            self.stats = TuningStats(
                total_runs=stats_data.get("total_runs", 0),
                successful_mutations=stats_data.get("successful_mutations", 0),
                rejected_mutations=stats_data.get("rejected_mutations", 0),
                total_improvement=stats_data.get("total_improvement", 0.0),
                best_score=stats_data.get("best_score", -float('inf')),
                worst_score=stats_data.get("worst_score", float('inf')),
                avg_evaluation_time=stats_data.get("avg_evaluation_time", 0.0),
                last_run_time=stats_data.get("last_run_time", 0.0),
                mutation_counts=stats_data.get("mutation_counts", {}),
            )
            
            # Load history
            history_data = state.get("history", [])
            self.history = [
                MutationCandidate(
                    path=item["path"],
                    old_value=item["old_value"],
                    new_value=item["new_value"],
                    mutation_type=MutationType(item.get("mutation_type", "multiplicative")),
                    score=item.get("score", 0.0),
                    drawdown=item.get("drawdown", 0.0),
                    improvement=item.get("improvement", 0.0),
                    accepted=item.get("accepted", False),
                    timestamp=item.get("timestamp", 0.0),
                )
                for item in history_data
            ]
            
            # Load performance trend
            self._performance_trend = state.get("performance_trend", [])
            
            # Load last good profile
            self._load_last_good_profile()
            
            self.log.info(f"Loaded self-tuner state from {state_path}")
            
        except Exception as e:
            self.log.error(f"Failed to load state: {e}")

    def _load_last_good_profile(self) -> Optional[Dict[str, Any]]:
        """Load last good profile from disk."""
        try:
            profile_path = self._get_profile_path("last_good_profile")
            
            if not os.path.exists(profile_path):
                return None
            
            profile = self._load_json(profile_path)
            
            if profile and isinstance(profile, dict):
                self._last_good_profile = profile
                return profile
                
        except Exception as e:
            self.log.error(f"Failed to load last good profile: {e}")
        
        return None

    def _apply_profile(self, engine: Any, profile: Dict[str, Any]) -> bool:
        """Apply profile to engine."""
        try:
            engine_cfg = getattr(engine, "cfg", None)
            if engine_cfg and isinstance(engine_cfg, dict):
                engine_cfg.clear()
                engine_cfg.update(copy.deepcopy(profile))
                return True
        except Exception as e:
            self.log.error(f"Failed to apply profile: {e}")
        
        return False

    def _persist_profile(self, profile: Dict[str, Any], tag: str):
        """Persist profile to disk."""
        try:
            profile_path = self._get_profile_path(tag)
            self._save_json(profile, profile_path)
        except Exception as e:
            self.log.error(f"Failed to persist profile: {e}")

    def _get_state_path(self) -> str:
        """Get state file path."""
        config = self.cfg.get("self_tuner", {})
        persistence = config.get("persistence", {})
        
        path = persistence.get("state_path", "profiles/self_tuner_state.json")
        
        if not os.path.isabs(path):
            path = os.path.join(self.base_dir, path)
        
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        return path

    def _get_profile_path(self, tag: str) -> str:
        """Get profile file path."""
        profiles_dir = os.path.join(self.base_dir, "profiles")
        os.makedirs(profiles_dir, exist_ok=True)
        
        filename = f"{tag}.json"
        return os.path.join(profiles_dir, filename)

    def _save_json(self, data: Any, path: str):
        """Save data as JSON with atomic write."""
        tmp_path = path + ".tmp"
        
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        
        os.replace(tmp_path, path)

    def _load_json(self, path: str) -> Any:
        """Load data from JSON."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _store_decision(self, engine: Any, decision_type: str, payload: Dict[str, Any]):
        """Store decision in engine's store if available."""
        try:
            store = getattr(engine, "store", None)
            if store and hasattr(store, "decision"):
                store.decision(decision_type, payload)
        except Exception:
            pass


# Factory function for easy creation
def create_self_tuner(cfg: Dict[str, Any], log: Any, base_dir: str = ".") -> SelfTuner:
    """Create a SelfTuner instance."""
    return SelfTuner(cfg, log, base_dir)


# Example usage
if __name__ == "__main__":
    import logging
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Example configuration
    config = {
        "self_tuner": {
            "enabled": True,
            "interval_sec": 3600,  # 1 hour
            "interval_jitter_sec": 300,  # 5 minutes
            "max_changes_per_day": 5,
            "allowed_paths": [
                "risk.stop_atr_mult",
                "risk.take_atr_mult",
                "signal.strength_threshold",
            ],
            "delta": 0.1,
            "min_mult": 0.5,
            "max_mult": 2.0,
            "min_improvement": 0.02,
            "max_dd_increase": 0.03,
            "candidates_per_run": 5,
            "realized_scale": 0.001,
            "realized_trades_window": 100,
            "drawdown_lambda": 1.5,
            "evaluation_weights": {
                "micro": 0.5,
                "realized": 0.3,
                "sharpe": 0.1,
                "drawdown": 0.4,
            },
            "micro_eval": {
                "enabled": True,
                "sample_symbols": 3,
                "ohlcv_limit": 500,
                "include_sides": ["long", "short"],
                "take_best_side": True,
                "max_symbols_fail": 2,
                "max_eval_sec": 2.0,
            },
            "persistence": {
                "enabled": True,
                "state_path": "profiles/self_tuner_state.json",
                "save_every_run": True,
            },
            "path_bounds": {
                "risk.stop_atr_mult": [0.5, 5.0],
                "risk.take_atr_mult": [0.5, 10.0],
            },
        },
        "risk": {
            "stop_atr_mult": 2.0,
            "take_atr_mult": 4.0,
        },
        "signal": {
            "strength_threshold": 1.5,
        },
    }
    
    # Create self tuner
    tuner = create_self_tuner(config, logger, base_dir="test_data")
    
    # Mock engine for testing
    class MockEngine:
        def __init__(self):
            self.cfg = config
            self.peak_equity = 10000
            self.paper = None
            self.rec = None
            self.store = None
            self.pairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
            self.client = None
        
        def equity(self):
            return 9500
        
        def risk_state(self):
            class RiskState:
                class Current:
                    state = "NORMAL"
                current = Current()
            return RiskState()
    
    engine = MockEngine()
    
    # Run tuning
    print("Running self-tuning...")
    result = tuner.maybe_run(engine)
    
    if result:
        print(f"Tuning result: {result}")
    else:
        print("No tuning performed")
    
    # Get stats
    stats = tuner.get_stats()
    print(f"Tuner stats: {stats}")
    
    # Cleanup
    import shutil
    if os.path.exists("test_data"):
        shutil.rmtree("test_data")
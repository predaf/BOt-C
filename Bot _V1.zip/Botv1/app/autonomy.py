from __future__ import annotations

import time
import math
import threading
import json
from collections import defaultdict, deque, OrderedDict
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional, Tuple, List, Union, Callable
from enum import Enum
import logging

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    np = None

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False
    pd = None


class MarketRegime(str, Enum):
    """Tipuri de regimuri de piață."""
    TREND_UP = "trend_up"
    TREND_DOWN = "trend_down"
    HIGH_VOL = "high_vol"
    LOW_VOL = "low_vol"
    RANGE = "range"
    NA = "na"


class DecisionSide(str, Enum):
    """Laturile unei decizii."""
    BUY = "buy"
    SELL = "sell"
    NA = "na"


@dataclass
class EntryDecision:
    """Decizie pentru intrarea în piață."""
    allow: bool
    risk_mult: float = 1.0
    reason: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "allow": self.allow,
            "risk_mult": self.risk_mult,
            "reason": self.reason,
            "details": self.details
        }


@dataclass
class SmartFilterResult:
    """Rezultatul SmartFilter."""
    profit_factor: Optional[float] = None
    trades: Optional[int] = None
    status: str = "pending"
    cached: bool = False
    execution_time_ms: float = 0.0


@dataclass
class RegimePrediction:
    """Predicție de regim."""
    regime: MarketRegime = MarketRegime.NA
    strength: float = 0.0
    confidence: float = 0.0
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GateResult:
    """Rezultatul unui gate."""
    passed: bool = True
    reason: str = ""
    risk_multiplier: float = 1.0
    details: Dict[str, Any] = field(default_factory=dict)


class SmartFilterCache:
    """Cache LRU cu TTL pentru SmartFilter."""
    
    def __init__(self, max_size: int = 512, ttl_seconds: float = 900.0):
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self._cache: Dict[Tuple[str, str, str, str], Tuple[float, Tuple[Any, ...], float, int]] = {}
        self._lru: OrderedDict[Tuple[str, str, str, str], float] = OrderedDict()
        self._lock = threading.RLock()
        self.hits = 0
        self.misses = 0
        self.evictions = 0
        
    def get(self, key: Tuple[str, str, str, str], signature: Tuple[Any, ...]) -> Optional[Tuple[float, int]]:
        """Obține o intrare din cache dacă este validă."""
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                self.misses += 1
                return None
            
            ts_cached, sig_cached, pf_cached, trades_cached = entry
            
            # Verifică TTL
            if time.time() - ts_cached > self.ttl_seconds:
                self._remove(key)
                self.misses += 1
                return None
            
            # Verifică signature
            if sig_cached != signature:
                self._remove(key)
                self.misses += 1
                return None
            
            # Update LRU
            self._touch(key)
            self.hits += 1
            
            return pf_cached, trades_cached
    
    def put(self, key: Tuple[str, str, str, str], signature: Tuple[Any, ...], 
            profit_factor: float, trades: int) -> None:
        """Adaugă o intrare în cache."""
        with self._lock:
            # Șterge dacă există deja
            if key in self._cache:
                self._remove(key)
            
            # Adaugă noua intrare
            self._cache[key] = (time.time(), signature, profit_factor, trades)
            self._touch(key)
            
            # Menține dimensiunea maximă
            self._enforce_size_limit()
    
    def _touch(self, key: Tuple[str, str, str, str]) -> None:
        """Updatează poziția LRU."""
        self._lru.pop(key, None)
        self._lru[key] = time.time()
    
    def _remove(self, key: Tuple[str, str, str, str]) -> None:
        """Șterge o intrare din cache."""
        if key in self._cache:
            del self._cache[key]
        if key in self._lru:
            del self._lru[key]
    
    def _enforce_size_limit(self) -> None:
        """Menține dimensiunea cache-ului sub limită."""
        while len(self._cache) > self.max_size and self._lru:
            oldest_key, _ = self._lru.popitem(last=False)
            if oldest_key in self._cache:
                del self._cache[oldest_key]
                self.evictions += 1
    
    def prune(self) -> int:
        """Șterge intrările expirate."""
        removed = 0
        now = time.time()
        with self._lock:
            for key in list(self._cache.keys()):
                ts_cached = self._cache[key][0]
                if now - ts_cached > self.ttl_seconds:
                    self._remove(key)
                    removed += 1
        return removed
    
    def clear(self) -> None:
        """Golește cache-ul."""
        with self._lock:
            self._cache.clear()
            self._lru.clear()
            self.hits = 0
            self.misses = 0
            self.evictions = 0
    
    @property
    def size(self) -> int:
        """Dimensiunea curentă a cache-ului."""
        return len(self._cache)
    
    @property
    def hit_rate(self) -> float:
        """Rate-ul de hit-uri."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0
    
    def stats(self) -> Dict[str, Any]:
        """Statistici despre cache."""
        return {
            "size": self.size,
            "max_size": self.max_size,
            "hits": self.hits,
            "misses": self.misses,
            "evictions": self.evictions,
            "hit_rate": round(self.hit_rate, 3),
            "ttl_seconds": self.ttl_seconds,
        }


class GateManager:
    """Manager pentru gate-uri de intrare."""
    
    def __init__(self, config: Dict[str, Any], logger=None):
        self.config = config
        self.logger = logger
        self._veto_cooldowns: Dict[Tuple[str, str, str, str, str], float] = {}
        self._veto_counts: Dict[str, int] = defaultdict(int)
        self._lock = threading.RLock()
        
    def _log(self, level: str, msg: str) -> None:
        if self.logger is None:
            return
        try:
            fn = getattr(self.logger, level, None)
            if callable(fn):
                fn(msg)
            else:
                self.logger.info(msg)
        except Exception:
            pass
    
    def _get(self, path: str, default):
        cur = self.config
        for k in path.split("."):
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur
    
    @staticmethod
    def _clamp(x: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, x))
    
    @staticmethod
    def _safe_float(x, default: float = 0.0) -> float:
        try:
            if x is None:
                return default
            v = float(x)
            if math.isnan(v) or math.isinf(v):
                return default
            return v
        except Exception:
            return default
    
    def balance_scale(self, equity: float, free_equity: float) -> GateResult:
        """Scale risk based on available free equity."""
        equity = self._safe_float(equity)
        free_equity = self._safe_float(free_equity)
        
        if equity <= 0:
            return GateResult(
                passed=False,
                reason="Zero or negative equity",
                risk_multiplier=0.0,
                details={"equity": equity, "free_equity": free_equity}
            )
        
        free_pct = free_equity / max(1e-12, equity)
        min_free = self._safe_float(self._get("autonomy.min_free_equity_pct", 0.10))
        
        if free_pct < min_free:
            return GateResult(
                passed=False,
                reason=f"Insufficient free equity: {free_pct:.1%} < {min_free:.1%}",
                risk_multiplier=0.0,
                details={
                    "equity": equity,
                    "free_equity": free_equity,
                    "free_pct": free_pct,
                    "min_required_pct": min_free
                }
            )
        
        # Calculează risk multiplier bazat pe free equity
        scale_min = self._safe_float(self._get("autonomy.risk_scale_min", 0.50))
        scale_max = self._safe_float(self._get("autonomy.risk_scale_max", 1.50))
        
        t = (free_pct - min_free) / max(1e-12, (1.0 - min_free))
        t = self._clamp(t, 0.0, 1.0)
        t = math.sqrt(t)  # concave mapping
        risk_mult = scale_min + t * (scale_max - scale_min)
        
        return GateResult(
            passed=True,
            risk_multiplier=risk_mult,
            details={
                "equity": equity,
                "free_equity": free_equity,
                "free_pct": free_pct,
                "risk_multiplier": risk_mult
            }
        )
    
    def spread_check(self, ticker: Dict[str, Any], regime: str) -> GateResult:
        """Check spread gate."""
        if not ticker:
            return GateResult(
                passed=True,
                reason="No ticker data",
                details={"ticker_available": False}
            )
        
        # Calculează spread
        spread_bps = self._calculate_spread(ticker)
        if spread_bps is None:
            return GateResult(
                passed=True,
                reason="Could not calculate spread",
                details={"spread_bps": None}
            )
        
        max_bps = self._safe_float(self._get("autonomy.spread_max_bps", 25.0))
        if regime == "high_vol":
            max_bps *= self._safe_float(self._get("autonomy.spread_max_mult_high_vol", 1.15))
        
        if spread_bps > max_bps:
            return GateResult(
                passed=False,
                reason=f"Spread too high: {spread_bps:.1f} bps > {max_bps:.1f} bps",
                risk_multiplier=1.0,
                details={
                    "spread_bps": spread_bps,
                    "max_allowed_bps": max_bps,
                    "regime": regime
                }
            )
        
        # Calculează risk multiplier bazat pe spread
        spread_ratio = spread_bps / max(1e-12, max_bps)
        risk_mult = max(0.8, 1.0 - 0.5 * spread_ratio)
        
        return GateResult(
            passed=True,
            risk_multiplier=risk_mult,
            details={
                "spread_bps": spread_bps,
                "max_allowed_bps": max_bps,
                "spread_ratio": spread_ratio,
                "risk_multiplier": risk_mult
            }
        )
    
    def _calculate_spread(self, ticker: Dict[str, Any]) -> Optional[float]:
        """Calculează spread-ul în bps."""
        try:
            bid_keys = ["bid", "bidPrice", "bestBid", "b"]
            ask_keys = ["ask", "askPrice", "bestAsk", "a"]
            
            bid = None
            for key in bid_keys:
                if key in ticker:
                    bid = self._safe_float(ticker[key])
                    if bid is not None:
                        break
            
            ask = None
            for key in ask_keys:
                if key in ticker:
                    ask = self._safe_float(ticker[key])
                    if ask is not None:
                        break
            
            if bid is None or ask is None or bid <= 0 or ask <= 0 or ask <= bid:
                return None
            
            mid = (bid + ask) / 2.0
            return (ask - bid) / max(1e-12, mid) * 10000.0
            
        except Exception:
            return None
    
    def signal_check(self, signal_strength: float, regime: str) -> GateResult:
        """Check signal strength gate."""
        min_abs = self._safe_float(self._get("autonomy.signal_min_abs", 1.10))
        
        if regime == "high_vol":
            min_abs *= self._safe_float(self._get("autonomy.signal_min_abs_mult_high_vol", 1.05))
        
        if abs(signal_strength) < min_abs:
            return GateResult(
                passed=False,
                reason=f"Signal too weak: {signal_strength:.2f} < {min_abs:.2f}",
                risk_multiplier=1.0,
                details={
                    "signal_strength": signal_strength,
                    "min_required": min_abs,
                    "regime": regime
                }
            )
        
        # Signal-based risk multiplier
        k = self._safe_float(self._get("autonomy.signal_risk_k", 0.15))
        sig_excess = max(0.0, abs(signal_strength) - min_abs)
        sig_mult = 1.0 + k * sig_excess
        sig_mult = self._clamp(sig_mult, 1.0, self._safe_float(self._get("autonomy.signal_risk_max", 1.25)))
        
        return GateResult(
            passed=True,
            risk_multiplier=sig_mult,
            details={
                "signal_strength": signal_strength,
                "min_required": min_abs,
                "excess": sig_excess,
                "multiplier": sig_mult
            }
        )
    
    def is_in_veto_cooldown(self, sym: str, side: str, tf: str, regime: str, kind: str) -> bool:
        """Check if in veto cooldown."""
        key = (sym, side, tf, regime, kind)
        with self._lock:
            until = self._veto_cooldowns.get(key, 0.0)
            return time.time() < until
    
    def set_veto_cooldown(self, sym: str, side: str, tf: str, regime: str, kind: str) -> None:
        """Set veto cooldown."""
        cd_sec = self._safe_float(self._get("autonomy.veto_cooldown_sec", 30.0))
        if cd_sec <= 0:
            return
        
        key = (sym, side, tf, regime, kind)
        with self._lock:
            self._veto_cooldowns[key] = time.time() + cd_sec
            self._veto_counts[kind] = self._veto_counts.get(kind, 0) + 1
    
    def clear_veto_cooldowns(self, symbol: Optional[str] = None) -> int:
        """Clear veto cooldowns."""
        cleared = 0
        with self._lock:
            if symbol:
                sym_upper = symbol.upper()
                keys_to_remove = [
                    k for k in self._veto_cooldowns.keys() 
                    if k[0].upper() == sym_upper
                ]
                for k in keys_to_remove:
                    self._veto_cooldowns.pop(k, None)
                    cleared += 1
            else:
                cleared = len(self._veto_cooldowns)
                self._veto_cooldowns.clear()
        return cleared
    
    def prune_veto_cooldowns(self) -> int:
        """Remove expired veto cooldowns."""
        removed = 0
        now = time.time()
        with self._lock:
            for key in list(self._veto_cooldowns.keys()):
                if self._veto_cooldowns[key] <= now:
                    self._veto_cooldowns.pop(key, None)
                    removed += 1
        return removed
    
    def get_stats(self) -> Dict[str, Any]:
        """Get gate manager statistics."""
        with self._lock:
            return {
                "veto_cooldowns": len(self._veto_cooldowns),
                "veto_counts": dict(self._veto_counts)
            }


class OnlineLearner:
    """Sistem de învățare online."""
    
    def __init__(self, config: Dict[str, Any], logger=None):
        self.config = config
        self.logger = logger
        
        # Learning state
        self._learned = defaultdict(
            lambda: {
                "n": 0,
                "wins": 0,
                "losses": 0,
                "ema_win_rate": 0.5,
                "ema_expectancy": 0.0,
                "ema_pf": 1.0,
                "last_ts": 0.0,
                "learned_ts_max": 0.0,
                "recent_pnls": deque(maxlen=200),
                "last_updated": 0.0,
            }
        )
        self._lock = threading.RLock()
    
    def _log(self, level: str, msg: str) -> None:
        if self.logger is None:
            return
        try:
            fn = getattr(self.logger, level, None)
            if callable(fn):
                fn(msg)
            else:
                self.logger.info(msg)
        except Exception:
            pass
    
    def _get(self, path: str, default):
        cur = self.config
        for k in path.split("."):
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur
    
    @staticmethod
    def _safe_float(x, default: float = 0.0) -> float:
        try:
            if x is None:
                return default
            v = float(x)
            if math.isnan(v) or math.isinf(v):
                return default
            return v
        except Exception:
            return default
    
    @staticmethod
    def _safe_int(x, default: int = 0) -> int:
        try:
            if x is None:
                return default
            return int(x)
        except Exception:
            return default
    
    @staticmethod
    def _clamp(x: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, x))
    
    def learn_from_trades(self, trades_data, batch_size: int = 100) -> Dict[str, Any]:
        """Learn from executed trades."""
        try:
            if trades_data is None:
                return {"ok": True, "learned": 0}
            
            if isinstance(trades_data, dict):
                trades = trades_data.get("trades") or trades_data.get("items") or trades_data.get("data")
                trades = trades if isinstance(trades, list) else []
            elif isinstance(trades_data, list):
                trades = trades_data
            else:
                trades = []
            
            alpha = self._safe_float(self._get("autonomy.learn_ema_alpha", 0.12))
            learned = 0
            skipped = 0
            now = time.time()
            
            with self._lock:
                for i, t in enumerate(trades):
                    if i >= batch_size and batch_size > 0:
                        break
                        
                    if not isinstance(t, dict):
                        continue
                    
                    sym = (t.get("symbol") or t.get("sym") or "").upper().strip()
                    if not sym:
                        continue
                    
                    side = (t.get("side") or "").lower().strip() or "na"
                    tf = str(t.get("tf") or t.get("timeframe") or "na")
                    regime = str(t.get("regime") or "na")
                    
                    # Timestamp for idempotence
                    ts = self._safe_float(t.get("ts") or t.get("timestamp") or now, now)
                    
                    key = (sym, side, tf, regime)
                    st = self._learned[key]
                    
                    # Skip if already learned
                    learned_max = self._safe_float(st.get("learned_ts_max", 0.0), 0.0)
                    if ts <= learned_max:
                        skipped += 1
                        continue
                    
                    # Extract P&L
                    pnl = None
                    for k in ("pnl", "realized_pnl", "profit", "profit_usd", "pnl_usd"):
                        if k in t and t.get(k) is not None:
                            pnl = t.get(k)
                            break
                    pnl_f = self._safe_float(pnl, 0.0)
                    
                    ret = t.get("return")
                    ret_f = self._safe_float(ret, 0.0)
                    
                    # Update statistics
                    st["n"] += 1
                    if pnl_f > 0:
                        st["wins"] += 1
                    elif pnl_f < 0:
                        st["losses"] += 1
                    
                    # Update EMAs
                    win = 1.0 if pnl_f > 0 else 0.0
                    st["ema_win_rate"] = (1 - alpha) * self._safe_float(st["ema_win_rate"], 0.5) + alpha * win
                    
                    x = ret_f if abs(ret_f) > 0 else pnl_f
                    st["ema_expectancy"] = (1 - alpha) * self._safe_float(st["ema_expectancy"], 0.0) + alpha * x
                    
                    # Update recent P&Ls and profit factor
                    st["recent_pnls"].append(pnl_f)
                    
                    gp = sum(p for p in st["recent_pnls"] if p > 0)
                    gl = -sum(p for p in st["recent_pnls"] if p < 0)
                    pf = (gp / max(1e-12, gl)) if gl > 0 else (gp if gp > 0 else 1.0)
                    st["ema_pf"] = (1 - alpha) * self._safe_float(st["ema_pf"], 1.0) + alpha * float(pf)
                    
                    # Update timestamps
                    st["last_ts"] = max(self._safe_float(st["last_ts"], 0.0), ts)
                    st["last_updated"] = now
                    st["learned_ts_max"] = max(self._safe_float(st.get("learned_ts_max", 0.0), 0.0), ts)
                    
                    learned += 1
            
            if learned and bool(self._get("autonomy.learn_log", True)):
                self._log("info", f"[autonomy] learned {learned} trades (skipped={skipped}, keys={len(self._learned)})")
            
            return {"ok": True, "learned": learned, "skipped": skipped, "keys": len(self._learned)}
            
        except Exception as e:
            self._log("warning", f"[autonomy] learn_from_trades failed: {e}")
            return {"ok": False, "learned": 0, "error": str(e)}
    
    def get_risk_multiplier(self, sym: str, side: str, tf: str, regime: str) -> Tuple[float, Dict[str, Any]]:
        """Compute learned risk multiplier."""
        key = (sym, side, str(tf), str(regime))
        with self._lock:
            st = self._learned.get(key)
        
        if not st:
            return 1.0, {"learned": "none"}
        
        n = self._safe_int(st.get("n", 0), 0)
        min_n = self._safe_int(self._get("autonomy.learn_min_samples", 30), 30)
        
        if n < max(1, min_n):
            return 1.0, {"n": n, "min_samples": min_n, "learned": "insufficient_samples"}
        
        ema_pf = self._safe_float(st.get("ema_pf", 1.0), 1.0)
        ema_wr = self._safe_float(st.get("ema_win_rate", 0.5), 0.5)
        ema_exp = self._safe_float(st.get("ema_expectancy", 0.0), 0.0)
        
        # Confidence based on sample size
        conf = self._clamp(n / max(1.0, float(min_n) * 3.0), 0.0, 1.0)
        
        # Normalized scores
        pf_score = self._clamp((ema_pf - 1.0) / 0.50, -1.0, 1.0)
        wr_score = self._clamp((ema_wr - 0.5) / 0.10, -1.0, 1.0)
        exp_score = self._clamp(ema_exp / 0.01, -1.0, 1.0)
        
        # Composite score
        score = 0.55 * pf_score + 0.35 * wr_score + 0.10 * exp_score
        score *= conf
        
        # Map score to risk multiplier
        lo = self._safe_float(self._get("autonomy.learn_risk_min", 0.50), 0.50)
        hi = self._safe_float(self._get("autonomy.learn_risk_max", 1.30), 1.30)
        
        if score >= 0:
            mult = 1.0 + score * (hi - 1.0)
        else:
            mult = 1.0 + score * (1.0 - lo)
        
        mult = self._clamp(mult, lo, hi)
        
        return mult, {
            "n": n,
            "ema_pf": ema_pf,
            "ema_win_rate": ema_wr,
            "ema_expectancy": ema_exp,
            "confidence": conf,
            "score": score,
            "mult": mult,
        }
    
    def export_state(self) -> Dict[str, Any]:
        """Export learned state."""
        out = {}
        with self._lock:
            for k, st in self._learned.items():
                rp = list(st.get("recent_pnls") or [])
                out["|".join(map(str, k))] = {
                    "n": self._safe_int(st.get("n", 0), 0),
                    "wins": self._safe_int(st.get("wins", 0), 0),
                    "losses": self._safe_int(st.get("losses", 0), 0),
                    "ema_win_rate": self._safe_float(st.get("ema_win_rate", 0.5), 0.5),
                    "ema_expectancy": self._safe_float(st.get("ema_expectancy", 0.0), 0.0),
                    "ema_pf": self._safe_float(st.get("ema_pf", 1.0), 1.0),
                    "last_ts": self._safe_float(st.get("last_ts", 0.0), 0.0),
                    "learned_ts_max": self._safe_float(st.get("learned_ts_max", 0.0), 0.0),
                    "last_updated": self._safe_float(st.get("last_updated", 0.0), 0.0),
                    "recent_pnls": rp,
                }
        return out
    
    def import_state(self, state: Dict[str, Any]) -> bool:
        """Import learned state."""
        try:
            with self._lock:
                for ks, st in state.items():
                    if not isinstance(ks, str) or not isinstance(st, dict):
                        continue
                    
                    parts = ks.split("|")
                    if len(parts) != 4:
                        continue
                    
                    key = (parts[0], parts[1], parts[2], parts[3])
                    cur = self._learned[key]
                    
                    cur["n"] = self._safe_int(st.get("n", 0), 0)
                    cur["wins"] = self._safe_int(st.get("wins", 0), 0)
                    cur["losses"] = self._safe_int(st.get("losses", 0), 0)
                    cur["ema_win_rate"] = self._safe_float(st.get("ema_win_rate", 0.5), 0.5)
                    cur["ema_expectancy"] = self._safe_float(st.get("ema_expectancy", 0.0), 0.0)
                    cur["ema_pf"] = self._safe_float(st.get("ema_pf", 1.0), 1.0)
                    cur["last_ts"] = self._safe_float(st.get("last_ts", 0.0), 0.0)
                    cur["learned_ts_max"] = self._safe_float(st.get("learned_ts_max", cur.get("learned_ts_max", 0.0)), 0.0)
                    cur["last_updated"] = self._safe_float(st.get("last_updated", cur.get("last_updated", 0.0)), 0.0)
                    
                    rp = st.get("recent_pnls", [])
                    if isinstance(rp, list):
                        cur["recent_pnls"].clear()
                        for x in rp[-200:]:
                            cur["recent_pnls"].append(self._safe_float(x, 0.0))
            
            return True
            
        except Exception as e:
            self._log("warning", f"[autonomy] import_state failed: {e}")
            return False
    
    def clear(self) -> None:
        """Clear learned data."""
        with self._lock:
            self._learned.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get learner statistics."""
        with self._lock:
            return {
                "keys": len(self._learned),
                "total_samples": sum(self._safe_int(st.get("n", 0), 0) for st in self._learned.values())
            }


class AutonomyController:
    """
    Autonomy controller for:
      - gating entries (signal strength, liquidity/free equity, spread, smartfilter micro-backtest)
      - lightweight online learning from executed trades
      - regime detection (trend/range/vol buckets)
      - conservative dynamic parameter tuning (risk-on / risk-off)
      - observability (decision details)
      - thread safety and rate limiting for micro-backtests
      - export/import state for persistence
      - improved thread safety and performance
    """

    def __init__(self, cfg: Dict[str, Any], log=None):
        self.cfg = cfg or {}
        self.log = log or self._create_default_logger()

        self._lock = threading.RLock()

        # Initialize components
        self.cache = SmartFilterCache(
            max_size=self._get_int("autonomy.smartfilter_cache_max", 512),
            ttl_seconds=self._get_float("autonomy.smartfilter_ttl_sec", 900.0)
        )
        
        self.gate_manager = GateManager(self.cfg, self.log)
        self.learner = OnlineLearner(self.cfg, self.log)

        # Rate limiting micro-backtests globally
        self._sim_timestamps = deque(maxlen=512)

        # Statistics for monitoring
        self._decision_count: int = 0
        self._start_time: float = time.time()

        # One-time validation
        self._validated_cfg = False
        self._validate_cfg_once()

    def _create_default_logger(self):
        """Create default logger if none provided."""
        logger = logging.getLogger("autonomy")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(name)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger

    def _log(self, level: str, msg: str) -> None:
        if self.log is None:
            return
        try:
            fn = getattr(self.log, level, None)
            if callable(fn):
                fn(msg)
            else:
                self.log.info(msg)
        except Exception:
            pass

    def _debug_enabled(self) -> bool:
        return bool(self._get("autonomy.debug", False))

    # -----------------------------
    # Config helpers (thread-safe)
    # -----------------------------
    def _get(self, path: str, default):
        with self._lock:
            cur = self.cfg
            for k in path.split("."):
                if not isinstance(cur, dict) or k not in cur:
                    return default
                cur = cur[k]
            return cur

    def _get_float(self, path: str, default: float) -> float:
        value = self._get(path, default)
        try:
            return float(value)
        except (ValueError, TypeError):
            return default

    def _get_int(self, path: str, default: int) -> int:
        value = self._get(path, default)
        try:
            return int(value)
        except (ValueError, TypeError):
            return default

    def _get_bool(self, path: str, default: bool) -> bool:
        value = self._get(path, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ("true", "yes", "1", "on")
        return bool(value)

    def _set(self, path: str, value: Any) -> None:
        """Set nested config path (dot-separated), creating dicts as needed."""
        with self._lock:
            parts = path.split(".")
            cur = self.cfg
            for k in parts[:-1]:
                nxt = cur.get(k)
                if not isinstance(nxt, dict):
                    nxt = {}
                    cur[k] = nxt
                cur = nxt
            cur[parts[-1]] = value

    def get_config(self) -> Dict[str, Any]:
        """Get a copy of the current configuration (thread-safe)."""
        with self._lock:
            import copy
            return copy.deepcopy(self.cfg)

    def update_config(self, updates: Dict[str, Any]) -> None:
        """Update configuration with new values (thread-safe)."""
        with self._lock:
            self._update_dict(self.cfg, updates)
            # Re-validate after update
            self._validated_cfg = False
            self._validate_cfg_once()

    def _update_dict(self, target: Dict, source: Dict) -> None:
        """Recursively update dictionary."""
        for key, value in source.items():
            if isinstance(value, dict) and key in target and isinstance(target[key], dict):
                self._update_dict(target[key], value)
            else:
                target[key] = value

    @staticmethod
    def _clamp(x: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, x))

    @staticmethod
    def _safe_float(x, default: float = 0.0) -> float:
        try:
            if x is None:
                return default
            v = float(x)
            if math.isnan(v) or math.isinf(v):
                return default
            return v
        except Exception:
            return default

    @staticmethod
    def _safe_int(x, default: int = 0) -> int:
        try:
            if x is None:
                return default
            return int(x)
        except Exception:
            return default

    def _validate_cfg_once(self) -> None:
        with self._lock:
            if self._validated_cfg:
                return
            self._validated_cfg = True

        # Conservative clamps / defaults
        def f(path: str, default: float, lo: float, hi: float):
            v = self._safe_float(self._get(path, default), default)
            v2 = self._clamp(v, lo, hi)
            if abs(v2 - v) > 1e-12 and self._debug_enabled():
                self._log("warning", f"[autonomy] cfg clamp {path}: {v} -> {v2}")
            self._set(path, v2)

        def i(path: str, default: int, lo: int, hi: int):
            v = self._safe_int(self._get(path, default), default)
            v2 = int(self._clamp(float(v), float(lo), float(hi)))
            if v2 != v and self._debug_enabled():
                self._log("warning", f"[autonomy] cfg clamp {path}: {v} -> {v2}")
            self._set(path, v2)

        # Enable switches
        self._set("autonomy.enabled", bool(self._get("autonomy.enabled", True)))
        self._set("autonomy.smartfilter_enabled", bool(self._get("autonomy.smartfilter_enabled", True)))
        self._set("autonomy.tuning.enabled", bool(self._get("autonomy.tuning.enabled", True)))

        # Entry gates
        f("autonomy.signal_min_abs", 1.10, 0.10, 10.0)
        f("autonomy.signal_min_abs_mult_high_vol", 1.05, 0.50, 3.00)
        f("autonomy.min_free_equity_pct", 0.10, 0.0, 0.95)
        f("autonomy.spread_max_bps", 25.0, 1.0, 500.0)
        f("autonomy.spread_max_mult_high_vol", 1.15, 0.50, 3.00)
        f("autonomy.risk_scale_min", 0.50, 0.0, 5.0)
        f("autonomy.risk_scale_max", 1.50, 0.0, 10.0)

        # Smartfilter
        i("autonomy.smartfilter_min_trades", 10, 0, 10_000)
        f("autonomy.smartfilter_pf_skip", 0.90, 0.1, 5.0)
        f("autonomy.smartfilter_ttl_sec", 900.0, 5.0, 86_400.0)
        i("autonomy.smartfilter_cache_max", 512, 16, 50_000)
        i("autonomy.smartfilter_window_bars", 400, 80, 10_000)

        # Smartfilter rate limit
        i("autonomy.smartfilter_rate.max_per_min", 4, 0, 120)
        f("autonomy.smartfilter_rate.window_sec", 60.0, 5.0, 300.0)
        f("autonomy.smartfilter_rate_cooldown_sec", 10.0, 0.0, 600.0)

        # Veto cooldown
        f("autonomy.veto_cooldown_sec", 30.0, 0.0, 3_600.0)

        # Online learning
        f("autonomy.learn_ema_alpha", 0.12, 0.01, 0.50)
        i("autonomy.learn_min_samples", 30, 0, 10_000)
        f("autonomy.learn_risk_min", 0.50, 0.0, 5.0)
        f("autonomy.learn_risk_max", 1.30, 0.0, 10.0)
        self._set("autonomy.learn_log", bool(self._get("autonomy.learn_log", True)))

        # Regime thresholds
        f("autonomy.regime.vol_high", 0.015, 0.0001, 1.0)
        f("autonomy.regime.vol_low", 0.004, 0.00005, 1.0)
        f("autonomy.regime.trend_thr", 0.0020, 0.00001, 1.0)
        f("autonomy.regime.r2_thr", 0.35, 0.0, 1.0)

        # Regime multipliers
        f("autonomy.regime_mult.high_vol", 0.75, 0.0, 5.0)
        f("autonomy.regime_mult.low_vol", 1.05, 0.0, 5.0)
        f("autonomy.regime_mult.trend", 1.10, 0.0, 5.0)
        f("autonomy.regime_mult.range", 1.00, 0.0, 5.0)

        # Signal-based multiplier
        f("autonomy.signal_risk_k", 0.15, 0.0, 2.0)
        f("autonomy.signal_risk_max", 1.25, 0.0, 10.0)

        # Final risk multiplier clamps
        f("autonomy.final_risk_min", 0.10, 0.0, 5.0)
        f("autonomy.final_risk_max", 2.50, 0.0, 50.0)

        # Tuning defaults
        f("autonomy.tuning.cooldown_sec", 1800.0, 10.0, 86_400.0)
        f("autonomy.tuning.dd_high", 0.18, 0.01, 0.95)
        f("autonomy.tuning.dd_low", 0.08, 0.00, 0.90)
        f("autonomy.tuning.pf_good", 1.25, 0.50, 10.0)
        f("autonomy.tuning.win_rate_good", 0.55, 0.01, 0.99)
        i("autonomy.tuning.loss_streak_bad", 4, 1, 50)
        i("autonomy.tuning.leverage_deadband", 1, 0, 10)
        self._set("autonomy.use_regime_predictor", bool(self._get("autonomy.use_regime_predictor", True)))
        self._set("autonomy.regime_prefer_pred", bool(self._get("autonomy.regime_prefer_pred", True)))

        if self._debug_enabled():
            self._log("info", "[autonomy] cfg validated/clamped")

    # -----------------------------
    # Core gating utilities
    # -----------------------------
    def _df_signature(self, df) -> Tuple[Any, ...]:
        """Cheap-but-better signature: length + last index + last ts + last OHLCV-ish."""
        try:
            if df is None or len(df) == 0:
                return ("empty", 0)

            n = len(df)
            last_idx = None
            try:
                last_idx = df.index[-1]
            except Exception:
                pass

            last_ts = None
            if hasattr(df, "columns") and "ts" in getattr(df, "columns", []):
                try:
                    last_ts = df["ts"].iloc[-1]
                except Exception:
                    last_ts = None

            def last_col(name: str):
                try:
                    if hasattr(df, "columns") and name in df.columns:
                        return float(df[name].iloc[-1])
                except Exception:
                    return None
                return None

            lc = last_col("close")
            lh = last_col("high")
            ll = last_col("low")
            lv = last_col("volume")

            return (n, str(last_idx), str(last_ts), lc, lh, ll, lv)
        except Exception:
            return ("na", time.time())

    def _smartfilter_rate_allow(self) -> bool:
        """Global token bucket (timestamp list) rate limiter for micro-backtests."""
        max_per_min = self._get_int("autonomy.smartfilter_rate.max_per_min", 4)
        if max_per_min <= 0:
            return False
        window = self._get_float("autonomy.smartfilter_rate.window_sec", 60.0)
        now = time.time()
        with self._lock:
            while self._sim_timestamps and (now - self._sim_timestamps[0]) > window:
                self._sim_timestamps.popleft()
            if len(self._sim_timestamps) >= max_per_min:
                return False
            self._sim_timestamps.append(now)
            return True

    def smartfilter_pf(
        self,
        sym: str,
        side: str,
        df,
        df_trend,
        tf: str,
        regime: str,
    ) -> Tuple[Optional[float], Optional[int], str]:
        """
        Cached micro-backtest (SmartFilter) returning profit factor and trade count.
        Returns: (pf, trades, status) where status in {"ok","cached","rate_limited","error","disabled","cooldown"}.
        """
        if not self._get_bool("autonomy.smartfilter_enabled", True):
            return None, None, "disabled"

        if self.gate_manager.is_in_veto_cooldown(sym, side, tf, regime, "smartfilter"):
            return None, None, "cooldown"

        ttl = self._get_float("autonomy.smartfilter_ttl_sec", 900.0)
        key = (sym, side, tf, regime)
        now = time.time()
        sig = self._df_signature(df)

        # Try cache first
        cached = self.cache.get(key, sig)
        if cached is not None:
            pf_cached, trades_cached = cached
            return pf_cached, trades_cached, "cached"

        # rate limit micro-backtests to avoid dominating CPU
        if not self._smartfilter_rate_allow():
            # Optional: short cooldown so we don't retry in tight loops
            cd_rl = self._get_float("autonomy.smartfilter_rate_cooldown_sec", 10.0)
            if cd_rl > 0:
                self.gate_manager.set_veto_cooldown(sym, side, tf, regime, "smartfilter_rate")
            return None, None, "rate_limited"

        try:
            # Try to import backtest module
            from .backtest import simulate

            bars = self._get_int("autonomy.smartfilter_window_bars", 400)

            # cap window (safe copy)
            if df is not None and len(df) > bars:
                sim_df = df.iloc[-bars:].copy()
            else:
                sim_df = df.copy() if df is not None else None

            if df_trend is not None and len(df_trend) > bars:
                sim_trend = df_trend.iloc[-bars:].copy()
            else:
                sim_trend = df_trend.copy() if df_trend is not None else None

            # Run simulate with current cfg (paper-mode inside backtest)
            res = simulate(self.cfg, sim_df, sim_trend)

            pf = self._safe_float(getattr(res, "profit_factor", 1.0), 1.0)
            trades = self._safe_int(getattr(res, "trades", 0), 0)

            # Cache the result
            self.cache.put(key, sig, pf, trades)

            return pf, trades, "ok"
        except ImportError:
            if self._debug_enabled():
                self._log("warning", "[autonomy] backtest module not available")
            return None, None, "backtest_not_available"
        except Exception as e:
            if self._debug_enabled():
                self._log("warning", f"[autonomy] smartfilter simulate failed: {e}")
            return None, None, "error"

    # -----------------------------
    # Regime detection (with numpy/pandas fallback)
    # -----------------------------
    def predict_market_regime(self, df, df_trend=None) -> RegimePrediction:
        """
        Predict a market regime from recent OHLCV.
        """
        prediction = RegimePrediction()
        
        try:
            if df is None or len(df) < 80:
                prediction.details = {"reason": "insufficient_bars"}
                return prediction

            # Check for numpy/pandas availability
            if not NUMPY_AVAILABLE or not PANDAS_AVAILABLE:
                prediction.details = {"reason": "numpy/pandas_not_available"}
                return prediction

            try:
                close = df["close"]
            except Exception:
                prediction.details = {"reason": "missing_close"}
                return prediction

            try:
                close = pd.to_numeric(close, errors="coerce")
                high = pd.to_numeric(df["high"], errors="coerce") if "high" in df.columns else close
                low = pd.to_numeric(df["low"], errors="coerce") if "low" in df.columns else close
            except Exception:
                close = close.astype(float)
                high = df.get("high", close).astype(float)
                low = df.get("low", close).astype(float)

            if close.isna().iloc[-1]:
                prediction.details = {"reason": "nan_close_last"}
                return prediction

            last = float(close.iloc[-1])
            if not (last > 0):
                prediction.details = {"reason": "invalid_last"}
                return prediction

            from .indicators import ema, atr

            _hlc = df.copy()
            if "high" not in _hlc.columns:
                _hlc["high"] = high
            if "low" not in _hlc.columns:
                _hlc["low"] = low
            if "close" not in _hlc.columns:
                _hlc["close"] = close
            _hlc = _hlc[["high", "low", "close"]].astype(float)

            a14 = atr(_hlc, 14)
            atr_last = float(a14.iloc[-1]) if a14 is not None and len(a14) else 0.0
            atr_pct = atr_last / max(1e-12, last)

            rets = close.pct_change().dropna()
            rv = float(rets.iloc[-40:].std() or 0.0) if len(rets) >= 40 else float(rets.std() or 0.0)

            e20 = ema(close.astype(float), 20)
            e50 = ema(close.astype(float), 50)
            spread = abs(float(e20.iloc[-1]) - float(e50.iloc[-1])) / max(1e-12, last)

            w = 60
            y = close.iloc[-w:].to_numpy(dtype=float)
            x = np.arange(w, dtype=float)
            slope, intercept = np.polyfit(x, y, 1)
            yhat = slope * x + intercept
            ss_res = float(np.sum((y - yhat) ** 2))
            ss_tot = float(np.sum((y - float(np.mean(y))) ** 2))
            r2 = 1.0 - ss_res / max(1e-12, ss_tot)
            slope_norm = float(slope) / max(1e-12, last)

            vol_hi = self._get_float("autonomy.regime.vol_high", 0.015)
            vol_lo = self._get_float("autonomy.regime.vol_low", 0.004)
            trend_thr = self._get_float("autonomy.regime.trend_thr", 0.0020)
            r2_thr = self._get_float("autonomy.regime.r2_thr", 0.35)

            if atr_pct >= vol_hi or rv >= (vol_hi * 0.8):
                regime = "high_vol"
                strength = self._clamp(max(atr_pct / max(1e-12, vol_hi), rv / max(1e-12, vol_hi)), 0.0, 2.0) / 2.0
            elif atr_pct <= vol_lo and rv <= (vol_lo * 1.2):
                regime = "low_vol"
                strength = self._clamp(1.0 - (atr_pct / max(1e-12, vol_lo)), 0.0, 1.0)
            else:
                trend_score = abs(slope_norm) * (0.5 + 0.5 * self._clamp(r2, 0.0, 1.0)) + spread
                if trend_score >= trend_thr and r2 >= r2_thr:
                    regime = "trend_up" if slope_norm > 0 else "trend_down"
                    strength = self._clamp(trend_score / max(1e-12, trend_thr), 0.0, 2.0) / 2.0
                else:
                    regime = "range"
                    strength = self._clamp(1.0 - (trend_score / max(1e-12, trend_thr)), 0.0, 1.0)

            prediction.regime = MarketRegime(regime)
            prediction.strength = float(self._clamp(strength, 0.0, 1.0))
            prediction.details = {
                "last": last,
                "atr_pct": float(atr_pct),
                "realized_vol": float(rv),
                "ema_spread": float(spread),
                "slope_norm": float(slope_norm),
                "r2": float(self._clamp(r2, -1.0, 1.0)),
            }
            
            return prediction
            
        except Exception as e:
            if self._debug_enabled():
                self._log("warning", f"[autonomy] predict_market_regime failed: {e}")
            prediction.details = {"error": str(e)}
            return prediction

    def _regime_risk_mult(self, regime: MarketRegime, strength: float) -> Tuple[float, Dict[str, Any]]:
        """Convert regime into a risk multiplier. Strength is used as a mild interpolator."""
        strength = self._clamp(strength, 0.0, 1.0)
        rm = 1.0
        
        if regime == MarketRegime.HIGH_VOL:
            base = self._get_float("autonomy.regime_mult.high_vol", 0.75)
            rm = 1.0 + (base - 1.0) * strength
        elif regime == MarketRegime.LOW_VOL:
            base = self._get_float("autonomy.regime_mult.low_vol", 1.05)
            rm = 1.0 + (base - 1.0) * strength
        elif regime in (MarketRegime.TREND_UP, MarketRegime.TREND_DOWN):
            base = self._get_float("autonomy.regime_mult.trend", 1.10)
            rm = 1.0 + (base - 1.0) * strength
        elif regime == MarketRegime.RANGE:
            base = self._get_float("autonomy.regime_mult.range", 1.00)
            rm = 1.0 + (base - 1.0) * strength
        else:
            rm = 1.0

        return float(rm), {"regime": regime.value, "strength": strength, "mult": float(rm)}

    # -----------------------------
    # Entry evaluation (main method)
    # -----------------------------
    def evaluate_entry(
        self,
        *,
        sym: str,
        side: str,
        signal_strength: float,
        equity: float,
        free_equity: float,
        ticker: Optional[Dict[str, Any]],
        df,
        df_trend,
        tf: str,
        regime: str,
    ) -> EntryDecision:
        """
        Returns a decision plus an aggregated risk multiplier.
        """
        # Increment decision counter
        self._decision_count += 1
        
        if not self._get_bool("autonomy.enabled", True):
            return EntryDecision(True, 1.0, "autonomy disabled", {"enabled": False})

        sym_u = (sym or "").upper().strip()
        side_l = (side or "").lower().strip() or "na"
        tf_s = str(tf)
        regime_s = str(regime)

        details: Dict[str, Any] = {
            "sym": sym_u,
            "side": side_l,
            "tf": tf_s,
            "regime_input": regime_s,
            "signal_strength": float(signal_strength),
            "equity": float(equity),
            "free_equity": float(free_equity),
            "timestamp": time.time(),
            "decision_id": f"{sym_u}_{side_l}_{int(time.time())}",
        }

        # Optional maintenance (auto-prune every 100 decisions)
        if self._get_bool("autonomy.auto_prune", True) and self._decision_count % 100 == 0:
            self.prune(force=False)

        # 0) Regime prediction hook
        if self._get_bool("autonomy.use_regime_predictor", True):
            pr = self.predict_market_regime(df, df_trend)
            pred_reg = pr.regime.value
            pred_strength = pr.strength
            details["regime_pred"] = {
                "regime": pred_reg,
                "strength": pred_strength,
                "details": pr.details
            }
        else:
            pred_reg, pred_strength = "na", 0.0

        # Pick regime used for multiplier (prefer predicted if meaningful)
        use_pred = self._get_bool("autonomy.regime_prefer_pred", True)
        eff_regime = pred_reg if (use_pred and pred_reg != "na") else regime_s
        eff_strength = pred_strength if (use_pred and pred_reg != "na") else 0.0
        details["regime_effective"] = {"regime": eff_regime, "strength": eff_strength}

        # 1) Signal gate
        signal_result = self.gate_manager.signal_check(signal_strength, eff_regime)
        details["signal_gate"] = {
            "passed": signal_result.passed,
            "reason": signal_result.reason,
            "details": signal_result.details
        }
        
        if not signal_result.passed:
            self.gate_manager.set_veto_cooldown(sym_u, side_l, tf_s, eff_regime, "signal")
            return EntryDecision(False, 1.0, signal_result.reason, details)

        # 2) Balance scale gate
        balance_result = self.gate_manager.balance_scale(equity, free_equity)
        details["balance_gate"] = {
            "passed": balance_result.passed,
            "reason": balance_result.reason,
            "details": balance_result.details
        }
        
        if not balance_result.passed:
            self.gate_manager.set_veto_cooldown(sym_u, side_l, tf_s, eff_regime, "liquidity")
            return EntryDecision(False, 1.0, balance_result.reason, details)

        # 3) Spread gate
        spread_result = self.gate_manager.spread_check(ticker, eff_regime)
        details["spread_gate"] = {
            "passed": spread_result.passed,
            "reason": spread_result.reason,
            "details": spread_result.details
        }
        
        if not spread_result.passed:
            self.gate_manager.set_veto_cooldown(sym_u, side_l, tf_s, eff_regime, "spread")
            return EntryDecision(False, 1.0, spread_result.reason, details)

        # 4) SmartFilter gate
        pf, trades, sf_status = self.smartfilter_pf(sym_u, side_l, df, df_trend, tf_s, eff_regime)
        details["smartfilter"] = {"pf": pf, "trades": trades, "status": sf_status}

        if pf is not None and trades is not None:
            pf_skip = self._get_float("autonomy.smartfilter_pf_skip", 0.90)
            min_trades = self._get_int("autonomy.smartfilter_min_trades", 10)
            details["smartfilter"]["pf_skip"] = float(pf_skip)
            details["smartfilter"]["min_trades"] = int(min_trades)

            if int(trades) >= min_trades and float(pf) < pf_skip:
                self.gate_manager.set_veto_cooldown(sym_u, side_l, tf_s, eff_regime, "smartfilter")
                return EntryDecision(False, 1.0, f"veto:smartfilter (PF={pf:.2f}, trades={trades})", details)

        # 5) Learned statistics risk modifier
        learned_mult, learned_details = self.learner.get_risk_multiplier(sym_u, side_l, tf_s, eff_regime)
        details["learned"] = learned_details

        # 6) Regime risk modifier
        regime_mult, regime_details = self._regime_risk_mult(MarketRegime(eff_regime), eff_strength)
        details["regime_mult"] = regime_details

        # Calculate final risk multiplier
        gate_risk_mult = (
            balance_result.risk_multiplier * 
            spread_result.risk_multiplier * 
            signal_result.risk_multiplier
        )
        
        final = gate_risk_mult * learned_mult * regime_mult
        final = self._clamp(
            final,
            self._get_float("autonomy.final_risk_min", 0.10),
            self._get_float("autonomy.final_risk_max", 2.50),
        )
        
        details["risk_mult_final"] = float(final)
        details["risk_mult_components"] = {
            "gate": float(gate_risk_mult),
            "learned": float(learned_mult),
            "regime": float(regime_mult),
        }

        # Log successful decision if debug enabled
        if self._debug_enabled():
            self._log("debug", f"[autonomy] Entry allowed for {sym_u} {side_l}: risk_mult={final:.3f}")

        return EntryDecision(True, final, "ok", details)

    # -----------------------------
    # Online learning from trades
    # -----------------------------
    def learn_from_trades(self, trades_data, batch_size: int = 100) -> Dict[str, Any]:
        """Online learning from executed trades."""
        return self.learner.learn_from_trades(trades_data, batch_size)

    # -----------------------------
    # Persistence (export/import)
    # -----------------------------
    def export_state(self, include_cache: bool = False) -> Dict[str, Any]:
        """Export learned stats and cooldown/cache metadata into JSON-friendly dict."""
        out = {
            "version": "2.0", 
            "timestamp": time.time(),
            "decision_count": self._decision_count,
            "start_time": self._start_time,
        }
        
        # Export learned data
        out["learned"] = self.learner.export_state()
        
        # Export gate manager state
        gate_stats = self.gate_manager.get_stats()
        out["gate_manager"] = {
            "veto_cooldowns": {
                "|".join(map(str, k)): v 
                for k, v in self.gate_manager._veto_cooldowns.items()
            },
            "veto_counts": gate_stats["veto_counts"]
        }
        
        # Export cache if requested
        if include_cache:
            out["cache"] = {
                "stats": self.cache.stats(),
                "items": {}
            }
            # Note: The actual cache content is not exported by default
            # as it's transient data. Only stats are exported.
        
        # Export config
        out["config"] = self.get_config()
        
        return out

    def import_state(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Restore learned stats and cooldowns from export_state() output."""
        try:
            if not isinstance(state, dict):
                return {"ok": False, "error": "state not dict"}
                
            version = state.get("version", "1.0")
            
            # Import learned data
            if "learned" in state:
                self.learner.import_state(state["learned"])
            
            # Import gate manager state
            if "gate_manager" in state:
                gate_data = state["gate_manager"]
                veto_cooldowns = gate_data.get("veto_cooldowns", {})
                
                # Clear existing cooldowns
                self.gate_manager.clear_veto_cooldowns()
                
                # Import new cooldowns
                for ks, v in veto_cooldowns.items():
                    parts = ks.split("|")
                    if len(parts) == 5:
                        self.gate_manager._veto_cooldowns[tuple(parts)] = float(v)
                
                # Import veto counts
                veto_counts = gate_data.get("veto_counts", {})
                self.gate_manager._veto_counts.update(veto_counts)
            
            # Import decision count
            if "decision_count" in state:
                self._decision_count = int(state["decision_count"])
            
            if "start_time" in state:
                self._start_time = float(state["start_time"])
            
            return {"ok": True, "keys": len(self.learner._learned), "version": version}
            
        except Exception as e:
            if self._debug_enabled():
                self._log("warning", f"[autonomy] import_state failed: {e}")
            return {"ok": False, "error": str(e)}

    # -----------------------------
    # Dynamic tuning (conservative control loop)
    # -----------------------------
    def optimize_parameters_dynamically(self, performance_data) -> Dict[str, Any]:
        """
        Dynamically tune a small subset of parameters based on performance.
        """
        try:
            if not self._get_bool("autonomy.tuning.enabled", True):
                return {"ok": True, "updated": False, "reason": "tuning disabled"}

            cooldown = self._get_float("autonomy.tuning.cooldown_sec", 1800)
            now = time.time()
            last_ts = self._get_float("autonomy.tuning.last_ts", 0.0)
            if now - last_ts < cooldown:
                return {"ok": True, "updated": False, "reason": "cooldown"}

            pd = performance_data or {}
            win_rate = self._safe_float(pd.get("win_rate"), 0.0)
            pf = self._safe_float(pd.get("profit_factor"), 1.0)
            dd = self._safe_float(pd.get("max_drawdown"), 0.0)

            # clamp common ranges
            win_rate = self._clamp(win_rate, 0.0, 1.0) if win_rate <= 1.0 else self._clamp(win_rate / 100.0, 0.0, 1.0)
            pf = self._clamp(pf, 0.0, 50.0)
            dd = self._clamp(dd, 0.0, 0.99)

            recent_pnls = pd.get("recent_pnls") or pd.get("pnls") or []
            if not isinstance(recent_pnls, list):
                recent_pnls = []
            recent_pnls = [self._safe_float(x, 0.0) for x in recent_pnls][-50:]

            loss_streak = 0
            for x in reversed(recent_pnls):
                if x < 0:
                    loss_streak += 1
                else:
                    break

            lev = self._get_int("futures.leverage", self._get_int("execution.leverage", 5))
            lev_min = self._get_int("futures.dynamic_leverage.min", 1)
            lev_max = self._get_int("futures.dynamic_leverage.max", max(lev, 5))

            dca_add_mult = self._get_float("risk.dca.add_qty_mult", 0.5)
            dca_max_adds = self._get_int("risk.dca.max_adds", 2)
            pyr_add_mult = self._get_float("risk.pyramid.add_qty_mult", 0.25)
            pyr_max_adds = self._get_int("risk.pyramid.max_adds", 2)

            changes = []

            dd_hi = self._get_float("autonomy.tuning.dd_high", 0.18)
            dd_lo = self._get_float("autonomy.tuning.dd_low", 0.08)
            pf_good = self._get_float("autonomy.tuning.pf_good", 1.25)
            wr_good = self._get_float("autonomy.tuning.win_rate_good", 0.55)
            streak_bad = self._get_int("autonomy.tuning.loss_streak_bad", 4)
            lev_deadband = self._get_int("autonomy.tuning.leverage_deadband", 1)

            risk_off = (dd >= dd_hi) or (loss_streak >= streak_bad) or (pf < 0.95)
            risk_on = (dd <= dd_lo) and (pf >= pf_good) and (win_rate >= wr_good)

            with self._lock:
                if risk_off:
                    sev = 1.0
                    if dd_hi > 1e-12:
                        sev = self._clamp(dd / dd_hi, 1.0, 2.0)

                    new_lev = max(lev_min, int(round(lev * (0.85 ** sev))))
                    if abs(new_lev - lev) >= lev_deadband:
                        self._set("futures.leverage", new_lev)
                        changes.append({"path": "futures.leverage", "from": lev, "to": new_lev})

                    new_pyr_max = max(0, pyr_max_adds - 1)
                    if new_pyr_max != pyr_max_adds:
                        self._set("risk.pyramid.max_adds", new_pyr_max)
                        changes.append({"path": "risk.pyramid.max_adds", "from": pyr_max_adds, "to": new_pyr_max})

                    new_dca_max = max(0, dca_max_adds - 1)
                    if new_dca_max != dca_max_adds:
                        self._set("risk.dca.max_adds", new_dca_max)
                        changes.append({"path": "risk.dca.max_adds", "from": dca_max_adds, "to": new_dca_max})

                    new_dca_mult = self._clamp(dca_add_mult * 0.90, 0.10, 1.0)
                    if abs(new_dca_mult - dca_add_mult) > 1e-9:
                        self._set("risk.dca.add_qty_mult", float(new_dca_mult))
                        changes.append({"path": "risk.dca.add_qty_mult", "from": dca_add_mult, "to": float(new_dca_mult)})

                    new_pyr_mult = self._clamp(pyr_add_mult * 0.90, 0.05, 1.0)
                    if abs(new_pyr_mult - pyr_add_mult) > 1e-9:
                        self._set("risk.pyramid.add_qty_mult", float(new_pyr_mult))
                        changes.append({"path": "risk.pyramid.add_qty_mult", "from": pyr_add_mult, "to": float(new_pyr_mult)})

                    self._log("warning", f"[autonomy] risk-off tuning (dd={dd:.2f}, pf={pf:.2f}, streak={loss_streak})")

                elif risk_on:
                    prefer = str(self._get("autonomy.tuning.risk_on_prefer", "leverage")).lower().strip()
                    if prefer not in ("leverage", "pyramid"):
                        prefer = "leverage"

                    if prefer == "leverage":
                        new_lev = min(lev_max, int(round(max(1, lev) * 1.10)) or lev)
                        if abs(new_lev - lev) >= lev_deadband:
                            self._set("futures.leverage", new_lev)
                            changes.append({"path": "futures.leverage", "from": lev, "to": new_lev})
                    else:
                        new_pyr_max = min(5, pyr_max_adds + 1)
                        if new_pyr_max != pyr_max_adds:
                            self._set("risk.pyramid.max_adds", new_pyr_max)
                            changes.append({"path": "risk.pyramid.max_adds", "from": pyr_max_adds, "to": new_pyr_max})

                    self._log("info", f"[autonomy] risk-on tuning (dd={dd:.2f}, pf={pf:.2f}, wr={win_rate:.2f})")

                self._set("autonomy.tuning.last_ts", now)

            if changes:
                return {"ok": True, "updated": True, "changes": changes}
            return {"ok": True, "updated": False, "reason": "no-op"}

        except Exception as e:
            self._log("warning", f"[autonomy] optimize_parameters_dynamically failed: {e}")
            return {"ok": False, "updated": False, "error": str(e)}

    # -----------------------------
    # Observability / Maintenance
    # -----------------------------
    def stats(self) -> Dict[str, Any]:
        """Lightweight stats for UI/debug."""
        now = time.time()
        uptime = now - self._start_time
        
        cache_stats = self.cache.stats()
        gate_stats = self.gate_manager.get_stats()
        learner_stats = self.learner.get_stats()
        
        return {
            "cache_size": cache_stats["size"],
            "cache_max": cache_stats["max_size"],
            "cache_hit_rate": cache_stats["hit_rate"],
            "veto_cooldowns": gate_stats["veto_cooldowns"],
            "veto_counts": gate_stats["veto_counts"],
            "learned_keys": learner_stats["keys"],
            "learned_samples": learner_stats["total_samples"],
            "sim_tokens": len(self._sim_timestamps),
            "decisions_total": self._decision_count,
            "enabled": self._get_bool("autonomy.enabled", True),
            "smartfilter_enabled": self._get_bool("autonomy.smartfilter_enabled", True),
            "tuning_enabled": self._get_bool("autonomy.tuning.enabled", True),
            "uptime_hours": round(uptime / 3600, 2),
            "avg_decisions_per_hour": round(self._decision_count / max(0.1, uptime / 3600), 1),
        }

    def get_detailed_stats(self) -> Dict[str, Any]:
        """Get detailed statistics including learned data summary."""
        stats = self.stats()
        
        # Add learned data summary
        learned_summary = {}
        # Note: Would need to expose learner._learned or add a method to get summary
        
        # Add cache items
        cache_items = []
        # Note: Would need to expose cache._cache or add a method to get keys
        
        stats["learned_summary"] = learned_summary
        stats["cache_items"] = cache_items[:10]
        return stats

    def reset(self, *, learned: bool = True, cache: bool = True, veto: bool = True, 
              stats: bool = False) -> Dict[str, Any]:
        """Reset internal state (useful for UI actions / tests)."""
        with self._lock:
            if learned:
                self.learner.clear()
            if cache:
                self.cache.clear()
            if veto:
                self.gate_manager.clear_veto_cooldowns()
                self.gate_manager._veto_counts.clear()
            if stats:
                self._sim_timestamps.clear()
                self._decision_count = 0
                self._start_time = time.time()
        
        return {"ok": True, "stats": self.stats()}

    def prune(self, force: bool = False) -> Dict[str, Any]:
        """Prune expired cooldowns and old cache entries (best-effort)."""
        now = time.time()
        
        # Only prune if more than 5 minutes since last prune or forced
        if not force:
            last_prune = getattr(self, "_last_prune_time", 0.0)
            if now - last_prune < 300:  # 5 minutes
                return {"ok": True, "pruned": False, "reason": "too_soon"}

        removed_cache = 0
        removed_veto = 0
        removed_learned = 0

        with self._lock:
            self._last_prune_time = now
            
            # Prune cache
            removed_cache = self.cache.prune()
            
            # Prune veto cooldowns
            removed_veto = self.gate_manager.prune_veto_cooldowns()
            
            # Note: Learner pruning would need to be implemented in OnlineLearner class

        return {
            "ok": True, 
            "removed_cache": removed_cache, 
            "removed_veto": removed_veto,
            "removed_learned": removed_learned,
            "stats": self.stats()
        }

    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of the autonomy controller."""
        stats = self.stats()
        now = time.time()
        
        health = {
            "status": "healthy",
            "timestamp": now,
            "components": {
                "cache": {
                    "size": stats["cache_size"],
                    "max": stats["cache_max"],
                    "health": "good" if stats["cache_size"] < stats["cache_max"] * 0.8 else "warning",
                },
                "learning": {
                    "keys": stats["learned_keys"],
                    "health": "good" if stats["learned_keys"] > 0 else "inactive",
                },
                "decisions": {
                    "total": stats["decisions_total"],
                    "rate_per_hour": stats["avg_decisions_per_hour"],
                    "health": "good" if stats["avg_decisions_per_hour"] > 0 else "inactive",
                },
            },
            "uptime_hours": stats["uptime_hours"],
        }
        
        # Check for potential issues
        issues = []
        if stats["cache_size"] >= stats["cache_max"]:
            issues.append("Cache at maximum capacity")
        if stats["veto_cooldowns"] > 100:
            issues.append(f"High number of veto cooldowns: {stats['veto_cooldowns']}")
        if stats["avg_decisions_per_hour"] == 0 and stats["uptime_hours"] > 1:
            issues.append("No decisions made recently")
            
        if issues:
            health["status"] = "warning"
            health["issues"] = issues
            
        return health

    def clear_veto_cooldowns(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Clear veto cooldowns for a specific symbol or all symbols."""
        cleared = self.gate_manager.clear_veto_cooldowns(symbol)
        return {"ok": True, "cleared": cleared, "remaining": len(self.gate_manager._veto_cooldowns)}

    def get_learned_data(self, symbol: Optional[str] = None, side: Optional[str] = None, 
                         limit: int = 50) -> Dict[str, Any]:
        """Get learned data for specific symbol/side or all."""
        # Note: This would need to be implemented in OnlineLearner class
        return {"ok": True, "data": {}, "count": 0}
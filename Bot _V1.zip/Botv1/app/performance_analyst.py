from __future__ import annotations

from typing import List, Dict, Any, Optional, Tuple
import math
import statistics


def _is_finite(x: float) -> bool:
    return math.isfinite(x)


def _f(x: Any, default: float = 0.0) -> Optional[float]:
    """Safe float conversion; returns None for non-finite."""
    try:
        if x is None:
            return None
        v = float(x)
        return v if _is_finite(v) else None
    except Exception:
        return None


def _clean_floats(xs: List[Any]) -> List[float]:
    out: List[float] = []
    for x in xs or []:
        v = _f(x, None)
        if v is None:
            continue
        out.append(float(v))
    return out


def _mean(xs: List[float]) -> float:
    return float(sum(xs) / max(1, len(xs))) if xs else 0.0


def _stdev(xs: List[float]) -> float:
    if not xs or len(xs) < 2:
        return 0.0
    m = _mean(xs)
    v = sum((x - m) ** 2 for x in xs) / max(1, (len(xs) - 1))
    return float(math.sqrt(max(0.0, v)))


def _median(xs: List[float]) -> float:
    if not xs:
        return 0.0
    try:
        return float(statistics.median(xs))
    except Exception:
        xs2 = sorted(xs)
        n = len(xs2)
        mid = n // 2
        if n % 2 == 1:
            return float(xs2[mid])
        return float(0.5 * (xs2[mid - 1] + xs2[mid]))


def _max_drawdown(equity: List[float]) -> Dict[str, Any]:
    """Compute max drawdown and duration from an equity curve."""
    eq = _clean_floats(equity)
    if len(eq) < 2:
        return {"max_drawdown": 0.0, "peak": None, "trough": None, "start_idx": None, "end_idx": None, "duration": 0}

    peak = eq[0]
    peak_i = 0
    max_dd = 0.0
    dd_start = 0
    dd_end = 0

    cur_start = 0
    for i, v in enumerate(eq):
        if v >= peak:
            peak = v
            peak_i = i
            cur_start = i
        dd = (peak - v) / max(1e-12, abs(peak))
        if dd > max_dd:
            max_dd = dd
            dd_start = peak_i
            dd_end = i

    duration = int(dd_end - dd_start)
    return {
        "max_drawdown": float(max_dd),
        "peak": float(eq[dd_start]) if dd_start is not None else None,
        "trough": float(eq[dd_end]) if dd_end is not None else None,
        "start_idx": int(dd_start),
        "end_idx": int(dd_end),
        "duration": duration,
    }


def _streaks(pnls: List[float]) -> Dict[str, int]:
    max_w = 0
    max_l = 0
    cur_w = 0
    cur_l = 0
    for p in pnls:
        if p > 0:
            cur_w += 1
            cur_l = 0
        elif p < 0:
            cur_l += 1
            cur_w = 0
        else:
            # treat 0 as streak breaker
            cur_w = 0
            cur_l = 0
        max_w = max(max_w, cur_w)
        max_l = max(max_l, cur_l)
    return {"max_consecutive_wins": int(max_w), "max_consecutive_losses": int(max_l)}


class PerformanceAnalyst:
    """
    Performance metrics for the bot.

    Notes:
      - `returns` should be periodic returns (e.g., per candle/day), not trade PnL.
      - `trades` should contain realized PnL per trade (or per fill aggregation).
    """

    def calculate_sharpe_ratio(
        self,
        returns: List[float],
        risk_free_rate: float = 0.0,
        *,
        annualize: bool = False,
        periods_per_year: int = 365,
    ) -> float:
        r = _clean_floats(returns)
        if len(r) < 2:
            return 0.0

        rf = float(risk_free_rate)
        adj = [x - rf for x in r]
        m = _mean(adj)
        s = _stdev(adj)
        if s <= 0:
            return 0.0

        sharpe = m / max(1e-12, s)
        if annualize:
            sharpe *= math.sqrt(max(1, int(periods_per_year)))
        return float(sharpe)

    def calculate_sortino_ratio(
        self,
        returns: List[float],
        target_return: float = 0.0,
        *,
        annualize: bool = False,
        periods_per_year: int = 365,
    ) -> float:
        r = _clean_floats(returns)
        if len(r) < 2:
            return 0.0

        t = float(target_return)
        downside = [min(0.0, x - t) for x in r]
        dd = math.sqrt(sum(x * x for x in downside) / max(1, len(downside)))
        m = _mean([x - t for x in r])
        if dd <= 0:
            return 0.0

        sortino = m / max(1e-12, dd)
        if annualize:
            sortino *= math.sqrt(max(1, int(periods_per_year)))
        return float(sortino)

    def calculate_max_consecutive_losses(self, trades: List[float]) -> int:
        pnls = _clean_floats(trades)
        return _streaks(pnls)["max_consecutive_losses"]

    def generate_performance_report(
        self,
        trades: List[Dict[str, Any]],
        equity_curve: List[float],
        *,
        returns: Optional[List[float]] = None,
        annualize: bool = False,
        periods_per_year: int = 365,
        risk_free_rate: float = 0.0,
        target_return: float = 0.0,
        starting_equity: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        trades: list of dicts with at least one PnL field:
          - realized / realized_pnl / pnl / profit
        equity_curve: list of equity values over time (optional; if empty and starting_equity set,
                      curve can be built from trades pnls).
        returns: periodic returns for Sharpe/Sortino (optional).
        """
        errors: List[str] = []
        warnings: List[str] = []

        # ---- extract pnls from trades ----
        pnls_raw: List[float] = []
        for t in trades or []:
            if not isinstance(t, dict):
                continue
            v = (
                t.get("realized")
                if "realized" in t
                else t.get("realized_pnl")
                if "realized_pnl" in t
                else t.get("pnl")
                if "pnl" in t
                else t.get("profit")
            )
            fv = _f(v, None)
            if fv is None:
                continue
            pnls_raw.append(float(fv))

        pnls = pnls_raw
        n = len(pnls)
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]

        total_pnl = float(sum(pnls)) if pnls else 0.0
        win_rate = float(len(wins) / n) if n else 0.0

        avg_win = float(sum(wins) / len(wins)) if wins else 0.0
        avg_loss = float(sum(losses) / len(losses)) if losses else 0.0  # negative
        median_pnl = _median(pnls)

        gross_profit = float(sum(wins)) if wins else 0.0
        gross_loss = float(abs(sum(losses))) if losses else 0.0
        profit_factor = float(gross_profit / max(1e-12, gross_loss)) if (wins or losses) else 0.0

        expectancy = 0.0
        if n:
            p_win = win_rate
            p_loss = 1.0 - p_win
            expectancy = p_win * avg_win + p_loss * avg_loss  # avg_loss is negative

        best_trade = max(pnls) if pnls else 0.0
        worst_trade = min(pnls) if pnls else 0.0

        streak = _streaks(pnls)

        # ---- equity curve handling ----
        eq = _clean_floats(equity_curve)
        if (not eq) and (starting_equity is not None):
            se = _f(starting_equity, None)
            if se is not None:
                cur = float(se)
                eq = [cur]
                for p in pnls:
                    cur += float(p)
                    eq.append(cur)
                warnings.append("equity_curve_missing_built_from_trades")

        equity_end = float(eq[-1]) if eq else None
        dd = _max_drawdown(eq) if eq else {"max_drawdown": 0.0, "peak": None, "trough": None, "start_idx": None, "end_idx": None, "duration": 0}

        # ---- returns metrics ----
        r = _clean_floats(returns or [])
        if returns is not None and len(r) < 2:
            warnings.append("returns_insufficient_for_sharpe_sortino")

        sharpe = self.calculate_sharpe_ratio(r, risk_free_rate=risk_free_rate, annualize=annualize, periods_per_year=periods_per_year) if r else 0.0
        sortino = self.calculate_sortino_ratio(r, target_return=target_return, annualize=annualize, periods_per_year=periods_per_year) if r else 0.0

        report = {
            "ok": True,
            "errors": errors,
            "warnings": warnings,
            "trade_metrics": {
                "trades": int(n),
                "win_rate": float(win_rate),
                "avg_win": float(avg_win),
                "avg_loss": float(avg_loss),
                "median_pnl": float(median_pnl),
                "total_pnl": float(total_pnl),
                "profit_factor": float(profit_factor),
                "expectancy": float(expectancy),
                "best_trade": float(best_trade),
                "worst_trade": float(worst_trade),
                **streak,
            },
            "equity_metrics": {
                "equity_end": equity_end,
                "max_drawdown": float(dd.get("max_drawdown", 0.0)),
                "drawdown_peak": dd.get("peak"),
                "drawdown_trough": dd.get("trough"),
                "drawdown_start_idx": dd.get("start_idx"),
                "drawdown_end_idx": dd.get("end_idx"),
                "drawdown_duration": dd.get("duration"),
            },
            "returns_metrics": {
                "count": int(len(r)),
                "sharpe": float(sharpe),
                "sortino": float(sortino),
                "annualize": bool(annualize),
                "periods_per_year": int(periods_per_year),
                "risk_free_rate": float(risk_free_rate),
                "target_return": float(target_return),
            },
        }
        return report

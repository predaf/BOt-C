# app/approvals.py
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional, List, Tuple, Set, Callable, Union, Iterator
from enum import Enum
from contextlib import contextmanager
import heapq
from collections import defaultdict
import logging

# Setup logging
logger = logging.getLogger(__name__)

# Constants
DEFAULT_TIMEOUT_SEC = 300
DEFAULT_KEEP_TERMINAL = 2000
DEFAULT_PURGE_AFTER_SEC = 24 * 3600
DEFAULT_DEDUP_WINDOW_SEC = 30
DEFAULT_AUTOSAVE_EVERY_SEC = 5

# Enums for better type safety
class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    EXECUTED = "executed"

class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"
    LONG = "long"
    SHORT = "short"

TERMINAL_STATES = {ApprovalStatus.REJECTED, ApprovalStatus.EXPIRED, ApprovalStatus.EXECUTED}
VALID_STATES = {s.value for s in ApprovalStatus}

# State machine transitions
_ALLOWED_TRANSITIONS: Dict[ApprovalStatus, Set[ApprovalStatus]] = {
    ApprovalStatus.PENDING: {ApprovalStatus.APPROVED, ApprovalStatus.REJECTED, ApprovalStatus.EXPIRED},
    ApprovalStatus.APPROVED: {ApprovalStatus.EXECUTED, ApprovalStatus.EXPIRED},
    ApprovalStatus.REJECTED: set(),
    ApprovalStatus.EXPIRED: set(),
    ApprovalStatus.EXECUTED: set(),
}

# Price precision for deduplication
PRICE_BUCKET_RATIO = 0.002  # 0.2%

def _now() -> float:
    """Get current monotonic time."""
    return time.monotonic()  # Use monotonic to avoid clock changes

def _as_float(x: Any) -> float:
    """Safely convert to float, return NaN on failure."""
    try:
        return float(x)
    except (ValueError, TypeError):
        return float("nan")

def _is_finite_pos(x: float) -> bool:
    """Check if value is positive, finite, and not NaN."""
    return x > 0.0 and x == x and x != float("inf") and x != float("-inf")

def _norm_side(side: str) -> str:
    """Normalize trading side with aliases support."""
    s = str(side or "").strip().lower()
    # Normalize aliases
    if s in ("long", "buy"):
        return Side.BUY.value  # Standardize to 'buy'
    if s in ("short", "sell"):
        return Side.SELL.value  # Standardize to 'sell'
    return s

def _norm_symbol(symbol: str) -> str:
    """Normalize symbol."""
    return str(symbol or "").strip().upper()

def _safe_int(x: Any, default: int) -> int:
    """Safely convert to int with default fallback."""
    try:
        return int(x)
    except (ValueError, TypeError):
        return int(default)

class ApprovalError(Exception):
    """Base exception for approval-related errors."""
    pass

class ValidationError(ApprovalError):
    """Raised when validation fails."""
    pass

class StateTransitionError(ApprovalError):
    """Raised when invalid state transition is attempted."""
    pass

@dataclass
class Approval:
    id: str
    created_ts: float
    symbol: str
    side: str
    qty: float
    price_ref: float
    reason: str
    meta: Dict[str, Any] = field(default_factory=dict)
    status: str = ApprovalStatus.PENDING.value
    decided_ts: Optional[float] = None
    decided_by: Optional[str] = None
    dedup_key: str = ""
    version: int = 1
    updated_ts: float = field(default_factory=_now)  # Track last update
    
    def __post_init__(self):
        """Validate after initialization."""
        if self.status not in VALID_STATES:
            self.status = ApprovalStatus.PENDING.value
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary with ISO timestamp strings."""
        data = asdict(self)
        # Optionally convert timestamps to ISO format for readability
        if self.decided_ts:
            data['decided_ts_iso'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                  time.localtime(self.decided_ts))
        data['created_ts_iso'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                              time.localtime(self.created_ts))
        return data
    
    def __str__(self) -> str:
        return (f"Approval(id={self.id[:8]}..., status={self.status}, "
                f"symbol={self.symbol}, side={self.side}, qty={self.qty})")
    
    @property
    def age(self) -> float:
        """Get age in seconds."""
        return _now() - self.created_ts
    
    @property
    def is_terminal(self) -> bool:
        """Check if approval is in terminal state."""
        return self.status in TERMINAL_STATES

class ApprovalQueue:
    """
    Thread-safe approval queue with persistence, deduplication, and state management.
    
    Features:
    - Thread-safe operations
    - Automatic expiration
    - Strict state machine
    - Memory bounds with purging
    - JSON persistence
    - Idempotent operations
    - Event callbacks
    """
    
    def __init__(
        self,
        timeout_sec: int = DEFAULT_TIMEOUT_SEC,
        *,
        keep_terminal: int = DEFAULT_KEEP_TERMINAL,
        purge_after_sec: int = DEFAULT_PURGE_AFTER_SEC,
        dedup_window_sec: int = DEFAULT_DEDUP_WINDOW_SEC,
        persist_path: Optional[str] = None,
        autosave_every_sec: int = DEFAULT_AUTOSAVE_EVERY_SEC,
        price_bucket_ratio: float = PRICE_BUCKET_RATIO,
        max_meta_size: int = 1024 * 10,  # 10KB max for meta
    ):
        self.timeout_sec = int(timeout_sec)
        self.keep_terminal = int(keep_terminal)
        self.purge_after_sec = int(purge_after_sec)
        self.dedup_window_sec = int(dedup_window_sec)
        self.price_bucket_ratio = float(price_bucket_ratio)
        self.max_meta_size = int(max_meta_size)
        
        self.persist_path = str(persist_path) if persist_path else ""
        self.autosave_every_sec = int(autosave_every_sec)
        
        self._lock = threading.RLock()
        self._items: Dict[str, Approval] = {}
        self._dedup_index: Dict[str, str] = {}  # dedup_key -> approval_id
        self._symbol_index: Dict[str, Set[str]] = defaultdict(set)  # symbol -> approval_ids
        self._status_index: Dict[str, Set[str]] = defaultdict(set)  # status -> approval_ids
        self._last_save_ts: float = 0.0
        
        # Event callbacks
        self._callbacks: Dict[str, List[Callable[[Approval], None]]] = defaultdict(list)
        
        # Load existing data
        if self.persist_path:
            self.load()
        
        # Start background maintenance thread
        self._maintenance_thread = threading.Thread(
            target=self._maintenance_loop,
            daemon=True,
            name="ApprovalQueue-Maintenance"
        )
        self._maintenance_thread.start()
    
    def _maintenance_loop(self):
        """Background thread for periodic maintenance."""
        while True:
            time.sleep(60)  # Run every minute
            try:
                self.expire_old()
                self._purge_old_terminal()
            except Exception as e:
                logger.error(f"Maintenance error: {e}")
    
    def _update_indexes(self, approval: Approval, old_status: Optional[str] = None):
        """Update all indexes for an approval."""
        # Update symbol index
        self._symbol_index[approval.symbol].add(approval.id)
        
        # Update status index
        if old_status and old_status in self._status_index:
            self._status_index[old_status].discard(approval.id)
        self._status_index[approval.status].add(approval.id)
    
    def _remove_from_indexes(self, approval_id: str, approval: Optional[Approval] = None):
        """Remove approval from all indexes."""
        if approval:
            self._symbol_index[approval.symbol].discard(approval_id)
            self._status_index[approval.status].discard(approval_id)
        else:
            # Remove from all indexes
            for symbol_set in self._symbol_index.values():
                symbol_set.discard(approval_id)
            for status_set in self._status_index.values():
                status_set.discard(approval_id)
    
    # -------------------------
    # Persistence Improvements
    # -------------------------
    
    def load(self) -> None:
        """Load approvals from persistent storage."""
        if not self.persist_path or not os.path.exists(self.persist_path):
            return
            
        with self._lock:
            try:
                with open(self.persist_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Check version compatibility
                version = data.get('version', 1)
                if version > 1:
                    logger.warning(f"File version {version} > 1, some data may not load correctly")
                
                restored = {}
                dedup_index = {}
                
                for item in data.get('items', []):
                    try:
                        approval = self._deserialize_approval(item)
                        if approval.id and approval.status in VALID_STATES:
                            restored[approval.id] = approval
                            if approval.dedup_key:
                                dedup_index[approval.dedup_key] = approval.id
                            
                            # Update indexes
                            self._update_indexes(approval)
                    except (KeyError, ValueError, TypeError) as e:
                        logger.warning(f"Failed to load item: {e}")
                        continue
                
                self._items = restored
                self._dedup_index = dedup_index
                
                logger.info(f"Loaded {len(restored)} approvals from {self.persist_path}")
                
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in {self.persist_path}: {e}")
                # Create backup of corrupt file
                backup_path = f"{self.persist_path}.corrupt.{int(time.time())}"
                try:
                    os.rename(self.persist_path, backup_path)
                    logger.info(f"Backed up corrupt file to {backup_path}")
                except OSError:
                    pass
            except Exception as e:
                logger.error(f"Failed to load from {self.persist_path}: {e}")
    
    def _deserialize_approval(self, data: Dict) -> Approval:
        """Deserialize approval from dictionary."""
        # Handle legacy formats
        if 'version' not in data:
            data['version'] = 1
        
        return Approval(
            id=str(data.get('id', uuid.uuid4().hex)),
            created_ts=float(data.get('created_ts', _now())),
            symbol=str(data.get('symbol', '')),
            side=str(data.get('side', '')),
            qty=float(data.get('qty', 0.0)),
            price_ref=float(data.get('price_ref', 0.0)),
            reason=str(data.get('reason', '')),
            meta=dict(data.get('meta') or {}),
            status=str(data.get('status', ApprovalStatus.PENDING.value)),
            decided_ts=data.get('decided_ts'),
            decided_by=data.get('decided_by'),
            dedup_key=str(data.get('dedup_key', '')),
            version=_safe_int(data.get('version', 1), 1),
        )
    
    def save(self, force: bool = False) -> None:
        """Save approvals to persistent storage."""
        if not self.persist_path:
            return
            
        with self._lock:
            now = _now()
            if not force and (now - self._last_save_ts) < self.autosave_every_sec:
                return
                
            try:
                # Ensure directory exists
                os.makedirs(os.path.dirname(self.persist_path) or '.', exist_ok=True)
                
                payload = {
                    'version': 2,  # Bump version for new format
                    'ts': now,
                    'count': len(self._items),
                    'items': [a.to_dict() for a in self._items.values()],
                }
                
                # Atomic write with temp file
                temp_path = f"{self.persist_path}.tmp.{os.getpid()}"
                with open(temp_path, 'w', encoding='utf-8') as f:
                    json.dump(payload, f, 
                             ensure_ascii=False, 
                             separators=(',', ':'), 
                             default=str,  # Handle non-serializable
                             sort_keys=True)
                
                # Atomic rename (works on POSIX, Windows needs special handling)
                try:
                    os.replace(temp_path, self.persist_path)
                except OSError:
                    # Fallback for Windows
                    if os.path.exists(self.persist_path):
                        os.remove(self.persist_path)
                    os.rename(temp_path, self.persist_path)
                
                self._last_save_ts = now
                logger.debug(f"Saved {len(self._items)} approvals")
                
            except Exception as e:
                logger.error(f"Failed to save approvals: {e}")
                # Try to save to backup location
                try:
                    backup_path = f"{self.persist_path}.backup.{int(time.time())}"
                    with open(backup_path, 'w') as f:
                        json.dump(payload, f)
                    logger.info(f"Created backup at {backup_path}")
                except Exception:
                    pass
    
    @contextmanager
    def batch_mode(self):
        """Context manager for batch operations (disables autosave)."""
        old_interval = self.autosave_every_sec
        self.autosave_every_sec = 0  # Disable autosave
        try:
            yield self
            self.save(force=True)  # Save at the end
        finally:
            self.autosave_every_sec = old_interval
    
    # -------------------------
    # Core Operations Improvements
    # -------------------------
    
    def _compute_dedup_key(self, symbol: str, side: str, qty: float, 
                          price_ref: float, reason: str) -> str:
        """Compute deterministic deduplication key."""
        sym = _norm_symbol(symbol)
        sd = _norm_side(side)
        q = round(float(qty), 8)
        pr = float(price_ref)
        
        # Handle zero price case
        if pr == 0:
            pr_bucket = 0
        else:
            pr_bucket = int(pr / max(1e-9, pr * self.price_bucket_ratio))
        
        rs = (reason or "").strip().lower()[:120]
        return f"{sym}|{sd}|{q}|{pr_bucket}|{rs}"
    
    def _validate_inputs(self, symbol: str, side: str, qty: float, 
                        price_ref: float, meta: Optional[Dict]) -> None:
        """Validate inputs, raise ValidationError on failure."""
        sym = _norm_symbol(symbol)
        sd = _norm_side(side)
        
        if not sym:
            raise ValidationError("Invalid symbol")
        if sd not in {s.value for s in Side}:
            raise ValidationError(f"Invalid side: {side}")
        
        q = _as_float(qty)
        if not _is_finite_pos(q):
            raise ValidationError(f"Invalid quantity: {qty}")
        
        pr = _as_float(price_ref)
        if not _is_finite_pos(pr):
            raise ValidationError(f"Invalid price reference: {price_ref}")
        
        # Validate meta size
        if meta:
            meta_size = len(json.dumps(meta))
            if meta_size > self.max_meta_size:
                raise ValidationError(f"Meta too large: {meta_size} > {self.max_meta_size}")
    
    def create(
        self,
        symbol: str,
        side: str,
        qty: float,
        price_ref: float,
        reason: str,
        meta: Optional[Dict[str, Any]] = None,
        *,
        dedup_key: Optional[str] = None,
        raise_on_duplicate: bool = False,
    ) -> Approval:
        """Create a new approval request."""
        with self._lock:
            self.expire_old()
            
            try:
                self._validate_inputs(symbol, side, qty, price_ref, meta)
            except ValidationError as e:
                # Create rejected approval for audit trail
                rejection = Approval(
                    id=str(uuid.uuid4()),
                    created_ts=_now(),
                    symbol=_norm_symbol(symbol),
                    side=_norm_side(side),
                    qty=float(_as_float(qty)),
                    price_ref=float(_as_float(price_ref)),
                    reason=str(reason),
                    meta=dict(meta or {}),
                    status=ApprovalStatus.REJECTED.value,
                    decided_ts=_now(),
                    decided_by="validator",
                    dedup_key=str(dedup_key or ""),
                )
                self._items[rejection.id] = rejection
                self._update_indexes(rejection)
                self._purge_old_terminal()
                self.save()
                raise ValidationError(f"Validation failed: {e}") from e
            
            sym = _norm_symbol(symbol)
            sd = _norm_side(side)
            q = float(qty)
            pr = float(price_ref)
            
            # Compute deduplication key
            dk = str(dedup_key or self._compute_dedup_key(sym, sd, q, pr, str(reason)))
            
            # Check for duplicate pending approval
            existing_id = self._dedup_index.get(dk)
            if existing_id:
                existing = self._items.get(existing_id)
                if existing and existing.status == ApprovalStatus.PENDING.value:
                    age = _now() - existing.created_ts
                    if age <= float(self.dedup_window_sec):
                        if raise_on_duplicate:
                            raise ValidationError(f"Duplicate approval within {self.dedup_window_sec}s")
                        return existing
            
            # Create new approval
            approval = Approval(
                id=str(uuid.uuid4()),
                created_ts=_now(),
                symbol=sym,
                side=sd,
                qty=q,
                price_ref=pr,
                reason=str(reason),
                meta=dict(meta or {}),
                dedup_key=dk,
            )
            
            self._items[approval.id] = approval
            self._dedup_index[dk] = approval.id
            self._update_indexes(approval)
            
            self._purge_old_terminal()
            self.save()
            
            # Trigger callback
            self._trigger_callback('created', approval)
            
            return approval
    
    def get(self, approval_id: str) -> Optional[Approval]:
        """Get approval by ID."""
        with self._lock:
            self.expire_old()
            return self._items.get(str(approval_id))
    
    def get_by_dedup_key(self, dedup_key: str) -> Optional[Approval]:
        """Get approval by deduplication key."""
        with self._lock:
            self.expire_old()
            approval_id = self._dedup_index.get(dedup_key)
            return self._items.get(approval_id) if approval_id else None
    
    def list(self, 
             status: Optional[str] = None, 
             symbol: Optional[str] = None,
             limit: int = 100,
             offset: int = 0) -> List[Approval]:
        """List approvals with filtering and pagination."""
        with self._lock:
            self.expire_old()
            
            # Use indexes for faster filtering
            approval_ids = None
            
            if status and symbol:
                # Intersection of status and symbol
                status_ids = self._status_index.get(status, set())
                symbol_ids = self._symbol_index.get(_norm_symbol(symbol), set())
                approval_ids = status_ids.intersection(symbol_ids)
            elif status:
                approval_ids = self._status_index.get(status, set())
            elif symbol:
                approval_ids = self._symbol_index.get(_norm_symbol(symbol), set())
            
            if approval_ids is not None:
                items = [self._items[aid] for aid in approval_ids if aid in self._items]
            else:
                items = list(self._items.values())
            
            # Sort by creation time (newest first)
            items.sort(key=lambda a: a.created_ts, reverse=True)
            
            # Apply pagination
            start = offset
            end = offset + limit
            return items[start:end]
    
    def search(self, 
               criteria: Dict[str, Any],
               limit: int = 100) -> List[Approval]:
        """Search approvals with flexible criteria."""
        with self._lock:
            self.expire_old()
            
            results = []
            for approval in self._items.values():
                match = True
                for key, value in criteria.items():
                    if key == 'min_qty':
                        if approval.qty < float(value):
                            match = False
                            break
                    elif key == 'max_qty':
                        if approval.qty > float(value):
                            match = False
                            break
                    elif key == 'min_age':
                        if approval.age < float(value):
                            match = False
                            break
                    elif key == 'max_age':
                        if approval.age > float(value):
                            match = False
                            break
                    elif hasattr(approval, key):
                        attr = getattr(approval, key)
                        if callable(value):
                            if not value(attr):
                                match = False
                                break
                        elif attr != value:
                            match = False
                            break
                    elif key in approval.meta:
                        if approval.meta[key] != value:
                            match = False
                            break
                    else:
                        match = False
                        break
                
                if match:
                    results.append(approval)
                    if len(results) >= limit:
                        break
            
            return results
    
    def stats(self) -> Dict[str, Any]:
        """Get queue statistics."""
        with self._lock:
            self.expire_old()
            
            counts = {s.value: 0 for s in ApprovalStatus}
            oldest_pending = None
            newest_pending = None
            now = _now()
            
            for approval in self._items.values():
                counts[approval.status] += 1
                if approval.status == ApprovalStatus.PENDING.value:
                    age = now - approval.created_ts
                    if oldest_pending is None or age > oldest_pending:
                        oldest_pending = age
                    if newest_pending is None or age < newest_pending:
                        newest_pending = age
            
            return {
                'counts': counts,
                'total': len(self._items),
                'timeout_sec': self.timeout_sec,
                'oldest_pending_age_sec': oldest_pending,
                'newest_pending_age_sec': newest_pending,
                'memory_usage': sum(len(str(a)) for a in self._items.values()),
            }
    
    # -------------------------
    # State Transition Improvements
    # -------------------------
    
    def expire_old(self) -> None:
        """Expire old pending approvals."""
        with self._lock:
            now = _now()
            expired_count = 0
            
            # Get pending approvals from index for efficiency
            pending_ids = self._status_index.get(ApprovalStatus.PENDING.value, set()).copy()
            
            for approval_id in pending_ids:
                approval = self._items.get(approval_id)
                if not approval:
                    continue
                    
                if (now - approval.created_ts) >= float(self.timeout_sec):
                    if self._set_status_locked(approval, ApprovalStatus.EXPIRED, by="system", ts=now):
                        expired_count += 1
            
            if expired_count > 0:
                logger.info(f"Expired {expired_count} pending approvals")
                self._trigger_callback('batch_expired', expired_count)
    
    def _set_status_locked(self, approval: Approval, new_status: ApprovalStatus, 
                          by: str, ts: Optional[float] = None) -> bool:
        """Internal method to change approval status with validation."""
        try:
            current_status = ApprovalStatus(approval.status)
            target_status = ApprovalStatus(new_status) if isinstance(new_status, str) else new_status
        except ValueError:
            return False
        
        # Check transition validity
        allowed = _ALLOWED_TRANSITIONS.get(current_status, set())
        if target_status not in allowed:
            logger.warning(f"Invalid transition: {current_status} -> {target_status}")
            return False
        
        # Update approval
        old_status = approval.status
        approval.status = target_status.value
        approval.decided_ts = ts if ts is not None else _now()
        approval.decided_by = str(by)
        approval.updated_ts = _now()
        
        # Update indexes
        self._remove_from_indexes(approval.id, approval)
        self._update_indexes(approval, old_status)
        
        # Clean up dedup index if moving to terminal state
        if target_status in TERMINAL_STATES and approval.dedup_key:
            self._dedup_index.pop(approval.dedup_key, None)
        
        # Trigger callbacks
        self._trigger_callback('status_changed', approval)
        if target_status == ApprovalStatus.APPROVED:
            self._trigger_callback('approved', approval)
        elif target_status == ApprovalStatus.EXECUTED:
            self._trigger_callback('executed', approval)
        
        logger.debug(f"Approval {approval.id[:8]} changed {old_status} -> {target_status.value}")
        return True
    
    def approve(self, approval_id: str, by: str = "api") -> bool:
        """Approve a pending approval."""
        with self._lock:
            self.expire_old()
            approval = self._items.get(str(approval_id))
            if not approval:
                return False
            return self._set_status_locked(approval, ApprovalStatus.APPROVED, by=by)
    
    def reject(self, approval_id: str, by: str = "api") -> bool:
        """Reject a pending approval."""
        with self._lock:
            self.expire_old()
            approval = self._items.get(str(approval_id))
            if not approval:
                return False
            return self._set_status_locked(approval, ApprovalStatus.REJECTED, by=by)
    
    def mark_executed(self, approval_id: str, by: str = "engine") -> bool:
        """Mark approved approval as executed."""
        with self._lock:
            self.expire_old()
            approval = self._items.get(str(approval_id))
            if not approval:
                return False
            return self._set_status_locked(approval, ApprovalStatus.EXECUTED, by=by)
    
    def update_meta(self, approval_id: str, meta_updates: Dict[str, Any]) -> bool:
        """Update meta data of a pending approval."""
        with self._lock:
            approval = self._items.get(str(approval_id))
            if not approval or approval.is_terminal:
                return False
            
            # Validate size
            new_meta = {**approval.meta, **meta_updates}
            meta_size = len(json.dumps(new_meta))
            if meta_size > self.max_meta_size:
                return False
            
            approval.meta = new_meta
            approval.updated_ts = _now()
            self.save()
            return True
    
    # -------------------------
    # Callback System
    # -------------------------
    
    def register_callback(self, event: str, callback: Callable[[Approval], None]):
        """Register callback for approval events."""
        with self._lock:
            self._callbacks[event].append(callback)
    
    def _trigger_callback(self, event: str, *args, **kwargs):
        """Trigger callbacks for event."""
        for callback in self._callbacks.get(event, []):
            try:
                callback(*args, **kwargs)
            except Exception as e:
                logger.error(f"Callback error for event {event}: {e}")
    
    # -------------------------
    # Purge / Housekeeping
    # -------------------------
    
    def _purge_old_terminal(self) -> None:
        """Purge old terminal approvals to free memory."""
        if self.keep_terminal <= 0 and self.purge_after_sec <= 0:
            return
        
        with self._lock:
            now = _now()
            terminal_items = []
            
            # Collect terminal items
            for approval in self._items.values():
                if approval.is_terminal:
                    ts = float(approval.decided_ts or approval.created_ts)
                    terminal_items.append((ts, approval.id, approval))
            
            if not terminal_items:
                return
            
            # Sort by timestamp (oldest first)
            terminal_items.sort(key=lambda x: x[0])
            
            # Time-based purge
            to_delete = set()
            if self.purge_after_sec > 0:
                cutoff = now - self.purge_after_sec
                for ts, aid, approval in terminal_items:
                    if ts < cutoff:
                        to_delete.add(aid)
            
            # Count-based purge (keep newest)
            if self.keep_terminal > 0 and len(terminal_items) > self.keep_terminal:
                # Keep the newest N
                keep_count = min(self.keep_terminal, len(terminal_items))
                items_to_keep = terminal_items[-keep_count:]
                keep_ids = {aid for _, aid, _ in items_to_keep}
                
                for ts, aid, approval in terminal_items:
                    if aid not in keep_ids:
                        to_delete.add(aid)
            
            # Delete marked items
            for aid in to_delete:
                approval = self._items.pop(aid, None)
                if approval:
                    self._remove_from_indexes(aid, approval)
            
            if to_delete:
                logger.info(f"Purged {len(to_delete)} terminal approvals")
                self.save()
    
    def cleanup(self):
        """Force cleanup of all expired/old approvals."""
        with self._lock:
            self.expire_old()
            self._purge_old_terminal()
            self.save(force=True)
    
    # -------------------------
    # Utility Methods
    # -------------------------
    
    def export(self, filepath: str, format: str = 'json') -> bool:
        """Export approvals to file."""
        try:
            with self._lock:
                data = {
                    'export_time': _now(),
                    'count': len(self._items),
                    'approvals': [a.to_dict() for a in self._items.values()]
                }
                
                if format == 'json':
                    with open(filepath, 'w') as f:
                        json.dump(data, f, indent=2)
                elif format == 'csv':
                    import csv
                    with open(filepath, 'w', newline='') as f:
                        writer = csv.writer(f)
                        # Write header
                        writer.writerow(['id', 'status', 'symbol', 'side', 'qty', 
                                        'price_ref', 'reason', 'created', 'decided_by'])
                        # Write data
                        for a in self._items.values():
                            writer.writerow([
                                a.id[:8],
                                a.status,
                                a.symbol,
                                a.side,
                                a.qty,
                                a.price_ref,
                                a.reason[:50],
                                time.strftime('%Y-%m-%d %H:%M', time.localtime(a.created_ts)),
                                a.decided_by or ''
                            ])
                else:
                    return False
                
                return True
        except Exception as e:
            logger.error(f"Export failed: {e}")
            return False
    
    def __len__(self) -> int:
        """Get number of approvals."""
        with self._lock:
            return len(self._items)
    
    def __contains__(self, approval_id: str) -> bool:
        """Check if approval exists."""
        with self._lock:
            return approval_id in self._items
    
    def __iter__(self) -> Iterator[Approval]:
        """Iterate over approvals."""
        with self._lock:
            # Return a copy to avoid modification during iteration
            return iter(list(self._items.values()))
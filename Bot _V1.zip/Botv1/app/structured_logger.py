# test_structured_logger.py
import json
import time
import math
import threading
from dataclasses import dataclass
from unittest.mock import Mock, patch, MagicMock
import pytest
from structured_logger import (
    StructuredLogger,
    _lower,
    _utc_iso,
    _sanitize_jsonable,
    _safe_json,
    _redact,
    _json_dumps,
    SENSITIVE_KEYS,
)


# Test helper functions
def test_lower():
    assert _lower("  HELLO  ") == "hello"
    assert _lower(None) == ""
    assert _lower(123) == "123"


def test_utc_iso():
    # Test with current time
    now_iso = _utc_iso()
    assert "T" in now_iso  # ISO format has T separator
    assert now_iso.endswith("Z") or "+00:00" in now_iso  # UTC timezone
    
    # Test with specific timestamp
    fixed_ts = 1609459200.0  # 2021-01-01 00:00:00 UTC
    iso = _utc_iso(fixed_ts)
    assert "2021-01-01" in iso


def test_sanitize_jsonable():
    # Test with float special values
    assert _sanitize_jsonable(float('nan')) is None
    assert _sanitize_jsonable(float('inf')) is None
    assert _sanitize_jsonable(1.5) == 1.5
    
    # Test with dataclass
    @dataclass
    class TestData:
        name: str
        value: int
    
    data = TestData("test", 42)
    result = _sanitize_jsonable(data)
    assert result == {"name": "test", "value": 42}
    
    # Test with custom to_dict method
    class CustomClass:
        def to_dict(self):
            return {"custom": "data"}
    
    custom = CustomClass()
    assert _sanitize_jsonable(custom) == {"custom": "data"}
    
    # Test with set
    assert _sanitize_jsonable({1, 2, 3}) == [1, 2, 3]


def test_safe_json():
    # Test with normal data
    assert _safe_json({"key": "value"}) == {"key": "value"}
    
    # Test with unserializable object
    class Unserializable:
        def __repr__(self):
            return "<Unserializable>"
    
    result = _safe_json(Unserializable())
    assert result == "<Unserializable>"


def test_redact():
    # Test redaction of sensitive keys
    data = {
        "api_key": "secret123",
        "password": "mypass",
        "normal_key": "visible",
        "nested": {
            "access_token": "token123",
            "public_data": "ok"
        }
    }
    
    redacted = _redact(data, max_depth=3)
    assert redacted["api_key"] == "***REDACTED***"
    assert redacted["password"] == "***REDACTED***"
    assert redacted["normal_key"] == "visible"
    assert redacted["nested"]["access_token"] == "***REDACTED***"
    assert redacted["nested"]["public_data"] == "ok"
    
    # Test substring redaction
    data2 = {"my_secret_key": "should_be_redacted"}
    redacted2 = _redact(data2, redact_substring=True)
    assert redacted2["my_secret_key"] == "***REDACTED***"
    
    # Test truncation
    long_string = "x" * 5000
    truncated = _redact({"text": long_string}, max_str=100)
    assert "...(truncated)" in truncated["text"]
    assert len(truncated["text"]) < 150


def test_json_dumps():
    data = {"a": 1, "b": "test", "c": [1, 2, 3]}
    result = _json_dumps(data)
    # Should be compact JSON (no extra spaces)
    assert " " not in result
    parsed = json.loads(result)
    assert parsed == data


# Test StructuredLogger class
class TestStructuredLogger:
    @pytest.fixture
    def mock_logger(self):
        mock = Mock()
        mock.info = Mock()
        mock.debug = Mock()
        mock.error = Mock()
        mock.warning = Mock()
        mock.warn = Mock()  # For compatibility
        return mock
    
    @pytest.fixture
    def structured_logger(self, mock_logger):
        return StructuredLogger(
            log=mock_logger,
            throttle_sec_market=0.1,  # Short throttle for testing
            max_payload_str=1000,
            rate_limit_per_sec=1000,  # High limit for testing
        )
    
    def test_initialization(self, mock_logger):
        logger = StructuredLogger(
            log=mock_logger,
            throttle_sec_market=5.0,
            max_payload_str=2000,
            max_depth=5,
            max_list=100,
            redact_substring=False,
            rate_limit_per_sec=10.0,
            rate_burst=20,
        )
        
        assert logger.log == mock_logger
        assert logger.throttle_sec_market == 5.0
        assert logger.max_payload_str == 2000
        assert logger.max_depth == 5
        assert logger.max_list == 100
        assert logger.redact_substring is False
        assert logger._rate == 10.0
        assert logger._burst == 20
    
    def test_rate_limiter(self, structured_logger):
        # Test with high rate limit (should allow all)
        structured_logger._rate = 1000
        structured_logger._tokens = 1000
        assert structured_logger._allow() is True
        
        # Test with zero rate (should allow all)
        structured_logger._rate = 0
        assert structured_logger._allow() is True
        
        # Test with very low rate
        structured_logger._rate = 0.0001
        structured_logger._tokens = 0
        structured_logger._last_refill = time.time()
        # First call might succeed due to burst, then should fail
        # This is probabilistic, so we test conservatively
    
    def test_event_id_increment(self, structured_logger):
        first_id = structured_logger._next_event_id()
        second_id = structured_logger._next_event_id()
        assert second_id == first_id + 1
        
        # Test thread safety by calling from multiple threads
        ids = []
        
        def get_id():
            ids.append(structured_logger._next_event_id())
        
        threads = [threading.Thread(target=get_id) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # All IDs should be unique
        assert len(set(ids)) == 10
    
    def test_log_trade_decision(self, structured_logger, mock_logger):
        decision_data = {
            "action": "BUY",
            "quantity": 100,
            "price": 150.25,
            "reason": "momentum_signal"
        }
        
        structured_logger.log_trade_decision(
            symbol="AAPL",
            decision_data=decision_data,
            correlation_id="test-correlation-123"
        )
        
        # Verify logger was called
        assert mock_logger.info.called
        
        # Extract the logged message
        call_args = mock_logger.info.call_args[0][0]
        assert "[DECISION]" in call_args
        
        # Parse the JSON part
        json_str = call_args.split("[DECISION] ")[1]
        logged_data = json.loads(json_str)
        
        assert logged_data["symbol"] == "AAPL"
        assert logged_data["correlation_id"] == "test-correlation-123"
        assert "decision" in logged_data
        assert logged_data["decision"]["action"] == "BUY"
    
    def test_log_market_conditions_with_throttling(self, structured_logger, mock_logger):
        conditions = {
            "volume": 1000000,
            "bid_ask_spread": 0.05,
            "volatility": 0.15
        }
        
        # First call should log
        structured_logger.log_market_conditions(
            conditions=conditions,
            symbol="MSFT",
            throttle=True
        )
        
        assert mock_logger.debug.called
        mock_logger.debug.reset_mock()
        
        # Immediate second call should be throttled
        structured_logger.log_market_conditions(
            conditions=conditions,
            symbol="MSFT",
            throttle=True
        )
        
        assert not mock_logger.debug.called  # Should be throttled
        
        # Wait longer than throttle time and try again
        time.sleep(0.15)  # throttle_sec_market is 0.1 in fixture
        structured_logger.log_market_conditions(
            conditions=conditions,
            symbol="MSFT",
            throttle=True
        )
        
        assert mock_logger.debug.called  # Should log again
    
    def test_log_event_custom(self, structured_logger, mock_logger):
        event_data = {
            "user_id": 12345,
            "action": "login",
            "ip_address": "192.168.1.1"
        }
        
        structured_logger.log_event(
            kind="USER_ACTION",
            data=event_data,
            symbol=None,
            level="info",
            throttle_sec=0  # No throttling
        )
        
        assert mock_logger.info.called
        call_args = mock_logger.info.call_args[0][0]
        assert "[USER_ACTION]" in call_args
    
    def test_log_exception(self, structured_logger, mock_logger):
        try:
            raise ValueError("Test error occurred")
        except ValueError as e:
            structured_logger.log_exception(
                kind="APP_ERROR",
                exc=e,
                data={"context": "test_context"},
                symbol="BTC",
                level="error"
            )
        
        assert mock_logger.error.called
        call_args = mock_logger.error.call_args[0][0]
        logged_data = json.loads(call_args.split("[APP_ERROR] ")[1])
        
        assert "ValueError: Test error occurred" in logged_data["error"]
        assert logged_data["symbol"] == "BTC"
        assert logged_data["data"]["context"] == "test_context"
    
    def test_redaction_in_logging(self, structured_logger, mock_logger):
        # Test that sensitive data is redacted in actual logs
        sensitive_data = {
            "api_key": "sk_test_1234567890",
            "user": "john_doe",
            "password": "super_secret",
            "metadata": {
                "access_token": "eyJhbGciOiJ...",
                "public_info": "can be shown"
            }
        }
        
        structured_logger.log_event(
            kind="SENSITIVE_TEST",
            data=sensitive_data,
            level="info"
        )
        
        call_args = mock_logger.info.call_args[0][0]
        logged_data = json.loads(call_args.split("[SENSITIVE_TEST] ")[1])
        
        # Check redaction
        assert logged_data["data"]["api_key"] == "***REDACTED***"
        assert logged_data["data"]["password"] == "***REDACTED***"
        assert logged_data["data"]["metadata"]["access_token"] == "***REDACTED***"
        assert logged_data["data"]["user"] == "john_doe"  # Not redacted
        assert logged_data["data"]["metadata"]["public_info"] == "can be shown"
    
    def test_mirror_functions(self, mock_logger):
        # Test with both trace_emit and audit_write
        mock_trace = Mock()
        mock_audit = Mock()
        
        logger = StructuredLogger(
            log=mock_logger,
            trace_emit=mock_trace,
            audit_write=mock_audit
        )
        
        logger.log_event(
            kind="MIRROR_TEST",
            data={"test": "value"},
            level="info"
        )
        
        # Verify trace_emit was called
        assert mock_trace.called
        assert mock_trace.call_args[0][0] == "MIRROR_TEST"
        
        # Verify audit_write was called
        assert mock_audit.called
        audit_data = mock_audit.call_args[0][0]
        assert audit_data["type"] == "mirror_test"
        assert audit_data["level"] == "info"
    
    def test_json_special_values(self, structured_logger, mock_logger):
        # Test handling of NaN, Inf
        data_with_special = {
            "normal_float": 3.14,
            "nan_value": float('nan'),
            "inf_value": float('inf'),
            "neg_inf": float('-inf')
        }
        
        structured_logger.log_event(
            kind="SPECIAL_VALUES",
            data=data_with_special,
            level="debug"
        )
        
        call_args = mock_logger.debug.call_args[0][0]
        logged_data = json.loads(call_args.split("[SPECIAL_VALUES] ")[1])
        
        # JSON should serialize without errors
        assert logged_data["data"]["normal_float"] == 3.14
        assert logged_data["data"]["nan_value"] is None
        assert logged_data["data"]["inf_value"] is None
        assert logged_data["data"]["neg_inf"] is None
    
    def test_max_depth_truncation(self, structured_logger, mock_logger):
        # Create deeply nested data
        data = {"level1": {"level2": {"level3": {"level4": {"level5": "too_deep"}}}}}
        
        logger = StructuredLogger(
            log=mock_logger,
            max_depth=3  # Only go 3 levels deep
        )
        
        logger.log_event(
            kind="DEEP_DATA",
            data=data,
            level="info"
        )
        
        call_args = mock_logger.info.call_args[0][0]
        # Should not crash, may truncate or represent differently at max depth


# Performance and stress tests
def test_concurrent_logging():
    """Test that logger is thread-safe under concurrent access."""
    mock_logger = Mock()
    mock_logger.info = Mock()
    
    logger = StructuredLogger(
        log=mock_logger,
        rate_limit_per_sec=10000  # High limit for stress test
    )
    
    errors = []
    
    def log_concurrently(thread_id):
        try:
            for i in range(100):
                logger.log_event(
                    kind=f"THREAD_{thread_id}",
                    data={"iteration": i, "thread": thread_id},
                    level="info"
                )
        except Exception as e:
            errors.append(e)
    
    threads = [threading.Thread(target=log_concurrently, args=(i,)) for i in range(10)]
    
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    
    # Should have no exceptions
    assert len(errors) == 0
    # Should have logged many events
    assert mock_logger.info.call_count > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
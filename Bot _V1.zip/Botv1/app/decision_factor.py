from __future__ import annotations

import time
import hashlib
import math
import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional, List, Tuple
from functools import lru_cache

try:
    from .symbol_policy import SymbolPolicyStore
except Exception:  # optional dependency
    SymbolPolicyStore = None  # type: ignore


def _f(x: Any, d: float = 0.0) -> float:
    """Safe float conversion with default."""
    try:
        return float(x)
    except Exception:
        return float(d)


def _clamp(x: float, lo: float, hi: float) -> float:
    """Clamp value between bounds."""
    return max(lo, min(hi, x))


def _sha1(s: str) -> str:
    """Get first 12 chars of SHA1 hash."""
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:12]


def _now() -> float:
    """Current timestamp."""
    return time.time()


def _sigmoid_score(raw_score: float, midpoint: float = 0.5, steepness: float = 10.0) -> float:
    """Convert raw score to sigmoid-shaped value."""
    return 1.0 / (1.0 + math.exp(-steepness * (raw_score - midpoint)))


@dataclass
class MarketProfile:
    symbol: str
    side: str
    tf: str
    last_price: float
    atr_val: float
    atr_pct: float
    spread_bps: float = 0.0
    vol_quote_usd_24h: float = 0.0
    trend_strength: float = 0.0
    regime: str = "NA"
    liquidity_state: str = "OK"  # OK/LOW
    vol_state: str = "NORMAL"    # NORMAL/HIGH
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BacktestSummary:
    enabled: bool = False
    tactic_scores: Dict[str, float] = field(default_factory=dict)
    tactic_param_scores: Dict[str, Dict[str, float]] = field(default_factory=dict)
    best_tactic: str = "none"
    best_score: float = 0.0
    best_param_id: str = ""
    best_params: Dict[str, Any] = field(default_factory=dict)
    reason: str = "disabled"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TradePlan:
    plan_id: str
    symbol: str
    side: str
    tactic: str
    created_ts: float
    ttl_sec: int = 3600

    # Which tools are allowed
    allow_dca: bool = False
    allow_pyramid: bool = False

    trailing_mode: str = "atr"       # atr/step/structure/off
    execution_prefer: str = ""       # maker_limit/market/twap/iceberg

    # Risk/params overrides (merged on top of cfg['risk'])
    overrides: Dict[str, Any] = field(default_factory=dict)

    # Explainability/audit payload
    votes: Dict[str, Any] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)

    def is_expired(self) -> bool:
        return (_now() - float(self.created_ts)) > float(self.ttl_sec)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TradePlan':
        """Create TradePlan from dictionary."""
        return cls(**data)

    def serialize(self) -> str:
        """Serialize plan to JSON string."""
        return json.dumps(self.to_dict())


class DecisionFactor:
    """
    Single decision point to prevent conflicts between multiple trading tools.
    Builds ONE plan per symbol entry that drives execution + position management.

    Improvements:
      - actually uses weights to score across sources
      - stability controls (cooldown, min refresh)
      - guardrails: liquidity/spread/vol hard stops
      - richer explainability
      - optional bandit selection via SymbolPolicyStore
    """

    def __init__(self, cfg: Dict[str, Any], log: Any = None):
        self.cfg = cfg or {}
        self.log = log

        # last plan per symbol for stability
        self._last_plan: Dict[str, TradePlan] = {}
        self._last_plan_ts: Dict[str, float] = {}
        
        # Metrics collection
        self._metrics: List[Dict[str, Any]] = []

        self.symbol_policy = None

    def bind_symbol_policy(self, policy: Any) -> None:
        """Bind an optional SymbolPolicyStore instance."""
        if SymbolPolicyStore is not None and isinstance(policy, SymbolPolicyStore):
            self.symbol_policy = policy
        elif policy is not None:
            self._log("warning", f"Invalid policy type: {type(policy)}")
        else:
            self.symbol_policy = None

    def enabled(self) -> bool:
        return bool((self.cfg.get("decision_factor") or {}).get("enabled", False))

    def _cfg(self) -> Dict[str, Any]:
        return self.cfg.get("decision_factor") or {}

    @lru_cache(maxsize=1)
    def _weights(self) -> Dict[str, float]:
        w = (self._cfg().get("weights") or {})
        # Normalize weights (safe)
        ww = {
            "regime": _f(w.get("regime", 0.35), 0.35),
            "micro_model": _f(w.get("micro_model", 0.20), 0.20),
            "backtest": _f(w.get("backtest", 0.25), 0.25),
            "ai_brain": _f(w.get("ai_brain", 0.15), 0.15),
            "llm": _f(w.get("llm", 0.05), 0.05),
        }
        s = sum(max(0.0, v) for v in ww.values())
        if s <= 0:
            return ww
        return {k: (max(0.0, v) / s) for k, v in ww.items()}

    def _log(self, level: str, msg: str) -> None:
        try:
            if self.log is None:
                return
            fn = getattr(self.log, level, None)
            if callable(fn):
                fn(msg)
            else:
                getattr(self.log, "info", print)(msg)
        except Exception:
            pass

    def validate_config(self) -> List[str]:
        """Validate configuration and return errors."""
        errors = []
        df_cfg = self._cfg()
        
        if not isinstance(df_cfg.get("weights", {}), dict):
            errors.append("weights must be a dictionary")
        
        if df_cfg.get("plan_ttl_sec", 3600) <= 0:
            errors.append("plan_ttl_sec must be positive")
            
        min_refresh = df_cfg.get("plan_min_refresh_sec", 3.0)
        if min_refresh < 0:
            errors.append("plan_min_refresh_sec must be non-negative")
            
        min_score = df_cfg.get("min_total_score_to_trade", 0.0)
        if not (0.0 <= min_score <= 1.0):
            errors.append("min_total_score_to_trade must be between 0 and 1")
            
        return errors

    def _validate_market_profile(self, mp: MarketProfile) -> bool:
        """Validate market profile data quality."""
        if not mp.symbol or not mp.side:
            return False
        if mp.last_price <= 0:
            return False
        if mp.atr_val < 0 or mp.atr_pct < 0:
            return False
        if mp.spread_bps < 0:
            return False
        return True

    # -----------------------------
    # Guardrails / thresholds
    # -----------------------------
    def _guardrails(self, mp: MarketProfile) -> Tuple[bool, List[str]]:
        cfg = self._cfg()
        reasons: List[str] = []
        ok = True

        # liquidity hard floor
        min_liq = _f(cfg.get("min_liquidity_usd_24h", 0.0), 0.0)
        if min_liq > 0 and _f(mp.vol_quote_usd_24h, 0.0) < min_liq:
            ok = False
            reasons.append(f"guardrail:liquidity<{min_liq:.0f}")

        # spread hard ceiling
        max_spread_hard = _f(cfg.get("max_spread_bps_hard", 0.0), 0.0)
        if max_spread_hard > 0 and _f(mp.spread_bps, 0.0) > max_spread_hard:
            ok = False
            reasons.append(f"guardrail:spread>{max_spread_hard:.1f}bps")

        # volatility hard ceiling (atr_pct in fraction, e.g. 0.02 = 2%)
        max_atr_pct = _f(cfg.get("max_atr_pct_hard", 0.0), 0.0)
        if max_atr_pct > 0 and _f(mp.atr_pct, 0.0) > max_atr_pct:
            ok = False
            reasons.append(f"guardrail:atr_pct>{max_atr_pct:.4f}")

        # explicit low liquidity state
        if str(mp.liquidity_state).upper() == "LOW":
            ok = False
            reasons.append("guardrail:liquidity_state=LOW")

        return ok, reasons

    def _base_tactic_from_regime(self, regime: str, autonomy_decision: Optional[Dict[str, Any]]) -> str:
        r = (regime or "NA").upper()
        if r in ("TREND", "UPTREND", "DOWNTREND", "TREND_UP", "TREND_DOWN"):
            return "trend_follow"
        if r in ("RANGE", "MEAN_REVERT", "CHOP", "LOW_VOL", "LOW_VOLATILITY"):
            return "range_reversion"
        if r in ("HIGH_VOL_EVENT", "HIGH_VOL", "EVENT"):
            return "breakout"
        if r in ("LOW_LIQUID", "LOW_LIQ", "ILLQ"):
            return "none"

        # fallback: autonomy risk_mult decides activity level
        rm = _f((autonomy_decision or {}).get("risk_mult", 1.0), 1.0)
        return "trend_follow" if rm >= 1.0 else "range_reversion"

    def _tool_flags_for_tactic(self, tactic: str) -> Tuple[bool, bool, str]:
        t = str(tactic or "").lower().strip()
        allow_dca = False
        allow_pyramid = False
        trailing_mode = "atr"

        if t == "trend_follow":
            allow_pyramid = True
            trailing_mode = "step"
        elif t == "range_reversion":
            allow_dca = True
            trailing_mode = "atr"
        elif t == "scalp":
            trailing_mode = "off"
        elif t == "grid":
            trailing_mode = "off"
            allow_dca = False
            allow_pyramid = False
        elif t == "breakout":
            trailing_mode = "structure"
        elif t == "high_vol_event":
            trailing_mode = "off"

        # mutual exclusion guarantee
        if allow_dca and allow_pyramid:
            allow_dca = False

        return bool(allow_dca), bool(allow_pyramid), str(trailing_mode)

    def _exec_pref(self, tactic: str, mp: MarketProfile) -> str:
        cfg = self._cfg()
        # defaults from global execution.type
        default_exec = str(((self.cfg.get("execution") or {}).get("type") or "maker_limit")).strip().lower()

        # tactical hints
        if str(tactic).lower() in ("high_vol_event",):
            return "twap"

        maker_spread = _f(cfg.get("maker_spread_bps", 35.0), 35.0)
        if _f(mp.spread_bps, 0.0) > maker_spread:
            return "market"

        # low liquidity -> avoid maker
        if str(mp.liquidity_state).upper() == "LOW":
            return "market"

        return default_exec or "maker_limit"

    # -----------------------------
    # Scoring across sources
    # -----------------------------
    def _score_regime(self, mp: MarketProfile, tactic: str) -> float:
        """Heuristic mapping: favor tactic that matches regime + trend_strength."""
        r = (mp.regime or "NA").upper()
        t = str(tactic).lower()
        ts = _clamp(_f(mp.trend_strength, 0.0), 0.0, 1.0)

        if r in ("TREND", "UPTREND", "DOWNTREND", "TREND_UP", "TREND_DOWN"):
            return 0.6 + 0.4 * ts if t == "trend_follow" else (0.3 + 0.2 * ts if t == "breakout" else 0.2)
        if r in ("RANGE", "MEAN_REVERT", "CHOP", "LOW_VOL", "LOW_VOLATILITY"):
            return 0.7 if t == "range_reversion" else (0.4 if t == "scalp" else 0.2)
        if r in ("HIGH_VOL_EVENT", "HIGH_VOL", "EVENT"):
            return 0.7 if t in ("breakout", "scalp") else 0.2
        if r in ("LOW_LIQUID", "LOW_LIQ", "ILLQ"):
            return 0.0 if t != "none" else 1.0
        return 0.5 if t in ("trend_follow", "range_reversion") else 0.3

    def _score_micro_model(self, mp: MarketProfile, tactic: str) -> float:
        """
        Micro score based on spread + liquidity + vol_state.
        We keep it generic (we don't assume orderbook metrics always exist here).
        """
        t = str(tactic).lower()
        spread = _f(mp.spread_bps, 0.0)
        liq = _f(mp.vol_quote_usd_24h, 0.0)

        # normalize: lower spread -> higher score
        spread_score = 1.0 - _clamp(spread / 80.0, 0.0, 1.0)
        liq_score = _clamp(liq / max(1.0, _f((self._cfg().get("good_liquidity_usd_24h", 2_000_000.0)), 2_000_000.0)), 0.0, 1.0)

        base = 0.5 * spread_score + 0.5 * liq_score

        # punish grid/scalp in very wide spread
        if spread > 40 and t in ("grid", "scalp"):
            base *= 0.6

        # high volatility: discourage add-based tactics
        if str(mp.vol_state).upper() == "HIGH" and t in ("range_reversion", "trend_follow"):
            base *= 0.7

        return _clamp(base, 0.0, 1.0)

    def _score_backtest(self, backtest: Optional[BacktestSummary], tactic: str) -> float:
        if not backtest or not backtest.enabled:
            return 0.5  # neutral when absent
        s = _f((backtest.tactic_scores or {}).get(str(tactic), 0.0), 0.0)
        # assume backtest scores are already in a reasonable range; squash to 0..1
        # simple logistic-ish mapping
        return _clamp(0.5 + _clamp(s, -1.0, 1.0) * 0.5, 0.0, 1.0)

    def _score_adj(self, adj: Optional[Dict[str, Any]], key: str = "score") -> float:
        """Score from AI brain or LLM adjustment dicts (expected -1..+1 or 0..1)."""
        if not adj:
            return 0.5
        if key in adj:
            v = _f(adj.get(key), 0.5)
            if 0.0 <= v <= 1.0:
                return v
            return _clamp(0.5 + _clamp(v, -1.0, 1.0) * 0.5, 0.0, 1.0)
        # try common keys
        for k in ("confidence", "conf", "vote", "weight", "signal"):
            if k in adj:
                v = _f(adj.get(k), 0.5)
                if 0.0 <= v <= 1.0:
                    return v
                return _clamp(0.5 + _clamp(v, -1.0, 1.0) * 0.5, 0.0, 1.0)
        return 0.5

    def _total_score(
        self,
        tactic: str,
        mp: MarketProfile,
        backtest: Optional[BacktestSummary],
        ai_brain_adj: Optional[Dict[str, Any]],
        llm_adj: Optional[Dict[str, Any]],
    ) -> Tuple[float, Dict[str, float]]:
        w = self._weights()
        parts = {
            "regime": self._score_regime(mp, tactic),
            "micro_model": self._score_micro_model(mp, tactic),
            "backtest": self._score_backtest(backtest, tactic),
            "ai_brain": self._score_adj(ai_brain_adj),
            "llm": self._score_adj(llm_adj),
        }
        total = 0.0
        for k, wk in w.items():
            total += wk * _f(parts.get(k, 0.5), 0.5)
        return _clamp(total, 0.0, 1.0), {k: float(v) for k, v in parts.items()}

    def _cleanup_expired_cache(self, max_age_sec: int = 3600) -> None:
        """Remove expired entries from cache."""
        now = _now()
        expired = []
        
        for symbol, plan in list(self._last_plan.items()):
            if plan.is_expired() or (now - self._last_plan_ts.get(symbol, 0)) > max_age_sec:
                expired.append(symbol)
        
        for symbol in expired:
            self._last_plan.pop(symbol, None)
            self._last_plan_ts.pop(symbol, None)

    def record_plan_metrics(self, plan: TradePlan, duration_ms: float) -> None:
        """Record performance metrics for auditing."""
        metrics = {
            "symbol": plan.symbol,
            "tactic": plan.tactic,
            "duration_ms": duration_ms,
            "score": plan.votes.get("scores", {}).get("best", {}).get("total", 0),
            "timestamp": _now(),
            "reasons": plan.reasons
        }
        self._metrics.append(metrics)
        
        # Keep only last 1000 metrics
        if len(self._metrics) > 1000:
            self._metrics = self._metrics[-1000:]

    def get_metrics(self, last_n: int = 100) -> List[Dict[str, Any]]:
        """Get recent metrics."""
        return self._metrics[-last_n:] if self._metrics else []

    def build_plans_batch(
        self,
        symbols_data: List[Tuple[str, MarketProfile, ...]]
    ) -> Dict[str, TradePlan]:
        """Build plans for multiple symbols efficiently."""
        plans = {}
        for data in symbols_data:
            try:
                plan = self.build_plan(*data)
                plans[data[0]] = plan
            except Exception as e:
                self._log("error", f"Failed to build plan for {data[0]}: {e}")
        return plans

    # -----------------------------
    # Main plan builder
    # -----------------------------
    def build_plan(
        self,
        symbol: str,
        side: str,
        tf: str,
        market_profile: MarketProfile,
        autonomy_decision: Optional[Dict[str, Any]] = None,
        ai_brain_adj: Optional[Dict[str, Any]] = None,
        llm_adj: Optional[Dict[str, Any]] = None,
        backtest: Optional[BacktestSummary] = None,
        risk_state: Optional[Dict[str, Any]] = None,
    ) -> TradePlan:
        start_time = _now()
        
        cfg = self._cfg()
        ttl = int(cfg.get("plan_ttl_sec", 3600) or 3600)

        # Clean up expired cache entries periodically
        if len(self._last_plan) > 100:  # Arbitrary threshold
            self._cleanup_expired_cache()

        # Validate market profile
        if not self._validate_market_profile(market_profile):
            self._log("warning", f"Invalid market profile for {symbol}")
            # Create a default "none" plan
            return TradePlan(
                plan_id=_sha1(f"{symbol}|{side}|none|{_now()}"),
                symbol=symbol,
                side=side,
                tactic="none",
                created_ts=_now(),
                ttl_sec=ttl,
                reasons=["invalid_market_profile"]
            )

        # stability: if we built a plan too recently, keep it (unless expired)
        min_refresh = float(cfg.get("plan_min_refresh_sec", 3.0) or 3.0)
        lastp = self._last_plan.get(symbol)
        last_ts = float(self._last_plan_ts.get(symbol, 0.0))
        
        # Clean up expired plan
        if lastp and lastp.is_expired():
            self._last_plan.pop(symbol, None)
            self._last_plan_ts.pop(symbol, None)
            lastp = None
            last_ts = 0.0

        if lastp and not lastp.is_expired() and (_now() - last_ts) < min_refresh:
            return lastp

        reasons: List[str] = []
        votes: Dict[str, Any] = {
            "regime": (market_profile.regime or "NA").upper(),
            "market_profile": market_profile.to_dict(),
            "autonomy": autonomy_decision or {},
            "ai_brain": ai_brain_adj or {},
            "llm": llm_adj or {},
            "backtest": (backtest.to_dict() if backtest else None),
            "risk_state": risk_state or {},
        }

        # Guardrails
        ok, gr = self._guardrails(market_profile)
        reasons.extend(gr)

        # Risk state gating
        rs_state = str((risk_state or {}).get("state") or "").upper()
        if rs_state in ("HALT",):
            ok = False
            reasons.append("risk_state:HALT")
        if rs_state in ("RISK_OFF",):
            # allow only very selective entries (depending on cfg)
            if not bool(cfg.get("allow_entries_in_risk_off", False)):
                ok = False
                reasons.append("risk_state:RISK_OFF:no_entries")

        base_tactic = self._base_tactic_from_regime(market_profile.regime, autonomy_decision)
        tactic = base_tactic

        # Candidate tactics
        bandit_cfg = (cfg.get("bandit") or {}) if isinstance(cfg.get("bandit"), dict) else {}
        tactics_cand: List[str]
        cand = bandit_cfg.get("tactics")
        if isinstance(cand, list) and cand:
            tactics_cand = [str(t) for t in cand if t]
        else:
            tactics_cand = ["trend_follow", "range_reversion", "scalp", "grid", "breakout"]

        # Bandit selection if available
        if bool(bandit_cfg.get("enabled", True)) and self.symbol_policy is not None:
            method = str(bandit_cfg.get("method", "thompson")).lower()
            ucb_c = _f(bandit_cfg.get("ucb_c", 2.0), 2.0)
            try:
                chosen, bandit_scores = self.symbol_policy.select_tactic(symbol, tactics_cand, method=method, ucb_c=ucb_c)
                votes["bandit"] = {"chosen": chosen, "scores": bandit_scores, "method": method}
                if chosen:
                    tactic = str(chosen)
                    reasons.append(f"tactic_from_bandit:{tactic}")
            except Exception as e:
                self._log("warning", f"Bandit selection failed: {e}")

        # If bandit picked none but base is viable, keep base
        if tactic == "none" and base_tactic != "none":
            tactic = base_tactic
            reasons.append(f"fallback_to_base_tactic:{tactic}")

        # Score each candidate and pick best (this is the core missing piece previously)
        scores_map: Dict[str, Any] = {}
        best_tactic = tactic
        best_total = -1.0
        best_parts: Dict[str, float] = {}

        for t in (tactics_cand + [tactic]):
            tt = str(t).lower().strip()
            if not tt:
                continue
            total, parts = self._total_score(tt, market_profile, backtest, ai_brain_adj, llm_adj)
            scores_map[tt] = {"total": float(total), "parts": parts}
            if total > best_total:
                best_total = total
                best_tactic = tt
                best_parts = parts

        votes["scores"] = {"candidates": scores_map, "best": {"tactic": best_tactic, "total": float(best_total), "parts": best_parts}}
        tactic = best_tactic

        # Minimum confidence to trade
        min_score = _f(cfg.get("min_total_score_to_trade", 0.0), 0.0)
        if min_score > 0 and best_total < min_score:
            ok = False
            reasons.append(f"min_score_not_met:{best_total:.3f}<{min_score:.3f}")

        # If not ok -> force none
        if not ok:
            tactic = "none"

        # Tool flags from final tactic
        allow_dca, allow_pyramid, trailing_mode = self._tool_flags_for_tactic(tactic)

        # Risk state modifiers
        if rs_state in ("CAUTION", "RISK_OFF", "HALT"):
            if allow_dca:
                allow_dca = False
                reasons.append(f"risk_state:{rs_state}:disable_dca")

            if rs_state in ("RISK_OFF", "HALT") and allow_pyramid:
                allow_pyramid = False
                reasons.append(f"risk_state:{rs_state}:disable_pyramid")

        # High volatility: disable adds
        if str(market_profile.vol_state).upper() == "HIGH":
            if allow_dca:
                allow_dca = False
                reasons.append("high_vol:disable_dca")
            if allow_pyramid:
                allow_pyramid = False
                reasons.append("high_vol:disable_pyramid")

        # Execution preference hint
        exec_pref = self._exec_pref(tactic, market_profile)

        # Overrides per tactic
        overrides: Dict[str, Any] = {}
        tdefs = (cfg.get("tactics") or {})
        if isinstance(tdefs, dict) and tactic in tdefs and isinstance(tdefs.get(tactic), dict):
            overrides = dict(tdefs.get(tactic) or {})

        # Ensure trailing block exists and is consistent
        overrides.setdefault("trailing", {})
        if isinstance(overrides.get("trailing"), dict):
            overrides["trailing"]["mode"] = str(overrides["trailing"].get("mode") or trailing_mode)

        # Backtest: optionally override stop/tp multipliers if best params exist and match
        if backtest and backtest.enabled and str(tactic) == str(backtest.best_tactic) and isinstance(backtest.best_params, dict):
            bp = dict(backtest.best_params)
            if "stop_atr_mult" in bp:
                overrides["stop_atr_mult"] = _f(bp.get("stop_atr_mult"), _f(overrides.get("stop_atr_mult"), 0.0))
            if "tp_atr_mult" in bp:
                overrides["tp_atr_mult"] = _f(bp.get("tp_atr_mult"), _f(overrides.get("tp_atr_mult"), 0.0))
            overrides.setdefault("backtest", {})
            if isinstance(overrides.get("backtest"), dict):
                overrides["backtest"]["best_param_id"] = str(getattr(backtest, "best_param_id", "") or "")
            reasons.append("applied_backtest_best_params")

        # Plan ID (stable per minute)
        regime = (market_profile.regime or "NA").upper()
        key = (
            f"{symbol}|{side}|{tactic}|{regime}|"
            f"{_f(market_profile.atr_pct,0.0):.4f}|{_f(market_profile.spread_bps,0.0):.2f}|"
            f"{int(_now()//60)}"
        )
        plan_id = _sha1(key)

        plan = TradePlan(
            plan_id=plan_id,
            symbol=str(symbol),
            side=str(side),
            tactic=str(tactic),
            created_ts=_now(),
            ttl_sec=ttl,
            allow_dca=bool(allow_dca),
            allow_pyramid=bool(allow_pyramid),
            trailing_mode=str(trailing_mode),
            execution_prefer=str(exec_pref or ""),
            overrides=overrides or {},
            votes=votes,
            reasons=reasons,
        )

        # feedback hook to bandit (best-effort): store the chosen tactic with its score
        try:
            if self.symbol_policy is not None and hasattr(self.symbol_policy, "observe_choice"):
                self.symbol_policy.observe_choice(symbol, tactic, float(best_total))
        except Exception as e:
            self._log("warning", f"Bandit feedback failed: {e}")

        self._last_plan[symbol] = plan
        self._last_plan_ts[symbol] = _now()
        
        # Record metrics
        duration_ms = (_now() - start_time) * 1000
        self.record_plan_metrics(plan, duration_ms)
        
        return plan


# Test suite example
if __name__ == "__main__":
    import unittest
    
    class TestDecisionFactor(unittest.TestCase):
        def setUp(self):
            self.cfg = {
                "decision_factor": {
                    "enabled": True,
                    "weights": {"regime": 0.35, "micro_model": 0.20, "backtest": 0.25, "ai_brain": 0.15, "llm": 0.05},
                    "plan_ttl_sec": 3600,
                    "plan_min_refresh_sec": 3.0,
                    "min_total_score_to_trade": 0.3
                }
            }
            self.df = DecisionFactor(self.cfg)
            
        def test_guardrails(self):
            mp = MarketProfile("BTCUSDT", "buy", "1h", 50000, 1000, 0.02)
            ok, reasons = self.df._guardrails(mp)
            self.assertIsInstance(ok, bool)
            self.assertIsInstance(reasons, list)
            
        def test_weights(self):
            weights = self.df._weights()
            self.assertIsInstance(weights, dict)
            total = sum(weights.values())
            self.assertAlmostEqual(total, 1.0, places=6)
            
        def test_tool_flags(self):
            allow_dca, allow_pyramid, trailing_mode = self.df._tool_flags_for_tactic("trend_follow")
            self.assertEqual(allow_pyramid, True)
            self.assertEqual(trailing_mode, "step")
            
    # Run tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestDecisionFactor)
    unittest.TextTestRunner(verbosity=2).run(suite)
from __future__ import annotations

from typing import Any, Dict, Optional, List, Tuple, TypedDict, ClassVar
import pandas as pd
import numpy as np
from dataclasses import dataclass, field
import logging


# 1. Definirea structurilor de date cu TypedDict pentru o tipizare mai bună
class ValidationResult(TypedDict, total=False):
    """Rezultatul validării datelor OHLCV."""
    ok: bool
    reason: str
    warnings: List[str]
    quality: float
    rows: int
    nan_rows: int
    invalid_hl: int
    invalid_open: int
    invalid_close: int
    neg_volume_rows: int
    spikes: int
    ts_issues: int


class TickerValidationResult(TypedDict, total=False):
    """Rezultatul validării datelor ticker."""
    ok: bool
    reason: str
    warnings: List[str]


# 2. Configurație prin dataclass pentru o gestionare mai ușoară
@dataclass
class ValidatorConfig:
    """Configurație pentru validare."""
    # Praguri pentru detectarea spike-urilor
    spike_zscore_threshold: float = 8.0
    # Calitatea minimă pentru flag-ul 'ok'
    min_quality_threshold: float = 0.7
    # Numărul minim de rânduri pentru date valide
    min_valid_rows: int = 50
    # Prag pentru spread (în bps)
    max_spread_bps: float = 2000.0
    # Factor pentru distanța de la bid/ask
    bid_ask_distance_factor: float = 0.05
    # Dacă să folosească MAD sau STD pentru detectarea spike-urilor
    use_mad_for_spikes: bool = True
    # Ponderea pentru fiecare tip de problemă în calculul calității
    issue_weights: Dict[str, float] = field(default_factory=lambda: {
        'nan_rows': 1.0,
        'invalid_hl': 0.8,
        'invalid_open': 0.5,
        'invalid_close': 0.5,
        'neg_volume_rows': 0.3,
        'spikes': 0.7,
        'ts_issues': 0.4,
    })


# 3. Clasa principală cu îmbunătățiri
class DataValidator:
    """Validator pentru date financiare OHLCV."""
    
    # 3.1. Folosim ClassVar pentru constante
    REQUIRED_OHLCV: ClassVar[Tuple[str, ...]] = ("open", "high", "low", "close", "volume")
    OPTIONAL_COLUMNS: ClassVar[Tuple[str, ...]] = ("timestamp",)
    
    def __init__(self, config: Optional[ValidatorConfig] = None):
        """Initializează validatorul cu configurație opțională.
        
        Args:
            config: Configurație personalizată. Dacă None, se folosește configurația implicită.
        """
        self.config = config or ValidatorConfig()
        self.logger = logging.getLogger(__name__)
        
    def _coerce_to_numeric(self, df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
        """Coerchează coloanele la numeric într-un mod sigur.
        
        Args:
            df: DataFrame-ul de procesat
            columns: Lista de coloane de coerchat
            
        Returns:
            DataFrame cu coloanele coerchate la numeric
        """
        result = df.copy()
        for col in columns:
            if col in result.columns:
                result[col] = pd.to_numeric(result[col], errors="coerce")
        return result.replace([np.inf, -np.inf], np.nan)
    
    def _check_ohlc_integrity(self, df: pd.DataFrame) -> Dict[str, int]:
        """Verifică integritatea datelor OHLC.
        
        Args:
            df: DataFrame cu coloanele OHLCV
            
        Returns:
            Dicționar cu numărul de probleme pentru fiecare tip
        """
        required = list(self.REQUIRED_OHLCV)
        if not all(col in df.columns for col in required):
            raise ValueError(f"Lipsesc coloanele obligatorii: {required}")
            
        return {
            "bad_hl": int((df["high"] < df["low"]).sum()),
            "bad_open": int(((df["open"] < df["low"]) | (df["open"] > df["high"])).sum()),
            "bad_close": int(((df["close"] < df["low"]) | (df["close"] > df["high"])).sum()),
            "neg_vol": int((df["volume"] < 0).sum()),
        }
    
    def _detect_return_spikes(self, close_series: pd.Series) -> int:
        """Detectează spike-uri în randamente folosind MAD robust.
        
        Args:
            close_series: Serie cu prețurile de închidere
            
        Returns:
            Numărul de spike-uri detectate
        """
        if len(close_series) < 2:
            return 0
            
        ret = close_series.pct_change().replace([np.inf, -np.inf], np.nan).fillna(0.0)
        
        if ret.nunique() <= 1:  # Toate valorile sunt aceleași
            return 0
        
        if self.config.use_mad_for_spikes:
            # Robust scale via MAD
            med = np.nanmedian(ret.values)
            mad = np.nanmedian(np.abs(ret.values - med))
            
            # Evită împărțirea la zero
            if mad > 0:
                scale = mad * 1.4826  # Constantă pentru distribuție normală
            else:
                scale = np.nanstd(ret.values) or 1e-6
        else:
            # Folosește deviația standard clasică
            scale = np.nanstd(ret.values) or 1e-6
            med = np.nanmean(ret.values)
            
        if scale <= 0:
            scale = 1e-6
            
        z_scores = np.abs((ret - med) / scale)
        spikes = int((z_scores > self.config.spike_zscore_threshold).sum())
        
        return spikes
    
    def _check_timestamps(self, df: pd.DataFrame) -> Tuple[int, List[str]]:
        """Verifică problemele cu timestamp-urile.
        
        Args:
            df: DataFrame cu coloana timestamp (dacă există)
            
        Returns:
            Tuple cu numărul de probleme și lista de warning-uri
        """
        issues = 0
        warnings = []
        
        if "timestamp" not in df.columns:
            return issues, warnings
            
        try:
            # Coerchează timestamp-urile la numeric
            ts_series = pd.to_numeric(df["timestamp"], errors="coerce")
            
            # Verifică valori NaN
            nan_count = ts_series.isna().sum()
            if nan_count > 0:
                issues += int(nan_count)
                warnings.append(f"timestamp_has_nan:{nan_count}")
                
            # Verifică monotonicitate (doar pentru timestamp-uri valide)
            valid_ts = ts_series.dropna()
            if len(valid_ts) >= 2:
                if not valid_ts.is_monotonic_increasing:
                    issues += 1
                    warnings.append("timestamp_not_monotonic")
                    
                # Verifică timestamp-uri duplicate
                duplicates = valid_ts.duplicated().sum()
                if duplicates > 0:
                    issues += int(duplicates)
                    warnings.append(f"timestamp_duplicates:{duplicates}")
                    
                # Verifică intervale de timp neregulate
                if len(valid_ts) >= 3:
                    diffs = valid_ts.diff().dropna()
                    if diffs.nunique() > 1:  # Mai multe intervale diferite
                        cv = diffs.std() / diffs.mean() if diffs.mean() != 0 else 0
                        if cv > 0.5:  # Coeficient de variație mare
                            warnings.append(f"irregular_time_intervals:cv={cv:.2f}")
                    
        except Exception as e:
            self.logger.warning(f"Timestamp check failed: {e}")
            warnings.append("timestamp_check_failed")
            
        return issues, warnings
    
    def _calculate_quality_score(self, n_rows: int, issues: Dict[str, int]) -> float:
        """Calculează scorul de calitate al datelor.
        
        Args:
            n_rows: Numărul total de rânduri
            issues: Dicționar cu numărul de probleme pentru fiecare tip
            
        Returns:
            Scorul de calitate între 0 și 1
        """
        if n_rows == 0:
            return 0.0
            
        # Calculăm scorul total de probleme ponderate
        weighted_issues = 0
        for issue_type, count in issues.items():
            weight = self.config.issue_weights.get(issue_type, 0.5)
            weighted_issues += count * weight
        
        # Normalizare la numărul de rânduri
        normalized_score = weighted_issues / n_rows
        
        # Transformăm în scor de calitate (mai mare = mai bine)
        quality = max(0.0, 1.0 - normalized_score)
        
        # Ajustare pentru volume mici de date
        if n_rows < 100:
            # Penalizare liniară pentru volume mici
            quality *= (n_rows / 100)
            
        return round(quality, 4)
    
    def _collect_warnings(
        self, 
        n_rows: int, 
        issues: Dict[str, int], 
        ts_warnings: List[str]
    ) -> List[str]:
        """Colectează toate warning-urile într-o listă.
        
        Args:
            n_rows: Numărul de rânduri
            issues: Dicționar cu probleme
            ts_warnings: Warning-uri legate de timestamp-uri
            
        Returns:
            Lista cu toate warning-urile
        """
        warnings = ts_warnings.copy()
        
        if n_rows < self.config.min_valid_rows:
            warnings.append(f"few_rows:{n_rows}")
        if issues.get("nan_rows", 0) > 0:
            warnings.append(f"nan_rows:{issues['nan_rows']}")
        if issues.get("neg_volume_rows", 0) > 0:
            warnings.append(f"negative_volume_rows:{issues['neg_volume_rows']}")
        
        ohlc_issues = issues.get("invalid_hl", 0) + \
                     issues.get("invalid_open", 0) + \
                     issues.get("invalid_close", 0)
        if ohlc_issues > 0:
            warnings.append(f"invalid_ohlc_rows:{ohlc_issues}")
        
        if issues.get("spikes", 0) > 0:
            warnings.append(f"return_spikes:{issues['spikes']}")
            
        return warnings
    
    def _determine_failure_reason(
        self, 
        n_rows: int, 
        quality: float, 
        issues: Dict[str, int]
    ) -> Optional[str]:
        """Determină motivul eșecului validării.
        
        Args:
            n_rows: Numărul de rânduri
            quality: Scorul de calitate
            issues: Dicționar cu probleme
            
        Returns:
            String cu motivul eșecului sau None dacă validarea a trecut
        """
        if n_rows < self.config.min_valid_rows:
            return f"insufficient_rows:{n_rows}"
        elif quality < self.config.min_quality_threshold:
            return f"low_quality:{quality:.4f}"
        elif issues.get("nan_rows", 0) > 0:
            return f"has_nan_rows:{issues['nan_rows']}"
        elif issues.get("neg_volume_rows", 0) > 0:
            return f"has_negative_volume:{issues['neg_volume_rows']}"
        elif any(issues.get(k, 0) > 0 for k in ["invalid_hl", "invalid_open", "invalid_close"]):
            invalid_total = issues.get("invalid_hl", 0) + \
                           issues.get("invalid_open", 0) + \
                           issues.get("invalid_close", 0)
            return f"invalid_ohlc_rows:{invalid_total}"
        
        return None
    
    def detect_data_anomalies(self, df: pd.DataFrame) -> ValidationResult:
        """
        Detectează anomalii în datele OHLCV.
        
        Args:
            df: DataFrame cu date OHLCV
            
        Returns:
            ValidationResult: Dicționar cu rezultatele validării
        """
        if df is None or df.empty:
            return {"ok": False, "reason": "empty", "warnings": [], "quality": 0.0}
        
        # Verifică coloanele obligatorii
        missing_cols = [c for c in self.REQUIRED_OHLCV if c not in df.columns]
        if missing_cols:
            return {
                "ok": False, 
                "reason": f"missing_cols:{missing_cols}", 
                "warnings": [], 
                "quality": 0.0
            }
        
        # 1. Coerchează la numeric
        numeric_df = self._coerce_to_numeric(df, list(self.REQUIRED_OHLCV))
        n_rows = len(numeric_df)
        
        # 2. Numără rândurile cu NaN
        nan_rows = int(numeric_df[self.REQUIRED_OHLCV].isna().any(axis=1).sum())
        
        # 3. Verifică integritatea OHLC
        ohlc_issues = self._check_ohlc_integrity(numeric_df)
        
        # 4. Detectează spike-uri în randamente
        spikes = self._detect_return_spikes(numeric_df["close"])
        
        # 5. Verifică timestamp-uri
        ts_issues, ts_warnings = self._check_timestamps(df)  # Folosește df original pentru timestamp-uri
        
        # 6. Verifică date statistice suplimentare
        additional_warnings = []
        if n_rows > 0:
            # Verifică volume zero sau foarte mici
            volume_stats = numeric_df["volume"].describe()
            if volume_stats["min"] == 0:
                zero_volume = (numeric_df["volume"] == 0).sum()
                if zero_volume > n_rows * 0.1:  # Mai mult de 10% volume zero
                    additional_warnings.append(f"high_zero_volume:{zero_volume}")
            
            # Verifică variația prețului
            price_range = numeric_df["high"].max() - numeric_df["low"].min()
            if price_range == 0 and n_rows > 1:
                additional_warnings.append("zero_price_range")
            
            # Verifică valori extreme (outliers) pentru volume
            if n_rows >= 10:
                q75, q25 = np.percentile(numeric_df["volume"].dropna(), [75, 25])
                iqr = q75 - q25
                if iqr > 0:
                    upper_bound = q75 + 3 * iqr
                    extreme_volume = (numeric_df["volume"] > upper_bound).sum()
                    if extreme_volume > 0:
                        additional_warnings.append(f"extreme_volume_outliers:{extreme_volume}")
        
        # Compilează toate problemele
        all_issues = {
            "nan_rows": nan_rows,
            "invalid_hl": ohlc_issues["bad_hl"],
            "invalid_open": ohlc_issues["bad_open"],
            "invalid_close": ohlc_issues["bad_close"],
            "neg_volume_rows": ohlc_issues["neg_vol"],
            "spikes": spikes,
            "ts_issues": ts_issues,
        }
        
        # Calculează scorul de calitate
        quality = self._calculate_quality_score(n_rows, all_issues)
        
        # Determină dacă datele sunt ok
        failure_reason = self._determine_failure_reason(n_rows, quality, all_issues)
        ok_flag = failure_reason is None
        
        # Colectează toate warning-urile
        warnings = self._collect_warnings(n_rows, all_issues, ts_warnings)
        warnings.extend(additional_warnings)
        
        # Construiește rezultatul
        result: ValidationResult = {
            "ok": ok_flag,
            "rows": n_rows,
            "nan_rows": nan_rows,
            "invalid_hl": ohlc_issues["bad_hl"],
            "invalid_open": ohlc_issues["bad_open"],
            "invalid_close": ohlc_issues["bad_close"],
            "neg_volume_rows": ohlc_issues["neg_vol"],
            "spikes": spikes,
            "ts_issues": ts_issues,
            "warnings": warnings,
            "quality": quality,
        }
        
        # Adaugă motiv dacă nu e ok
        if not ok_flag:
            result["reason"] = failure_reason
        
        return result
    
    def validate_ticker_data(self, ticker: Dict[str, Any]) -> TickerValidationResult:
        """Validează datele ticker-ului.
        
        Args:
            ticker: Dicționar cu datele ticker-ului (last, bid, ask, etc.)
            
        Returns:
            TickerValidationResult: Rezultatul validării
        """
        if not ticker:
            return {"ok": False, "reason": "empty"}
        
        def safe_float(value: Any) -> Optional[float]:
            """Convertește în siguranță la float.
            
            Args:
                value: Valoarea de convertit
                
            Returns:
                Valoarea convertită la float sau None dacă nu se poate converti
            """
            if value is None:
                return None
            try:
                v = float(value)
                return v if np.isfinite(v) else None
            except (ValueError, TypeError):
                return None
        
        last = safe_float(ticker.get("last"))
        bid = safe_float(ticker.get("bid"))
        ask = safe_float(ticker.get("ask"))
        
        # Verifică valori invalide
        warnings: List[str] = []
        
        for field_name, value, converted in [
            ("last", ticker.get("last"), last),
            ("bid", ticker.get("bid"), bid),
            ("ask", ticker.get("ask"), ask),
        ]:
            if value is not None and converted is None:
                return {"ok": False, "reason": f"invalid_{field_name}:{value}"}
        
        # Verifică relațiile bid/ask
        if bid is not None and ask is not None:
            if bid > ask:
                return {"ok": False, "reason": f"bid_gt_ask:{bid}>{ask}"}
            
            # Calculează spread-ul
            if bid > 0 and ask > 0:
                spread_bps = (ask - bid) / ((bid + ask) / 2) * 10000
                if spread_bps > self.config.max_spread_bps:
                    warnings.append(f"huge_spread:{spread_bps:.1f}bps")
            
            # Verifică distanța last față de bid/ask
            if last is not None:
                if bid > 0 and last < bid * (1 - self.config.bid_ask_distance_factor):
                    warnings.append(f"last_below_bid:{last}<{bid}")
                if ask > 0 and last > ask * (1 + self.config.bid_ask_distance_factor):
                    warnings.append(f"last_above_ask:{last}>{ask}")
        
        return {"ok": True, "warnings": warnings}
    
    def sanitize_ohlcv(
        self, 
        df: pd.DataFrame, 
        *,
        min_rows: Optional[int] = None,
        drop_invalid_ohlc: bool = True,
        fix_timestamps: bool = True,
        remove_duplicates: bool = True,
        fill_method: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Sanitizează datele OHLCV.
        
        Args:
            df: DataFrame cu date OHLCV
            min_rows: Numărul minim de rânduri (suprascrie config)
            drop_invalid_ohlc: Dacă să elimine rândurile cu OHLC invalid
            fix_timestamps: Dacă să repare și să sorteze timestamp-urile
            remove_duplicates: Dacă să elimine duplicatele
            fill_method: Metoda de fill pentru valori lipsă (None, 'ffill', 'bfill')
            
        Returns:
            DataFrame sanitizat
        """
        if df is None or df.empty:
            return pd.DataFrame()
        
        # Folosește min_rows din config dacă nu e specificat
        min_rows = min_rows or self.config.min_valid_rows
        
        # Verifică coloanele obligatorii
        missing_required = [c for c in self.REQUIRED_OHLCV if c not in df.columns]
        if missing_required:
            self.logger.warning(f"Missing required columns: {missing_required}")
            # Întoarce DataFrame gol pentru a evita confuzii
            return pd.DataFrame()
        
        out = df.copy()
        
        # 1. Coerchează la numeric
        out = self._coerce_to_numeric(out, list(self.REQUIRED_OHLCV))
        
        # 2. Elimină rândurile cu NaN în coloanele obligatorii
        out = out.dropna(subset=list(self.REQUIRED_OHLCV))
        
        # 3. Fill values dacă este specificată o metodă
        if fill_method in ['ffill', 'bfill']:
            out[self.REQUIRED_OHLCV] = out[self.REQUIRED_OHLCV].fillna(method=fill_method)
        
        # 4. Asigură volume >= 0
        out = out[out["volume"] >= 0]
        
        # 5. Elimină OHLC invalid dacă este cerut
        if drop_invalid_ohlc:
            mask = (
                (out["high"] >= out["low"]) &
                (out["open"] >= out["low"]) & (out["open"] <= out["high"]) &
                (out["close"] >= out["low"]) & (out["close"] <= out["high"])
            )
            out = out[mask]
        
        # 6. Procesează timestamp-uri
        if fix_timestamps and "timestamp" in out.columns:
            try:
                # Coerchează timestamp-urile
                out["timestamp"] = pd.to_numeric(out["timestamp"], errors="coerce")
                
                # Elimină rândurile cu timestamp NaN
                out = out.dropna(subset=["timestamp"])
                
                # Sortează după timestamp
                out = out.sort_values("timestamp")
                
                # Elimină duplicatele dacă este cerut
                if remove_duplicates:
                    out = out.drop_duplicates(subset=["timestamp"], keep="last")
                
                # Reset index pentru un DataFrame mai curat
                out = out.reset_index(drop=True)
                
            except Exception as e:
                self.logger.warning(f"Failed to process timestamps: {e}")
        
        # 7. Verifică și ajustează extreme values dacă este necesar
        if len(out) > 0:
            # Corectează relațiile high-low dacă high < low (doar pentru afișare, nu pentru calcul)
            hl_invalid = out["high"] < out["low"]
            if hl_invalid.any():
                # Swap high și low unde high < low
                out.loc[hl_invalid, ["high", "low"]] = out.loc[hl_invalid, ["low", "high"]].values
        
        # 8. Verifică numărul minim de rânduri
        if len(out) < min_rows:
            self.logger.warning(f"Sanitized data has only {len(out)} rows, minimum is {min_rows}")
        
        return out
    
    def validate_and_sanitize(
        self, 
        df: pd.DataFrame, 
        **sanitize_kwargs
    ) -> Tuple[ValidationResult, pd.DataFrame]:
        """
        Combină validarea și sanitizarea într-un singur apel.
        
        Args:
            df: DataFrame cu date OHLCV
            **sanitize_kwargs: Argumente pentru metoda sanitize_ohlcv
            
        Returns:
            Tuple cu rezultatul validării și DataFrame-ul sanitizat
        """
        validation_result = self.detect_data_anomalies(df)
        sanitized_df = self.sanitize_ohlcv(df, **sanitize_kwargs)
        return validation_result, sanitized_df
    
    def generate_report(self, validation_result: ValidationResult) -> str:
        """Generează un raport text din rezultatul validării.
        
        Args:
            validation_result: Rezultatul validării
            
        Returns:
            String cu raportul formatat
        """
        lines = []
        lines.append("=" * 60)
        lines.append("DATA VALIDATION REPORT")
        lines.append("=" * 60)
        
        lines.append(f"Status: {'PASS' if validation_result['ok'] else 'FAIL'}")
        lines.append(f"Quality Score: {validation_result.get('quality', 0):.4f}")
        lines.append(f"Rows Analyzed: {validation_result.get('rows', 0)}")
        
        if not validation_result['ok']:
            lines.append(f"Failure Reason: {validation_result.get('reason', 'unknown')}")
        
        # Probleme detectate
        lines.append("\n--- Issues Detected ---")
        issues = [
            ("NaN Rows", validation_result.get('nan_rows', 0)),
            ("Invalid High-Low", validation_result.get('invalid_hl', 0)),
            ("Invalid Open Price", validation_result.get('invalid_open', 0)),
            ("Invalid Close Price", validation_result.get('invalid_close', 0)),
            ("Negative Volume", validation_result.get('neg_volume_rows', 0)),
            ("Return Spikes", validation_result.get('spikes', 0)),
            ("Timestamp Issues", validation_result.get('ts_issues', 0)),
        ]
        
        for issue_name, count in issues:
            if count > 0:
                lines.append(f"  {issue_name}: {count}")
        
        # Warning-uri
        warnings = validation_result.get('warnings', [])
        if warnings:
            lines.append("\n--- Warnings ---")
            for warning in warnings:
                lines.append(f"  • {warning}")
        
        lines.append("=" * 60)
        
        return "\n".join(lines)


# 4. Funcție de utilitate pentru setup rapid
def create_validator(
    spike_threshold: float = 8.0,
    min_quality: float = 0.7,
    min_rows: int = 50,
    max_spread_bps: float = 2000.0,
    use_mad: bool = True
) -> DataValidator:
    """Creează un validator cu configurație rapidă.
    
    Args:
        spike_threshold: Pragul Z-score pentru detectarea spike-urilor
        min_quality: Calitatea minimă acceptată
        min_rows: Numărul minim de rânduri
        max_spread_bps: Spread maxim acceptat în bps
        use_mad: Dacă să folosească MAD pentru detectarea spike-urilor
        
    Returns:
        Instanța DataValidator configurată
    """
    config = ValidatorConfig(
        spike_zscore_threshold=spike_threshold,
        min_quality_threshold=min_quality,
        min_valid_rows=min_rows,
        max_spread_bps=max_spread_bps,
        use_mad_for_spikes=use_mad
    )
    return DataValidator(config)


# 5. Exemplu de utilizare (pentru documentație)
if __name__ == "__main__":
    # Exemplu de utilizare a clasei
    print("Exemplu de utilizare DataValidator")
    print("-" * 40)
    
    # Creează date de test
    test_data = pd.DataFrame({
        'open': [100, 101, 102, 103, 104],
        'high': [105, 106, 107, 108, 109],
        'low': [99, 100, 101, 102, 103],
        'close': [104, 105, 106, 107, 108],
        'volume': [1000, 1100, 1200, 1300, 1400],
        'timestamp': [1, 2, 3, 4, 5]
    })
    
    # Creează validator
    validator = create_validator()
    
    # Validează datele
    result = validator.detect_data_anomalies(test_data)
    
    # Afișează raport
    print(validator.generate_report(result))
    
    # Sanitizează datele
    sanitized = validator.sanitize_ohlcv(test_data)
    print(f"\nDate sanitizate: {len(sanitized)} rânduri")
    
    # Validează ticker
    ticker_result = validator.validate_ticker_data({
        'bid': 100.5,
        'ask': 101.0,
        'last': 100.7
    })
    print(f"\nValidare ticker: {'OK' if ticker_result['ok'] else 'FAIL'}")
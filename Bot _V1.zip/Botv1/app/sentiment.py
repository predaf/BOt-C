# test_sentiment.py
import time
import threading
import json
from unittest.mock import Mock, patch, MagicMock
from dataclasses import dataclass
import pytest
import math

from sentiment import SentimentEngine, SentimentResult


# Mock provider classes
class MockNewsFeed:
    def __init__(self, scores=None, raise_exception=False, timeout=False):
        self.scores = scores or {}
        self.raise_exception = raise_exception
        self.timeout = timeout
        self.calls = []
    
    def score_for_symbol(self, symbol):
        self.calls.append(symbol)
        if self.timeout:
            time.sleep(2)  # Simulate timeout
            return 0.0
        if self.raise_exception:
            raise ValueError(f"Mock error for {symbol}")
        return self.scores.get(symbol.upper(), 0.0)


class MockOnChain:
    def __init__(self, scores=None, raise_exception=False):
        self.scores = scores or {}
        self.raise_exception = raise_exception
        self.calls = []
    
    def score_for_symbol(self, symbol):
        self.calls.append(symbol)
        if self.raise_exception:
            raise RuntimeError(f"Onchain error for {symbol}")
        return self.scores.get(symbol.upper(), 0.0)


# Test SentimentResult
def test_sentiment_result():
    result = SentimentResult(score=0.75, details={"source": "test"})
    assert result.score == 0.75
    assert result.details["source"] == "test"
    
    # Test dataclass conversion
    dict_repr = asdict(result)
    assert dict_repr["score"] == 0.75


class TestSentimentEngine:
    @pytest.fixture
    def mock_logger(self):
        logger = Mock()
        logger.info = Mock()
        logger.debug = Mock()
        logger.error = Mock()
        logger.warning = Mock()
        return logger
    
    @pytest.fixture
    def basic_config(self):
        return {
            "sentiment": {
                "enabled": True,
                "news_weight": 0.6,
                "onchain_weight": 0.4,
                "cache_ttl_sec": 5.0,
                "final_cache_ttl_sec": 2.0,
                "ema_alpha": 0.2,
                "provider_error_cooldown": 30.0,
                "provider_timeout_sec": 1.0,
                "provider_max_consecutive_errors": 3,
                "log_debug": True,
                "log_debug_every_sec": 10.0,
                "clamp_min": -1.0,
                "clamp_max": 1.0,
                "max_cache_items": 1000
            }
        }
    
    @pytest.fixture
    def engine_with_providers(self, basic_config, mock_logger):
        news = MockNewsFeed(scores={"BTCUSDT": 0.8, "ETHUSDT": -0.3})
        onchain = MockOnChain(scores={"BTCUSDT": 0.6, "ETHUSDT": 0.2})
        
        engine = SentimentEngine(
            cfg=basic_config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        return engine
    
    def test_initialization(self, basic_config, mock_logger):
        # Test with minimal config
        engine = SentimentEngine(cfg={}, log=mock_logger)
        assert not engine.enabled
        assert engine.news_w == 0.6  # Default values
        assert engine.onchain_w == 0.4
        
        # Test with custom config
        config = {
            "sentiment": {
                "enabled": True,
                "news_weight": 0.8,
                "onchain_weight": 0.2,
                "cache_ttl_sec": 10.0,
                "clamp_min": -2.0,
                "clamp_max": 2.0
            }
        }
        
        engine = SentimentEngine(cfg=config, log=mock_logger)
        assert engine.enabled
        assert engine.news_w == 0.8
        assert engine.onchain_w == 0.2
        assert engine.cache_ttl == 10.0
        assert engine.clamp_min == -2.0
        assert engine.clamp_max == 2.0
        
        # Test weight normalization
        config2 = {
            "sentiment": {
                "news_weight": 0.3,
                "onchain_weight": 0.9  # Sum > 1, should normalize
            }
        }
        
        engine2 = SentimentEngine(cfg=config2, log=mock_logger)
        total = engine2.news_w + engine2.onchain_w
        assert abs(total - 1.0) < 0.001
        
        # Test invalid weights
        config3 = {
            "sentiment": {
                "news_weight": "invalid",
                "onchain_weight": None
            }
        }
        
        engine3 = SentimentEngine(cfg=config3, log=mock_logger)
        assert engine3.news_w == 0.6  # Should fallback to defaults
        assert engine3.onchain_w == 0.4
    
    def test_clamp_and_safe_float(self, basic_config, mock_logger):
        engine = SentimentEngine(cfg=basic_config, log=mock_logger)
        
        # Test clamp
        assert engine._clamp(1.5, -1.0, 1.0) == 1.0
        assert engine._clamp(-1.5, -1.0, 1.0) == -1.0
        assert engine._clamp(0.3, -1.0, 1.0) == 0.3
        
        # Test safe_float
        assert engine._safe_float(3.14) == 3.14
        assert engine._safe_float("2.5") == 2.5
        assert engine._safe_float(None) == 0.0
        assert engine._safe_float(float('nan')) == 0.0
        assert engine._safe_float(float('inf')) == 0.0
        assert engine._safe_float("invalid", default=1.0) == 1.0
    
    def test_sanitize_details(self, basic_config, mock_logger):
        engine = SentimentEngine(cfg=basic_config, log=mock_logger)
        
        # Test with special values
        data = {
            "normal": 1.5,
            "nan": float('nan'),
            "inf": float('inf'),
            "neg_inf": float('-inf'),
            "list": [1, 2, float('nan')],
            "nested": {"key": float('inf')}
        }
        
        sanitized = engine._sanitize_details(data)
        
        # Should be JSON serializable
        json_str = json.dumps(sanitized)
        parsed = json.loads(json_str)
        
        assert parsed["normal"] == 1.5
        assert parsed["nan"] is None
        assert parsed["inf"] is None
        assert parsed["neg_inf"] is None
        assert parsed["list"][2] is None
        assert parsed["nested"]["key"] is None
        
        # Test with dataclass
        @dataclass
        class TestData:
            value: float
        
        test_obj = TestData(value=3.14)
        sanitized_obj = engine._sanitize_details(test_obj)
        assert sanitized_obj == {"value": 3.14}
    
    def test_basic_scoring(self, engine_with_providers, mock_logger):
        engine = engine_with_providers
        
        # Test basic score
        score = engine.score("BTCUSDT")
        assert -1.0 <= score <= 1.0  # Within clamp range
        
        # Test with details
        result = engine.score("BTCUSDT", with_details=True)
        assert isinstance(result, SentimentResult)
        assert -1.0 <= result.score <= 1.0
        assert "symbol" in result.details
        assert "news_raw" in result.details
        assert "onchain_raw" in result.details
        assert "combined_smooth" in result.details
        
        # Test EMA smoothing
        initial_score = result.score
        
        # Get another score quickly (should use cache)
        result2 = engine.score("BTCUSDT", with_details=True)
        assert result2.details.get("news_cached") is True
        assert result2.details.get("onchain_cached") is True
        
        # After multiple calls with same input, EMA should converge
        for _ in range(10):
            engine.score("BTCUSDT")
        
        final_result = engine.score("BTCUSDT", with_details=True)
        # Score should be smoothed by EMA
    
    def test_cache_functionality(self, basic_config, mock_logger):
        # Create engine with short cache TTL
        config = basic_config.copy()
        config["sentiment"]["cache_ttl_sec"] = 0.1  # Very short cache
        
        news = MockNewsFeed(scores={"BTCUSDT": 0.8})
        onchain = MockOnChain(scores={"BTCUSDT": 0.6})
        
        engine = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        # First call - should call providers
        engine.score("BTCUSDT")
        assert len(news.calls) == 1
        assert len(onchain.calls) == 1
        
        # Immediate second call - should use cache
        news.calls.clear()
        onchain.calls.clear()
        engine.score("BTCUSDT")
        assert len(news.calls) == 0  # Cached
        assert len(onchain.calls) == 0  # Cached
        
        # Wait for cache to expire
        time.sleep(0.15)
        engine.score("BTCUSDT")
        assert len(news.calls) == 1  # Cache expired, called again
        assert len(onchain.calls) == 1
        
        # Test final cache
        config["sentiment"]["final_cache_ttl_sec"] = 0.1
        engine2 = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        # Get initial score
        score1 = engine2.score("BTCUSDT")
        
        # Immediate call should use final cache
        score2 = engine2.score("BTCUSDT")
        assert score1 == score2  # Should be same due to final cache
        
        # Wait for final cache to expire
        time.sleep(0.15)
        score3 = engine2.score("BTCUSDT")
        # Might be different due to EMA or other factors
    
    def test_ema_functionality(self, basic_config, mock_logger):
        # Test EMA smoothing
        config = basic_config.copy()
        config["sentiment"]["ema_alpha"] = 0.5  # Strong smoothing
        
        news = MockNewsFeed(scores={"BTCUSDT": 0.8})
        onchain = MockOnChain(scores={"BTCUSDT": 0.6})
        
        engine = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        scores = []
        for i in range(5):
            # Change provider scores to see EMA effect
            if i > 0:
                news.scores["BTCUSDT"] = 0.9
                onchain.scores["BTCUSDT"] = 0.7
            
            score = engine.score("BTCUSDT")
            scores.append(score)
        
        # With alpha=0.5, scores should converge toward new value
        # but not immediately jump
        assert abs(scores[-1] - scores[-2]) < abs(scores[1] - scores[0])
    
    def test_provider_errors(self, basic_config, mock_logger):
        # Test error handling and backoff
        news = MockNewsFeed(raise_exception=True)
        onchain = MockOnChain(scores={"BTCUSDT": 0.5})
        
        engine = SentimentEngine(
            cfg=basic_config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        # First call - news will error
        result = engine.score("BTCUSDT", with_details=True)
        assert "news_error" in result.details
        assert result.details["providers_ok"]["news"] is False
        
        # News should be blocked for cooldown period
        assert engine._news_block_until > time.time()
        
        # Check error counter
        assert engine._news_err_count == 1
        
        # Simulate multiple consecutive errors
        for _ in range(5):
            try:
                engine.score("BTCUSDT")
            except:
                pass
        
        # After max_consecutive_errors, news should be disabled
        assert engine._news_err_count >= engine.max_consecutive_errors
        
        # With news disabled, only onchain should be used
        result = engine.score("BTCUSDT", with_details=True)
        weights = result.details["weights_effective"]
        assert weights["news"] == 0.0
        assert weights["onchain"] == 1.0  # Only onchain weight remains
    
    def test_provider_timeout(self, basic_config, mock_logger):
        # Test timeout functionality
        config = basic_config.copy()
        config["sentiment"]["provider_timeout_sec"] = 0.5  # Short timeout
        
        news = MockNewsFeed(timeout=True)  # Will sleep for 2 seconds
        onchain = MockOnChain(scores={"BTCUSDT": 0.5})
        
        engine = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        start_time = time.time()
        result = engine.score("BTCUSDT", with_details=True)
        elapsed = time.time() - start_time
        
        # Should timeout and return error quickly
        assert elapsed < 1.0  # Should be around timeout (0.5s)
        assert "news_error" in result.details
        assert "timeout" in str(result.details["news_error"]).lower()
        
        # Onchain should still work
        assert result.details["providers_ok"]["onchain"] is True
    
    def test_weight_adjustment(self, basic_config, mock_logger):
        # Test weight adjustment when one provider fails
        news = MockNewsFeed(scores={"BTCUSDT": 0.8})
        onchain = MockOnChain(raise_exception=True)  # Onchain will fail
        
        engine = SentimentEngine(
            cfg=basic_config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        # With onchain failing, effective weights should adjust
        result = engine.score("BTCUSDT", with_details=True)
        
        weights = result.details["weights_effective"]
        # News weight should be 1.0 (only working provider)
        # Onchain weight should be 0.0
        assert abs(weights["news"] - 1.0) < 0.001
        assert abs(weights["onchain"] - 0.0) < 0.001
        
        # Raw news score should be used
        assert abs(result.details["news_raw"] - 0.8) < 0.001
        assert result.details["onchain_raw"] == 0.0
        
        # Test with no providers
        engine2 = SentimentEngine(
            cfg=basic_config,
            log=mock_logger,
            news_feed=None,
            onchain=None
        )
        
        result2 = engine2.score("BTCUSDT", with_details=True)
        assert result2.details.get("reason") == "no_providers_available"
        assert result2.score == 0.0
    
    def test_clamping(self, basic_config, mock_logger):
        # Test score clamping
        config = basic_config.copy()
        config["sentiment"]["clamp_min"] = -0.5
        config["sentiment"]["clamp_max"] = 0.5
        
        # Provide extreme scores
        news = MockNewsFeed(scores={"BTCUSDT": 1.5})  # Above max
        onchain = MockOnChain(scores={"BTCUSDT": -0.8})  # Below min
        
        engine = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        result = engine.score("BTCUSDT", with_details=True)
        
        # Score should be clamped
        assert -0.5 <= result.score <= 0.5
        assert result.details["combined_raw"] <= 0.5
        assert result.details["combined_raw"] >= -0.5
        assert result.details["combined_smooth"] <= 0.5
        assert result.details["combined_smooth"] >= -0.5
    
    def test_tick_cache_cleanup(self, basic_config, mock_logger):
        # Test cache cleanup functionality
        config = basic_config.copy()
        config["sentiment"]["max_cache_items"] = 3  # Very small limit
        
        news = MockNewsFeed()
        onchain = MockOnChain()
        
        engine = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        # Fill cache with many items
        symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "ADAUSDT", "DOTUSDT"]
        for symbol in symbols:
            engine.score(symbol)
        
        # Initial cache sizes
        assert len(engine._last) == 5
        
        # Run tick to clean up
        engine.tick()
        
        # Should have removed some items
        assert len(engine._last) <= 4  # Removed ~20% (1 item)
        
        # Run tick multiple times
        for _ in range(10):
            engine.tick()
        
        # Should stay within limit
        assert len(engine._last) <= 3
    
    def test_last_method(self, engine_with_providers):
        engine = engine_with_providers
        
        # Get score
        score1 = engine.score("BTCUSDT")
        
        # Get last result
        last_result = engine.last("BTCUSDT")
        assert last_result is not None
        last_score, last_ts = last_result
        
        assert abs(last_score - score1) < 0.001
        assert last_ts <= time.time()
        
        # Test with unknown symbol
        assert engine.last("UNKNOWN") is None
        assert engine.last("") is None
        assert engine.last(None) is None
    
    def test_empty_symbol(self, engine_with_providers):
        # Test with empty or invalid symbol
        result = engine_with_providers.score("", with_details=True)
        assert result.score == 0.0
        assert result.details.get("reason") == "empty_symbol"
        
        result2 = engine_with_providers.score(None, with_details=True)
        assert result2.score == 0.0
    
    def test_disabled_engine(self, basic_config, mock_logger):
        # Test when engine is disabled
        config = basic_config.copy()
        config["sentiment"]["enabled"] = False
        
        engine = SentimentEngine(
            cfg=config,
            log=mock_logger,
            news_feed=MockNewsFeed(),
            onchain=MockOnChain()
        )
        
        result = engine.score("BTCUSDT", with_details=True)
        assert result.score == 0.0
        assert result.details.get("enabled") is False
    
    def test_thread_safety(self, basic_config, mock_logger):
        # Test concurrent access
        news = MockNewsFeed(scores={"BTCUSDT": 0.5})
        onchain = MockOnChain(scores={"BTCUSDT": 0.3})
        
        engine = SentimentEngine(
            cfg=basic_config,
            log=mock_logger,
            news_feed=news,
            onchain=onchain
        )
        
        results = []
        errors = []
        
        def worker(worker_id):
            try:
                for i in range(10):
                    score = engine.score(f"SYMBOL{worker_id % 3}")
                    results.append((worker_id, i, score))
                    time.sleep(0.001)
            except Exception as e:
                errors.append(e)
        
        # Create multiple threads
        threads = []
        for i in range(5):
            t = threading.Thread(target=worker, args=(i,))
            threads.append(t)
        
        for t in threads:
            t.start()
        
        for t in threads:
            t.join()
        
        # No errors should occur
        assert len(errors) == 0
        assert len(results) == 50  # 5 workers * 10 iterations
    
    def test_logging(self, basic_config):
        # Test debug logging
        logger = Mock()
        logger.info = Mock()
        
        config = basic_config.copy()
        config["sentiment"]["log_debug"] = True
        config["sentiment"]["log_debug_every_sec"] = 1.0  # Log every second
        
        engine = SentimentEngine(
            cfg=config,
            log=logger,
            news_feed=MockNewsFeed(scores={"BTCUSDT": 0.5}),
            onchain=MockOnChain(scores={"BTCUSDT": 0.3})
        )
        
        # First call should log (if enough time has passed since init)
        engine.score("BTCUSDT")
        
        # Mock the _log method to track calls
        log_calls = []
        original_log = engine._log
        engine._log = lambda level, msg: log_calls.append((level, msg))
        
        # Call multiple times quickly - should log based on throttle
        for _ in range(5):
            engine.score("BTCUSDT")
            time.sleep(0.1)  # Less than debug_every_sec
        
        # Should have logged at least once (depending on timing)
        # Restore original
        engine._log = original_log
        
        # Test with no logger
        engine2 = SentimentEngine(cfg=basic_config, log=None)
        # Should not crash
        engine2.score("BTCUSDT")


# Integration test with real providers (mocked)
def test_integration_with_mock_providers():
    """Test the engine with realistic mock providers."""
    
    # Create realistic mock providers
    class RealisticNewsFeed:
        def score_for_symbol(self, symbol):
            # Simulate API call
            time.sleep(0.01)
            # Return score based on symbol
            if "BTC" in symbol:
                return 0.7  # Generally positive for BTC
            elif "ETH" in symbol:
                return 0.3  # Moderately positive for ETH
            else:
                return 0.0  # Neutral for others
    
    class RealisticOnChain:
        def score_for_symbol(self, symbol):
            # Simulate blockchain data analysis
            time.sleep(0.01)
            # Return on-chain metrics
            if "BTC" in symbol:
                return 0.6  # Good on-chain metrics
            elif "ETH" in symbol:
                return 0.4  # Average metrics
            else:
                return -0.1  # Slightly negative
    
    config = {
        "sentiment": {
            "enabled": True,
            "news_weight": 0.7,  # Rely more on news
            "onchain_weight": 0.3,
            "cache_ttl_sec": 30.0,
            "ema_alpha": 0.3,
            "provider_timeout_sec": 2.0,
            "clamp_min": -1.0,
            "clamp_max": 1.0
        }
    }
    
    logger = Mock()
    engine = SentimentEngine(
        cfg=config,
        log=logger,
        news_feed=RealisticNewsFeed(),
        onchain=RealisticOnChain()
    )
    
    # Test multiple symbols
    symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "ADAUSDT"]
    
    for symbol in symbols:
        result = engine.score(symbol, with_details=True)
        print(f"{symbol}: Score={result.score:.3f}, "
              f"News={result.details.get('news_raw', 0):.3f}, "
              f"Onchain={result.details.get('onchain_raw', 0):.3f}")
        
        assert -1.0 <= result.score <= 1.0
        assert "weights_effective" in result.details


# Performance test
def test_performance():
    """Test engine performance with many symbols."""
    config = {
        "sentiment": {
            "enabled": True,
            "news_weight": 0.6,
            "onchain_weight": 0.4,
            "cache_ttl_sec": 10.0,
            "max_cache_items": 10000
        }
    }
    
    # Create providers with many symbols
    news_scores = {f"SYMBOL{i}": (i % 100) / 100.0 for i in range(1000)}
    onchain_scores = {f"SYMBOL{i}": ((i + 50) % 100) / 100.0 for i in range(1000)}
    
    news = MockNewsFeed(scores=news_scores)
    onchain = MockOnChain(scores=onchain_scores)
    
    engine = SentimentEngine(
        cfg=config,
        log=None,
        news_feed=news,
        onchain=onchain
    )
    
    import time
    start = time.time()
    
    # Score many symbols
    for i in range(100):
        engine.score(f"SYMBOL{i}")
    
    elapsed = time.time() - start
    print(f"Scored 100 symbols in {elapsed:.3f}s ({100/elapsed:.1f} symbols/sec)")
    
    # First calls are slower due to provider calls
    # Subsequent calls should be faster due to caching
    start = time.time()
    for i in range(100):
        engine.score(f"SYMBOL{i}")  # Already cached
    
    cached_elapsed = time.time() - start
    print(f"Cached scoring: {100/cached_elapsed:.1f} symbols/sec")
    
    assert cached_elapsed < elapsed  # Cached should be faster


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
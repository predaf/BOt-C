# app/audit.py
from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Dict, Optional


class AuditLogger:
    """Very small JSONL audit logger (thread-safe).

    This project had multiple audit implementations drifting in signatures.
    This version is intentionally minimal and *backward compatible* with the engine.

    Supported init patterns:
      - AuditLogger(path="logs/audit.jsonl", enabled=True, max_bytes=..., backup_count=...)
      - AuditLogger(config_like_dict_or_obj)  (best-effort)
    """

    def __init__(self, config: Any = None, **kwargs: Any):
        # Normalize kwargs from either config or explicit parameters
        enabled = True
        path = None
        max_bytes = 10_000_000
        backup_count = 5

        # config object/dict support (best-effort)
        if config is not None and not kwargs:
            if isinstance(config, dict):
                enabled = bool(config.get("enabled", True))
                path = config.get("path") or config.get("file_path") or config.get("base_path")
                max_bytes = int(config.get("max_bytes", max_bytes))
                backup_count = int(config.get("backup_count", backup_count))
            else:
                enabled = bool(getattr(config, "enabled", enabled))
                path = getattr(config, "path", None) or getattr(config, "file_path", None) or getattr(config, "base_path", None)
                max_bytes = int(getattr(config, "max_bytes", max_bytes))
                backup_count = int(getattr(config, "backup_count", backup_count))

        # explicit kwargs override
        if kwargs:
            if "enabled" in kwargs:
                enabled = bool(kwargs.get("enabled"))
            path = kwargs.get("path") or kwargs.get("file_path") or kwargs.get("base_path") or path
            if kwargs.get("max_bytes") is not None:
                max_bytes = int(kwargs.get("max_bytes"))
            if kwargs.get("backup_count") is not None:
                backup_count = int(kwargs.get("backup_count"))

        self.enabled = bool(enabled)
        self.path = str(path or "logs/audit.jsonl")
        self.max_bytes = int(max_bytes)
        self.backup_count = int(backup_count)

        self._lock = threading.RLock()
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)

    # --- public API used by engine ---
    def log(self, event: Any, level: str = "info") -> None:
        """Append an audit event as JSONL. Accepts dict/str/any."""
        if not self.enabled:
            return
        try:
            payload = self._normalize_event(event, level=level)
            line = json.dumps(payload, ensure_ascii=False)
            with self._lock:
                self._rotate_if_needed()
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
        except Exception:
            # audit must never crash the bot
            return

    def info(self, msg: Any, **data: Any) -> None:
        self.log(self._msg_payload(msg, data), level="info")

    def warn(self, msg: Any, **data: Any) -> None:
        self.log(self._msg_payload(msg, data), level="warning")

    def error(self, msg: Any, **data: Any) -> None:
        self.log(self._msg_payload(msg, data), level="error")

    def debug(self, msg: Any, **data: Any) -> None:
        self.log(self._msg_payload(msg, data), level="debug")

    # --- internals ---
    def _msg_payload(self, msg: Any, data: Dict[str, Any]) -> Dict[str, Any]:
        out = {"message": str(msg)}
        if isinstance(data, dict) and data:
            out["data"] = data
        return out

    def _normalize_event(self, event: Any, level: str) -> Dict[str, Any]:
        ts = time.time()

        if isinstance(event, dict):
            d = dict(event)
            # normalize timestamp aliases
            if "timestamp" not in d:
                if "ts" in d:
                    d["timestamp"] = d.get("ts")
                elif "time" in d:
                    d["timestamp"] = d.get("time")
            d.setdefault("timestamp", ts)

            # normalize level
            d.setdefault("level", level)
            if isinstance(d.get("level"), str):
                d["level"] = d["level"].lower()

            # normalize type/name
            d.setdefault("event_type", d.get("type") or d.get("action") or "event")
            return d

        if isinstance(event, str):
            return {"timestamp": ts, "level": level, "event_type": "log", "message": event}

        # fallback: best effort serialize
        try:
            return {"timestamp": ts, "level": level, "event_type": "log", "message": str(event)}
        except Exception:
            return {"timestamp": ts, "level": level, "event_type": "log", "message": "<unserializable>"}

    def _rotate_if_needed(self) -> None:
        try:
            if self.max_bytes <= 0:
                return
            if not os.path.exists(self.path):
                return
            if os.path.getsize(self.path) < self.max_bytes:
                return

            # rotate: audit.jsonl -> audit.jsonl.1 -> ... -> .N
            for i in range(self.backup_count - 1, 0, -1):
                src = f"{self.path}.{i}"
                dst = f"{self.path}.{i+1}"
                if os.path.exists(src):
                    try:
                        if os.path.exists(dst):
                            os.remove(dst)
                        os.replace(src, dst)
                    except Exception:
                        pass
            # move current to .1
            first = f"{self.path}.1"
            try:
                if os.path.exists(first):
                    os.remove(first)
                os.replace(self.path, first)
            except Exception:
                pass
        except Exception:
            return

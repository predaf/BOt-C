from __future__ import annotations

import time
import uuid
import math
import random
import json
from typing import Optional, Dict, Any, Literal, Tuple, Callable
from datetime import datetime, timedelta

try:
    import ccxt  # optional, used only for exception typing if available
except Exception:  # pragma: no cover
    ccxt = None


TradingMode = Literal["LIVE", "PAPER"]
Side = Literal["buy", "sell"]
OrderType = Literal["market", "limit"]
OrderStatus = Literal["open", "partial", "filled", "canceled", "rejected"]
ErrorCategory = Literal["auth", "funds", "validation", "network", "exchange", "system"]


# ----------------------------
# Metrics and Monitoring
# ----------------------------

class Metrics:
    """Simple metrics collector for monitoring trade execution"""
    
    _counters: Dict[str, int] = {}
    _timers: Dict[str, List[float]] = {}
    _gauges: Dict[str, float] = {}
    
    @classmethod
    def counter(cls, name: str, value: int = 1) -> None:
        """Increment a counter metric"""
        cls._counters[name] = cls._counters.get(name, 0) + value
    
    @classmethod
    def timer(cls, name: str, duration: float) -> None:
        """Record a timing metric"""
        if name not in cls._timers:
            cls._timers[name] = []
        cls._timers[name].append(duration)
        # Keep only last 1000 measurements
        if len(cls._timers[name]) > 1000:
            cls._timers[name] = cls._timers[name][-1000:]
    
    @classmethod
    def gauge(cls, name: str, value: float) -> None:
        """Set a gauge metric"""
        cls._gauges[name] = value
    
    @classmethod
    def get_metrics(cls) -> Dict[str, Any]:
        """Get all metrics for reporting"""
        return {
            "counters": dict(cls._counters),
            "timers": {
                name: {
                    "count": len(values),
                    "mean": sum(values) / len(values) if values else 0,
                    "p95": sorted(values)[int(len(values) * 0.95)] if values else 0,
                    "max": max(values) if values else 0,
                }
                for name, values in cls._timers.items()
            },
            "gauges": dict(cls._gauges),
        }
    
    @classmethod
    def reset(cls) -> None:
        """Reset all metrics (for testing)"""
        cls._counters.clear()
        cls._timers.clear()
        cls._gauges.clear()


# ----------------------------
# Configuration
# ----------------------------

class TradeConfig:
    """Configuration for trade execution"""
    
    def __init__(
        self,
        default_slippage_bps: float = 5.0,
        default_fee_bps: float = 10.0,
        default_partial_fill_prob: float = 0.0,
        default_partial_fill_min: float = 0.3,
        idempotency_ttl_sec: float = 300.0,
        max_idempotency_size: int = 1000,
        enable_distributed_cache: bool = False,
        redis_url: Optional[str] = None,
        circuit_breaker_threshold: int = 10,
        circuit_breaker_window_sec: int = 60,
    ):
        self.default_slippage_bps = default_slippage_bps
        self.default_fee_bps = default_fee_bps
        self.default_partial_fill_prob = default_partial_fill_prob
        self.default_partial_fill_min = default_partial_fill_min
        self.idempotency_ttl_sec = idempotency_ttl_sec
        self.max_idempotency_size = max_idempotency_size
        self.enable_distributed_cache = enable_distributed_cache
        self.redis_url = redis_url
        self.circuit_breaker_threshold = circuit_breaker_threshold
        self.circuit_breaker_window_sec = circuit_breaker_window_sec


# ----------------------------
# Circuit Breaker
# ----------------------------

class CircuitBreaker:
    """Circuit breaker pattern for exchange failures"""
    
    def __init__(self, threshold: int = 10, window_sec: int = 60):
        self.threshold = threshold
        self.window_sec = window_sec
        self.failures: List[Tuple[float, str]] = []
        self.tripped_until: Optional[float] = None
    
    def record_failure(self, error_code: str) -> None:
        """Record a failure occurrence"""
        now = time.time()
        self.failures.append((now, error_code))
        # Clean old failures
        cutoff = now - self.window_sec
        self.failures = [(ts, code) for ts, code in self.failures if ts > cutoff]
        
        # Check if we should trip
        if len(self.failures) >= self.threshold:
            self.tripped_until = now + self.window_sec
            Metrics.counter("circuit_breaker_tripped", 1)
    
    def record_success(self) -> None:
        """Record a success, potentially resetting the breaker"""
        now = time.time()
        # Reset if we have successes and enough time has passed
        if self.tripped_until and now > self.tripped_until:
            self.tripped_until = None
            self.failures.clear()
    
    def is_tripped(self) -> bool:
        """Check if circuit breaker is tripped"""
        if not self.tripped_until:
            return False
        if time.time() > self.tripped_until:
            self.tripped_until = None
            return False
        return True
    
    def get_state(self) -> Dict[str, Any]:
        """Get current circuit breaker state"""
        return {
            "tripped": self.is_tripped(),
            "tripped_until": self.tripped_until,
            "failure_count": len(self.failures),
            "threshold": self.threshold,
            "window_sec": self.window_sec,
        }


# ----------------------------
# small utils
# ----------------------------

def _norm_mode(trading_mode: str) -> str:
    tm = (trading_mode or "PAPER").strip().upper()
    if tm in ("PAPER", "SIM", "SIMULATED", "BACKTEST"):
        return "PAPER"
    if tm in ("LIVE", "REAL"):
        return "LIVE"
    return "INVALID"


def _norm_side(side: str) -> Optional[str]:
    s = (side or "").strip().lower()
    if s in ("buy", "b", "long"):
        return "buy"
    if s in ("sell", "s", "short"):
        return "sell"
    return None


def _safe_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        v = float(x)
        if not math.isfinite(v):
            return None
        return v
    except Exception:
        return None


def _safe_log(log: Any, level: str, msg: str) -> None:
    try:
        fn = getattr(log, level, None)
        if callable(fn):
            fn(msg)
            return
        fn2 = getattr(log, "info", None)
        if callable(fn2):
            fn2(msg)
    except Exception:
        pass


def _err(
    code: str, 
    message: str, 
    *, 
    retriable: bool = False,
    category: Optional[ErrorCategory] = None,
    **extra
) -> Dict[str, Any]:
    """Create standardized error response"""
    out = {
        "status": "error", 
        "code": code, 
        "error": message, 
        "retriable": bool(retriable),
        "category": category or "system",
        "ts": time.time()
    }
    if extra:
        out.update(extra)
    return out


def _classify_error(e: Exception) -> Tuple[str, bool, ErrorCategory]:
    """Classify an exception into error code, retriable flag, and category"""
    # Default classification
    code = "exchange_error"
    retriable = False
    category: ErrorCategory = "exchange"
    
    if ccxt is not None:
        try:
            if isinstance(e, getattr(ccxt, "AuthenticationError", ())):
                code = "auth_error"
                retriable = False
                category = "auth"
            elif isinstance(e, getattr(ccxt, "PermissionDenied", ())):
                code = "permission_denied"
                retriable = False
                category = "auth"
            elif isinstance(e, getattr(ccxt, "InsufficientFunds", ())):
                code = "insufficient_funds"
                retriable = False
                category = "funds"
            elif isinstance(e, getattr(ccxt, "InvalidOrder", ())):
                code = "invalid_order"
                retriable = False
                category = "validation"
            elif isinstance(e, getattr(ccxt, "InvalidAddress", ())):
                code = "invalid_address"
                retriable = False
                category = "validation"
            elif isinstance(e, getattr(ccxt, "RateLimitExceeded", ())):
                code = "rate_limited"
                retriable = True
                category = "exchange"
            elif isinstance(e, getattr(ccxt, "DDoSProtection", ())):
                code = "ddos_protection"
                retriable = True
                category = "network"
            elif isinstance(e, getattr(ccxt, "NetworkError", ())):
                code = "network_error"
                retriable = True
                category = "network"
            elif isinstance(e, getattr(ccxt, "ExchangeNotAvailable", ())):
                code = "exchange_not_available"
                retriable = True
                category = "exchange"
            elif isinstance(e, getattr(ccxt, "ExchangeError", ())):
                code = "exchange_error"
                retriable = True
                category = "exchange"
            elif isinstance(e, getattr(ccxt, "RequestTimeout", ())):
                code = "request_timeout"
                retriable = True
                category = "network"
        except Exception:
            pass
    else:
        # Fallback classification without ccxt
        error_str = str(e).lower()
        if "network" in error_str or "timeout" in error_str or "connection" in error_str:
            code = "network_error"
            retriable = True
            category = "network"
        elif "auth" in error_str or "permission" in error_str or "key" in error_str:
            code = "auth_error"
            retriable = False
            category = "auth"
        elif "balance" in error_str or "fund" in error_str:
            code = "insufficient_funds"
            retriable = False
            category = "funds"
    
    return code, retriable, category


# ----------------------------
# in-process idempotency cache with Redis support
# ----------------------------

_IDEMPOTENCY: Dict[str, Tuple[float, Optional[Dict[str, Any]]]] = {}
_DEFAULT_CONFIG = TradeConfig()


class IdempotencyCache:
    """Idempotency cache with support for distributed Redis cache"""
    
    def __init__(self, config: TradeConfig = _DEFAULT_CONFIG):
        self.config = config
        self.redis_client = None
        
        if config.enable_distributed_cache and config.redis_url:
            try:
                import redis
                self.redis_client = redis.Redis.from_url(config.redis_url, decode_responses=True)
                # Test connection
                self.redis_client.ping()
            except Exception as e:
                _safe_log(None, "warning", f"Failed to connect to Redis: {e}. Falling back to in-memory cache.")
                self.redis_client = None
    
    def get(self, coid: str) -> Optional[Dict[str, Any]]:
        """Get cached result for client order ID"""
        now = time.time()
        
        # Try Redis first if available
        if self.redis_client:
            try:
                cached = self.redis_client.get(f"idem:{coid}")
                if cached:
                    data = json.loads(cached)
                    stored_ts = data.get("_ts", 0)
                    if (now - stored_ts) < self.config.idempotency_ttl_sec:
                        return data.get("result")
                    else:
                        # Expired, delete it
                        self.redis_client.delete(f"idem:{coid}")
            except Exception as e:
                _safe_log(None, "warning", f"Redis get failed: {e}")
        
        # Fallback to in-memory cache
        self._prune_memory_cache()
        
        ent = _IDEMPOTENCY.get(coid)
        if not ent:
            return None
        
        ts0, res = ent
        if (now - float(ts0)) > self.config.idempotency_ttl_sec:
            _IDEMPOTENCY.pop(coid, None)
            return None
        return res  # may be None if "in-flight"
    
    def mark_inflight(self, coid: str) -> None:
        """Mark an order as in-flight to prevent duplicate execution"""
        now = time.time()
        
        if self.redis_client:
            try:
                # Store with short TTL for inflight marker
                data = {"_ts": now, "result": None, "_state": "inflight"}
                self.redis_client.setex(
                    f"idem:{coid}",
                    int(self.config.idempotency_ttl_sec),
                    json.dumps(data)
                )
            except Exception as e:
                _safe_log(None, "warning", f"Redis setex failed: {e}")
        
        # Always update memory cache as fallback
        _IDEMPOTENCY[coid] = (now, None)
    
    def store(self, coid: str, res: Dict[str, Any]) -> None:
        """Store final result for client order ID"""
        now = time.time()
        
        if self.redis_client:
            try:
                data = {"_ts": now, "result": dict(res), "_state": "completed"}
                self.redis_client.setex(
                    f"idem:{coid}",
                    int(self.config.idempotency_ttl_sec),
                    json.dumps(data)
                )
            except Exception as e:
                _safe_log(None, "warning", f"Redis setex failed: {e}")
        
        # Always update memory cache as fallback
        _IDEMPOTENCY[coid] = (now, dict(res))
    
    def _prune_memory_cache(self) -> None:
        """Prune old entries from in-memory cache"""
        if len(_IDEMPOTENCY) <= self.config.max_idempotency_size:
            return
        
        now = time.time()
        to_remove = []
        
        for k, (ts0, _) in _IDEMPOTENCY.items():
            if (now - float(ts0)) > self.config.idempotency_ttl_sec:
                to_remove.append(k)
        
        for k in to_remove:
            _IDEMPOTENCY.pop(k, None)
        
        # If still too large, remove oldest entries
        if len(_IDEMPOTENCY) > self.config.max_idempotency_size:
            sorted_keys = sorted(_IDEMPOTENCY.keys(), 
                               key=lambda k: _IDEMPOTENCY[k][0])
            for k in sorted_keys[:self.config.max_idempotency_size // 2]:
                _IDEMPOTENCY.pop(k, None)


# Global idempotency cache instance
_idem_cache = IdempotencyCache()


# ----------------------------
# Enhanced Simulation Engine
# ----------------------------

class OrderBookSimulator:
    """Simple order book simulator for PAPER mode"""
    
    def __init__(self, depth: int = 5, spread_bps: float = 2.0):
        self.depth = depth
        self.spread_bps = spread_bps
        self.order_book: Dict[str, List[Tuple[float, float]]] = {}
    
    def update_market_data(self, symbol: str, mid_price: float, volume: float = 100.0) -> None:
        """Update simulated order book for a symbol"""
        spread = mid_price * (self.spread_bps / 10000.0)
        bid_price = mid_price - spread / 2
        ask_price = mid_price + spread / 2
        
        bids = []
        asks = []
        
        for i in range(self.depth):
            # Simple depth simulation
            bid_level_price = bid_price * (1 - 0.001 * i)
            bid_level_volume = volume * (0.8 ** i)
            bids.append((bid_level_price, bid_level_volume))
            
            ask_level_price = ask_price * (1 + 0.001 * i)
            ask_level_volume = volume * (0.8 ** i)
            asks.append((ask_level_price, ask_level_volume))
        
        self.order_book[symbol] = {
            "bids": bids,  # (price, volume) sorted descending
            "asks": asks,  # (price, volume) sorted ascending
            "timestamp": time.time()
        }
    
    def simulate_limit_order(
        self,
        symbol: str,
        side: Side,
        price: float,
        amount: float,
        time_in_force: str = "GTC"
    ) -> Tuple[float, float, OrderStatus]:
        """
        Simulate limit order execution against order book
        
        Returns: (avg_fill_price, filled_amount, status)
        """
        if symbol not in self.order_book:
            return 0.0, 0.0, "open"
        
        order_book = self.order_book[symbol]
        remaining = amount
        filled = 0.0
        cost = 0.0
        
        if side == "buy":
            # Buy order: check if price >= ask prices
            for ask_price, ask_volume in order_book["asks"]:
                if price >= ask_price and remaining > 0:
                    fill_amount = min(remaining, ask_volume)
                    filled += fill_amount
                    cost += fill_amount * ask_price
                    remaining -= fill_amount
                else:
                    break
        else:  # sell
            # Sell order: check if price <= bid prices
            for bid_price, bid_volume in order_book["bids"]:
                if price <= bid_price and remaining > 0:
                    fill_amount = min(remaining, bid_volume)
                    filled += fill_amount
                    cost += fill_amount * bid_price
                    remaining -= fill_amount
                else:
                    break
        
        if filled == 0:
            return 0.0, 0.0, "open"
        
        avg_price = cost / filled if filled > 0 else 0.0
        
        if remaining > 0:
            return avg_price, filled, "partial"
        else:
            return avg_price, filled, "filled"


# Global order book simulator
_order_book_sim = OrderBookSimulator()


# ----------------------------
# main
# ----------------------------

def execute_trade(
    exchange: Any,
    trading_mode: str,
    symbol: str,
    side: str,
    amount: float,
    price: Optional[float] = None,
    *,
    order_type: Optional[str] = None,
    params: Optional[Dict[str, Any]] = None,
    client_order_id: Optional[str] = None,
    ticker: Optional[Dict[str, Any]] = None,
    log: Any = None,
    config: Optional[TradeConfig] = None,
    circuit_breaker: Optional[CircuitBreaker] = None,
) -> Dict[str, Any]:
    """Routes orders based on trading_mode and returns a standardized response."""
    global _idem_cache
    
    # Start timing
    exec_start = time.time()
    Metrics.counter(f"trade_execution_total", 1)
    
    # Use provided config or default
    cfg = config or _DEFAULT_CONFIG
    
    # Initialize circuit breaker if not provided
    if circuit_breaker is None:
        circuit_breaker = CircuitBreaker(
            threshold=cfg.circuit_breaker_threshold,
            window_sec=cfg.circuit_breaker_window_sec
        )
    
    # Check circuit breaker
    if circuit_breaker.is_tripped():
        Metrics.counter("trade_execution_circuit_tripped", 1)
        return _err(
            "circuit_breaker_tripped",
            "Trading temporarily suspended due to repeated failures",
            retriable=True,
            category="system",
            tripped_until=circuit_breaker.tripped_until,
            request_time=exec_start
        )
    
    ts = time.time()
    tm = _norm_mode(trading_mode)
    sym = (symbol or "").strip()
    s = _norm_side(side)
    amt = _safe_float(amount)
    prc = _safe_float(price)
    
    # Validation
    if tm == "INVALID":
        return _err("invalid_mode", f"invalid trading_mode={trading_mode!r}", 
                   trading_mode=trading_mode, category="validation")
    
    if not sym:
        return _err("invalid_symbol", "symbol is required", 
                   symbol=symbol, category="validation")
    
    if s is None:
        return _err("invalid_side", f"invalid side={side!r}", 
                   side=side, category="validation")
    
    if amt is None or amt <= 0:
        return _err("invalid_amount", f"amount must be > 0 (got {amount!r})", 
                   amount=amount, category="validation")
    
    ot = (order_type or "").strip().lower()
    if ot not in ("market", "limit", ""):
        return _err("invalid_order_type", f"order_type must be market|limit (got {order_type!r})", 
                   order_type=order_type, category="validation")
    
    # infer order type
    if not ot:
        ot = "limit" if prc is not None else "market"
    
    if ot == "limit":
        if prc is None or prc <= 0:
            return _err("invalid_price", f"limit price must be > 0 (got {price!r})", 
                       price=price, category="validation")
    else:
        prc = None
    
    p = dict(params or {})
    
    # idempotency key
    coid = (client_order_id or "").strip()
    if not coid:
        coid = f"bot-{uuid.uuid4().hex[:16]}"
    
    # fast idempotency guard
    prev = _idem_cache.get(coid)
    if prev is not None:
        # already executed recently
        out = dict(prev)
        out.setdefault("meta", {})
        out["meta"]["idempotent_replay"] = True
        Metrics.counter("trade_execution_idempotent_hit", 1)
        return out
    
    # mark inflight
    _idem_cache.mark_inflight(coid)
    
    # attach coid for traceability (some exchanges honor it)
    p.setdefault("clientOrderId", coid)
    
    # Prepare request metadata
    request = {
        "ts": ts,
        "mode": tm,
        "symbol": sym,
        "side": s,
        "amount": float(amt),
        "order_type": ot,
        "price": float(prc) if prc is not None else None,
        "params": p,
        "client_order_id": coid,
    }
    
    # Update global idempotency cache config if needed
    if config and config != _DEFAULT_CONFIG:
        _idem_cache = IdempotencyCache(config)
    
    # -------------------------
    # PAPER (simulation)
    # -------------------------
    if tm == "PAPER":
        Metrics.counter("trade_execution_paper", 1)
        
        # configurable sim knobs
        sim_cfg = {}
        try:
            sim_cfg = ((p.get("sim") or {}) if isinstance(p.get("sim"), dict) else {})
        except Exception:
            sim_cfg = {}
        
        # Use config defaults if not specified in params
        slip_bps = float(sim_cfg.get("slippage_bps", cfg.default_slippage_bps))
        fee_bps = float(sim_cfg.get("fee_bps", cfg.default_fee_bps))
        partial_prob = float(sim_cfg.get("partial_fill_prob", cfg.default_partial_fill_prob))
        partial_min = float(sim_cfg.get("partial_fill_min", cfg.default_partial_fill_min))
        use_orderbook = bool(sim_cfg.get("use_orderbook", False))
        
        bid = _safe_float((ticker or {}).get("bid"))
        ask = _safe_float((ticker or {}).get("ask"))
        last = _safe_float((ticker or {}).get("last"))
        
        # choose reference price
        ref = None
        if bid is not None and ask is not None and ask >= bid:
            ref = (bid + ask) / 2.0
        elif last is not None:
            ref = last
        elif prc is not None:
            ref = prc
        
        fill_price: Optional[float] = None
        fill_status: OrderStatus = "open"
        filled_amt = 0.0
        
        if ot == "market":
            if ref is not None:
                # apply slippage against trader
                slip = (slip_bps / 10_000.0) * ref
                fill_price = ref + slip if s == "buy" else ref - slip
                fill_status = "filled"
                filled_amt = float(amt)
        else:
            # limit order
            if prc is not None and ref is not None:
                # Enhanced simulation with order book if available
                if use_orderbook:
                    # Update order book simulator
                    _order_book_sim.update_market_data(sym, ref)
                    # Simulate against order book
                    avg_price, filled, status = _order_book_sim.simulate_limit_order(
                        sym, s, prc, amt
                    )
                    if filled > 0:
                        fill_price = avg_price
                        filled_amt = filled
                        fill_status = status
                else:
                    # Simple crossing logic (backward compatible)
                    if s == "buy":
                        crossed = (ask is not None and prc >= ask) or (last is not None and prc >= last)
                    else:
                        crossed = (bid is not None and prc <= bid) or (last is not None and prc <= last)
                    
                    if crossed:
                        fill_price = ref
                        fill_status = "filled"
                        filled_amt = float(amt)
        
        # partial fill simulation (only for market orders or crossed limit orders)
        if fill_status in ("filled", "partial") and partial_prob > 0.0 and random.random() < partial_prob:
            frac = max(float(partial_min), random.random())
            filled_amt = float(amt) * float(frac)
            if filled_amt < float(amt):
                fill_status = "partial"
        
        # Calculate fees and notional
        notional = (filled_amt * float(fill_price)) if (fill_price is not None) else 0.0
        fee = notional * (fee_bps / 10_000.0) if notional > 0 else 0.0
        
        sim_id = f"paper-{uuid.uuid4().hex[:12]}"
        latency_ms = int((time.time() - ts) * 1000)
        
        res = {
            "status": "ok",
            "simulated": True,
            "ts": ts,
            "id": sim_id,
            "clientOrderId": coid,
            "symbol": sym,
            "side": s,
            "type": ot,
            "amount": float(amt),
            "price": float(prc) if prc is not None else None,
            "fill_price": float(fill_price) if fill_price is not None else None,
            "fill_status": fill_status,
            "filled_amount": float(filled_amt),
            "remaining_amount": float(amt) - float(filled_amt),
            "fee_est": float(fee),
            "notional": float(notional),
            "request": request,
            "meta": {
                "latency_ms": latency_ms,
                "retriable": False,
                "exchange_id": getattr(exchange, "id", None),
                "mode": tm,
                "sim_config": {
                    "slippage_bps": slip_bps,
                    "fee_bps": fee_bps,
                    "partial_fill_prob": partial_prob,
                    "partial_fill_min": partial_min,
                    "use_orderbook": use_orderbook,
                },
            },
        }
        
        _idem_cache.store(coid, res)
        Metrics.timer("trade_execution_paper_latency", latency_ms / 1000.0)
        Metrics.counter(f"trade_paper_{ot}_{s}", 1)
        
        return res
    
    # -------------------------
    # LIVE
    # -------------------------
    Metrics.counter("trade_execution_live", 1)
    
    t0 = time.time()
    try:
        if not hasattr(exchange, "create_order"):
            res = _err("invalid_exchange", "exchange has no create_order()", 
                      exchange=str(type(exchange)), category="system")
            _idem_cache.store(coid, res)
            return res
        
        # Market order: avoid passing price=None if exchange wrapper is strict.
        if ot == "limit":
            raw = exchange.create_order(sym, "limit", s, float(amt), float(prc), p)
        else:
            raw = exchange.create_order(sym, "market", s, float(amt), None, p)
        
        # Record success for circuit breaker
        circuit_breaker.record_success()
        
        # normalize result
        order_id = None
        if isinstance(raw, dict):
            order_id = raw.get("id") or raw.get("orderId") or raw.get("clientOrderId")
        
        latency_ms = int((time.time() - t0) * 1000)
        res = {
            "status": "ok",
            "ts": ts,
            "id": order_id or f"live-{uuid.uuid4().hex[:12]}",
            "clientOrderId": coid,
            "symbol": sym,
            "side": s,
            "type": ot,
            "amount": float(amt),
            "price": float(prc) if prc is not None else None,
            "raw": raw,
            "request": request,
            "meta": {
                "latency_ms": latency_ms,
                "retriable": False,
                "exchange_id": getattr(exchange, "id", None),
                "mode": tm,
            },
        }
        
        _idem_cache.store(coid, res)
        Metrics.timer("trade_execution_live_latency", latency_ms / 1000.0)
        Metrics.counter(f"trade_live_{ot}_{s}", 1)
        Metrics.gauge(f"last_trade_latency_{getattr(exchange, 'id', 'unknown')}", latency_ms)
        
        return res
    
    except Exception as e:
        # Classify error
        code, retriable, category = _classify_error(e)
        
        # Record failure for circuit breaker
        circuit_breaker.record_failure(code)
        
        _safe_log(log, "warning", f"[execute_trade] {code}: {e} | {request}")
        
        latency_ms = int((time.time() - t0) * 1000)
        res = _err(
            code,
            str(e),
            retriable=retriable,
            category=category,
            symbol=sym,
            side=s,
            amount=float(amt),
            price=float(prc) if prc is not None else None,
            order_type=ot,
            clientOrderId=coid,
            request=request,
            meta={
                "latency_ms": latency_ms,
                "retriable": retriable,
                "exchange_id": getattr(exchange, "id", None),
                "mode": tm,
                "error_type": type(e).__name__,
                "circuit_breaker_state": circuit_breaker.get_state(),
            },
        )
        
        _idem_cache.store(coid, res)
        Metrics.counter(f"trade_error_{code}", 1)
        Metrics.counter(f"trade_error_category_{category}", 1)
        
        return res
    finally:
        # Record total execution time
        total_time = time.time() - exec_start
        Metrics.timer("trade_execution_total_time", total_time)


# ----------------------------
# Additional utility functions
# ----------------------------

def cancel_order(
    exchange: Any,
    trading_mode: str,
    symbol: str,
    order_id: str,
    *,
    client_order_id: Optional[str] = None,
    params: Optional[Dict[str, Any]] = None,
    log: Any = None,
) -> Dict[str, Any]:
    """Cancel an existing order"""
    
    ts = time.time()
    tm = _norm_mode(trading_mode)
    sym = (symbol or "").strip()
    
    if tm == "INVALID":
        return _err("invalid_mode", f"invalid trading_mode={trading_mode!r}", 
                   trading_mode=trading_mode, category="validation")
    
    if not sym:
        return _err("invalid_symbol", "symbol is required", 
                   symbol=symbol, category="validation")
    
    if not order_id:
        return _err("invalid_order_id", "order_id is required", 
                   order_id=order_id, category="validation")
    
    p = dict(params or {})
    
    # PAPER mode: just simulate cancellation
    if tm == "PAPER":
        sim_id = f"cancel-paper-{uuid.uuid4().hex[:8]}"
        return {
            "status": "ok",
            "simulated": True,
            "ts": ts,
            "id": order_id,
            "clientOrderId": client_order_id,
            "symbol": sym,
            "cancelled": True,
            "sim_id": sim_id,
            "meta": {
                "mode": tm,
                "exchange_id": getattr(exchange, "id", None),
            },
        }
    
    # LIVE mode
    try:
        if not hasattr(exchange, "cancel_order"):
            return _err("invalid_exchange", "exchange has no cancel_order()", 
                       exchange=str(type(exchange)), category="system")
        
        raw = exchange.cancel_order(order_id, sym, p)
        
        return {
            "status": "ok",
            "ts": ts,
            "id": order_id,
            "clientOrderId": client_order_id,
            "symbol": sym,
            "cancelled": True,
            "raw": raw,
            "meta": {
                "exchange_id": getattr(exchange, "id", None),
                "mode": tm,
            },
        }
    
    except Exception as e:
        code, retriable, category = _classify_error(e)
        _safe_log(log, "warning", f"[cancel_order] {code}: {e}")
        
        return _err(
            code,
            str(e),
            retriable=retriable,
            category=category,
            symbol=sym,
            order_id=order_id,
            clientOrderId=client_order_id,
        )


def get_order_status(
    exchange: Any,
    trading_mode: str,
    symbol: str,
    order_id: str,
    *,
    client_order_id: Optional[str] = None,
    params: Optional[Dict[str, Any]] = None,
    log: Any = None,
) -> Dict[str, Any]:
    """Get status of an existing order"""
    
    ts = time.time()
    tm = _norm_mode(trading_mode)
    sym = (symbol or "").strip()
    
    if tm == "INVALID":
        return _err("invalid_mode", f"invalid trading_mode={trading_mode!r}", 
                   trading_mode=trading_mode, category="validation")
    
    if not sym:
        return _err("invalid_symbol", "symbol is required", 
                   symbol=symbol, category="validation")
    
    if not order_id:
        return _err("invalid_order_id", "order_id is required", 
                   order_id=order_id, category="validation")
    
    p = dict(params or {})
    
    # PAPER mode: check idempotency cache
    if tm == "PAPER":
        if client_order_id:
            cached = _idem_cache.get(client_order_id)
            if cached:
                return {
                    "status": "ok",
                    "ts": ts,
                    "id": order_id,
                    "clientOrderId": client_order_id,
                    "symbol": sym,
                    "order_status": cached.get("fill_status", "open"),
                    "filled": cached.get("filled_amount", 0.0),
                    "remaining": cached.get("remaining_amount", cached.get("amount", 0.0)),
                    "average_price": cached.get("fill_price"),
                    "simulated": True,
                    "meta": {
                        "mode": tm,
                        "exchange_id": getattr(exchange, "id", None),
                        "from_cache": True,
                    },
                }
        
        # Not found in cache
        return {
            "status": "ok",
            "ts": ts,
            "id": order_id,
            "clientOrderId": client_order_id,
            "symbol": sym,
            "order_status": "unknown",
            "filled": 0.0,
            "remaining": 0.0,
            "simulated": True,
            "meta": {
                "mode": tm,
                "exchange_id": getattr(exchange, "id", None),
                "from_cache": False,
            },
        }
    
    # LIVE mode
    try:
        if not hasattr(exchange, "fetch_order"):
            return _err("invalid_exchange", "exchange has no fetch_order()", 
                       exchange=str(type(exchange)), category="system")
        
        raw = exchange.fetch_order(order_id, sym, p)
        
        # Normalize common fields
        status = raw.get("status", "unknown")
        filled = float(raw.get("filled", 0.0))
        remaining = float(raw.get("remaining", 0.0))
        average = _safe_float(raw.get("average"))
        
        return {
            "status": "ok",
            "ts": ts,
            "id": order_id,
            "clientOrderId": client_order_id or raw.get("clientOrderId"),
            "symbol": sym,
            "order_status": status,
            "filled": filled,
            "remaining": remaining,
            "average_price": average,
            "raw": raw,
            "meta": {
                "exchange_id": getattr(exchange, "id", None),
                "mode": tm,
            },
        }
    
    except Exception as e:
        code, retriable, category = _classify_error(e)
        _safe_log(log, "warning", f"[get_order_status] {code}: {e}")
        
        return _err(
            code,
            str(e),
            retriable=retriable,
            category=category,
            symbol=sym,
            order_id=order_id,
            clientOrderId=client_order_id,
        )


def set_config(new_config: TradeConfig) -> None:
    """Update global configuration"""
    global _DEFAULT_CONFIG, _idem_cache
    _DEFAULT_CONFIG = new_config
    _idem_cache = IdempotencyCache(new_config)


def get_metrics() -> Dict[str, Any]:
    """Get execution metrics"""
    return Metrics.get_metrics()


def reset_metrics() -> None:
    """Reset all metrics (for testing)"""
    Metrics.reset()

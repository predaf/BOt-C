from app.health import HealthMonitor
import app.health as h

class L:
    def info(self,*a,**k): pass
    def warning(self,*a,**k): pass
    def warn(self,*a,**k): pass
    def error(self,*a,**k): pass
    def debug(self,*a,**k): pass

hm = HealthMonitor({}, L())
print("health file =", h.__file__)
print("has _lock =", hasattr(hm, "_lock"))
print("lock type =", type(getattr(hm, "_lock", None)).__name__)
try:
    _ = hm.last_state
    print("last_state access ok = True")
except Exception as e:
    print("last_state access ok = False:", type(e).__name__, e)
PY
Dacă PowerShell-ul tău nu acceptă python - <<'PY', atunci fă rapid un fișier check_health.py și rulează-l:

@'
from app.health import HealthMonitor
import app.health as h

class L:
    def info(self,*a,**k): pass
    def warning(self,*a,**k): pass
    def warn(self,*a,**k): pass
    def error(self,*a,**k): pass
    def debug(self,*a,**k): pass

hm = HealthMonitor({}, L())
print("health file =", h.__file__)
print("has _lock =", hasattr(hm, "_lock"))
print("lock type =", type(getattr(hm, "_lock", None)).__name__)
try:
    _ = hm.last_state
    print("last_state access ok = True")
except Exception as e:
    print("last_state access ok = False:", type(e).__name__, e)
'@ | Set-Content -Encoding UTF8 .\check_health.py
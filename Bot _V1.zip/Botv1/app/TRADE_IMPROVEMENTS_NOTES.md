# Trade improvements (v8.2 autonomy ML) — patches

## What was changed

### 1) Safer DCA / pyramiding
- Added per-position counters and base size tracking:
  - `LivePosition.base_qty`, `LivePosition.dca_count`, `LivePosition.pyramid_count`.
- Added caps to `_maybe_dca()`:
  - `risk.dca.max_steps` (default 2)
  - `risk.dca.max_total_mult` (default 2.5× of initial position)
  - `risk.dca.min_add_qty_pct` (default 5% of initial position)
- Added similar caps to `_maybe_pyramid()`:
  - `risk.pyramid.max_steps` (default 2)
  - `risk.pyramid.max_total_mult` (default 2.0×)
  - `risk.pyramid.min_add_qty_pct` (default 5%)

### 2) Cooldown after losing exits
- Added `self._cooldowns`.
- When a paper fill closes with a loss (reason contains `stop_loss` or `signal_exit`), the symbol is put on cooldown.
- Entry logic `_maybe_entry()` skips symbols in cooldown.
- Config:
  - `risk.cooldown_after_loss_sec` (default 600s)

### 3) Paper leverage clamp (spot-safe default)
- In paper mode, `_place_order()` enforces a max notional exposure based on `paper.max_leverage`.
- Default is **1.0×** if futures are disabled, and **3.0×** if futures are enabled.

### 4) SQLite trade listing robustness
- `SQLiteStore.list_trades()` now supports both:
  - `trades.ts` stored as ISO string (recommended)
  - `trades.ts` stored as epoch seconds
- `since_ts` works even when `ts` is ISO (epoch is converted to ISO for filtering).

## Suggested config additions (optional)
Add to your config (YAML/JSON) if you want explicit control:

```yaml
risk:
  cooldown_after_loss_sec: 900
  dca:
    max_steps: 2
    max_total_mult: 2.0
    min_add_qty_pct: 0.10
  pyramid:
    max_steps: 1
    max_total_mult: 1.5
    min_add_qty_pct: 0.10
paper:
  max_leverage: 1.0
```


### 2) Cooldown after loss
- Added `self._cooldowns` map in `TradingEngine`.
- If a PAPER close trade has `reason` containing `stop_loss` or `signal_exit` and realized PnL < 0, the symbol is put on cooldown.
- Entry logic (`_maybe_entry`) skips symbols still in cooldown.

Config:
- `risk.cooldown_after_loss_sec` (default 600 seconds)

### 3) Paper leverage cap even when not futures
- In paper mode, `_place_order()` now enforces a maximum leverage cap:
  - If futures are enabled: uses `paper.max_leverage` or default 3.0
  - If futures are disabled: defaults to 1.0 unless you explicitly set `paper.max_leverage`

This prevents unbounded exposure when shorts are allowed.

### 4) SQLiteStore list_trades made robust
- `SQLiteStore.list_trades()` now works regardless of whether `trades.ts` is stored as ISO string or epoch.
- `since_ts` (epoch seconds) is supported even with ISO timestamps.
- Missing imports were fixed.

## Recommended config additions
Add/adjust these in your config (YAML/JSON depending on your setup):

```yaml
risk:
  cooldown_after_loss_sec: 900          # 15m cooldown after a losing close
  dca:
    enabled: true
    max_steps: 2                       # number of DCA adds per position
    max_total_mult: 2.0                # max total size vs initial size
    min_add_qty_pct: 0.10              # don’t add micro-quantities
  pyramid:
    enabled: true
    max_steps: 2
    max_total_mult: 2.0
    min_add_qty_pct: 0.10
paper:
  max_leverage: 1.0                    # for spot-like paper; set >1 only if you WANT margin
```


### 4) SQLite /trades robustness
- `SQLiteStore.list_trades()` now supports:
  - `ts` stored as ISO string (your current schema)
  - `ts` stored as epoch seconds (older variants)
- `since_ts` (epoch seconds) is converted to ISO and filtered correctly when `ts` is ISO.

## Suggested config defaults
Add to your config (YAML/JSON), under `risk`:

```yaml
risk:
  cooldown_after_loss_sec: 600
  max_position_pct_paper: 0.10
  dca:
    max_steps: 2
    max_total_mult: 2.5
    min_add_qty_pct: 0.05
  pyramid:
    max_steps: 2
    max_total_mult: 2.0
    min_add_qty_pct: 0.05
paper:
  max_leverage: 1.0
```

If you trade futures in paper mode and want controlled leverage:

```yaml
paper:
  max_leverage: 2.0
```
  dca:
    enabled: true
    max_steps: 2
    max_total_mult: 2.5
    min_add_qty_pct: 0.05
  pyramid:
    enabled: true
    max_steps: 2
    max_total_mult: 2.0
    min_add_qty_pct: 0.05
paper:
  max_leverage: 2.0  # set 1.0 if you want strict spot-like
```

Notes:
- If you observe overtrading in choppy markets, increase `cooldown_after_loss_sec` to 1200–3600.
- If you want to reduce fee drag, lower `max_position_pct_paper` and reduce `dca.max_total_mult`.

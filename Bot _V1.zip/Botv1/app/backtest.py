from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Tuple, List, Optional, Union, Callable
import json
import copy
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import hashlib
import warnings
from scipy import stats
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
import itertools
from tqdm import tqdm

from .strategy import StrategyEngine
from .paper import PaperPortfolio
from .indicators import atr, calculate_indicators

# Suppress warnings
warnings.filterwarnings('ignore')

# -----------------------------
# Data Models
# -----------------------------

@dataclass
class BacktestResult:
    """Extended backtest result with comprehensive metrics."""
    trades: int = 0
    win_rate: float = 0.0           # percent 0..100
    total_return_pct: float = 0.0
    max_dd_pct: float = 0.0
    profit_factor: float = 0.0
    equity_end: float = 0.0
    note: str = ""
    equity_curve: List[float] = field(default_factory=list)
    daily_returns: List[float] = field(default_factory=list)
    trade_history: List[Dict[str, Any]] = field(default_factory=list)
    
    # Advanced metrics
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    omega_ratio: float = 0.0
    tail_ratio: float = 0.0
    annual_return_pct: float = 0.0
    annual_volatility_pct: float = 0.0
    ulcer_index: float = 0.0
    gain_to_pain_ratio: float = 0.0
    avg_profit_per_trade: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    largest_win: float = 0.0
    largest_loss: float = 0.0
    profit_loss_ratio: float = 0.0
    expectency: float = 0.0
    kelly_criterion: float = 0.0
    recovery_factor: float = 0.0
    skewness: float = 0.0
    kurtosis: float = 0.0
    var_95: float = 0.0
    cvar_95: float = 0.0
    
    # Timing and execution
    execution_time_ms: float = 0.0
    bars_processed: int = 0
    
    # Strategy-specific
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def win_rate_pct(self) -> float:
        return float(self.win_rate)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return asdict(self)
    
    def summary(self) -> Dict[str, Any]:
        """Return key metrics summary."""
        return {
            'trades': self.trades,
            'win_rate': self.win_rate,
            'total_return_pct': self.total_return_pct,
            'max_dd_pct': self.max_dd_pct,
            'profit_factor': self.profit_factor,
            'sharpe_ratio': self.sharpe_ratio,
            'calmar_ratio': self.calmar_ratio,
            'annual_return_pct': self.annual_return_pct,
            'note': self.note
        }
    
    def get_grade(self) -> str:
        """Grade strategy performance."""
        score = 0
        
        if self.sharpe_ratio > 1.5: score += 3
        elif self.sharpe_ratio > 1.0: score += 2
        elif self.sharpe_ratio > 0.5: score += 1
        
        if self.profit_factor > 2.0: score += 3
        elif self.profit_factor > 1.5: score += 2
        elif self.profit_factor > 1.2: score += 1
        
        if self.max_dd_pct < 10: score += 3
        elif self.max_dd_pct < 20: score += 2
        elif self.max_dd_pct < 30: score += 1
        
        if self.total_return_pct > 50: score += 3
        elif self.total_return_pct > 20: score += 2
        elif self.total_return_pct > 0: score += 1
        
        if score >= 10: return 'A'
        elif score >= 7: return 'B'
        elif score >= 4: return 'C'
        else: return 'D'


@dataclass
class WalkForwardResult:
    """Results from walk-forward optimization."""
    train_results: Dict[str, BacktestResult]
    test_results: Dict[str, BacktestResult]
    best_params: Dict[str, Any]
    stability_score: float = 0.0
    oos_performance: Dict[str, float] = field(default_factory=dict)
    note: str = ""


@dataclass
class MonteCarloResult:
    """Results from Monte Carlo simulation."""
    var_95: float
    cvar_95: float
    worst_case: float
    best_case: float
    median_case: float
    probability_of_profit: float
    probability_of_ruin: float
    confidence_intervals: Dict[str, Tuple[float, float]]
    distribution_stats: Dict[str, float]


# -----------------------------
# Helpers
# -----------------------------

def _cfg_get(cfg: Dict[str, Any], path: str, default: Any) -> Any:
    """Safely get nested config value."""
    cur: Any = cfg
    for k in path.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def _clamp(x: float, lo: float, hi: float) -> float:
    """Clamp value between bounds."""
    return max(lo, min(hi, x))


def _hash_config(cfg: Dict[str, Any]) -> str:
    """Create hash from config for caching."""
    cfg_str = json.dumps(cfg, sort_keys=True, default=str)
    return hashlib.md5(cfg_str.encode()).hexdigest()[:12]


def _max_drawdown(equity: List[float]) -> Tuple[float, int, int]:
    """Calculate max drawdown and its duration."""
    if not equity:
        return 0.0, 0, 0
    
    peak = equity[0]
    max_dd = 0.0
    dd_start = 0
    dd_end = 0
    current_start = 0
    
    for i, val in enumerate(equity):
        if val > peak:
            peak = val
            current_start = i
        
        dd = (peak - val) / max(peak, 1e-12)
        if dd > max_dd:
            max_dd = dd
            dd_start = current_start
            dd_end = i
    
    return float(max_dd * 100.0), dd_start, dd_end


def _ensure_ts(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure DataFrame has timestamp column."""
    if df is None or len(df) == 0:
        return df
    if "ts" in df.columns:
        return df

    # Accept "time" from ExchangeClient.fetch_ohlcv_df()
    if "time" in df.columns:
        df = df.copy()
        df["ts"] = pd.to_datetime(df["time"], utc=True, errors="coerce")
        return df

    # Fallback: index
    df = df.copy()
    try:
        df["ts"] = pd.to_datetime(df.index, utc=True, errors="coerce")
    except Exception:
        df["ts"] = pd.date_range(start='2020-01-01', periods=len(df), freq='D', tz='UTC')
    
    return df


def _calculate_advanced_metrics(equity_curve: List[float], 
                               daily_returns: List[float],
                               trade_history: List[Dict[str, Any]]) -> Dict[str, float]:
    """Calculate advanced performance metrics."""
    if len(equity_curve) < 2 or len(daily_returns) == 0:
        return {}
    
    # Convert to numpy arrays
    equity = np.array(equity_curve)
    returns = np.array(daily_returns)
    
    # Basic metrics
    total_return = (equity[-1] / equity[0] - 1) * 100
    max_dd, _, _ = _max_drawdown(equity_curve)
    
    # Annualized metrics (assuming 252 trading days)
    annual_return = ((1 + total_return/100) ** (252/len(returns)) - 1) * 100
    annual_vol = np.std(returns) * np.sqrt(252) * 100
    
    # Sharpe ratio (risk-free rate = 0)
    sharpe = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else 0
    
    # Sortino ratio (downside deviation)
    downside_returns = returns[returns < 0]
    downside_dev = np.std(downside_returns) if len(downside_returns) > 0 else 0
    sortino = np.mean(returns) / downside_dev * np.sqrt(252) if downside_dev > 0 else 0
    
    # Calmar ratio
    calmar = annual_return / max_dd if max_dd > 0 else 0
    
    # Omega ratio
    threshold = 0
    gains = returns[returns > threshold]
    losses = returns[returns <= threshold]
    omega = np.sum(gains) / abs(np.sum(losses)) if len(losses) > 0 and np.sum(losses) != 0 else 0
    
    # Ulcer index
    peak = np.maximum.accumulate(equity)
    drawdowns = (peak - equity) / peak
    ulcer = np.sqrt(np.mean(drawdowns ** 2)) * 100
    
    # Gain to pain ratio
    total_gain = np.sum(returns[returns > 0])
    total_loss = abs(np.sum(returns[returns < 0]))
    gain_to_pain = total_gain / total_loss if total_loss > 0 else 0
    
    # Tail ratio (95th percentile / 5th percentile)
    tail_ratio = np.percentile(returns, 95) / abs(np.percentile(returns, 5)) if np.percentile(returns, 5) != 0 else 0
    
    # Trade-based metrics
    trade_pnls = [t.get('pnl', 0) for t in trade_history]
    if trade_pnls:
        wins = [p for p in trade_pnls if p > 0]
        losses = [p for p in trade_pnls if p < 0]
        
        avg_win = np.mean(wins) if wins else 0
        avg_loss = np.mean(losses) if losses else 0
        profit_loss_ratio = abs(avg_win / avg_loss) if avg_loss != 0 else 0
        
        # Kelly criterion
        win_prob = len(wins) / len(trade_pnls) if trade_pnls else 0
        kelly = win_prob - (1 - win_prob) / profit_loss_ratio if profit_loss_ratio > 0 else 0
    else:
        avg_win = avg_loss = profit_loss_ratio = kelly = 0
    
    # Statistical metrics
    skewness = stats.skew(returns) if len(returns) > 0 else 0
    kurtosis = stats.kurtosis(returns) if len(returns) > 0 else 0
    
    # Value at Risk and Conditional VaR
    var_95 = np.percentile(returns, 5)  # 5th percentile (worst 5%)
    cvar_95 = returns[returns <= var_95].mean() if len(returns[returns <= var_95]) > 0 else var_95
    
    # Recovery factor
    recovery = total_return / max_dd if max_dd > 0 else 0
    
    return {
        'sharpe_ratio': float(sharpe),
        'sortino_ratio': float(sortino),
        'calmar_ratio': float(calmar),
        'omega_ratio': float(omega),
        'tail_ratio': float(tail_ratio),
        'annual_return_pct': float(annual_return),
        'annual_volatility_pct': float(annual_vol),
        'ulcer_index': float(ulcer),
        'gain_to_pain_ratio': float(gain_to_pain),
        'profit_loss_ratio': float(profit_loss_ratio),
        'kelly_criterion': float(kelly),
        'recovery_factor': float(recovery),
        'skewness': float(skewness),
        'kurtosis': float(kurtosis),
        'var_95': float(var_95 * 100),  # Convert to percentage
        'cvar_95': float(cvar_95 * 100),
        'avg_win': float(avg_win),
        'avg_loss': float(avg_loss),
    }


def _slip_price(px: float, side: str, slip_bps: float) -> float:
    """Apply slippage to execution price."""
    px = float(px)
    bps = float(slip_bps)
    m = 1.0 + (bps / 10_000.0) if side == "buy" else 1.0 - (bps / 10_000.0)
    return float(px * m)


def _paper_buy(paper: PaperPortfolio, sym: str, qty: float, px: float, 
              maker: bool = False) -> Tuple[float, float, float]:
    """Normalize PaperPortfolio.buy return."""
    r = paper.buy(sym, float(qty), float(px), maker=bool(maker))
    realized = 0.0
    if isinstance(r, tuple) and len(r) >= 3:
        try:
            realized = float(r[2] or 0.0)
        except Exception:
            realized = 0.0
    return float(qty), float(px), float(realized)


def _paper_sell(paper: PaperPortfolio, sym: str, qty: float, px: float, 
               maker: bool = False) -> Tuple[float, float, float]:
    """Normalize PaperPortfolio.sell return."""
    r = paper.sell(sym, float(qty), float(px), maker=bool(maker))
    realized = 0.0
    if isinstance(r, tuple) and len(r) >= 3:
        try:
            realized = float(r[2] or 0.0)
        except Exception:
            realized = 0.0
    return float(qty), float(px), float(realized)


def _ts_ns_safe(ts_val: Any) -> int:
    """Convert timestamp to nanoseconds."""
    try:
        return int(pd.Timestamp(ts_val).value)
    except Exception:
        try:
            return int(pd.to_datetime(ts_val, utc=True, errors="coerce").value)
        except Exception:
            return 0


def _resample_data(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    """Resample OHLC data to different timeframe."""
    if df.empty or 'ts' not in df.columns:
        return df
    
    df = df.copy()
    df.set_index('ts', inplace=True)
    
    # Define resample rules
    rules = {
        '1m': '1T',
        '5m': '5T',
        '15m': '15T',
        '30m': '30T',
        '1h': '1H',
        '4h': '4H',
        '1d': '1D',
        '1w': '1W',
        '1M': '1M'
    }
    
    if timeframe not in rules:
        return df.reset_index()
    
    resampled = df.resample(rules[timeframe]).agg({
        'open': 'first',
        'high': 'max',
        'low': 'min',
        'close': 'last',
        'volume': 'sum'
    }).dropna()
    
    return resampled.reset_index()


def _create_synthetic_data(df: pd.DataFrame, 
                          method: str = 'bootstrap',
                          seed: Optional[int] = None) -> pd.DataFrame:
    """Create synthetic data for stress testing."""
    if df.empty:
        return df
    
    if seed is not None:
        np.random.seed(seed)
    
    df = df.copy()
    
    if method == 'bootstrap':
        # Block bootstrap to preserve autocorrelation
        block_size = 20
        n_blocks = len(df) // block_size + 1
        indices = []
        
        for _ in range(n_blocks):
            start = np.random.randint(0, len(df) - block_size)
            indices.extend(range(start, start + block_size))
        
        indices = indices[:len(df)]
        synthetic = df.iloc[indices].reset_index(drop=True)
        
    elif method == 'garch':
        # Simple GARCH-like volatility clustering
        returns = df['close'].pct_change().dropna()
        sigma = returns.std()
        
        synthetic_returns = np.zeros(len(df))
        h = sigma ** 2
        
        for i in range(1, len(synthetic_returns)):
            # GARCH(1,1) process
            h = 0.05 + 0.85 * h + 0.1 * (synthetic_returns[i-1] ** 2)
            synthetic_returns[i] = np.random.normal(0, np.sqrt(h))
        
        # Reconstruct price series
        synthetic_close = df['close'].iloc[0] * np.cumprod(1 + synthetic_returns)
        synthetic = df.copy()
        synthetic['close'] = synthetic_close
        synthetic['open'] = synthetic_close.shift(1).fillna(synthetic_close)
        synthetic['high'] = synthetic_close * (1 + np.abs(synthetic_returns) * 1.5)
        synthetic['low'] = synthetic_close * (1 - np.abs(synthetic_returns) * 1.5)
        synthetic['volume'] = df['volume'] * (1 + synthetic_returns * 2)
    
    else:
        synthetic = df.copy()
    
    return synthetic


# -----------------------------
# Core Simulation
# -----------------------------

def simulate(cfg: Dict[str, Any], 
            df: pd.DataFrame, 
            df_trend: Optional[pd.DataFrame] = None,
            symbol: str = "X",
            enable_progress: bool = False) -> BacktestResult:
    """
    Enhanced backtest engine with comprehensive metrics and progress tracking.
    """
    import time
    start_time = time.time()
    
    # --- Normalize timestamps ---
    df = _ensure_ts(df)
    if df_trend is not None:
        df_trend = _ensure_ts(df_trend)
    
    eq0 = float(_cfg_get(cfg, "paper.initial_cash_quote", 10000.0))
    
    if df is None or len(df) == 0 or "ts" not in df.columns:
        return BacktestResult(
            note="ERROR: missing ts in df",
            equity_end=eq0,
            execution_time_ms=(time.time() - start_time) * 1000
        )
    
    # Clean + sort
    df = df.dropna(subset=["ts"]).sort_values("ts").reset_index(drop=True)
    
    if df_trend is None or len(df_trend) == 0 or "ts" not in df_trend.columns:
        df_trend = pd.DataFrame(columns=df.columns)
        df_trend["ts"] = pd.to_datetime([], utc=True)
    else:
        df_trend = df_trend.dropna(subset=["ts"]).sort_values("ts").reset_index(drop=True)
    
    # Setup config clone
    try:
        c = copy.deepcopy(cfg)
    except Exception:
        c = json.loads(json.dumps(cfg))
    
    c["mode"] = "paper"
    
    # Optional seed for reproducibility
    seed = _cfg_get(c, "backtest.seed", None)
    if seed is not None:
        try:
            np.random.seed(int(seed))
        except Exception:
            pass
    
    # Enable futures/shorting
    enable_futures = bool(c.get("enable_futures", False) or _cfg_get(c, "futures.enabled", False))
    
    # Strategy + Paper
    strat = StrategyEngine(
        c,
        log=type("L", (), {"info": lambda *_: None, "warn": lambda *_: None, "error": lambda *_: None})(),
    )
    paper = PaperPortfolio(c)
    
    # Guards
    if len(df) < 140:
        return BacktestResult(
            note="Not enough bars",
            equity_end=eq0,
            execution_time_ms=(time.time() - start_time) * 1000
        )
    
    # Backtest knobs
    lookback = int(_cfg_get(c, "backtest.max_lookback_bars", 400))
    min_notional = float(_cfg_get(c, "backtest.min_notional", 5.0))
    
    # Stops/TP
    stop_atr_mult = float(_cfg_get(c, "risk.stop_atr_mult", 2.5))
    tp_atr_mult = float(_cfg_get(c, "risk.tp_atr_mult", 3.5))
    use_intrabar_sl_tp = bool(_cfg_get(c, "backtest.intrabar_sl_tp", True))
    sl_first = bool(_cfg_get(c, "backtest.sl_first_if_both_hit", True))
    
    # Slippage model
    slip_bps_fixed = float(_cfg_get(c, "backtest.slippage_bps", 2.0))
    slip_atr_mult = float(_cfg_get(c, "backtest.slippage_atr_mult", 0.05))
    
    # Risk sizing
    risk_per_trade = float(_cfg_get(c, "risk.risk_per_trade", 0.01))
    max_pos_pct = float(_cfg_get(c, "risk.max_position_pct", 0.15))
    atr_period = int(_cfg_get(c, "risk.atr_period", 14))
    min_stop_frac = float(_cfg_get(c, "backtest.min_stop_frac", 0.002))
    
    # Commission model
    commission_bps = float(_cfg_get(c, "backtest.commission_bps", 5.0))
    
    # Trend slicing
    trend_ts_ns = (
        df_trend["ts"].astype("int64").values
        if (df_trend is not None and len(df_trend) > 0 and "ts" in df_trend.columns)
        else None
    )
    
    # Storage
    equity_curve: List[float] = []
    daily_returns: List[float] = []
    trade_history: List[Dict[str, Any]] = []
    current_trade: Optional[Dict[str, Any]] = None
    
    wins = losses = 0
    gross_p = 0.0
    gross_l = 0.0
    
    # Current simulated protective levels
    cur_stop: Optional[float] = None
    cur_tp: Optional[float] = None
    cur_dir: int = 0  # +1 long, -1 short, 0 flat
    entry_price: Optional[float] = None
    
    def _calc_slip_bps(last_px: float, cur_atr: float) -> float:
        """Calculate dynamic slippage."""
        if last_px <= 0:
            return float(slip_bps_fixed)
        atr_pct = float(cur_atr) / max(1e-12, float(last_px))
        add_bps = (atr_pct * 10_000.0) * float(slip_atr_mult)
        return float(_clamp(slip_bps_fixed + add_bps, 0.0, 50.0))
    
    def _apply_commission(qty: float, price: float, side: str) -> float:
        """Apply commission to trade."""
        notional = qty * price
        commission = notional * (commission_bps / 10000.0)
        return commission
    
    def _close_trade(exit_price: float, exit_time: Any, exit_reason: str):
        """Close current trade and record it."""
        nonlocal current_trade
        if current_trade:
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = exit_time
            current_trade['exit_reason'] = exit_reason
            
            # Calculate P&L
            if current_trade['side'] == 'long':
                pnl = (exit_price - current_trade['entry_price']) * current_trade['qty']
            else:  # short
                pnl = (current_trade['entry_price'] - exit_price) * current_trade['qty']
            
            # Apply commission
            entry_commission = _apply_commission(
                current_trade['qty'], 
                current_trade['entry_price'], 
                current_trade['side']
            )
            exit_commission = _apply_commission(
                current_trade['qty'], 
                exit_price, 
                'sell' if current_trade['side'] == 'long' else 'buy'
            )
            pnl -= (entry_commission + exit_commission)
            
            current_trade['pnl'] = pnl
            current_trade['pnl_pct'] = (pnl / (current_trade['qty'] * current_trade['entry_price'])) * 100
            current_trade['commission'] = entry_commission + exit_commission
            
            trade_history.append(current_trade.copy())
            current_trade = None
    
    # Progress tracking
    start_i = 90
    end_i = len(df) - 2
    total_bars = end_i - start_i + 1
    
    if enable_progress:
        progress_bar = tqdm(total=total_bars, desc=f"Backtesting {symbol}", unit="bar")
    
    # Main loop
    for i in range(start_i, end_i + 1):
        i0 = max(0, i + 1 - lookback)
        bar = df.iloc[i0: i + 1]
        t_now = bar["ts"].iloc[-1]
        
        # Trend slice via searchsorted (fast)
        if trend_ts_ns is not None and len(trend_ts_ns) > 0:
            t_ns = _ts_ns_safe(t_now)
            idx = int(np.searchsorted(trend_ts_ns, t_ns, side="right"))
            tr_slice = df_trend.iloc[:idx]
        else:
            tr_slice = df_trend
        
        if tr_slice is None or len(tr_slice) < 90:
            continue
        
        last = float(bar["close"].iloc[-1])
        
        next_row = df.iloc[i + 1]
        next_open = float(next_row["open"]) if "open" in next_row else last
        next_high = float(next_row["high"]) if "high" in next_row else next_open
        next_low = float(next_row["low"]) if "low" in next_row else next_open
        
        # Calculate equity and returns
        try:
            current_equity = float(paper.equity({symbol: last}))
            equity_curve.append(current_equity)
            
            # Calculate daily return
            if len(equity_curve) > 1:
                daily_return = (equity_curve[-1] / equity_curve[-2] - 1.0)
                daily_returns.append(daily_return)
        except Exception:
            equity_curve.append(equity_curve[-1] if equity_curve else eq0)
        
        # Strategy compute
        sig = strat.compute(bar.assign(symbol=symbol), tr_slice.assign(symbol=symbol), symbol)
        
        # ATR calc
        try:
            cur_atr = float(atr(bar, atr_period).iloc[-1])
            if not np.isfinite(cur_atr) or cur_atr <= 0:
                cur_atr = last * 0.02
        except Exception:
            cur_atr = last * 0.02
        
        slip_bps = _calc_slip_bps(last, cur_atr)
        
        # Current position
        has_pos = paper.has_position(symbol)
        pos_qty = float(paper.positions[symbol].qty) if has_pos else 0.0
        
        # 0) Intrabar SL/TP on next bar for existing position
        if has_pos and use_intrabar_sl_tp and cur_dir != 0 and cur_stop is not None and cur_tp is not None:
            hit_sl = False
            hit_tp = False
            
            if cur_dir > 0:  # Long
                hit_sl = (next_low <= cur_stop)
                hit_tp = (next_high >= cur_tp)
                if hit_sl and hit_tp:
                    if sl_first:
                        hit_tp = False
                    else:
                        hit_sl = False
                
                if hit_sl:
                    px = _slip_price(cur_stop, "sell", slip_bps)
                    _, _, realized = _paper_sell(paper, symbol, abs(pos_qty), px, maker=False)
                    _close_trade(px, t_now, "stop_loss")
                    if realized >= 0:
                        wins += 1
                        gross_p += realized
                    else:
                        losses += 1
                        gross_l += abs(realized)
                    cur_dir, cur_stop, cur_tp, entry_price = 0, None, None, None
                
                elif hit_tp:
                    px = _slip_price(cur_tp, "sell", slip_bps)
                    _, _, realized = _paper_sell(paper, symbol, abs(pos_qty), px, maker=False)
                    _close_trade(px, t_now, "take_profit")
                    if realized >= 0:
                        wins += 1
                        gross_p += realized
                    else:
                        losses += 1
                        gross_l += abs(realized)
                    cur_dir, cur_stop, cur_tp, entry_price = 0, None, None, None
            
            elif cur_dir < 0:  # Short
                hit_sl = (next_high >= cur_stop)
                hit_tp = (next_low <= cur_tp)
                if hit_sl and hit_tp:
                    if sl_first:
                        hit_tp = False
                    else:
                        hit_sl = False
                
                if hit_sl:
                    px = _slip_price(cur_stop, "buy", slip_bps)
                    _, _, realized = _paper_buy(paper, symbol, abs(pos_qty), px, maker=False)
                    _close_trade(px, t_now, "stop_loss")
                    if realized >= 0:
                        wins += 1
                        gross_p += realized
                    else:
                        losses += 1
                        gross_l += abs(realized)
                    cur_dir, cur_stop, cur_tp, entry_price = 0, None, None, None
                
                elif hit_tp:
                    px = _slip_price(cur_tp, "buy", slip_bps)
                    _, _, realized = _paper_buy(paper, symbol, abs(pos_qty), px, maker=False)
                    _close_trade(px, t_now, "take_profit")
                    if realized >= 0:
                        wins += 1
                        gross_p += realized
                    else:
                        losses += 1
                        gross_l += abs(realized)
                    cur_dir, cur_stop, cur_tp, entry_price = 0, None, None, None
        
        # Refresh state after intrabar closes
        has_pos = paper.has_position(symbol)
        pos_qty = float(paper.positions[symbol].qty) if has_pos else 0.0
        
        # 1) Signal-based exit at next_open
        if has_pos:
            act = getattr(sig, "action", None)
            
            # Long and signal sell -> close
            if pos_qty > 0 and act == "sell":
                px = _slip_price(next_open, "sell", slip_bps)
                _, _, realized = _paper_sell(paper, symbol, abs(pos_qty), px, maker=False)
                _close_trade(px, t_now, "signal_exit")
                if realized >= 0:
                    wins += 1
                    gross_p += realized
                else:
                    losses += 1
                    gross_l += abs(realized)
                cur_dir, cur_stop, cur_tp, entry_price = 0, None, None, None
            
            # Short and signal buy -> cover
            elif pos_qty < 0 and act == "buy":
                px = _slip_price(next_open, "buy", slip_bps)
                _, _, realized = _paper_buy(paper, symbol, abs(pos_qty), px, maker=False)
                _close_trade(px, t_now, "signal_exit")
                if realized >= 0:
                    wins += 1
                    gross_p += realized
                else:
                    losses += 1
                    gross_l += abs(realized)
                cur_dir, cur_stop, cur_tp, entry_price = 0, None, None, None
        
        # 2) Entry logic at next_open (only if flat)
        if not paper.has_position(symbol):
            eq = float(paper.equity({symbol: last}))
            risk_amt = risk_per_trade * eq
            stop_dist = max(cur_atr * stop_atr_mult, last * min_stop_frac)
            
            qty_by_risk = (risk_amt / max(1e-12, stop_dist))
            qty_by_cap = (max_pos_pct * eq) / max(1e-12, last)
            qty = float(min(qty_by_risk, qty_by_cap))
            
            if qty * last >= min_notional:
                act = getattr(sig, "action", None)
                
                # LONG
                if act == "buy":
                    px = _slip_price(next_open, "buy", slip_bps)
                    _paper_buy(paper, symbol, qty, px, maker=False)
                    
                    # Start new trade record
                    current_trade = {
                        'entry_price': px,
                        'entry_time': t_now,
                        'qty': qty,
                        'side': 'long',
                        'symbol': symbol,
                        'stop_loss': px - stop_dist,
                        'take_profit': px + (cur_atr * tp_atr_mult)
                    }
                    
                    cur_dir = +1
                    cur_stop = float(px - stop_dist)
                    cur_tp = float(px + (cur_atr * tp_atr_mult))
                    entry_price = px
                
                # SHORT (only if futures enabled)
                elif act == "sell" and enable_futures:
                    px = _slip_price(next_open, "sell", slip_bps)
                    _paper_sell(paper, symbol, qty, px, maker=False)
                    
                    # Start new trade record
                    current_trade = {
                        'entry_price': px,
                        'entry_time': t_now,
                        'qty': qty,
                        'side': 'short',
                        'symbol': symbol,
                        'stop_loss': px + stop_dist,
                        'take_profit': px - (cur_atr * tp_atr_mult)
                    }
                    
                    cur_dir = -1
                    cur_stop = float(px + stop_dist)
                    cur_tp = float(px - (cur_atr * tp_atr_mult))
                    entry_price = px
        
        if enable_progress:
            progress_bar.update(1)
    
    # Close any open trade at end
    if current_trade:
        last_price = float(df["close"].iloc[-1])
        _close_trade(last_price, df["ts"].iloc[-1], "end_of_backtest")
    
    # Append final equity point
    try:
        final_equity = float(paper.equity({symbol: float(df["close"].iloc[-1])}))
        equity_curve.append(final_equity)
        
        if len(equity_curve) > 1:
            daily_return = (equity_curve[-1] / equity_curve[-2] - 1.0)
            daily_returns.append(daily_return)
    except Exception:
        pass
    
    if enable_progress:
        progress_bar.close()
    
    # End metrics
    eq_end = float(paper.equity({symbol: float(df["close"].iloc[-1])}))
    ret = (eq_end / max(1e-12, eq0) - 1.0) * 100.0
    trades = int(wins + losses)
    win_rate = (wins / trades) * 100.0 if trades else 0.0
    
    if gross_l > 1e-12:
        pf = gross_p / gross_l
    else:
        pf = float("inf") if gross_p > 0 else 0.0
    
    mdd, dd_start, dd_end = _max_drawdown(equity_curve)
    
    # Calculate advanced metrics
    advanced_metrics = _calculate_advanced_metrics(equity_curve, daily_returns, trade_history)
    
    # Calculate additional trade metrics
    if trade_history:
        pnls = [t['pnl'] for t in trade_history]
        avg_profit = np.mean(pnls) if pnls else 0.0
        largest_win = max(pnls) if pnls else 0.0
        largest_loss = min(pnls) if pnls else 0.0
        
        # Expectancy
        expectancy = (win_rate/100 * advanced_metrics.get('avg_win', 0) + 
                     (1 - win_rate/100) * advanced_metrics.get('avg_loss', 0))
    else:
        avg_profit = largest_win = largest_loss = expectancy = 0.0
    
    execution_time = (time.time() - start_time) * 1000
    
    note = (
        f"SL/TP={'on' if use_intrabar_sl_tp else 'off'} "
        f"slip_bps={slip_bps_fixed:.1f}+atr*{slip_atr_mult:.2f} "
        f"trades={trades} DD={mdd:.1f}%"
    )
    
    return BacktestResult(
        trades=int(trades),
        win_rate=float(win_rate),
        total_return_pct=float(ret),
        max_dd_pct=float(mdd),
        profit_factor=float(pf),
        equity_end=float(eq_end),
        note=note,
        equity_curve=equity_curve,
        daily_returns=daily_returns,
        trade_history=trade_history,
        sharpe_ratio=advanced_metrics.get('sharpe_ratio', 0.0),
        sortino_ratio=advanced_metrics.get('sortino_ratio', 0.0),
        calmar_ratio=advanced_metrics.get('calmar_ratio', 0.0),
        omega_ratio=advanced_metrics.get('omega_ratio', 0.0),
        tail_ratio=advanced_metrics.get('tail_ratio', 0.0),
        annual_return_pct=advanced_metrics.get('annual_return_pct', 0.0),
        annual_volatility_pct=advanced_metrics.get('annual_volatility_pct', 0.0),
        ulcer_index=advanced_metrics.get('ulcer_index', 0.0),
        gain_to_pain_ratio=advanced_metrics.get('gain_to_pain_ratio', 0.0),
        avg_profit_per_trade=float(avg_profit),
        avg_win=advanced_metrics.get('avg_win', 0.0),
        avg_loss=advanced_metrics.get('avg_loss', 0.0),
        largest_win=float(largest_win),
        largest_loss=float(largest_loss),
        profit_loss_ratio=advanced_metrics.get('profit_loss_ratio', 0.0),
        expectency=float(expectancy),
        kelly_criterion=advanced_metrics.get('kelly_criterion', 0.0),
        recovery_factor=advanced_metrics.get('recovery_factor', 0.0),
        skewness=advanced_metrics.get('skewness', 0.0),
        kurtosis=advanced_metrics.get('kurtosis', 0.0),
        var_95=advanced_metrics.get('var_95', 0.0),
        cvar_95=advanced_metrics.get('cvar_95', 0.0),
        execution_time_ms=float(execution_time),
        bars_processed=int(total_bars),
        parameters={
            'stop_atr_mult': stop_atr_mult,
            'tp_atr_mult': tp_atr_mult,
            'risk_per_trade': risk_per_trade,
            'atr_period': atr_period,
            'slip_bps': slip_bps_fixed
        }
    )


def simulate_multiple(cfg: Dict[str, Any], 
                     symbols_data: Dict[str, Tuple[pd.DataFrame, Optional[pd.DataFrame]]],
                     parallel: bool = True) -> Dict[str, BacktestResult]:
    """
    Run backtest for multiple symbols.
    
    Args:
        cfg: Configuration dictionary
        symbols_data: Dict of symbol -> (price_df, trend_df)
        parallel: Whether to run in parallel
    
    Returns:
        Dict of symbol -> BacktestResult
    """
    results = {}
    
    if parallel and len(symbols_data) > 1:
        # Run in parallel
        with ThreadPoolExecutor(max_workers=min(8, len(symbols_data))) as executor:
            futures = {}
            for symbol, (df, df_trend) in symbols_data.items():
                future = executor.submit(
                    simulate, 
                    cfg, 
                    df, 
                    df_trend, 
                    symbol, 
                    False  # Don't show progress for individual symbols
                )
                futures[future] = symbol
            
            for future in tqdm(as_completed(futures), total=len(futures), desc="Parallel Backtesting"):
                symbol = futures[future]
                try:
                    results[symbol] = future.result()
                except Exception as e:
                    results[symbol] = BacktestResult(
                        note=f"Error: {str(e)}",
                        equity_end=float(_cfg_get(cfg, "paper.initial_cash_quote", 10000.0))
                    )
    else:
        # Run sequentially
        for symbol, (df, df_trend) in tqdm(symbols_data.items(), desc="Sequential Backtesting"):
            try:
                results[symbol] = simulate(cfg, df, df_trend, symbol, True)
            except Exception as e:
                results[symbol] = BacktestResult(
                    note=f"Error: {str(e)}",
                    equity_end=float(_cfg_get(cfg, "paper.initial_cash_quote", 10000.0))
                )
    
    return results


# -----------------------------
# Walk-forward Optimization
# -----------------------------

def walk_forward_optimize(cfg: Dict[str, Any], 
                         df: pd.DataFrame, 
                         df_trend: Optional[pd.DataFrame] = None,
                         method: str = 'grid') -> Dict[str, Any]:
    """
    Enhanced WFO with multiple optimization methods.
    
    Methods:
        - grid: Grid search
        - random: Random search
        - bayesian: Bayesian optimization (requires scikit-optimize)
        - genetic: Genetic algorithm
    """
    df = _ensure_ts(df)
    if df_trend is not None:
        df_trend = _ensure_ts(df_trend)
    
    if df is None or len(df) < 240 or "ts" not in df.columns:
        return cfg
    
    df = df.dropna(subset=["ts"]).sort_values("ts").reset_index(drop=True)
    
    if df_trend is None or len(df_trend) == 0 or "ts" not in df_trend.columns:
        df_trend = df.copy()
    else:
        df_trend = df_trend.dropna(subset=["ts"]).sort_values("ts").reset_index(drop=True)
    
    auto = cfg.get("auto_opt", {}) or {}
    wf = auto.get("walk_forward", {}) or {}
    
    train_frac = float(wf.get("train_frac", 0.7))
    n_windows = int(wf.get("n_windows", 5))
    optimization_method = str(wf.get("method", "grid")).lower()
    
    n = len(df)
    if n < 240:
        return cfg
    
    # Create windows
    window_size = n // n_windows
    windows = []
    
    for i in range(n_windows):
        train_start = 0
        train_end = int((i + 1) * window_size * train_frac)
        test_start = train_end
        test_end = min(n, int((i + 1) * window_size))
        
        if test_end - test_start < 80:
            continue
        
        windows.append({
            'train': (train_start, train_end),
            'test': (test_start, test_end)
        })
    
    if not windows:
        return cfg
    
    # Parameter space
    param_grid = wf.get("candidates", {}) or {}
    if not param_grid:
        # Default parameter grid
        param_grid = {
            'ema_fast': [8, 12, 20],
            'ema_slow': [21, 26, 34],
            'rsi_period': [7, 14, 21],
            'rsi_buy': [25, 30, 35],
            'rsi_sell': [65, 70, 75],
            'stop_atr_mult': [1.5, 2.0, 2.5, 3.0],
            'tp_atr_mult': [2.0, 3.0, 4.0, 5.0]
        }
    
    # Optimization method
    if optimization_method == 'grid':
        best_params = _grid_search_optimization(cfg, df, df_trend, param_grid, windows)
    elif optimization_method == 'random':
        best_params = _random_search_optimization(cfg, df, df_trend, param_grid, windows, 
                                                 n_iter=int(wf.get('n_iter', 100)))
    else:
        best_params = _grid_search_optimization(cfg, df, df_trend, param_grid, windows)
    
    # Apply best parameters to config
    if best_params:
        cfg = _apply_parameters(cfg, best_params)
        
        # Test on full out-of-sample period
        test_results = []
        for window in windows:
            train_start, train_end = window['train']
            test_start, test_end = window['test']
            
            df_train = df.iloc[train_start:train_end]
            df_test = df.iloc[test_start:test_end]
            
            # Get corresponding trend data
            train_end_ts = df_train["ts"].iloc[-1]
            test_end_ts = df_test["ts"].iloc[-1]
            
            df_train_trend = df_trend[df_trend["ts"] <= train_end_ts].copy()
            df_test_trend = df_trend[df_trend["ts"] <= test_end_ts].copy()
            
            result = simulate(cfg, df_test, df_test_trend)
            test_results.append(result)
        
        # Calculate stability metrics
        returns = [r.total_return_pct for r in test_results]
        dd = [r.max_dd_pct for r in test_results]
        
        stability = 1.0 - (np.std(returns) / (abs(np.mean(returns)) + 1e-12))
        avg_return = np.mean(returns)
        avg_dd = np.mean(dd)
        
        cfg["_auto_opt_note"] = (
            f"WFO-{optimization_method}: windows={len(windows)} "
            f"avg_ret={avg_return:.2f}% avg_dd={avg_dd:.2f}% "
            f"stability={stability:.3f}"
        )
        cfg["_auto_opt_metrics"] = {
            "avg_return_pct": float(avg_return),
            "avg_max_dd_pct": float(avg_dd),
            "stability_score": float(stability),
            "n_windows": len(windows),
            "best_params": best_params
        }
    
    return cfg


def _grid_search_optimization(cfg: Dict[str, Any],
                             df: pd.DataFrame,
                             df_trend: pd.DataFrame,
                             param_grid: Dict[str, List[Any]],
                             windows: List[Dict[str, Tuple[int, int]]]) -> Dict[str, Any]:
    """Grid search optimization."""
    best_score = -float('inf')
    best_params = None
    
    # Create parameter combinations
    keys = list(param_grid.keys())
    values = list(param_grid.values())
    combinations = list(itertools.product(*values))
    
    total_combinations = len(combinations)
    max_evals = min(total_combinations, 500)
    
    # Sample combinations if too many
    if total_combinations > max_evals:
        np.random.seed(42)
        indices = np.random.choice(total_combinations, max_evals, replace=False)
        combinations = [combinations[i] for i in indices]
    
    for combo in tqdm(combinations, desc="Grid Search"):
        params = dict(zip(keys, combo))
        
        # Skip invalid combinations
        if 'ema_fast' in params and 'ema_slow' in params:
            if params['ema_fast'] >= params['ema_slow']:
                continue
        
        # Evaluate on training windows
        window_scores = []
        for window in windows:
            train_start, train_end = window['train']
            df_train = df.iloc[train_start:train_end]
            
            # Get corresponding trend data
            train_end_ts = df_train["ts"].iloc[-1]
            df_train_trend = df_trend[df_trend["ts"] <= train_end_ts].copy()
            
            # Create config with current parameters
            cfg_test = _apply_parameters(copy.deepcopy(cfg), params)
            result = simulate(cfg_test, df_train, df_train_trend)
            
            # Score the result
            score = _score_backtest_result(result)
            window_scores.append(score)
        
        avg_score = np.mean(window_scores) if window_scores else -float('inf')
        
        if avg_score > best_score:
            best_score = avg_score
            best_params = params
    
    return best_params


def _random_search_optimization(cfg: Dict[str, Any],
                               df: pd.DataFrame,
                               df_trend: pd.DataFrame,
                               param_grid: Dict[str, List[Any]],
                               windows: List[Dict[str, Tuple[int, int]]],
                               n_iter: int = 100) -> Dict[str, Any]:
    """Random search optimization."""
    best_score = -float('inf')
    best_params = None
    
    keys = list(param_grid.keys())
    
    for _ in tqdm(range(n_iter), desc="Random Search"):
        params = {}
        for key in keys:
            values = param_grid[key]
            params[key] = np.random.choice(values)
        
        # Skip invalid combinations
        if 'ema_fast' in params and 'ema_slow' in params:
            if params['ema_fast'] >= params['ema_slow']:
                continue
        
        # Evaluate on training windows
        window_scores = []
        for window in windows[:2]:  # Use fewer windows for speed
            train_start, train_end = window['train']
            df_train = df.iloc[train_start:train_end]
            
            train_end_ts = df_train["ts"].iloc[-1]
            df_train_trend = df_trend[df_trend["ts"] <= train_end_ts].copy()
            
            cfg_test = _apply_parameters(copy.deepcopy(cfg), params)
            result = simulate(cfg_test, df_train, df_train_trend)
            
            score = _score_backtest_result(result)
            window_scores.append(score)
        
        avg_score = np.mean(window_scores) if window_scores else -float('inf')
        
        if avg_score > best_score:
            best_score = avg_score
            best_params = params
    
    return best_params


def _apply_parameters(cfg: Dict[str, Any], params: Dict[str, Any]) -> Dict[str, Any]:
    """Apply parameters to config."""
    cfg = copy.deepcopy(cfg)
    
    for key, value in params.items():
        if key in ['ema_fast', 'ema_slow']:
            cfg.setdefault('strategies', {}).setdefault('ema_cross', {})[key] = value
        elif key in ['rsi_period', 'rsi_buy', 'rsi_sell']:
            cfg.setdefault('strategies', {}).setdefault('rsi_reversion', {})[key] = value
        elif key in ['stop_atr_mult', 'tp_atr_mult']:
            cfg.setdefault('risk', {})[key] = value
        elif key in ['risk_per_trade', 'max_position_pct']:
            cfg.setdefault('risk', {})[key] = value
    
    return cfg


def _score_backtest_result(result: BacktestResult) -> float:
    """Score a backtest result."""
    # Weights for different metrics
    weights = {
        'sharpe': 2.0,
        'profit_factor': 1.5,
        'calmar': 1.0,
        'win_rate': 0.5,
        'total_return': 1.0,
        'trades': 0.1
    }
    
    # Penalty for few trades
    trade_penalty = max(0, 10 - result.trades) * 0.1 if result.trades < 10 else 0
    
    # Normalize metrics
    sharpe_score = min(result.sharpe_ratio, 3.0) / 3.0
    pf_score = min(result.profit_factor, 5.0) / 5.0
    calmar_score = min(abs(result.calmar_ratio), 3.0) / 3.0 if result.calmar_ratio != 0 else 0
    win_rate_score = result.win_rate / 100.0
    return_score = min(abs(result.total_return_pct), 100.0) / 100.0
    trades_score = min(result.trades / 50.0, 1.0)
    
    # Calculate weighted score
    score = (
        weights['sharpe'] * sharpe_score +
        weights['profit_factor'] * pf_score +
        weights['calmar'] * calmar_score +
        weights['win_rate'] * win_rate_score +
        weights['total_return'] * return_score +
        weights['trades'] * trades_score -
        trade_penalty
    )
    
    return score


# -----------------------------
# Monte Carlo Simulation
# -----------------------------

def monte_carlo_simulation(cfg: dict, 
                          equity_curve: list, 
                          iterations: int = 1000,
                          method: str = 'bootstrap') -> MonteCarloResult:
    """
    Enhanced Monte Carlo simulation with multiple methods.
    
    Methods:
        - bootstrap: Block bootstrap
        - geometric: Geometric Brownian motion
        - garch: GARCH model simulation
    """
    if not equity_curve or len(equity_curve) < 2:
        return MonteCarloResult(
            var_95=0.0,
            cvar_95=0.0,
            worst_case=0.0,
            best_case=0.0,
            median_case=0.0,
            probability_of_profit=0.0,
            probability_of_ruin=0.0,
            confidence_intervals={},
            distribution_stats={}
        )
    
    # Set seed for reproducibility
    seed = (cfg.get("backtest", {}) or {}).get("seed", None)
    if seed is not None:
        np.random.seed(int(seed))
    
    # Calculate returns
    returns = []
    for i in range(1, len(equity_curve)):
        ret = (equity_curve[i] / equity_curve[i-1]) - 1.0
        returns.append(ret)
    
    returns = np.array(returns)
    start_equity = equity_curve[0]
    
    # Run simulations
    final_equities = []
    
    if method == 'bootstrap':
        block_size = int((cfg.get("backtest", {}) or {}).get("mc_block", 5))
        block_size = max(1, min(block_size, len(returns)))
        
        for _ in range(iterations):
            equity = start_equity
            idx = 0
            
            while idx < len(returns):
                block_start = np.random.randint(0, len(returns) - block_size + 1)
                for j in range(block_size):
                    if idx >= len(returns):
                        break
                    equity *= (1.0 + returns[block_start + j])
                    idx += 1
            
            final_equities.append(equity)
    
    elif method == 'geometric':
        # Geometric Brownian motion
        mu = np.mean(returns) * 252  # Annual drift
        sigma = np.std(returns) * np.sqrt(252)  # Annual volatility
        dt = 1.0 / 252  # Daily steps
        
        for _ in range(iterations):
            equity = start_equity
            for _ in range(len(returns)):
                shock = np.random.normal(mu * dt, sigma * np.sqrt(dt))
                equity *= (1.0 + shock)
            
            final_equities.append(equity)
    
    else:  # Default to bootstrap
        for _ in range(iterations):
            sampled_returns = np.random.choice(returns, size=len(returns), replace=True)
            equity = start_equity * np.prod(1 + sampled_returns)
            final_equities.append(equity)
    
    # Calculate statistics
    final_equities = np.array(final_equities)
    final_returns = (final_equities / start_equity - 1.0) * 100
    
    # VaR and CVaR
    var_95 = np.percentile(final_returns, 5)  # 5th percentile (worst 5%)
    cvar_mask = final_returns <= var_95
    cvar_95 = np.mean(final_returns[cvar_mask]) if np.any(cvar_mask) else var_95
    
    # Probability metrics
    probability_of_profit = np.mean(final_returns > 0) * 100
    probability_of_ruin = np.mean(final_equities < start_equity * 0.5) * 100  # 50% drawdown
    
    # Confidence intervals
    confidence_intervals = {
        '80': (np.percentile(final_returns, 10), np.percentile(final_returns, 90)),
        '90': (np.percentile(final_returns, 5), np.percentile(final_returns, 95)),
        '95': (np.percentile(final_returns, 2.5), np.percentile(final_returns, 97.5))
    }
    
    # Distribution statistics
    distribution_stats = {
        'mean': float(np.mean(final_returns)),
        'median': float(np.median(final_returns)),
        'std': float(np.std(final_returns)),
        'skewness': float(stats.skew(final_returns)),
        'kurtosis': float(stats.kurtosis(final_returns)),
        'min': float(np.min(final_returns)),
        'max': float(np.max(final_returns))
    }
    
    return MonteCarloResult(
        var_95=float(var_95),
        cvar_95=float(cvar_95),
        worst_case=float(np.min(final_returns)),
        best_case=float(np.max(final_returns)),
        median_case=float(np.median(final_returns)),
        probability_of_profit=float(probability_of_profit),
        probability_of_ruin=float(probability_of_ruin),
        confidence_intervals={k: (float(v[0]), float(v[1])) for k, v in confidence_intervals.items()},
        distribution_stats=distribution_stats
    )


# -----------------------------
# Advanced Analysis Functions
# -----------------------------

def sensitivity_analysis(cfg: Dict[str, Any], 
                        df: pd.DataFrame,
                        param_ranges: Dict[str, List[Any]]) -> Dict[str, Any]:
    """
    Perform sensitivity analysis on parameters.
    
    Returns:
        Dictionary with parameter importance and optimal ranges.
    """
    results = []
    
    # Create base parameter set
    base_params = {}
    for param, values in param_ranges.items():
        base_params[param] = values[0]
    
    # Test each parameter
    for param_name, param_values in param_ranges.items():
        param_results = []
        
        for value in tqdm(param_values, desc=f"Sensitivity: {param_name}"):
            # Create config with this parameter value
            params = base_params.copy()
            params[param_name] = value
            cfg_test = _apply_parameters(cfg, params)
            
            # Run backtest
            result = simulate(cfg_test, df)
            param_results.append({
                'value': value,
                'total_return': result.total_return_pct,
                'sharpe': result.sharpe_ratio,
                'max_dd': result.max_dd_pct,
                'profit_factor': result.profit_factor
            })
        
        results.append({
            'parameter': param_name,
            'results': param_results,
            'optimal': max(param_results, key=lambda x: x['sharpe']) if param_results else None
        })
    
    # Calculate parameter importance
    importance = {}
    for param_result in results:
        if param_result['results']:
            returns = [r['total_return'] for r in param_result['results']]
            importance[param_result['parameter']] = np.std(returns) / (abs(np.mean(returns)) + 1e-12)
    
    return {
        'sensitivity_results': results,
        'parameter_importance': dict(sorted(importance.items(), key=lambda x: x[1], reverse=True)),
        'recommended_parameters': {
            r['parameter']: r['optimal']['value'] for r in results if r['optimal']
        }
    }


def stress_test(cfg: Dict[str, Any], 
               df: pd.DataFrame,
               scenarios: List[Dict[str, Any]]) -> Dict[str, BacktestResult]:
    """
    Stress test strategy under different market scenarios.
    
    Scenarios can include:
        - high_volatility: Increase volatility
        - flash_crash: Simulate rapid price drop
        - low_liquidity: Increase slippage
        - black_swan: Extreme market move
    """
    results = {}
    
    for scenario in tqdm(scenarios, desc="Stress Testing"):
        scenario_name = scenario.get('name', 'unknown')
        scenario_cfg = copy.deepcopy(cfg)
        
        # Apply scenario modifications
        if scenario.get('high_volatility'):
            scenario_cfg['backtest']['slippage_bps'] = scenario_cfg.get('backtest', {}).get('slippage_bps', 2.0) * 2
            scenario_cfg['backtest']['slippage_atr_mult'] = scenario_cfg.get('backtest', {}).get('slippage_atr_mult', 0.05) * 2
        
        if scenario.get('flash_crash'):
            # Create synthetic flash crash in data
            df_scenario = df.copy()
            crash_idx = len(df_scenario) // 2
            crash_duration = scenario.get('crash_duration', 10)
            
            for i in range(crash_duration):
                if crash_idx + i < len(df_scenario):
                    df_scenario.loc[crash_idx + i, 'close'] *= 0.8  # 20% drop
                    df_scenario.loc[crash_idx + i, 'low'] *= 0.7  # 30% drop
        else:
            df_scenario = df
        
        # Run backtest with scenario
        try:
            result = simulate(scenario_cfg, df_scenario)
            result.note = f"Scenario: {scenario_name}"
            results[scenario_name] = result
        except Exception as e:
            results[scenario_name] = BacktestResult(
                note=f"Error in scenario {scenario_name}: {str(e)}"
            )
    
    return results


def regime_analysis(cfg: Dict[str, Any],
                   df: pd.DataFrame,
                   regime_column: str = 'regime') -> Dict[str, BacktestResult]:
    """
    Analyze strategy performance in different market regimes.
    """
    if regime_column not in df.columns:
        return {'all': simulate(cfg, df)}
    
    regimes = df[regime_column].unique()
    results = {}
    
    for regime in tqdm(regimes, desc="Regime Analysis"):
        df_regime = df[df[regime_column] == regime].copy()
        
        if len(df_regime) < 100:
            continue
        
        # Reset index for simulation
        df_regime = df_regime.reset_index(drop=True)
        
        try:
            result = simulate(cfg, df_regime)
            result.note = f"Regime: {regime}"
            results[str(regime)] = result
        except Exception as e:
            results[str(regime)] = BacktestResult(
                note=f"Error in regime {regime}: {str(e)}"
            )
    
    return results


# -----------------------------
# Reporting and Visualization
# -----------------------------

def generate_report(results: Union[BacktestResult, Dict[str, BacktestResult]],
                   title: str = "Backtest Report") -> Dict[str, Any]:
    """
    Generate comprehensive backtest report.
    """
    if isinstance(results, BacktestResult):
        results = {'single': results}
    
    report = {
        'title': title,
        'timestamp': datetime.now().isoformat(),
        'summary': {},
        'detailed_results': {},
        'comparison': {},
        'recommendations': []
    }
    
    # Collect all results
    for name, result in results.items():
        report['detailed_results'][name] = result.to_dict()
        
        # Add to summary
        report['summary'][name] = {
            'grade': result.get_grade(),
            'total_return_pct': result.total_return_pct,
            'max_dd_pct': result.max_dd_pct,
            'sharpe_ratio': result.sharpe_ratio,
            'profit_factor': result.profit_factor,
            'win_rate': result.win_rate,
            'trades': result.trades
        }
    
    # Generate comparison if multiple results
    if len(results) > 1:
        comparisons = []
        for name, result in results.items():
            comparisons.append({
                'name': name,
                'score': result.sharpe_ratio * 2 + result.profit_factor * 1.5 - result.max_dd_pct * 0.1,
                'sharpe': result.sharpe_ratio,
                'profit_factor': result.profit_factor,
                'max_dd': result.max_dd_pct
            })
        
        # Sort by score
        comparisons.sort(key=lambda x: x['score'], reverse=True)
        report['comparison'] = {
            'rankings': comparisons,
            'best_overall': comparisons[0]['name'] if comparisons else None
        }
    
    # Generate recommendations
    best_result = max(results.values(), key=lambda r: r.sharpe_ratio) if results else None
    if best_result:
        if best_result.sharpe_ratio < 1.0:
            report['recommendations'].append("Consider improving risk-adjusted returns (Sharpe < 1.0)")
        if best_result.max_dd_pct > 20:
            report['recommendations'].append("Drawdown is high (>20%), consider adding stricter risk management")
        if best_result.trades < 10:
            report['recommendations'].append("Low number of trades, strategy may not be robust")
        if best_result.win_rate < 40:
            report['recommendations'].append("Low win rate (<40%), consider improving entry signals")
    
    return report


def export_results(results: Union[BacktestResult, Dict[str, BacktestResult]],
                  format: str = 'json',
                  filename: str = 'backtest_results') -> str:
    """
    Export backtest results to file.
    
    Formats: json, csv, html
    """
    import json as json_module
    import csv
    
    if isinstance(results, BacktestResult):
        data = results.to_dict()
    else:
        data = {k: v.to_dict() for k, v in results.items()}
    
    if format == 'json':
        filepath = f"{filename}.json"
        with open(filepath, 'w') as f:
            json_module.dump(data, f, indent=2, default=str)
    
    elif format == 'csv':
        filepath = f"{filename}.csv"
        if isinstance(data, dict) and len(data) > 1:
            # Multiple results
            rows = []
            for name, result in data.items():
                row = {'name': name}
                row.update(result)
                rows.append(row)
            
            with open(filepath, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
        else:
            # Single result
            if isinstance(data, dict) and 'single' in data:
                result = data['single']
            else:
                result = data
            
            with open(filepath, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Metric', 'Value'])
                for key, value in result.items():
                    writer.writerow([key, value])
    
    elif format == 'html':
        filepath = f"{filename}.html"
        html_content = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Backtest Results</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                table { border-collapse: collapse; width: 100%; margin: 20px 0; }
                th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
                th { background-color: #f4f4f4; }
                .good { color: green; }
                .bad { color: red; }
                .neutral { color: orange; }
            </style>
        </head>
        <body>
            <h1>Backtest Results</h1>
            <p>Generated: {timestamp}</p>
        """.format(timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        
        if isinstance(data, dict) and len(data) > 1:
            html_content += "<h2>Comparison</h2><table>"
            html_content += "<tr><th>Strategy</th><th>Total Return</th><th>Max DD</th><th>Sharpe</th><th>Profit Factor</th><th>Grade</th></tr>"
            
            for name, result in data.items():
                grade_class = {
                    'A': 'good',
                    'B': 'good',
                    'C': 'neutral',
                    'D': 'bad'
                }.get(result.get('grade', 'D'), 'neutral')
                
                html_content += f"""
                <tr>
                    <td>{name}</td>
                    <td>{result.get('total_return_pct', 0):.2f}%</td>
                    <td>{result.get('max_dd_pct', 0):.2f}%</td>
                    <td>{result.get('sharpe_ratio', 0):.2f}</td>
                    <td>{result.get('profit_factor', 0):.2f}</td>
                    <td class="{grade_class}">{result.get('grade', 'N/A')}</td>
                </tr>
                """
            
            html_content += "</table>"
        
        html_content += """
        </body>
        </html>
        """
        
        with open(filepath, 'w') as f:
            f.write(html_content)
    
    return filepath


# -----------------------------
# Utility Functions
# -----------------------------

def parameter_optimization(cfg: dict, 
                          df: pd.DataFrame, 
                          param_grid: dict,
                          objective: str = 'sharpe') -> dict:
    """
    Grid search optimization for parameters.
    """
    best_score = -float('inf')
    best_params = None
    best_result = None
    
    # Generate all parameter combinations
    keys = list(param_grid.keys())
    values = list(param_grid.values())
    combinations = list(itertools.product(*values))
    
    for combo in tqdm(combinations, desc="Parameter Optimization"):
        params = dict(zip(keys, combo))
        
        # Skip invalid combinations
        if 'ema_fast' in params and 'ema_slow' in params:
            if params['ema_fast'] >= params['ema_slow']:
                continue
        
        # Apply parameters and run backtest
        cfg_test = _apply_parameters(copy.deepcopy(cfg), params)
        result = simulate(cfg_test, df)
        
        # Calculate objective score
        if objective == 'sharpe':
            score = result.sharpe_ratio
        elif objective == 'profit_factor':
            score = result.profit_factor
        elif objective == 'calmar':
            score = result.calmar_ratio
        elif objective == 'composite':
            score = (result.sharpe_ratio + result.profit_factor) / 2 - result.max_dd_pct * 0.01
        else:
            score = result.total_return_pct
        
        if score > best_score:
            best_score = score
            best_params = params
            best_result = result
    
    return {
        "ok": True,
        "best_params": best_params,
        "best_score": best_score,
        "best_result": best_result.to_dict() if best_result else None,
        "objective": objective,
        "note": f"Found best parameters with {objective}={best_score:.4f}"
    }


def walk_forward_analysis(cfg: dict, 
                         df: pd.DataFrame,
                         windows: int = 10,
                         train_size: float = 0.7) -> dict:
    """
    Perform walk-forward analysis.
    """
    n = len(df) if df is not None else 0
    if n <= 0:
        return {"ok": False, "reason": "df empty"}
    
    w = max(1, int(n / max(1, int(windows))))
    splits = []
    results = []
    
    for i in range(0, n, w):
        train_end = i + int(w * train_size)
        test_end = min(n, i + w)
        
        if test_end <= train_end or train_end <= i:
            continue
        
        train_data = df.iloc[i:train_end]
        test_data = df.iloc[train_end:test_end]
        
        if len(train_data) < 100 or len(test_data) < 50:
            continue
        
        splits.append({
            "train": [i, train_end],
            "test": [train_end, test_end],
            "train_size": len(train_data),
            "test_size": len(test_data)
        })
        
        # Run backtest on test data
        try:
            result = simulate(cfg, test_data)
            results.append({
                "window": len(splits) - 1,
                "total_return_pct": result.total_return_pct,
                "max_dd_pct": result.max_dd_pct,
                "sharpe_ratio": result.sharpe_ratio,
                "profit_factor": result.profit_factor,
                "trades": result.trades
            })
        except Exception as e:
            results.append({
                "window": len(splits) - 1,
                "error": str(e)
            })
    
    # Calculate stability metrics
    if results and all('sharpe_ratio' in r for r in results if 'error' not in r):
        valid_results = [r for r in results if 'error' not in r]
        returns = [r['total_return_pct'] for r in valid_results]
        sharpes = [r['sharpe_ratio'] for r in valid_results]
        
        stability = {
            'return_std': float(np.std(returns)),
            'return_mean': float(np.mean(returns)),
            'sharpe_std': float(np.std(sharpes)),
            'sharpe_mean': float(np.mean(sharpes)),
            'consistency': float(np.mean([1 if r > 0 else 0 for r in returns]) * 100),
            'n_valid_windows': len(valid_results)
        }
    else:
        stability = {}
    
    return {
        "ok": True,
        "splits": splits,
        "results": results,
        "stability": stability,
        "n_windows": len(splits)
    }


# -----------------------------
# Main Execution
# -----------------------------

def run_comprehensive_backtest(cfg: Dict[str, Any],
                             df: pd.DataFrame,
                             df_trend: Optional[pd.DataFrame] = None,
                             symbol: str = "X",
                             include_analysis: bool = True) -> Dict[str, Any]:
    """
    Run comprehensive backtest with all analyses.
    """
    import time
    start_time = time.time()
    
    # 1. Run base backtest
    print("Running base backtest...")
    base_result = simulate(cfg, df, df_trend, symbol, True)
    
    results = {
        'base': base_result,
        'analyses': {}
    }
    
    if include_analysis and base_result.trades > 0:
        # 2. Monte Carlo simulation
        print("\nRunning Monte Carlo simulation...")
        mc_result = monte_carlo_simulation(
            cfg, 
            base_result.equity_curve, 
            iterations=1000
        )
        results['analyses']['monte_carlo'] = mc_result
        
        # 3. Sensitivity analysis (if enough trades)
        if base_result.trades > 20:
            print("\nRunning sensitivity analysis...")
            # Define parameter ranges for sensitivity
            param_ranges = {
                'stop_atr_mult': [1.5, 2.0, 2.5, 3.0],
                'tp_atr_mult': [2.0, 3.0, 4.0, 5.0],
                'risk_per_trade': [0.005, 0.01, 0.02, 0.03]
            }
            
            sens_result = sensitivity_analysis(cfg, df, param_ranges)
            results['analyses']['sensitivity'] = sens_result
        
        # 4. Stress tests
        print("\nRunning stress tests...")
        scenarios = [
            {'name': 'high_volatility', 'high_volatility': True},
            {'name': 'increased_slippage', 'slippage': 10.0},
            {'name': 'flash_crash', 'flash_crash': True}
        ]
        
        stress_results = stress_test(cfg, df, scenarios)
        results['analyses']['stress_tests'] = stress_results
    
    total_time = time.time() - start_time
    
    # Generate report
    report = generate_report(results['base'], f"Comprehensive Backtest: {symbol}")
    report['total_execution_time'] = total_time
    report['analyses_included'] = list(results['analyses'].keys())
    
    results['report'] = report
    
    return results


# Example usage
if __name__ == "__main__":
    # Create sample configuration
    sample_cfg = {
        "mode": "paper",
        "paper": {"initial_cash_quote": 10000.0},
        "risk": {
            "stop_atr_mult": 2.5,
            "tp_atr_mult": 3.5,
            "risk_per_trade": 0.01,
            "max_position_pct": 0.15,
            "atr_period": 14
        },
        "backtest": {
            "slippage_bps": 2.0,
            "slippage_atr_mult": 0.05,
            "intrabar_sl_tp": True,
            "min_notional": 5.0
        },
        "strategies": {
            "ema_cross": {"fast": 12, "slow": 26},
            "rsi_reversion": {"period": 14, "buy_below": 30, "sell_above": 70}
        }
    }
    
    # Create sample data
    np.random.seed(42)
    dates = pd.date_range(start='2023-01-01', periods=1000, freq='H', tz='UTC')
    prices = 100 + np.cumsum(np.random.randn(1000) * 0.5)
    
    sample_df = pd.DataFrame({
        'ts': dates,
        'open': prices * 0.999,
        'high': prices * 1.005,
        'low': prices * 0.995,
        'close': prices,
        'volume': np.random.randn(1000).clip(1000, 5000)
    })
    
    # Run backtest
    print("Starting comprehensive backtest...")
    results = run_comprehensive_backtest(sample_cfg, sample_df, symbol="BTCUSDT")
    
    print("\n" + "="*80)
    print("BACKTEST COMPLETE")
    print("="*80)
    
    base = results['base']
    print(f"\nBase Results:")
    print(f"  Trades: {base.trades}")
    print(f"  Total Return: {base.total_return_pct:.2f}%")
    print(f"  Max Drawdown: {base.max_dd_pct:.2f}%")
    print(f"  Sharpe Ratio: {base.sharpe_ratio:.2f}")
    print(f"  Profit Factor: {base.profit_factor:.2f}")
    print(f"  Grade: {base.get_grade()}")
    
    if 'analyses' in results:
        print(f"\nAnalyses Completed: {len(results['analyses'])}")
        
        if 'monte_carlo' in results['analyses']:
            mc = results['analyses']['monte_carlo']
            print(f"\nMonte Carlo Results:")
            print(f"  Probability of Profit: {mc.probability_of_profit:.1f}%")
            print(f"  VaR 95%: {mc.var_95:.2f}%")
            print(f"  CVaR 95%: {mc.cvar_95:.2f}%")
    
    print(f"\nTotal Execution Time: {results['report']['total_execution_time']:.2f}s")
    
    # Export results
    export_path = export_results(results['base'], 'json', 'backtest_results')
    print(f"\nResults exported to: {export_path}")
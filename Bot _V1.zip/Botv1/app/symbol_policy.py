from __future__ import annotations

import os
import sqlite3
import time
import math
import random
import threading
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple, List, Union
from datetime import datetime, timedelta


def _f(x: Any, d: float = 0.0) -> float:
    """Safely convert to float with default."""
    try:
        return float(x)
    except Exception:
        return float(d)


def _i(x: Any, d: int = 0) -> int:
    """Safely convert to int with default."""
    try:
        return int(x)
    except Exception:
        return int(d)


def _day_key(ts: Optional[float] = None) -> str:
    """Get day key in format YYYY-MM-DD."""
    ts = float(ts if ts is not None else time.time())
    return time.strftime("%Y-%m-%d", time.gmtime(ts))


def _norm_symbol(sym: str, *, strip_suffix: bool = False) -> str:
    """
    Optional normalization for futures symbols like 'BTC/USDT:USDT' -> 'BTC/USDT'.
    Keep strip_suffix=False by default to avoid breaking exchange-specific symbol usage.
    """
    s = str(sym or "").strip()
    if strip_suffix and ":" in s:
        s = s.split(":", 1)[0]
    return s


@dataclass
class BanditState:
    """State for multi-armed bandit algorithm."""
    # Beta posterior for Thompson Sampling
    alpha: float = 1.0
    beta: float = 1.0
    # UCB1 bookkeeping
    pulls: int = 0
    reward_sum: float = 0.0
    # Last update timestamp
    last_updated: float = 0.0

    def mean(self) -> float:
        """Get mean success probability."""
        denom = max(1e-12, float(self.alpha + self.beta))
        return float(self.alpha) / denom

    def ucb1(self, total_pulls: int, c: float = 2.0) -> float:
        """Calculate UCB1 score."""
        if self.pulls <= 0:
            return 1e9
        avg = self.reward_sum / max(1e-12, float(self.pulls))
        bonus = float(c) * math.sqrt(math.log(max(1, int(total_pulls))) / max(1, int(self.pulls)))
        return float(avg + bonus)

    def confidence_interval(self, confidence: float = 0.95) -> Tuple[float, float]:
        """Get confidence interval for success probability."""
        from scipy.stats import beta
        try:
            lower = beta.ppf((1 - confidence) / 2, self.alpha, self.beta)
            upper = beta.ppf(1 - (1 - confidence) / 2, self.alpha, self.beta)
            return float(lower), float(upper)
        except Exception:
            return 0.0, 1.0


class SymbolPolicyStore:
    """Per-symbol policy + bandit learning store.

    Goals:
      - enforce per-symbol cooldown/loss-streak/trades-per-day (anti-overtrading)
      - persist per-symbol bandit state (tactic selection)
      - support global daily loss limits

    This stays independent from engine internals: it only needs a SQLite path.
    """

    def __init__(
        self,
        db_path: str,
        *,
        table_prefix: str = "policy",
        sqlite_timeout_sec: float = 10.0,
        normalize_symbols: bool = False,
        normalize_strip_suffix: bool = False,
        logger: Optional[logging.Logger] = None,
    ):
        self.db_path = str(db_path)
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)

        self.logger = logger or logging.getLogger(__name__)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=float(sqlite_timeout_sec))
        self.conn.row_factory = sqlite3.Row
        self.pfx = str(table_prefix)

        # concurrency guard for this connection
        self._lock = threading.RLock()

        # optional symbol normalization (useful for futures)
        self.normalize_symbols = bool(normalize_symbols)
        self.normalize_strip_suffix = bool(normalize_strip_suffix)

        self._init()

    def __enter__(self) -> "SymbolPolicyStore":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        """Destructor to ensure connection is closed."""
        try:
            self.close()
        except Exception:
            pass

    def close(self) -> None:
        """Close database connection."""
        try:
            with self._lock:
                self.conn.close()
                self.logger.debug(f"Closed database connection: {self.db_path}")
        except Exception as e:
            self.logger.warning(f"Error closing database: {e}")

    # ----------------------------
    # Low-level exec with retry
    # ----------------------------
    def _exec(self, sql: str, params: Tuple[Any, ...] = (), *, commit: bool = False) -> sqlite3.Cursor:
        """
        Execute SQL with basic retry/backoff to reduce 'database is locked' pain under concurrency.
        """
        last_exc: Optional[Exception] = None
        for attempt in range(5):
            try:
                with self._lock:
                    cur = self.conn.cursor()
                    cur.execute(sql, params)
                    if commit:
                        self.conn.commit()
                    return cur
            except sqlite3.OperationalError as e:
                last_exc = e
                msg = str(e).lower()
                if "locked" in msg or "busy" in msg:
                    time.sleep(0.05 * (attempt + 1))
                    continue
                raise
            except sqlite3.Error as e:
                self.logger.error(f"SQL error: {e}, SQL: {sql}, Params: {params}")
                raise
        # final raise
        if last_exc:
            raise last_exc
        raise sqlite3.OperationalError("sqlite exec failed")

    def _init(self) -> None:
        """Initialize database tables and indexes."""
        with self._lock:
            cur = self.conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("PRAGMA synchronous=NORMAL;")
            cur.execute("PRAGMA temp_store=MEMORY;")
            cur.execute("PRAGMA busy_timeout=3000;")
            cur.execute("PRAGMA foreign_keys=ON;")

            # Symbol table
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.pfx}_symbol(
                  symbol TEXT PRIMARY KEY,
                  cooldown_until REAL DEFAULT 0,
                  loss_streak INTEGER DEFAULT 0,
                  trades_day_key TEXT DEFAULT '',
                  trades_today INTEGER DEFAULT 0,
                  created_ts REAL DEFAULT 0,
                  updated_ts REAL DEFAULT 0
                );
                """
            )

            # Bandit table
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.pfx}_bandit(
                  symbol TEXT NOT NULL,
                  tactic TEXT NOT NULL,
                  alpha REAL DEFAULT 1,
                  beta REAL DEFAULT 1,
                  pulls INTEGER DEFAULT 0,
                  reward_sum REAL DEFAULT 0,
                  created_ts REAL DEFAULT 0,
                  updated_ts REAL DEFAULT 0,
                  PRIMARY KEY(symbol, tactic)
                );
                """
            )

            # Global daily stats
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.pfx}_global(
                  day_key TEXT PRIMARY KEY,
                  realized_pnl REAL DEFAULT 0,
                  total_trades INTEGER DEFAULT 0,
                  winning_trades INTEGER DEFAULT 0,
                  created_ts REAL DEFAULT 0,
                  updated_ts REAL DEFAULT 0
                );
                """
            )

            # Create indexes for performance
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{self.pfx}_symbol_updated ON {self.pfx}_symbol(updated_ts);")
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{self.pfx}_bandit_updated ON {self.pfx}_bandit(updated_ts);")
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{self.pfx}_bandit_symbol ON {self.pfx}_bandit(symbol);")
            
            self.conn.commit()
            self.logger.info(f"Initialized database tables with prefix '{self.pfx}'")

    def _sym(self, symbol: str) -> str:
        """Normalize symbol if configured."""
        if not self.normalize_symbols:
            return str(symbol)
        return _norm_symbol(str(symbol), strip_suffix=self.normalize_strip_suffix)

    # ----------------------------
    # Symbol gating
    # ----------------------------
    def can_open(
        self,
        symbol: str,
        *,
        now: Optional[float] = None,
        max_loss_streak: int = 3,
        cooldown_sec_on_streak: float = 6 * 3600,
        cooldown_sec: Optional[float] = None,
        max_trades_per_day_symbol: int = 999999,
        max_trades_per_day: Optional[int] = None,
        global_daily_loss_limit_pct: Optional[float] = None,
        global_daily_loss_limit_usd: Optional[float] = None,
        equity_usd: Optional[float] = None,
        start_equity_usd: Optional[float] = None,
        check_global: bool = True,
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Returns (allowed, reason, details).

        Notes:
          - If global_daily_loss_limit_pct is set, provide equity_usd or start_equity_usd.
          - details contains additional information about the decision
        """
        now = float(now if now is not None else time.time())
        if cooldown_sec is not None:
            cooldown_sec_on_streak = float(cooldown_sec)
        if max_trades_per_day is not None:
            max_trades_per_day_symbol = int(max_trades_per_day)

        sym = self._sym(symbol)
        dk = _day_key(now)
        details = {
            "symbol": sym,
            "day_key": dk,
            "timestamp": now,
            "checks_passed": 0,
            "checks_failed": 0,
        }

        # -------- global daily loss checks (best-effort) --------
        if check_global and global_daily_loss_limit_usd is not None:
            try:
                cur = self._exec(
                    f"SELECT realized_pnl FROM {self.pfx}_global WHERE day_key=?",
                    (dk,),
                    commit=False,
                )
                row = cur.fetchone()
                pnl = float(row[0]) if row else 0.0
                limit = abs(float(global_daily_loss_limit_usd))
                if pnl <= -limit:
                    details["checks_failed"] += 1
                    details["global_pnl"] = pnl
                    details["global_limit_usd"] = limit
                    return False, f"global_daily_loss_limit_usd hit pnl={pnl:.2f}", details
                details["checks_passed"] += 1
                details["global_pnl"] = pnl
            except Exception as e:
                self.logger.warning(f"Error checking global loss limit (USD): {e}")

        if check_global and global_daily_loss_limit_pct is not None:
            try:
                base = float(equity_usd if equity_usd is not None else (start_equity_usd if start_equity_usd is not None else 0.0))
                if base > 0:
                    cur = self._exec(
                        f"SELECT realized_pnl FROM {self.pfx}_global WHERE day_key=?",
                        (dk,),
                        commit=False,
                    )
                    row = cur.fetchone()
                    pnl = float(row[0]) if row else 0.0
                    lim = abs(float(global_daily_loss_limit_pct)) * base / 100.0
                    if pnl <= -lim:
                        details["checks_failed"] += 1
                        details["global_pnl"] = pnl
                        details["global_limit_pct"] = lim
                        return False, f"global_daily_loss_limit_pct hit pnl={pnl:.2f} lim={lim:.2f}", details
                    details["checks_passed"] += 1
                    details["global_pnl"] = pnl
            except Exception as e:
                self.logger.warning(f"Error checking global loss limit (pct): {e}")

        # -------- per-symbol state --------
        cur = self._exec(
            f"SELECT cooldown_until, loss_streak, trades_day_key, trades_today FROM {self.pfx}_symbol WHERE symbol=?",
            (sym,),
            commit=False,
        )
        row = cur.fetchone()
        
        if row is None:
            # initialize
            self._exec(
                f"INSERT OR IGNORE INTO {self.pfx}_symbol(symbol, cooldown_until, loss_streak, trades_day_key, trades_today, created_ts, updated_ts) VALUES(?,?,?,?,?,?,?)",
                (sym, 0.0, 0, dk, 0, now, now),
                commit=True,
            )
            details["checks_passed"] += 1
            details["initialized"] = True
            return True, "ok", details

        cooldown_until = _f(row[0], 0.0)
        loss_streak = _i(row[1], 0)
        trades_day_key = str(row[2] or "")
        trades_today = _i(row[3], 0)

        # reset day counters if needed
        if trades_day_key != dk:
            trades_day_key = dk
            trades_today = 0
            self._exec(
                f"UPDATE {self.pfx}_symbol SET trades_day_key=?, trades_today=?, updated_ts=? WHERE symbol=?",
                (trades_day_key, trades_today, now, sym),
                commit=True,
            )
            details["day_reset"] = True

        details.update({
            "cooldown_until": cooldown_until,
            "loss_streak": loss_streak,
            "trades_today": trades_today,
            "max_trades_per_day": max_trades_per_day_symbol,
        })

        # Check cooldown
        if cooldown_until and now < float(cooldown_until):
            remaining = int(cooldown_until - now)
            details["checks_failed"] += 1
            details["cooldown_remaining_sec"] = remaining
            return False, f"cooldown_until {remaining}s", details
        details["checks_passed"] += 1

        # Check loss streak
        if loss_streak >= int(max_loss_streak):
            cd = float(cooldown_sec_on_streak)
            until = now + cd
            self._exec(
                f"UPDATE {self.pfx}_symbol SET cooldown_until=?, updated_ts=? WHERE symbol=?",
                (until, now, sym),
                commit=True,
            )
            details["checks_failed"] += 1
            details["loss_streak_triggered"] = True
            details["new_cooldown_until"] = until
            return False, f"loss_streak {loss_streak} (cooldown {int(cd)}s)", details
        details["checks_passed"] += 1

        # Check daily trades limit
        if trades_today >= int(max_trades_per_day_symbol):
            details["checks_failed"] += 1
            return False, f"max_trades_per_day_symbol {trades_today}/{max_trades_per_day_symbol}", details
        details["checks_passed"] += 1

        return True, "ok", details

    def mark_open_attempt(self, symbol: str, *, now: Optional[float] = None) -> None:
        """Record an opening attempt for a symbol."""
        now = float(now if now is not None else time.time())
        sym = self._sym(symbol)
        dk = _day_key(now)

        cur = self._exec(
            f"SELECT trades_day_key, trades_today FROM {self.pfx}_symbol WHERE symbol=?",
            (sym,),
            commit=False,
        )
        row = cur.fetchone()
        if row is None:
            self._exec(
                f"INSERT OR IGNORE INTO {self.pfx}_symbol(symbol, trades_day_key, trades_today, created_ts, updated_ts) VALUES(?,?,?,?,?)",
                (sym, dk, 1, now, now),
                commit=True,
            )
            return

        day_key = str(row[0] or "")
        trades_today = _i(row[1], 0)
        if day_key != dk:
            trades_today = 0
        trades_today += 1

        self._exec(
            f"UPDATE {self.pfx}_symbol SET trades_day_key=?, trades_today=?, updated_ts=? WHERE symbol=?",
            (dk, trades_today, now, sym),
            commit=True,
        )

    def get_symbol_state(self, symbol: str) -> Dict[str, Any]:
        """Get detailed state for a symbol."""
        sym = self._sym(symbol)
        cur = self._exec(
            f"SELECT symbol, cooldown_until, loss_streak, trades_day_key, trades_today, created_ts, updated_ts FROM {self.pfx}_symbol WHERE symbol=?",
            (sym,),
            commit=False,
        )
        row = cur.fetchone()
        if not row:
            return {"symbol": sym, "exists": False}
        
        cooldown_until = float(row["cooldown_until"] or 0.0)
        now = time.time()
        
        return {
            "symbol": str(row["symbol"]),
            "cooldown_until": cooldown_until,
            "cooldown_remaining": max(0.0, cooldown_until - now) if cooldown_until > now else 0.0,
            "loss_streak": int(row["loss_streak"] or 0),
            "trades_day_key": str(row["trades_day_key"] or ""),
            "trades_today": int(row["trades_today"] or 0),
            "created_ts": float(row["created_ts"] or 0.0),
            "updated_ts": float(row["updated_ts"] or 0.0),
            "exists": True,
        }

    def get_all_symbol_states(self, active_only: bool = True) -> List[Dict[str, Any]]:
        """Get states for all symbols."""
        sql = f"SELECT symbol, cooldown_until, loss_streak, trades_day_key, trades_today, created_ts, updated_ts FROM {self.pfx}_symbol"
        if active_only:
            sql += " WHERE updated_ts > ?"
            cutoff = time.time() - 7 * 24 * 3600  # Last 7 days
            cur = self._exec(sql, (cutoff,), commit=False)
        else:
            cur = self._exec(sql, commit=False)
        
        rows = cur.fetchall()
        result = []
        now = time.time()
        
        for row in rows:
            cooldown_until = float(row["cooldown_until"] or 0.0)
            result.append({
                "symbol": str(row["symbol"]),
                "cooldown_until": cooldown_until,
                "cooldown_remaining": max(0.0, cooldown_until - now) if cooldown_until > now else 0.0,
                "loss_streak": int(row["loss_streak"] or 0),
                "trades_day_key": str(row["trades_day_key"] or ""),
                "trades_today": int(row["trades_today"] or 0),
                "created_ts": float(row["created_ts"] or 0.0),
                "updated_ts": float(row["updated_ts"] or 0.0),
            })
        
        return result

    # ----------------------------
    # Close / global pnl
    # ----------------------------
    def get_global_pnl(self, day_key: Optional[str] = None) -> Dict[str, Any]:
        """Get global PnL and trade stats for a day."""
        dk = str(day_key or _day_key())
        try:
            cur = self._exec(
                f"SELECT realized_pnl, total_trades, winning_trades, created_ts, updated_ts FROM {self.pfx}_global WHERE day_key=?",
                (dk,),
                commit=False,
            )
            row = cur.fetchone()
            if row:
                total_trades = int(row["total_trades"] or 0)
                winning_trades = int(row["winning_trades"] or 0)
                win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0.0
                
                return {
                    "day_key": dk,
                    "realized_pnl": float(row["realized_pnl"] or 0.0),
                    "total_trades": total_trades,
                    "winning_trades": winning_trades,
                    "win_rate": win_rate,
                    "created_ts": float(row["created_ts"] or 0.0),
                    "updated_ts": float(row["updated_ts"] or 0.0),
                }
            else:
                return {
                    "day_key": dk,
                    "realized_pnl": 0.0,
                    "total_trades": 0,
                    "winning_trades": 0,
                    "win_rate": 0.0,
                    "created_ts": 0.0,
                    "updated_ts": 0.0,
                    "exists": False,
                }
        except Exception as e:
            self.logger.error(f"Error getting global PnL: {e}")
            return {
                "day_key": dk,
                "realized_pnl": 0.0,
                "error": str(e),
            }

    def reset_day(self, day_key: Optional[str] = None) -> None:
        """Reset global stats for a day."""
        dk = str(day_key or _day_key())
        try:
            now = time.time()
            self._exec(
                f"INSERT OR REPLACE INTO {self.pfx}_global(day_key, realized_pnl, total_trades, winning_trades, created_ts, updated_ts) VALUES(?,?,?,?,?,?)",
                (dk, 0.0, 0, 0, now, now),
                commit=True,
            )
            self.logger.info(f"Reset global stats for day: {dk}")
        except Exception as e:
            self.logger.error(f"Error resetting day: {e}")

    def record_close(
        self,
        symbol: str,
        realized_pnl: float,
        *,
        now: Optional[float] = None,
        cooldown_sec_on_loss: float = 0.0,
        win_threshold: float = 0.0,
    ) -> Dict[str, Any]:
        """Record a position close and return updated state."""
        now = float(now if now is not None else time.time())
        sym = self._sym(symbol)
        pnl = float(realized_pnl)
        is_win = pnl > float(win_threshold)
        
        result = {
            "symbol": sym,
            "pnl": pnl,
            "is_win": is_win,
            "timestamp": now,
            "cooldown_applied": False,
        }

        # fetch streak
        cur = self._exec(
            f"SELECT loss_streak, cooldown_until FROM {self.pfx}_symbol WHERE symbol=?",
            (sym,),
            commit=False,
        )
        row = cur.fetchone()
        ls = _i(row[0], 0) if row else 0
        existing_cd = _f(row[1], 0.0) if row else 0.0

        if not is_win:
            ls += 1
            cd_until = 0.0
            if float(cooldown_sec_on_loss) > 0:
                cd_until = now + float(cooldown_sec_on_loss)
                result["cooldown_applied"] = True
                result["cooldown_duration"] = float(cooldown_sec_on_loss)
                result["cooldown_until"] = cd_until
            # keep max cooldown
            cd_new = max(float(existing_cd), float(cd_until))
            self._exec(
                f"""
                INSERT INTO {self.pfx}_symbol(symbol, loss_streak, cooldown_until, updated_ts)
                VALUES(?,?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET
                  loss_streak=excluded.loss_streak,
                  cooldown_until=MAX({self.pfx}_symbol.cooldown_until, excluded.cooldown_until),
                  updated_ts=excluded.updated_ts
                """,
                (sym, ls, cd_new, now),
                commit=True,
            )
            result["new_loss_streak"] = ls
        else:
            # reset on win
            self._exec(
                f"""
                INSERT INTO {self.pfx}_symbol(symbol, loss_streak, updated_ts)
                VALUES(?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET
                  loss_streak=0,
                  updated_ts=excluded.updated_ts
                """,
                (sym, 0, now),
                commit=True,
            )
            result["loss_streak_reset"] = True

        # update global realized pnl
        dk = _day_key(now)
        try:
            self._exec(
                f"INSERT OR IGNORE INTO {self.pfx}_global(day_key, realized_pnl, total_trades, winning_trades, created_ts, updated_ts) VALUES(?,?,?,?,?,?)",
                (dk, 0.0, 0, 0, now, now),
                commit=True,
            )
            
            # Update with the trade
            update_sql = f"""
                UPDATE {self.pfx}_global 
                SET realized_pnl = realized_pnl + ?,
                    total_trades = total_trades + 1,
                    winning_trades = winning_trades + ?,
                    updated_ts = ?
                WHERE day_key = ?
            """
            self._exec(
                update_sql,
                (float(pnl), 1 if is_win else 0, now, dk),
                commit=True,
            )
            
            result["global_updated"] = True
            result["day_key"] = dk
            
        except Exception as e:
            self.logger.error(f"Error updating global stats: {e}")
            result["global_update_error"] = str(e)

        return result

    def update_on_close(
        self,
        symbol: str,
        tactic: str,
        reward: float,
        win: bool,
        *,
        realized_pnl_usd: float = 0.0,
        notional_usd: float = 0.0,
        now: Optional[float] = None,
        cooldown_sec_on_loss: float = 0.0,
        success_threshold: float = 0.0,
        reward_clip: float = 1.0,
    ) -> Dict[str, Any]:
        """Unified post-close update used by engine.

        - updates per-symbol loss streak/cooldown + global realized pnl
        - updates bandit reward posterior for (symbol,tactic)

        reward is expected to be normalized (e.g., realized_pnl/notional).
        Returns comprehensive result dictionary.
        """
        now = float(now if now is not None else time.time())
        sym = self._sym(symbol)
        tac = str(tactic or "")
        
        result = {
            "symbol": sym,
            "tactic": tac,
            "timestamp": now,
            "reward": float(reward),
            "win": bool(win),
            "success": float(reward) > float(success_threshold),
        }

        # 1) streak/cooldown + daily pnl
        try:
            pnl = float(realized_pnl_usd or 0.0)
            if abs(pnl) <= 1e-12 and float(notional_usd or 0.0) > 0:
                pnl = float(reward) * float(notional_usd)
            close_result = self.record_close(
                sym, 
                float(pnl), 
                now=now, 
                cooldown_sec_on_loss=float(cooldown_sec_on_loss or 0.0),
                win_threshold=float(success_threshold)
            )
            result.update({"close_update": close_result})
        except Exception as e:
            self.logger.error(f"Error in record_close: {e}")
            result["close_update_error"] = str(e)

        # 2) bandit posterior update
        try:
            if tac:
                r = float(reward)
                if reward_clip > 0:
                    r = max(-abs(float(reward_clip)), min(abs(float(reward_clip)), r))
                bandit_result = self.update_reward(
                    sym, tac, r, 
                    now=now, 
                    success_threshold=float(success_threshold),
                    return_state=True
                )
                result.update({"bandit_update": bandit_result})
        except Exception as e:
            self.logger.error(f"Error updating bandit reward: {e}")
            result["bandit_update_error"] = str(e)

        return result

    # ----------------------------
    # Bandit learning
    # ----------------------------
    def _ensure_bandit_row(self, symbol: str, tactic: str, *, now: Optional[float] = None) -> bool:
        """Ensure bandit row exists, return True if created."""
        now = float(now if now is not None else time.time())
        try:
            cur = self._exec(
                f"SELECT 1 FROM {self.pfx}_bandit WHERE symbol=? AND tactic=?",
                (str(symbol), str(tactic)),
                commit=False,
            )
            if cur.fetchone():
                return False
            
            self._exec(
                f"INSERT INTO {self.pfx}_bandit(symbol, tactic, alpha, beta, pulls, reward_sum, created_ts, updated_ts) VALUES(?,?,?,?,?,?,?,?)",
                (str(symbol), str(tactic), 1.0, 1.0, 0, 0.0, now, now),
                commit=True,
            )
            return True
        except Exception as e:
            self.logger.error(f"Error ensuring bandit row: {e}")
            return False

    def update_reward(
        self,
        symbol: str,
        tactic: str,
        reward: float,
        *,
        now: Optional[float] = None,
        success_threshold: float = 0.0,
        return_state: bool = False,
    ) -> Union[None, Dict[str, Any]]:
        """Update posterior.

        reward is expected in ~[-1..+1]. We'll map to success probability using threshold:
          success = reward > success_threshold

        We still store reward_sum for UCB.
        If return_state is True, returns the updated state.
        """
        now = float(now if now is not None else time.time())
        sym = self._sym(symbol)
        tac = str(tactic)
        
        if not tac or tac.lower() == "none":
            return None if not return_state else {}
            
        self._ensure_bandit_row(sym, tac, now=now)

        success = 1.0 if float(reward) > float(success_threshold) else 0.0

        cur = self._exec(
            f"SELECT alpha, beta, pulls, reward_sum FROM {self.pfx}_bandit WHERE symbol=? AND tactic=?",
            (sym, tac),
            commit=False,
        )
        row = cur.fetchone()
        a = _f(row[0], 1.0) if row else 1.0
        b = _f(row[1], 1.0) if row else 1.0
        pulls = _i(row[2], 0) if row else 0
        rsum = _f(row[3], 0.0) if row else 0.0

        new_a = a + success
        new_b = b + (1.0 - success)
        new_pulls = pulls + 1
        new_rsum = rsum + float(reward)

        self._exec(
            f"UPDATE {self.pfx}_bandit SET alpha=?, beta=?, pulls=?, reward_sum=?, updated_ts=? WHERE symbol=? AND tactic=?",
            (new_a, new_b, new_pulls, new_rsum, now, sym, tac),
            commit=True,
        )

        if return_state:
            return {
                "symbol": sym,
                "tactic": tac,
                "old_alpha": a,
                "old_beta": b,
                "new_alpha": new_a,
                "new_beta": new_b,
                "old_pulls": pulls,
                "new_pulls": new_pulls,
                "old_reward_sum": rsum,
                "new_reward_sum": new_rsum,
                "reward": float(reward),
                "success": bool(success),
                "mean": new_a / max(1e-12, new_a + new_b),
                "timestamp": now,
            }
        return None

    def get_bandit_state(self, symbol: str, tactic: str) -> BanditState:
        """Get bandit state for a symbol-tactic pair."""
        sym = self._sym(symbol)
        cur = self._exec(
            f"SELECT alpha, beta, pulls, reward_sum, updated_ts FROM {self.pfx}_bandit WHERE symbol=? AND tactic=?",
            (str(sym), str(tactic)),
            commit=False,
        )
        row = cur.fetchone()
        if not row:
            return BanditState(last_updated=time.time())
        return BanditState(
            alpha=_f(row[0], 1.0),
            beta=_f(row[1], 1.0),
            pulls=_i(row[2], 0),
            reward_sum=_f(row[3], 0.0),
            last_updated=_f(row[4], time.time()),
        )

    def get_all_bandit_states(self, symbol: Optional[str] = None) -> Dict[str, Dict[str, BanditState]]:
        """Get bandit states for all symbol-tactic pairs, optionally filtered by symbol."""
        if symbol:
            sym = self._sym(symbol)
            sql = f"SELECT symbol, tactic, alpha, beta, pulls, reward_sum, updated_ts FROM {self.pfx}_bandit WHERE symbol=?"
            params = (sym,)
        else:
            sql = f"SELECT symbol, tactic, alpha, beta, pulls, reward_sum, updated_ts FROM {self.pfx}_bandit"
            params = ()
        
        cur = self._exec(sql, params, commit=False)
        rows = cur.fetchall()
        
        result = {}
        for row in rows:
            sym = str(row["symbol"])
            tac = str(row["tactic"])
            
            if sym not in result:
                result[sym] = {}
                
            result[sym][tac] = BanditState(
                alpha=_f(row["alpha"], 1.0),
                beta=_f(row["beta"], 1.0),
                pulls=_i(row["pulls"], 0),
                reward_sum=_f(row["reward_sum"], 0.0),
                last_updated=_f(row["updated_ts"], time.time()),
            )
        
        return result

    def select_tactic(
        self,
        symbol: str,
        tactics: List[str],
        *,
        method: str = "thompson",
        ucb_c: float = 2.0,
        seed: Optional[int] = None,
        exploration_bonus: float = 0.0,
        min_pulls_for_exploitation: int = 10,
    ) -> Tuple[str, Dict[str, Any]]:
        """Return chosen tactic + scores and details for audit."""
        sym = self._sym(symbol)
        cand = [str(t) for t in (tactics or []) if t and str(t).lower() != "none"]
        if not cand:
            return "none", {"method": method, "scores": {}, "details": "no tactics available"}

        if seed is not None:
            random.seed(int(seed))

        scores: Dict[str, float] = {}
        details: Dict[str, Any] = {
            "method": method,
            "symbol": sym,
            "candidates": cand,
            "exploration_bonus": exploration_bonus,
            "min_pulls_for_exploitation": min_pulls_for_exploitation,
        }
        
        m = str(method or "thompson").lower()

        # Get states for all candidates
        states: Dict[str, BanditState] = {}
        total_pulls = 0
        for t in cand:
            st = self.get_bandit_state(sym, t)
            states[t] = st
            total_pulls += int(st.pulls)
        
        details["total_pulls"] = total_pulls
        details["states"] = {t: {"pulls": s.pulls, "mean": s.mean(), "reward_sum": s.reward_sum} for t, s in states.items()}

        # Check if we should force exploration
        if min_pulls_for_exploitation > 0:
            under_explored = [t for t in cand if states[t].pulls < min_pulls_for_exploitation]
            if under_explored:
                # Randomly select from under-explored tactics
                chosen = random.choice(under_explored)
                scores = {t: 0.0 for t in cand}
                scores[chosen] = 1.0
                details["force_exploration"] = True
                details["under_explored"] = under_explored
                details["chosen_reason"] = f"force exploration (pulls < {min_pulls_for_exploitation})"
                return chosen, {"method": "exploration", "scores": scores, "details": details}

        if m in ("ucb", "ucb1"):
            for t, st in states.items():
                scores[t] = float(st.ucb1(total_pulls=max(1, total_pulls), c=float(ucb_c)))
            details["ucb_c"] = ucb_c
        else:
            # Thompson Sampling
            for t, st in states.items():
                try:
                    scores[t] = float(random.betavariate(max(1e-9, st.alpha), max(1e-9, st.beta)))
                except Exception:
                    scores[t] = float(st.mean())
        
        # Apply exploration bonus if specified
        if exploration_bonus > 0:
            for t in cand:
                if states[t].pulls == 0:
                    scores[t] += exploration_bonus
            details["exploration_bonus_applied"] = True

        # deterministic tie-break: max score then lexical
        sorted_items = sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))
        best = sorted_items[0][0]
        
        details["scores"] = scores
        details["chosen"] = best
        details["chosen_score"] = scores[best]
        details["chosen_pulls"] = states[best].pulls
        
        return best, {"method": m, "scores": scores, "details": details}

    # ----------------------------
    # Maintenance operations
    # ----------------------------
    def cleanup_old_data(self, days_to_keep: int = 30) -> Dict[str, int]:
        """Clean up old data from database."""
        cutoff = time.time() - days_to_keep * 24 * 3600
        result = {"symbols_deleted": 0, "bandits_deleted": 0}
        
        try:
            # Clean old symbols (no activity for N days)
            cur = self._exec(
                f"DELETE FROM {self.pfx}_symbol WHERE updated_ts < ?",
                (cutoff,),
                commit=True,
            )
            result["symbols_deleted"] = cur.rowcount
            
            # Clean old bandits
            cur = self._exec(
                f"DELETE FROM {self.pfx}_bandit WHERE updated_ts < ?",
                (cutoff,),
                commit=True,
            )
            result["bandits_deleted"] = cur.rowcount
            
            self.logger.info(f"Cleaned up old data: {result}")
            return result
            
        except Exception as e:
            self.logger.error(f"Error cleaning up old data: {e}")
            result["error"] = str(e)
            return result

    def reset_symbol(self, symbol: str) -> bool:
        """Reset all data for a symbol."""
        sym = self._sym(symbol)
        try:
            with self._lock:
                # Delete from both tables
                self._exec(f"DELETE FROM {self.pfx}_symbol WHERE symbol=?", (sym,), commit=False)
                self._exec(f"DELETE FROM {self.pfx}_bandit WHERE symbol=?", (sym,), commit=False)
                self.conn.commit()
                
            self.logger.info(f"Reset all data for symbol: {sym}")
            return True
        except Exception as e:
            self.logger.error(f"Error resetting symbol {sym}: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        try:
            stats = {}
            
            # Count symbols
            cur = self._exec(f"SELECT COUNT(*) as cnt FROM {self.pfx}_symbol", commit=False)
            stats["total_symbols"] = cur.fetchone()[0]
            
            # Count bandit entries
            cur = self._exec(f"SELECT COUNT(*) as cnt FROM {self.pfx}_bandit", commit=False)
            stats["total_bandit_entries"] = cur.fetchone()[0]
            
            # Count unique tactics
            cur = self._exec(f"SELECT COUNT(DISTINCT tactic) as cnt FROM {self.pfx}_bandit", commit=False)
            stats["unique_tactics"] = cur.fetchone()[0]
            
            # Get recent activity
            week_ago = time.time() - 7 * 24 * 3600
            cur = self._exec(
                f"SELECT COUNT(*) as cnt FROM {self.pfx}_symbol WHERE updated_ts > ?", 
                (week_ago,), 
                commit=False
            )
            stats["active_symbols_7d"] = cur.fetchone()[0]
            
            # Database size
            if os.path.exists(self.db_path):
                stats["db_size_mb"] = os.path.getsize(self.db_path) / (1024 * 1024)
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Error getting stats: {e}")
            return {"error": str(e)}

    def backup(self, backup_path: Optional[str] = None) -> bool:
        """Create a backup of the database."""
        if backup_path is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            backup_path = f"{self.db_path}.backup_{timestamp}"
        
        try:
            with self._lock:
                # Use SQLite backup API
                backup_conn = sqlite3.connect(backup_path)
                self.conn.backup(backup_conn)
                backup_conn.close()
            
            self.logger.info(f"Created backup at: {backup_path}")
            return True
        except Exception as e:
            self.logger.error(f"Error creating backup: {e}")
            return False


# ----------------------------
# Helper functions
# ----------------------------
def create_default_policy_store(
    db_path: str = "data/policy.db",
    logger: Optional[logging.Logger] = None
) -> SymbolPolicyStore:
    """Create a default policy store with sensible defaults."""
    return SymbolPolicyStore(
        db_path=db_path,
        table_prefix="policy",
        sqlite_timeout_sec=10.0,
        normalize_symbols=True,
        normalize_strip_suffix=True,
        logger=logger,
    )


# ----------------------------
# Example usage
# ----------------------------
if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Create policy store
    store = create_default_policy_store("test_policy.db", logger)
    
    try:
        # Test can_open
        symbol = "BTC/USDT"
        allowed, reason, details = store.can_open(
            symbol,
            max_loss_streak=3,
            max_trades_per_day_symbol=10,
            global_daily_loss_limit_usd=1000,
        )
        print(f"Can open {symbol}: {allowed} - {reason}")
        print(f"Details: {details}")
        
        # Test bandit selection
        tactics = ["momentum", "mean_reversion", "breakout"]
        chosen, selection_info = store.select_tactic(symbol, tactics, method="thompson")
        print(f"\nSelected tactic: {chosen}")
        print(f"Selection info: {selection_info}")
        
        # Simulate a trade
        trade_result = store.update_on_close(
            symbol=symbol,
            tactic=chosen,
            reward=0.05,  # 5% return
            win=True,
            realized_pnl_usd=50.0,
            notional_usd=1000.0,
        )
        print(f"\nTrade result: {trade_result}")
        
        # Get stats
        stats = store.get_stats()
        print(f"\nDatabase stats: {stats}")
        
        # Get symbol state
        state = store.get_symbol_state(symbol)
        print(f"\nSymbol state: {state}")
        
    finally:
        store.close()
        # Clean up test file
        import os
        if os.path.exists("test_policy.db"):
            os.remove("test_policy.db")
from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional


def _now() -> float:
    return time.time()


def _s(x: Any, default: str = "") -> str:
    try:
        if x is None:
            return default
        return str(x)
    except Exception:
        return default


def _f(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        if v != v or v in (float("inf"), float("-inf")):
            return float(default)
        return v
    except Exception:
        return float(default)


def _obj_to_dict(x: Any) -> Dict[str, Any]:
    if x is None:
        return {}
    if isinstance(x, dict):
        return x
    if hasattr(x, "to_dict") and callable(getattr(x, "to_dict")):
        try:
            v = x.to_dict()
            return v if isinstance(v, dict) else {"value": v}
        except Exception:
            pass
    if hasattr(x, "__dict__"):
        try:
            return dict(x.__dict__)
        except Exception:
            pass
    return {"repr": _s(x)}


def _normalize_positions(ex_pos: Any) -> List[Dict[str, Any]]:
    """
    Normalize exchange positions into:
      {"symbol": str, "side": "long"|"short", "qty": float, "entry": float, ...}
    Accepts dict or list shapes; never raises.
    """
    out: List[Dict[str, Any]] = []

    # dict shape: {symbol: {side, qty, entry, ...}}
    if isinstance(ex_pos, dict):
        for sym, p in ex_pos.items():
            try:
                if not isinstance(p, dict):
                    p = _obj_to_dict(p)
                qty = _f(p.get("qty") or p.get("size") or p.get("contracts") or p.get("positionAmt"), 0.0)
                side = _s(p.get("side") or p.get("positionSide") or "").lower().strip()
                entry = _f(p.get("entry") or p.get("avg_price") or p.get("avgPrice") or p.get("entryPrice"), 0.0)

                if not side:
                    side = "short" if qty < 0 else ("long" if qty > 0 else "")

                if side in ("buy", "long"):
                    side = "long"
                elif side in ("sell", "short"):
                    side = "short"

                out.append(
                    {
                        "symbol": _s(sym),
                        "side": side,
                        "qty": abs(float(qty)),
                        "entry": float(entry),
                    }
                )
            except Exception:
                continue
        return out

    # list shape
    if isinstance(ex_pos, list):
        for p in ex_pos:
            try:
                if not isinstance(p, dict):
                    p = _obj_to_dict(p)
                sym = _s(p.get("symbol") or p.get("sym") or p.get("pair") or "")
                if not sym:
                    continue
                qty = _f(p.get("qty") or p.get("size") or p.get("contracts") or p.get("positionAmt"), 0.0)
                side = _s(p.get("side") or p.get("positionSide") or "").lower().strip()
                entry = _f(p.get("entry") or p.get("avg_price") or p.get("avgPrice") or p.get("entryPrice"), 0.0)

                if not side:
                    side = "short" if qty < 0 else ("long" if qty > 0 else "")

                if side in ("buy", "long"):
                    side = "long"
                elif side in ("sell", "short"):
                    side = "short"

                out.append({"symbol": sym, "side": side, "qty": abs(float(qty)), "entry": float(entry)})
            except Exception:
                continue
        return out

    return out


class PortfolioSnapshotter:
    """
    Source-of-truth portfolio snapshot.

    - PAPER: derives from engine.paper / engine.positions / engine.pending
    - LIVE : queries engine.client (CCXT wrapper) best-effort

    This module is intentionally self-contained (no imports from engine),
    to avoid circular-import issues that can manifest as:
      ImportError: cannot import name 'PortfolioSnapshotter' ...
    """

    def __init__(self, engine: Any):
        self.engine = engine
        self._cache: Optional[Dict[str, Any]] = None
        self._cache_ts: float = 0.0
        self._lock = threading.RLock()

    def snapshot(self, ttl_sec: float = 1.0, force: bool = False) -> Dict[str, Any]:
        return self.get(ttl_sec=ttl_sec, force=force)

    def get(self, ttl_sec: float = 1.0, force: bool = False) -> Dict[str, Any]:
        now = _now()
        with self._lock:
            if (not force) and self._cache and (now - self._cache_ts) <= float(ttl_sec):
                return dict(self._cache)

        mode = str(getattr(self.engine, "cfg", {}).get("mode", "paper")).lower().strip()
        if mode == "live":
            snap = self._live_snapshot()
        else:
            snap = self._paper_snapshot()

        with self._lock:
            self._cache = snap
            self._cache_ts = now
        return dict(snap)

    # ---------------- internal helpers ----------------

    def _engine_equity_best_effort(self) -> float:
        eng = self.engine

        # 1) metrics.state.equity
        try:
            m = getattr(eng, "metrics", None)
            if m is not None and getattr(m, "state", None) is not None:
                v = getattr(m.state, "equity", None)
                if v is not None:
                    return float(v)
        except Exception:
            pass

        # 2) eng.equity()
        try:
            eq_fn = getattr(eng, "equity", None)
            if callable(eq_fn):
                return float(eq_fn())
        except Exception:
            pass

        # 3) paper portfolio
        try:
            paper = getattr(eng, "paper", None) or getattr(eng, "paper_portfolio", None)
            if paper is not None:
                for name in ("equity", "cash_quote", "cash", "balance", "free_cash"):
                    v = getattr(paper, name, None)
                    if v is not None:
                        return float(v)
        except Exception:
            pass

        # 4) fallback config
        try:
            cfg = getattr(eng, "cfg", {}) or {}
            p = (cfg.get("paper", {}) or {})
            v = p.get("initial_cash_quote", None)
            if v is not None:
                return float(v)
        except Exception:
            pass

        return 0.0

    def _paper_snapshot(self) -> Dict[str, Any]:
        eng = self.engine
        cfg = getattr(eng, "cfg", {}) or {}
        quote = str(cfg.get("quote_asset", "USDT")).upper()

        eq = float(self._engine_equity_best_effort())

        # positions: prefer engine.get_positions_snapshot()
        positions: List[Dict[str, Any]] = []
        try:
            fn = getattr(eng, "get_positions_snapshot", None)
            if callable(fn):
                positions = fn() or []
        except Exception:
            positions = []

        if not positions:
            # fallback to paper.positions / engine.positions
            try:
                paper = getattr(eng, "paper", None) or getattr(eng, "paper_portfolio", None)
                if paper is not None and getattr(paper, "positions", None):
                    for sym, p in (paper.positions or {}).items():
                        pd = p if isinstance(p, dict) else _obj_to_dict(p)
                        qty = _f(pd.get("qty") or pd.get("size") or 0.0, 0.0)
                        if qty == 0.0:
                            continue
                        side = "long" if qty > 0 else "short"
                        positions.append(
                            {
                                "symbol": _s(sym),
                                "side": side,
                                "qty": abs(float(qty)),
                                "entry": _f(pd.get("avg_price") or pd.get("entry") or pd.get("price"), 0.0),
                                "unrealized_pnl": _f(pd.get("unrealized_pnl") or pd.get("upl"), 0.0),
                            }
                        )
            except Exception:
                pass

        pending: List[Dict[str, Any]] = []
        try:
            fnp = getattr(eng, "get_pending_snapshot", None)
            if callable(fnp):
                pending = fnp() or []
        except Exception:
            pending = []

        if not pending:
            try:
                pend = getattr(eng, "pending", None) or getattr(eng, "pending_orders", None) or {}
                if isinstance(pend, dict):
                    for k, po in pend.items():
                        if isinstance(po, dict):
                            d = dict(po)
                            d.setdefault("key", str(k))
                            pending.append(d)
                        else:
                            pending.append(getattr(po, "__dict__", {"key": str(k), "repr": str(po)}))
                elif isinstance(pend, list):
                    for po in pend:
                        pending.append(po if isinstance(po, dict) else getattr(po, "__dict__", {"repr": str(po)}))
            except Exception:
                pending = []

        return {
            "ts": _now(),
            "ok": True,
            "stale": False,
            "mode": "paper",
            "exchange": str(cfg.get("exchange", "")),
            "equity": float(eq),
            "balances": {"free": float(eq), "used": 0.0, "total": float(eq), "currency": quote},
            "futures": {
                "enabled": bool(cfg.get("enable_futures", False)),
                "margin_mode": None,
                "leverage": None,
                "hedge_mode": None,
            },
            "positions": positions,
            "open_orders": [],
            "pending": pending,
        }

    def _live_snapshot(self) -> Dict[str, Any]:
        eng = self.engine
        cfg = getattr(eng, "cfg", {}) or {}
        quote = str(cfg.get("quote_asset", "USDT")).upper()
        client = getattr(eng, "client", None)

        if not client:
            return {
                "ts": _now(),
                "ok": False,
                "stale": False,
                "mode": "live",
                "exchange": str(cfg.get("exchange", "")),
                "error": "missing_exchange_client",
            }

        # balance
        bal: Dict[str, Any] = {}
        try:
            if hasattr(client, "fetch_balance") and callable(getattr(client, "fetch_balance")):
                bal = client.fetch_balance() or {}
        except Exception as e:
            bal = {"error": f"{type(e).__name__}: {e}"}

        # positions
        positions: List[Dict[str, Any]] = []
        try:
            ex_pos = {}
            if hasattr(client, "fetch_open_positions") and callable(getattr(client, "fetch_open_positions")):
                ex_pos = client.fetch_open_positions() or {}
            positions = _normalize_positions(ex_pos)
        except Exception:
            positions = []

        # open orders
        open_orders: List[Dict[str, Any]] = []
        try:
            if hasattr(client, "fetch_open_orders") and callable(getattr(client, "fetch_open_orders")):
                open_orders = client.fetch_open_orders(limit=200) or []
            if not isinstance(open_orders, list):
                open_orders = []
        except Exception:
            open_orders = []

        # normalize balance
        free = used = total = 0.0
        try:
            if isinstance(bal, dict):
                bq = bal.get(quote)
                if isinstance(bq, dict):
                    free = float(bq.get("free") or 0.0)
                    used = float(bq.get("used") or 0.0)
                    total = float(bq.get("total") or 0.0)
                else:
                    free = float((bal.get("free") or {}).get(quote) or 0.0)
                    used = float((bal.get("used") or {}).get(quote) or 0.0)
                    total = float((bal.get("total") or {}).get(quote) or 0.0)
        except Exception:
            pass

        fut_cfg = (cfg.get("futures") or {})

        eq_best = float(self._engine_equity_best_effort() or 0.0)
        equity = eq_best if eq_best > 0 else float(total or free)

        return {
            "ts": _now(),
            "ok": True,
            "stale": False,
            "mode": "live",
            "exchange": str(cfg.get("exchange", "")),
            "equity": float(equity),
            "balances": {"free": float(free), "used": float(used), "total": float(total), "currency": quote, "raw": bal},
            "futures": {
                "enabled": bool(cfg.get("enable_futures", False)),
                "margin_mode": str(fut_cfg.get("margin_mode")) if fut_cfg else None,
                "leverage": int(fut_cfg.get("leverage")) if fut_cfg and fut_cfg.get("leverage") is not None else None,
                "hedge_mode": bool(fut_cfg.get("hedge_mode", False)) if fut_cfg else False,
            },
            "positions": positions,
            "open_orders": open_orders,
            "pending": [],
        }


__all__ = ["PortfolioSnapshotter"]
from __future__ import annotations

import os
import sqlite3
from typing import Optional, List, Tuple, Dict, Any
from datetime import datetime, timedelta

import pandas as pd
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(
    page_title="Crypto Bot Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

DEFAULT_DB = os.environ.get(
    "BOT_DB_PATH",
    os.path.join(os.path.dirname(__file__), "..", "reports", "bot.db")
)

# Sidebar configuration
with st.sidebar:
    st.header("Dashboard Configuration")
    
    db_path = st.text_input("SQLite DB path", value=DEFAULT_DB)
    if not os.path.exists(db_path):
        st.error("❌ DB file not found. Start the bot (with sqlite enabled) to generate it.")
        st.stop()
    
    st.divider()
    
    st.header("Data Filters")
    time_window = st.selectbox(
        "Time Window",
        ["All", "24h", "7d", "30d", "90d", "Custom"],
        index=1
    )
    
    if time_window == "Custom":
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input("Start Date", value=datetime.now() - timedelta(days=7))
        with col2:
            end_date = st.date_input("End Date", value=datetime.now())
    
    auto_refresh = st.checkbox("Auto-refresh (10s)", value=False)
    if auto_refresh:
        st.rerun()
    
    st.divider()
    st.caption(f"DB: {db_path}")
    st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

st.title("📊 Crypto Bot Dashboard")
st.markdown("---")

@st.cache_resource
def get_conn(path: str) -> sqlite3.Connection:
    return sqlite3.connect(path, check_same_thread=False)

conn = get_conn(db_path)

def list_tables() -> List[str]:
    try:
        df = pd.read_sql_query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name", conn)
        return df["name"].tolist()
    except Exception as e:
        st.error(f"Error listing tables: {e}")
        return []

TABLES = set(list_tables())
required = {"snapshots", "trades", "signals"}
missing = sorted(list(required - TABLES))

if missing:
    st.warning(f"⚠️ Missing tables in DB: {missing}")
    st.info(f"Available tables: {sorted(list(TABLES))}")
    
    # Don't stop completely; user may still want to inspect existing tables
    # Create empty DataFrames for missing required tables
    for table in missing:
        globals()[table] = pd.DataFrame()
else:
    # Load the data
    @st.cache_data(ttl=10)
    def load_data() -> Dict[str, pd.DataFrame]:
        data = {}
        try:
            for table in required:
                data[table] = pd.read_sql_query(f"SELECT * FROM {table} ORDER BY ts DESC", conn)
        except Exception as e:
            st.error(f"Error loading table {table}: {e}")
        return data
    
    data = load_data()
    snap = data.get("snapshots", pd.DataFrame())
    trades = data.get("trades", pd.DataFrame())
    signals = data.get("signals", pd.DataFrame())

def _ts_to_dt(ts: pd.Series) -> pd.Series:
    """Convert mixed ts formats to pandas datetime (UTC)."""
    if ts is None or len(ts) == 0:
        return pd.to_datetime(pd.Series([], dtype='datetime64[ns]'), utc=True, errors='coerce')
    
    # Try numeric first
    s_num = pd.to_numeric(ts, errors='coerce')
    if s_num.notna().any():
        try:
            mx = float(s_num.dropna().max())
            unit = 'ms' if mx > 1e12 else 's'
            return pd.to_datetime(s_num, unit=unit, utc=True, errors='coerce')
        except Exception:
            pass
    
    # Fallback: parse as datetime strings
    return pd.to_datetime(ts, utc=True, errors='coerce')

def apply_window(df: pd.DataFrame, time_window: str) -> pd.DataFrame:
    """Apply time window filter to DataFrame."""
    if df is None or df.empty or "ts" not in df.columns:
        return df
    
    df = df.copy()
    df["_dt"] = _ts_to_dt(df["ts"])
    
    now = pd.Timestamp.utcnow().tz_localize("UTC")
    
    if time_window == "24h":
        cutoff = now - pd.Timedelta(hours=24)
        return df[df["_dt"] >= cutoff]
    elif time_window == "7d":
        cutoff = now - pd.Timedelta(days=7)
        return df[df["_dt"] >= cutoff]
    elif time_window == "30d":
        cutoff = now - pd.Timedelta(days=30)
        return df[df["_dt"] >= cutoff]
    elif time_window == "90d":
        cutoff = now - pd.Timedelta(days=90)
        return df[df["_dt"] >= cutoff]
    elif time_window == "Custom":
        start = pd.Timestamp(st.session_state.get('start_date', datetime.now() - timedelta(days=7)))
        end = pd.Timestamp(st.session_state.get('end_date', datetime.now()))
        return df[(df["_dt"] >= start) & (df["_dt"] <= end)]
    else:  # "All"
        return df

# Apply time window filter
if 'snap' in locals() and not snap.empty:
    snap = apply_window(snap, time_window)
if 'trades' in locals() and not trades.empty:
    trades = apply_window(trades, time_window)
if 'signals' in locals() and not signals.empty:
    signals = apply_window(signals, time_window)

# Filters section
st.header("🔍 Filters")

col1, col2, col3, col4 = st.columns(4)

with col1:
    ex_opts = sorted([x for x in trades.get("exchange", pd.Series(dtype=str)).dropna().unique().tolist() if x])
    ex_sel = st.selectbox("Exchange", ["All"] + ex_opts)

with col2:
    mode_opts = sorted([x for x in trades.get("mode", pd.Series(dtype=str)).dropna().unique().tolist() if x])
    mode_sel = st.selectbox("Mode", ["All"] + mode_opts)

with col3:
    sym_opts = sorted(list(set(
        trades.get("symbol", pd.Series(dtype=str)).dropna().unique().tolist() +
        signals.get("symbol", pd.Series(dtype=str)).dropna().unique().tolist()
    )))
    sym_sel = st.selectbox("Symbol", ["All"] + sym_opts)

with col4:
    status_opts = sorted([x for x in trades.get("status", pd.Series(dtype=str)).dropna().unique().tolist() if x])
    status_sel = st.selectbox("Status", ["All"] + status_opts)

def apply_filters(df: pd.DataFrame) -> pd.DataFrame:
    """Apply all filters to DataFrame."""
    if df is None or df.empty:
        return df
    
    out = df.copy()
    
    if ex_sel != "All" and "exchange" in out.columns:
        out = out[out["exchange"] == ex_sel]
    
    if mode_sel != "All" and "mode" in out.columns:
        out = out[out["mode"] == mode_sel]
    
    if sym_sel != "All" and "symbol" in out.columns:
        out = out[out["symbol"] == sym_sel]
    
    if status_sel != "All" and "status" in out.columns:
        out = out[out["status"] == status_sel]
    
    return out

trades_f = apply_filters(trades)
signals_f = apply_filters(signals)

# Dashboard Summary Cards
st.header("📈 Performance Summary")

if not trades_f.empty and 'realized_pnl' in trades_f.columns:
    pnl_series = pd.to_numeric(trades_f["realized_pnl"], errors="coerce").fillna(0.0)
    fee_series = pd.to_numeric(trades_f.get("fee", 0.0), errors="coerce").fillna(0.0)
    
    total_trades = int(len(trades_f))
    wins = int((pnl_series > 0).sum())
    losses = int((pnl_series < 0).sum())
    win_rate = (wins / total_trades * 100) if total_trades else 0.0
    
    pnl_sum = float(pnl_series.sum())
    avg_pnl = float(pnl_series.mean()) if total_trades else 0.0
    gross_win = float(pnl_series[pnl_series > 0].sum())
    gross_loss = float(pnl_series[pnl_series < 0].sum())
    profit_factor = (gross_win / abs(gross_loss)) if gross_loss != 0 else float("inf")
    
    fee_sum = float(fee_series.sum())
    net_pnl = pnl_sum - fee_sum
    
    # Create summary cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total P&L",
            value=f"${pnl_sum:,.2f}",
            delta=f"${net_pnl:,.2f} net",
            delta_color="normal" if net_pnl >= 0 else "inverse"
        )
    
    with col2:
        st.metric(
            label="Win Rate",
            value=f"{win_rate:.1f}%",
            delta=f"{wins}/{total_trades} trades"
        )
    
    with col3:
        st.metric(
            label="Profit Factor",
            value=f"{profit_factor:.2f}" if profit_factor != float("inf") else "∞",
            delta=f"Gross: ${gross_win:,.2f}"
        )
    
    with col4:
        st.metric(
            label="Total Fees",
            value=f"${fee_sum:,.2f}",
            delta=f"Avg: ${fee_series.mean():.4f}"
        )
else:
    st.info("No trade data available for summary.")

# Equity & Drawdown Charts
st.header("📊 Equity & Drawdown")

if not snap.empty and "equity" in snap.columns:
    snap = snap.copy()
    snap["dt"] = _ts_to_dt(snap["ts"])
    snap = snap.dropna(subset=["dt"])
    snap = snap.sort_values("dt")
    
    # Process equity and drawdown
    eq = pd.to_numeric(snap["equity"], errors="coerce").ffill()
    snap["equity"] = eq
    
    # Calculate drawdown
    roll_max = eq.cummax()
    dd = (eq / roll_max - 1.0).fillna(0.0)
    snap["drawdown"] = dd
    
    # Create subplots
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Equity Curve', 'Drawdown', 'Open Positions', 'Daily Returns'),
        vertical_spacing=0.15,
        horizontal_spacing=0.15
    )
    
    # Equity curve
    fig.add_trace(
        go.Scatter(x=snap["dt"], y=snap["equity"], mode='lines', name='Equity',
                  line=dict(color='green', width=2)),
        row=1, col=1
    )
    
    # Drawdown
    fig.add_trace(
        go.Scatter(x=snap["dt"], y=snap["drawdown"] * 100, mode='lines', name='Drawdown',
                  fill='tozeroy', fillcolor='rgba(255,0,0,0.2)', line=dict(color='red')),
        row=1, col=2
    )
    
    # Open positions
    if "open_positions" in snap.columns:
        fig.add_trace(
            go.Scatter(x=snap["dt"], y=snap["open_positions"], mode='lines', name='Open Positions',
                      line=dict(color='blue', width=1)),
            row=2, col=1
        )
    
    # Daily returns (if we have equity)
    if len(snap) > 1:
        snap['daily_return'] = snap['equity'].pct_change().fillna(0) * 100
        fig.add_trace(
            go.Bar(x=snap["dt"], y=snap["daily_return"], name='Daily Return',
                  marker_color=np.where(snap['daily_return'] >= 0, 'green', 'red')),
            row=2, col=2
        )
    
    fig.update_layout(height=600, showlegend=True, hovermode='x unified')
    st.plotly_chart(fig, use_container_width=True)
    
    # Display max drawdown stats
    max_dd = dd.min() * 100
    max_dd_duration = 0
    current_dd_duration = 0
    in_dd = False
    
    for i, dd_val in enumerate(dd):
        if dd_val < 0:
            if not in_dd:
                in_dd = True
                start_idx = i
            current_dd_duration = i - start_idx + 1
            max_dd_duration = max(max_dd_duration, current_dd_duration)
        else:
            in_dd = False
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Max Drawdown", f"{max_dd:.2f}%")
    with col2:
        st.metric("Current Equity", f"${eq.iloc[-1]:,.2f}" if len(eq) > 0 else "N/A")
    with col3:
        st.metric("Peak Equity", f"${roll_max.iloc[-1]:,.2f}" if len(roll_max) > 0 else "N/A")
else:
    st.info("No snapshot data available for equity analysis.")

# Trade Analysis
st.header("🔍 Trade Analysis")

if not trades_f.empty:
    # Trade distribution by symbol
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Trades by Symbol")
        trades_by_symbol = trades_f['symbol'].value_counts().head(10)
        fig = go.Figure(data=[
            go.Bar(x=trades_by_symbol.index, y=trades_by_symbol.values,
                  marker_color='lightblue')
        ])
        fig.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("P&L Distribution")
        if not pnl_series.empty:
            fig = go.Figure(data=[
                go.Histogram(x=pnl_series, nbinsx=50,
                           marker_color='lightgreen',
                           opacity=0.7)
            ])
            fig.update_layout(height=300, margin=dict(l=20, r=20, t=30, b=20),
                            xaxis_title="P&L", yaxis_title="Frequency")
            st.plotly_chart(fig, use_container_width=True)
    
    # Advanced metrics
    st.subheader("Advanced Metrics")
    
    if 'entry_time' in trades_f.columns and 'exit_time' in trades_f.columns:
        trades_f['entry_dt'] = _ts_to_dt(trades_f['entry_time'])
        trades_f['exit_dt'] = _ts_to_dt(trades_f['exit_time'])
        trades_f['duration'] = (trades_f['exit_dt'] - trades_f['entry_dt']).dt.total_seconds() / 60  # minutes
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            avg_duration = trades_f['duration'].mean()
            st.metric("Avg Trade Duration", f"{avg_duration:.1f} min")
        
        with col2:
            win_duration = trades_f[trades_f['realized_pnl'] > 0]['duration'].mean()
            st.metric("Avg Win Duration", f"{win_duration:.1f} min" if not pd.isna(win_duration) else "N/A")
        
        with col3:
            loss_duration = trades_f[trades_f['realized_pnl'] < 0]['duration'].mean()
            st.metric("Avg Loss Duration", f"{loss_duration:.1f} min" if not pd.isna(loss_duration) else "N/A")
    
    # Correlation heatmap (if multiple symbols)
    if len(trades_f['symbol'].unique()) > 1:
        st.subheader("Symbol Correlation")
        
        # Create pivot table of daily returns by symbol
        trades_f['date'] = _ts_to_dt(trades_f['entry_time']).dt.date
        daily_pnl = trades_f.pivot_table(
            index='date',
            columns='symbol',
            values='realized_pnl',
            aggfunc='sum',
            fill_value=0
        )
        
        if not daily_pnl.empty and daily_pnl.shape[1] > 1:
            correlation = daily_pnl.corr()
            
            fig = go.Figure(data=go.Heatmap(
                z=correlation.values,
                x=correlation.columns,
                y=correlation.index,
                colorscale='RdBu',
                zmid=0,
                text=correlation.values.round(2),
                texttemplate='%{text}',
                textfont={"size": 10}
            ))
            fig.update_layout(height=400, title="Daily P&L Correlation")
            st.plotly_chart(fig, use_container_width=True)

# Recent Data Tables
st.header("📋 Recent Activity")

tab1, tab2, tab3 = st.tabs(["Recent Trades", "Recent Signals", "Raw Data"])

with tab1:
    if trades_f.empty:
        st.info("No trades to display.")
    else:
        # Format display columns
        display_cols = [col for col in trades_f.columns if col not in ['_dt', 'dt']]
        display_df = trades_f[display_cols].head(100)
        
        # Format numeric columns
        for col in display_df.select_dtypes(include=[np.number]).columns:
            display_df[col] = display_df[col].apply(lambda x: f"{x:,.4f}" if abs(x) < 1000 else f"{x:,.2f}")
        
        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "realized_pnl": st.column_config.NumberColumn(
                    "P&L",
                    format="$%.4f",
                    help="Realized profit/loss"
                ),
                "fee": st.column_config.NumberColumn(
                    "Fee",
                    format="$%.4f"
                )
            }
        )
        
        # Download button
        csv = trades_f.to_csv(index=False)
        st.download_button(
            label="📥 Download Trades CSV",
            data=csv,
            file_name=f"trades_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

with tab2:
    if signals_f.empty:
        st.info("No signals to display.")
    else:
        display_cols = [col for col in signals_f.columns if col not in ['_dt', 'dt']]
        display_df = signals_f[display_cols].head(100)
        
        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True
        )
        
        # Signal statistics
        if 'action' in signals_f.columns:
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Signals", len(signals_f))
            with col2:
                buy_signals = (signals_f['action'] == 'BUY').sum()
                st.metric("Buy Signals", buy_signals)
            with col3:
                sell_signals = (signals_f['action'] == 'SELL').sum()
                st.metric("Sell Signals", sell_signals)

with tab3:
    # Show raw table info
    st.subheader("Database Schema")
    
    for table_name in sorted(TABLES):
        with st.expander(f"Table: {table_name}"):
            try:
                table_info = pd.read_sql_query(f"PRAGMA table_info({table_name})", conn)
                st.write(f"Columns: {len(table_info)}")
                st.dataframe(table_info, use_container_width=True, hide_index=True)
                
                # Show sample data
                sample = pd.read_sql_query(f"SELECT * FROM {table_name} LIMIT 5", conn)
                st.write("Sample data:")
                st.dataframe(sample, use_container_width=True, hide_index=True)
            except Exception as e:
                st.error(f"Error reading table {table_name}: {e}")

# Performance Attribution
st.header("🎯 Performance Attribution")

if not trades_f.empty and 'symbol' in trades_f.columns:
    # Calculate performance by symbol
    perf_by_symbol = trades_f.groupby('symbol').agg({
        'realized_pnl': ['sum', 'count', 'mean', 'std'],
        'fee': 'sum'
    }).round(4)
    
    perf_by_symbol.columns = ['Total P&L', 'Trade Count', 'Avg P&L', 'Std Dev', 'Total Fees']
    perf_by_symbol['Net P&L'] = perf_by_symbol['Total P&L'] - perf_by_symbol['Total Fees']
    perf_by_symbol['Win Rate'] = trades_f.groupby('symbol').apply(
        lambda x: (x['realized_pnl'] > 0).sum() / len(x) * 100
    ).round(1)
    
    # Sort by net P&L
    perf_by_symbol = perf_by_symbol.sort_values('Net P&L', ascending=False)
    
    st.dataframe(
        perf_by_symbol,
        use_container_width=True,
        column_config={
            "Total P&L": st.column_config.NumberColumn(format="$%.2f"),
            "Net P&L": st.column_config.NumberColumn(format="$%.2f"),
            "Total Fees": st.column_config.NumberColumn(format="$%.2f"),
            "Avg P&L": st.column_config.NumberColumn(format="$%.4f"),
            "Std Dev": st.column_config.NumberColumn(format="$%.4f"),
            "Win Rate": st.column_config.NumberColumn(format="%.1f%%")
        }
    )

# Footer
st.markdown("---")
st.caption(f"Dashboard v1.0 • Last update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} • Data source: {db_path}")

# Auto-refresh logic
if auto_refresh:
    import time
    time.sleep(10)
    st.rerun()
# exchange.py
from __future__ import annotations

import os
import time
import math
import json
import random
import hashlib
import asyncio
import threading
from typing import Any, Dict, Optional, Tuple, List, Callable, Union, Set
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import deque, OrderedDict
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from enum import Enum

import ccxt
import pandas as pd

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


# ============================================================================
# Constants and Enums
# ============================================================================

class ExchangeType(Enum):
    SPOT = "spot"
    FUTURE = "future"
    SWAP = "swap"
    MARGIN = "margin"


class OrderType(Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LOSS = "stop_loss"
    STOP_LOSS_LIMIT = "stop_loss_limit"
    TAKE_PROFIT = "take_profit"
    TAKE_PROFIT_LIMIT = "take_profit_limit"
    TRAILING_STOP = "trailing_stop"
    OCO = "oco"


class PositionSide(Enum):
    LONG = "long"
    SHORT = "short"
    BOTH = "both"


class ErrorType(Enum):
    RATE_LIMIT = "rate_limit"
    NETWORK = "network"
    AUTHENTICATION = "auth"
    INSUFFICIENT = "insufficient"
    EXCHANGE = "exchange"
    VALIDATION = "validation"
    TIMEOUT = "timeout"
    OTHER = "other"


# ============================================================================
# Configuration and Validation
# ============================================================================

@dataclass
class ExchangeConfig:
    """Configuration class for exchange with validation."""
    exchange_id: str = "binance"
    quote_asset: str = "USDT"
    enable_futures: bool = False
    hedge_mode: bool = False
    mode: str = "paper"  # paper, live
    api_key: str = ""
    api_secret: str = ""
    passphrase: str = ""  # For exchanges like OKX
    
    # Rate limiting
    min_req_interval_sec: float = 0.0
    enable_rate_limit: bool = True
    rate_limit_window_sec: int = 60
    max_requests_per_window: int = 1200
    
    # Timeouts
    request_timeout_sec: float = 30.0
    connection_timeout_sec: float = 10.0
    
    # Caching
    ticker_cache_ttl_sec: float = 1.5
    order_book_cache_ttl_sec: float = 0.5
    markets_cache_ttl_sec: float = 300.0
    
    # Retry settings
    max_retries: int = 3
    retry_backoff_factor: float = 2.0
    initial_retry_delay_sec: float = 0.5
    
    # Risk management
    max_leverage: int = 20
    default_leverage: int = 1
    margin_mode: str = "isolated"  # isolated, cross
    
    # Features
    preload_markets: bool = True
    auto_set_leverage: bool = True
    auto_set_margin_mode: bool = True
    auto_set_position_mode: bool = True
    enable_ws_fallback: bool = True
    
    # Monitoring
    slow_api_threshold_ms: float = 1500.0
    health_check_interval_sec: float = 60.0
    
    @classmethod
    def from_dict(cls, cfg: Dict[str, Any]) -> "ExchangeConfig":
        """Create and validate configuration from dictionary."""
        # Get environment variables
        exchange_id = str(cfg.get("exchange", "binance")).lower()
        prefix = exchange_id.upper()
        
        api_key = os.getenv(f"{prefix}_API_KEY", "")
        api_secret = os.getenv(f"{prefix}_SECRET", "")
        passphrase = os.getenv(f"{prefix}_PASSPHRASE", "")
        
        # Validate exchange
        if exchange_id not in ccxt.exchanges:
            raise ValueError(f"Unsupported exchange: {exchange_id}")
        
        # Validate mode
        mode = str(cfg.get("mode", "paper")).lower()
        if mode not in ("paper", "live"):
            raise ValueError(f"Invalid mode: {mode}. Must be 'paper' or 'live'")
        
        # Validate futures settings
        enable_futures = cls._as_bool(cfg.get("enable_futures", False))
        hedge_mode = cls._as_bool(cfg.get("futures", {}).get("hedge_mode", False))
        
        if hedge_mode and not enable_futures:
            raise ValueError("Hedge mode requires futures to be enabled")
        
        # Validate timeouts
        request_timeout = max(1.0, float(cfg.get("request_timeout_sec", 30.0)))
        connection_timeout = max(1.0, float(cfg.get("connection_timeout_sec", 10.0)))
        
        # Validate rate limiting
        min_req_interval = max(0.0, float(cfg.get("min_req_interval_sec", 0.0)))
        
        # Validate leverage
        max_leverage = max(1, int(cfg.get("futures", {}).get("max_leverage", 20)))
        default_leverage = min(
            max(1, int(cfg.get("futures", {}).get("default_leverage", 1))),
            max_leverage
        )
        
        return cls(
            exchange_id=exchange_id,
            quote_asset=str(cfg.get("quote_asset", "USDT")).upper(),
            enable_futures=enable_futures,
            hedge_mode=hedge_mode,
            mode=mode,
            api_key=api_key,
            api_secret=api_secret,
            passphrase=passphrase,
            min_req_interval_sec=min_req_interval,
            enable_rate_limit=cls._as_bool(cfg.get("enable_rate_limit", True)),
            rate_limit_window_sec=max(1, int(cfg.get("rate_limit_window_sec", 60))),
            max_requests_per_window=max(10, int(cfg.get("max_requests_per_window", 1200))),
            request_timeout_sec=request_timeout,
            connection_timeout_sec=connection_timeout,
            ticker_cache_ttl_sec=max(0.1, float(cfg.get("ticker_cache_ttl_sec", 1.5))),
            order_book_cache_ttl_sec=max(0.1, float(cfg.get("order_book_cache_ttl_sec", 0.5))),
            markets_cache_ttl_sec=max(10.0, float(cfg.get("markets_cache_ttl_sec", 300.0))),
            max_retries=max(0, int(cfg.get("max_retries", 3))),
            retry_backoff_factor=max(1.0, float(cfg.get("retry_backoff_factor", 2.0))),
            initial_retry_delay_sec=max(0.1, float(cfg.get("initial_retry_delay_sec", 0.5))),
            max_leverage=max_leverage,
            default_leverage=default_leverage,
            margin_mode=str(cfg.get("futures", {}).get("margin_mode", "isolated")).lower(),
            preload_markets=cls._as_bool(cfg.get("preload_markets", True)),
            auto_set_leverage=cls._as_bool(cfg.get("futures", {}).get("auto_set_leverage", True)),
            auto_set_margin_mode=cls._as_bool(cfg.get("futures", {}).get("auto_set_margin_mode", True)),
            auto_set_position_mode=cls._as_bool(cfg.get("futures", {}).get("auto_set_position_mode", True)),
            enable_ws_fallback=cls._as_bool(cfg.get("enable_ws_fallback", True)),
            slow_api_threshold_ms=max(100.0, float(cfg.get("slow_api_ms", 1500.0))),
            health_check_interval_sec=max(10.0, float(cfg.get("health_check_interval_sec", 60.0))),
        )
    
    @staticmethod
    def _as_bool(x: Any, default: bool = False) -> bool:
        """Safely convert any value to boolean."""
        if x is None:
            return default
        if isinstance(x, bool):
            return x
        s = str(x).strip().lower()
        return s in ("1", "true", "yes", "y", "on")
    
    @property
    def is_live_mode(self) -> bool:
        """Check if running in live mode."""
        return self.mode == "live"
    
    @property
    def has_api_keys(self) -> bool:
        """Check if API keys are configured."""
        return bool(self.api_key) and bool(self.api_secret)
    
    @property
    def default_type(self) -> str:
        """Get default CCXT type."""
        if not self.enable_futures:
            return "spot"
        if self.exchange_id == "bybit":
            return "swap"
        return "future"


# ============================================================================
# Caching Classes
# ============================================================================

class LRUCache:
    """LRU Cache with TTL and size limit."""
    def __init__(self, max_size: int = 1000, default_ttl_sec: float = 60.0):
        self.max_size = max_size
        self.default_ttl = default_ttl_sec
        self._cache = OrderedDict()
        self._lock = threading.RLock()
    
    def get(self, key: str) -> Optional[Any]:
        """Get value if not expired."""
        with self._lock:
            if key in self._cache:
                entry_time, value = self._cache[key]
                if time.time() - entry_time < self.default_ttl:
                    # Move to end (most recently used)
                    self._cache.move_to_end(key)
                    return value
                else:
                    # Remove expired
                    self._cache.pop(key)
            return None
    
    def set(self, key: str, value: Any, ttl_sec: Optional[float] = None):
        """Set value with TTL."""
        with self._lock:
            ttl = ttl_sec or self.default_ttl
            self._cache[key] = (time.time() + ttl, value)
            self._cache.move_to_end(key)
            self._cleanup()
    
    def delete(self, key: str) -> bool:
        """Delete a key."""
        with self._lock:
            if key in self._cache:
                self._cache.pop(key)
                return True
            return False
    
    def clear(self):
        """Clear all cache."""
        with self._lock:
            self._cache.clear()
    
    def _cleanup(self):
        """Remove expired entries and trim if needed."""
        now = time.time()
        
        # Remove expired
        expired = []
        for key, (expiry, _) in self._cache.items():
            if now >= expiry:
                expired.append(key)
        
        for key in expired:
            self._cache.pop(key, None)
        
        # Trim if still too large
        while len(self._cache) > self.max_size:
            self._cache.popitem(last=False)
    
    def size(self) -> int:
        """Get current cache size."""
        with self._lock:
            return len(self._cache)
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            now = time.time()
            expired = 0
            for expiry, _ in self._cache.values():
                if now >= expiry:
                    expired += 1
            
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "expired_entries": expired,
                "utilization": len(self._cache) / self.max_size if self.max_size > 0 else 0,
                "default_ttl": self.default_ttl,
            }


class TokenBucket:
    """Token bucket rate limiter."""
    def __init__(self, capacity: int, refill_rate: float):
        self.capacity = capacity
        self.refill_rate = refill_rate  # tokens per second
        self.tokens = capacity
        self.last_refill = time.time()
        self._lock = threading.RLock()
    
    def consume(self, tokens: int = 1) -> bool:
        """Try to consume tokens."""
        with self._lock:
            self._refill()
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False
    
    def _refill(self):
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - self.last_refill
        new_tokens = elapsed * self.refill_rate
        self.tokens = min(self.capacity, self.tokens + new_tokens)
        self.last_refill = now
    
    def wait_until_available(self, tokens: int = 1, timeout: float = 10.0) -> bool:
        """Wait until tokens are available."""
        start = time.time()
        while time.time() - start < timeout:
            if self.consume(tokens):
                return True
            time.sleep(0.01)
        return False
    
    def stats(self) -> Dict[str, Any]:
        """Get bucket statistics."""
        with self._lock:
            self._refill()
            return {
                "capacity": self.capacity,
                "refill_rate": self.refill_rate,
                "current_tokens": self.tokens,
                "utilization": 1.0 - (self.tokens / self.capacity) if self.capacity > 0 else 0,
            }


# ============================================================================
# Metrics Collector
# ============================================================================

@dataclass
class ExchangeMetrics:
    """Metrics collector for exchange operations."""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    rate_limit_hits: int = 0
    timeouts: int = 0
    network_errors: int = 0
    auth_errors: int = 0
    
    # Latency tracking
    latencies_ms: deque = field(default_factory=lambda: deque(maxlen=1000))
    
    # Error tracking
    recent_errors: deque = field(default_factory=lambda: deque(maxlen=100))
    
    # Cache statistics
    cache_hits: int = 0
    cache_misses: int = 0
    
    def record_request(self, success: bool, latency_ms: float, error: Optional[str] = None):
        """Record a request."""
        self.total_requests += 1
        if success:
            self.successful_requests += 1
        else:
            self.failed_requests += 1
            if error:
                self.recent_errors.append(f"{time.time()}: {error}")
        
        self.latencies_ms.append(latency_ms)
    
    def record_error_type(self, error_type: ErrorType):
        """Record error by type."""
        if error_type == ErrorType.RATE_LIMIT:
            self.rate_limit_hits += 1
        elif error_type == ErrorType.TIMEOUT:
            self.timeouts += 1
        elif error_type == ErrorType.NETWORK:
            self.network_errors += 1
        elif error_type == ErrorType.AUTHENTICATION:
            self.auth_errors += 1
    
    def record_cache_hit(self, hit: bool):
        """Record cache hit/miss."""
        if hit:
            self.cache_hits += 1
        else:
            self.cache_misses += 1
    
    def get_latency_stats(self) -> Dict[str, float]:
        """Get latency statistics."""
        if not self.latencies_ms:
            return {}
        
        latencies = list(self.latencies_ms)
        try:
            import statistics
            return {
                "avg": statistics.mean(latencies),
                "p50": statistics.median(latencies),
                "p90": statistics.quantiles(latencies, n=10)[8] if len(latencies) >= 10 else 0,
                "p95": statistics.quantiles(latencies, n=20)[18] if len(latencies) >= 5 else 0,
                "p99": statistics.quantiles(latencies, n=100)[98] if len(latencies) >= 5 else 0,
                "min": min(latencies),
                "max": max(latencies),
            }
        except Exception:
            return {}
    
    def get_success_rate(self) -> float:
        """Calculate success rate."""
        total = self.successful_requests + self.failed_requests
        return self.successful_requests / total if total > 0 else 0.0
    
    def get_cache_hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.cache_hits + self.cache_misses
        return self.cache_hits / total if total > 0 else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "total_requests": self.total_requests,
            "successful_requests": self.successful_requests,
            "failed_requests": self.failed_requests,
            "success_rate": self.get_success_rate(),
            "rate_limit_hits": self.rate_limit_hits,
            "timeouts": self.timeouts,
            "network_errors": self.network_errors,
            "auth_errors": self.auth_errors,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate": self.get_cache_hit_rate(),
            "latency_stats": self.get_latency_stats(),
            "recent_errors": list(self.recent_errors)[-10:],  # Last 10 errors
        }


# ============================================================================
# Circuit Breaker
# ============================================================================

class CircuitBreaker:
    """Circuit breaker for fault tolerance."""
    def __init__(self, failure_threshold: int = 5, reset_timeout_sec: float = 60.0):
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout_sec
        self.failure_count = 0
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
        self._lock = threading.RLock()
    
    def record_success(self):
        """Record a successful operation."""
        with self._lock:
            self.failure_count = 0
            self.state = "CLOSED"
    
    def record_failure(self):
        """Record a failed operation."""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
    
    def can_execute(self) -> bool:
        """Check if execution is allowed."""
        with self._lock:
            if self.state == "CLOSED":
                return True
            
            if self.state == "OPEN":
                # Check if enough time has passed for reset
                if time.time() - self.last_failure_time > self.reset_timeout:
                    self.state = "HALF_OPEN"
                    return True
                return False
            
            # HALF_OPEN - allow one attempt for testing
            return True
    
    def get_state(self) -> str:
        """Get current state."""
        with self._lock:
            return self.state
    
    def stats(self) -> Dict[str, Any]:
        """Get circuit breaker statistics."""
        with self._lock:
            return {
                "state": self.state,
                "failure_count": self.failure_count,
                "last_failure_time": self.last_failure_time,
                "reset_timeout": self.reset_timeout,
                "failure_threshold": self.failure_threshold,
                "is_open": self.state == "OPEN",
            }


# ============================================================================
# Main Exchange Client
# ============================================================================

class ExchangeClient:
    """
    Advanced CCXT wrapper with:
    - Circuit breaker pattern
    - Rate limiting with token bucket
    - Comprehensive caching
    - Advanced error handling
    - Metrics collection
    - Automatic reconnection
    - Health checks
    - Batch operations
    """
    
    def __init__(self, cfg: Dict[str, Any], log: Any = None, ws_cache: Any = None):
        self.config = ExchangeConfig.from_dict(cfg)
        self.log = log or self._create_default_logger()
        self.ws_cache = ws_cache
        
        # CCXT exchange instance
        self.ex = self._create_exchange()
        
        # Caches
        self.ticker_cache = LRUCache(max_size=1000, default_ttl_sec=self.config.ticker_cache_ttl_sec)
        self.order_book_cache = LRUCache(max_size=100, default_ttl_sec=self.config.order_book_cache_ttl_sec)
        self.markets_cache = LRUCache(max_size=1, default_ttl_sec=self.config.markets_cache_ttl_sec)
        
        # Rate limiter
        if self.config.enable_rate_limit:
            tokens_per_second = self.config.max_requests_per_window / self.config.rate_limit_window_sec
            self.rate_limiter = TokenBucket(
                capacity=self.config.max_requests_per_window,
                refill_rate=tokens_per_second
            )
        else:
            self.rate_limiter = None
        
        # Circuit breaker
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            reset_timeout_sec=60.0
        )
        
        # Metrics
        self.metrics = ExchangeMetrics()
        
        # Thread pool for async operations
        self.thread_pool = ThreadPoolExecutor(max_workers=4)
        
        # State
        self._markets: Dict[str, Any] = {}
        self._last_request_time = 0.0
        self._lock = threading.RLock()
        self._shutdown = False
        
        # Health check thread
        self._health_check_thread = None
        self._start_health_check()
        
        # Initialize
        self._initialize()
    
    def _create_default_logger(self):
        """Create a default logger if none provided."""
        import logging
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _log(self, level: str, msg: str, *args, **kwargs):
        """Log message with given level."""
        try:
            if hasattr(self.log, level):
                getattr(self.log, level)(msg, *args, **kwargs)
            else:
                print(f"[{level.upper()}] {msg}")
        except Exception:
            print(f"[{level.upper()}] {msg}")
    
    # ------------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------------
    
    def _create_exchange(self):
        """Create and configure CCXT exchange instance."""
        ex_class = getattr(ccxt, self.config.exchange_id, None)
        if ex_class is None:
            raise ValueError(f"Exchange {self.config.exchange_id} not found in CCXT")
        
        params = {
            "enableRateLimit": self.config.enable_rate_limit,
            "options": {"defaultType": self.config.default_type},
            "timeout": int(self.config.request_timeout_sec * 1000),
        }
        
        # Add API credentials if available
        if self.config.has_api_keys:
            params["apiKey"] = self.config.api_key
            params["secret"] = self.config.api_secret
            if self.config.passphrase:
                params["password"] = self.config.passphrase
        
        # Exchange-specific configurations
        if self.config.exchange_id == "binance":
            params["options"].update({
                "adjustForTimeDifference": True,
                "recvWindow": 10000,
                "defaultTimeInForce": "GTC",
            })
        elif self.config.exchange_id == "bybit":
            params["options"].update({
                "defaultType": self.config.default_type,
            })
        elif self.config.exchange_id == "okx":
            params["options"].update({
                "defaultType": self.config.default_type,
            })
            if self.config.passphrase:
                params["options"]["passphrase"] = self.config.passphrase
        
        return ex_class(params)
    
    def _initialize(self):
        """Initialize exchange client."""
        try:
            # Test connection
            self._test_connection()
            
            # Load markets if configured
            if self.config.preload_markets:
                self.load_markets()
            
            # Configure futures settings if enabled
            if self.config.enable_futures:
                self._configure_futures()
            
            self._log("info", f"✅ Exchange client initialized: {self.config.exchange_id.upper()} "
                   f"({self.config.default_type.upper()}, mode={self.config.mode})")
        
        except Exception as e:
            if self.config.is_live_mode:
                raise RuntimeError(f"Failed to initialize exchange: {e}") from e
            self._log("warning", f"⚠️ Exchange initialization failed (paper mode): {e}")
    
    def _configure_futures(self):
        """Configure futures settings."""
        try:
            if self.config.auto_set_position_mode:
                self.set_position_mode(self.config.hedge_mode)
            
            # Load markets to get symbols
            markets = self.load_markets()
            
            # Apply default leverage and margin mode to all futures symbols
            if self.config.auto_set_leverage or self.config.auto_set_margin_mode:
                futures_symbols = [
                    sym for sym, info in markets.items()
                    if info.get("type", "").lower() in ("future", "swap", "perpetual")
                ]
                
                for symbol in futures_symbols[:10]:  # Limit to first 10 symbols
                    try:
                        if self.config.auto_set_margin_mode:
                            self.set_margin_mode(symbol, self.config.margin_mode)
                        
                        if self.config.auto_set_leverage:
                            self.set_leverage(symbol, self.config.default_leverage)
                    
                    except Exception as e:
                        self._log("debug", f"Could not configure {symbol}: {e}")
        
        except Exception as e:
            self._log("warning", f"Failed to configure futures: {e}")
    
    def _test_connection(self):
        """Test exchange connection."""
        has_keys = self.config.has_api_keys
        
        try:
            if has_keys:
                # Test with authenticated endpoint
                balance = self._safe_call("fetch_balance", self.ex.fetch_balance)
                total = balance.get("total", {})
                usdt_balance = total.get(self.config.quote_asset, 0.0)
                
                self._log("info", f"Authenticated connection OK. {self.config.quote_asset} balance: {usdt_balance}")
            
            else:
                # Test with public endpoint
                try:
                    self.ex.fetch_time()
                except Exception:
                    # Try with ticker as fallback
                    symbols = getattr(self.ex, "symbols", [])
                    test_symbol = "BTC/USDT"
                    if symbols and test_symbol not in symbols:
                        test_symbol = symbols[0]
                    self.ex.fetch_ticker(test_symbol)
                
                self._log("info", "Public connection OK")
        
        except Exception as e:
            if self.config.is_live_mode and has_keys:
                raise RuntimeError(f"Failed to connect to exchange: {e}") from e
            self._log("warning", f"Connection test failed: {e}")
    
    # ------------------------------------------------------------------------
    # Health Checking
    # ------------------------------------------------------------------------
    
    def _start_health_check(self):
        """Start periodic health check."""
        def health_check_loop():
            while not self._shutdown:
                try:
                    time.sleep(self.config.health_check_interval_sec)
                    self._perform_health_check()
                except Exception as e:
                    self._log("error", f"Health check failed: {e}")
        
        self._health_check_thread = threading.Thread(target=health_check_loop, daemon=True)
        self._health_check_thread.start()
    
    def _perform_health_check(self):
        """Perform health check."""
        try:
            # Test basic connectivity
            if self.config.has_api_keys:
                self.ex.fetch_balance()
            else:
                self.ex.fetch_time()
            
            # Check circuit breaker
            if self.circuit_breaker.get_state() == "OPEN":
                self._log("warning", "Circuit breaker is OPEN")
            
            # Log metrics
            stats = self.metrics.to_dict()
            success_rate = stats.get("success_rate", 0)
            
            if success_rate < 0.9:
                self._log("warning", f"Low success rate: {success_rate:.1%}")
            
            self._log("debug", f"Health check OK. Success rate: {success_rate:.1%}")
        
        except Exception as e:
            self._log("warning", f"Health check failed: {e}")
    
    # ------------------------------------------------------------------------
    # Rate Limiting and Request Management
    # ------------------------------------------------------------------------
    
    def _rate_limit_check(self):
        """Apply rate limiting."""
        # Local pacing guard
        if self.config.min_req_interval_sec > 0:
            now = time.time()
            elapsed = now - self._last_request_time
            if elapsed < self.config.min_req_interval_sec:
                time.sleep(self.config.min_req_interval_sec - elapsed)
            self._last_request_time = time.time()
        
        # Token bucket rate limiting
        if self.rate_limiter:
            if not self.rate_limiter.wait_until_available(timeout=5.0):
                raise RuntimeError("Rate limit timeout")
    
    def _classify_error(self, error: Exception) -> ErrorType:
        """Classify exception for appropriate handling."""
        error_str = str(error).lower()
        error_type = type(error).__name__.lower()
        
        if "rate limit" in error_str or "429" in error_str or "too many" in error_str:
            return ErrorType.RATE_LIMIT
        elif "timeout" in error_str or "time out" in error_str:
            return ErrorType.TIMEOUT
        elif "network" in error_str or "connection" in error_str or "econn" in error_str:
            return ErrorType.NETWORK
        elif "authentication" in error_str or "invalid api" in error_str or "permission" in error_str:
            return ErrorType.AUTHENTICATION
        elif "insufficient" in error_str or "not enough" in error_str:
            return ErrorType.INSUFFICIENT
        elif "exchange" in error_str or error_type.endswith("error"):
            return ErrorType.EXCHANGE
        else:
            return ErrorType.OTHER
    
    def _should_retry_error(self, error: Exception) -> bool:
        """Determine if error should be retried."""
        error_type = self._classify_error(error)
        retryable_errors = {
            ErrorType.RATE_LIMIT,
            ErrorType.NETWORK,
            ErrorType.TIMEOUT,
        }
        return error_type in retryable_errors
    
    def _safe_call(self, operation: str, func: Callable, *args, **kwargs) -> Any:
        """
        Safe wrapper for CCXT calls with:
        - Rate limiting
        - Circuit breaker
        - Retry logic
        - Metrics collection
        - Error classification
        """
        # Check circuit breaker
        if not self.circuit_breaker.can_execute():
            self.metrics.record_error_type(ErrorType.RATE_LIMIT)
            raise RuntimeError("Circuit breaker is OPEN")
        
        # Apply rate limiting
        self._rate_limit_check()
        
        # Retry loop
        last_error = None
        delay = self.config.initial_retry_delay_sec
        
        for attempt in range(self.config.max_retries + 1):
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000
                
                # Record success
                self.metrics.record_request(True, latency_ms)
                self.circuit_breaker.record_success()
                
                # Log slow operations
                if latency_ms > self.config.slow_api_threshold_ms:
                    self._log("warning", f"Slow {operation}: {latency_ms:.0f}ms")
                
                return result
            
            except Exception as e:
                latency_ms = (time.time() - start_time) * 1000
                error_type = self._classify_error(e)
                
                # Record failure
                self.metrics.record_request(False, latency_ms, str(e))
                self.metrics.record_error_type(error_type)
                self.circuit_breaker.record_failure()
                
                last_error = e
                
                # Check if should retry
                if attempt < self.config.max_retries and self._should_retry_error(e):
                    # Add jitter to avoid thundering herd
                    jitter = random.uniform(0.8, 1.2)
                    sleep_time = delay * jitter
                    
                    self._log("warning", 
                           f"{operation} failed (attempt {attempt + 1}/{self.config.max_retries + 1}): "
                           f"{error_type.value} - Retrying in {sleep_time:.2f}s")
                    
                    time.sleep(sleep_time)
                    delay *= self.config.retry_backoff_factor
                
                else:
                    # Final attempt failed
                    self._log("error", 
                           f"{operation} failed after {attempt + 1} attempts: {error_type.value}: {e}")
                    raise
        
        raise last_error  # Should never reach here
    
    # ------------------------------------------------------------------------
    # Symbol Management
    # ------------------------------------------------------------------------
    
    def _normalize_symbol(self, symbol: str) -> str:
        """Normalize symbol for exchange."""
        symbol = str(symbol).strip().upper()
        
        # Handle futures symbols
        if self.config.enable_futures:
            # Check if symbol already has suffix
            if ":" not in symbol:
                # Try to add standard suffix
                suffix = f":{self.config.quote_asset}"
                
                # Check if markets are loaded
                if self._markets:
                    # Try with suffix
                    if f"{symbol}{suffix}" in self._markets:
                        return f"{symbol}{suffix}"
                
                # Return as-is for now
                return symbol
            
        return symbol
    
    def _denormalize_symbol(self, symbol: str) -> str:
        """Remove exchange-specific suffix."""
        if ":" in symbol:
            return symbol.split(":")[0]
        return symbol
    
    def _get_symbol_info(self, symbol: str) -> Dict[str, Any]:
        """Get symbol information from markets."""
        normalized = self._normalize_symbol(symbol)
        
        if not self._markets:
            self.load_markets()
        
        return self._markets.get(normalized, {})
    
    # ------------------------------------------------------------------------
    # Market Data
    # ------------------------------------------------------------------------
    
    def load_markets(self, reload: bool = False) -> Dict[str, Any]:
        """Load markets with caching."""
        cache_key = "markets"
        
        # Check cache
        cached = self.markets_cache.get(cache_key)
        if cached and not reload:
            self._markets = cached
            self.metrics.record_cache_hit(True)
            return cached
        
        self.metrics.record_cache_hit(False)
        
        # Load from exchange
        markets = self._safe_call("load_markets", self.ex.load_markets)
        
        # Cache results
        self._markets = markets
        self.markets_cache.set(cache_key, markets)
        
        return markets
    
    def fetch_ticker(self, symbol: str, use_cache: bool = True) -> Dict[str, Any]:
        """Fetch ticker with caching and WS fallback."""
        normalized = self._normalize_symbol(symbol)
        
        # Try WebSocket cache first
        if self.config.enable_ws_fallback and self.ws_cache:
            try:
                ws_ticker = self.ws_cache.get_ticker(normalized)
                if ws_ticker and self._is_valid_ticker(ws_ticker):
                    self.metrics.record_cache_hit(True)
                    return ws_ticker
            except Exception:
                pass
        
        # Check memory cache
        if use_cache:
            cached = self.ticker_cache.get(normalized)
            if cached:
                self.metrics.record_cache_hit(True)
                return cached
        
        self.metrics.record_cache_hit(False)
        
        # Fetch from exchange
        ticker = self._safe_call("fetch_ticker", self.ex.fetch_ticker, normalized)
        
        # Calculate quote volume if missing
        if ticker.get("quoteVolume") is None and ticker.get("baseVolume") and ticker.get("last"):
            try:
                ticker["quoteVolume"] = float(ticker["baseVolume"]) * float(ticker["last"])
            except Exception:
                pass
        
        # Cache result
        self.ticker_cache.set(normalized, ticker)
        
        return ticker
    
    def _is_valid_ticker(self, ticker: Dict[str, Any]) -> bool:
        """Validate ticker data."""
        required_fields = ["bid", "ask", "last"]
        return all(field in ticker and ticker[field] is not None for field in required_fields)
    
    def fetch_order_book(self, symbol: str, limit: int = 20, use_cache: bool = True) -> Dict[str, Any]:
        """Fetch order book with caching."""
        normalized = self._normalize_symbol(symbol)
        cache_key = f"orderbook:{normalized}:{limit}"
        
        if use_cache:
            cached = self.order_book_cache.get(cache_key)
            if cached:
                self.metrics.record_cache_hit(True)
                return cached
        
        self.metrics.record_cache_hit(False)
        
        orderbook = self._safe_call("fetch_order_book", self.ex.fetch_order_book, normalized, limit)
        
        if use_cache:
            self.order_book_cache.set(cache_key, orderbook)
        
        return orderbook
    
    def fetch_ohlcv(self, symbol: str, timeframe: str = "1m", limit: int = 300, 
                   since: Optional[int] = None) -> List[List[float]]:
        """Fetch OHLCV data."""
        normalized = self._normalize_symbol(symbol)
        return self._safe_call("fetch_ohlcv", self.ex.fetch_ohlcv, normalized, 
                             timeframe=timeframe, limit=limit, since=since)
    
    def fetch_ohlcv_df(self, symbol: str, timeframe: str = "1m", limit: int = 300,
                      since: Optional[int] = None) -> pd.DataFrame:
        """Fetch OHLCV as pandas DataFrame."""
        ohlcv = self.fetch_ohlcv(symbol, timeframe, limit, since)
        
        if not ohlcv:
            return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])
        
        df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        df.set_index("timestamp", inplace=True)
        
        return df
    
    # ------------------------------------------------------------------------
    # Account Information
    # ------------------------------------------------------------------------
    
    def fetch_balance(self) -> Dict[str, Any]:
        """Fetch account balance."""
        return self._safe_call("fetch_balance", self.ex.fetch_balance)
    
    def get_balance(self, asset: str) -> float:
        """Get balance for specific asset."""
        balance = self.fetch_balance()
        total = balance.get("total", {})
        return float(total.get(asset.upper(), 0.0))
    
    def fetch_positions(self) -> List[Dict[str, Any]]:
        """Fetch open positions."""
        if not self.config.enable_futures:
            return []
        
        try:
            if hasattr(self.ex, "fetch_positions"):
                positions = self._safe_call("fetch_positions", self.ex.fetch_positions)
                return self._normalize_positions(positions)
            else:
                self._log("warning", "fetch_positions not supported")
                return []
        
        except Exception as e:
            self._log("error", f"Failed to fetch positions: {e}")
            return []
    
    def _normalize_positions(self, positions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Normalize position data from different exchanges."""
        normalized = []
        
        for pos in positions:
            try:
                # Extract basic information
                symbol = pos.get("symbol") or ""
                contracts = pos.get("contracts", 0)
                
                # Skip zero positions
                if not contracts or float(contracts) == 0:
                    continue
                
                # Determine side
                side = str(pos.get("side", "")).lower()
                if not side:
                    side = "long" if float(contracts) > 0 else "short"
                
                # Extract entry price
                entry_price = pos.get("entryPrice") or pos.get("averagePrice") or 0.0
                
                # Extract unrealized P&L
                unrealized_pnl = pos.get("unrealizedPnl") or pos.get("unrealizedProfit") or 0.0
                
                # Extract leverage
                leverage = pos.get("leverage") or 1.0
                
                normalized.append({
                    "symbol": self._normalize_symbol(symbol),
                    "side": side,
                    "size": abs(float(contracts)),
                    "entry_price": float(entry_price),
                    "mark_price": float(pos.get("markPrice") or pos.get("mark_price") or 0.0),
                    "liquidation_price": float(pos.get("liquidationPrice") or 0.0),
                    "unrealized_pnl": float(unrealized_pnl),
                    "leverage": float(leverage),
                    "margin_mode": pos.get("marginMode", ""),
                    "raw": pos,  # Keep raw data
                })
            
            except Exception as e:
                self._log("debug", f"Failed to normalize position: {e}")
                continue
        
        return normalized
    
    def fetch_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """Fetch open orders."""
        try:
            if symbol:
                normalized = self._normalize_symbol(symbol)
                orders = self._safe_call("fetch_open_orders", self.ex.fetch_open_orders, normalized)
            else:
                orders = self._safe_call("fetch_open_orders", self.ex.fetch_open_orders)
            
            return self._normalize_orders(orders)
        
        except Exception as e:
            self._log("error", f"Failed to fetch open orders: {e}")
            return []
    
    def _normalize_orders(self, orders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Normalize order data."""
        normalized = []
        
        for order in orders:
            try:
                normalized.append({
                    "id": order.get("id"),
                    "client_order_id": order.get("clientOrderId"),
                    "symbol": self._normalize_symbol(order.get("symbol")),
                    "type": order.get("type"),
                    "side": order.get("side"),
                    "price": float(order.get("price") or 0.0),
                    "amount": float(order.get("amount") or 0.0),
                    "filled": float(order.get("filled") or 0.0),
                    "remaining": float(order.get("remaining") or 0.0),
                    "status": order.get("status"),
                    "timestamp": order.get("timestamp"),
                    "raw": order,  # Keep raw data
                })
            
            except Exception as e:
                self._log("debug", f"Failed to normalize order: {e}")
                continue
        
        return normalized
    
    # ------------------------------------------------------------------------
    # Trading Operations
    # ------------------------------------------------------------------------
    
    def create_order(self, symbol: str, order_type: str, side: str, 
                    amount: float, price: Optional[float] = None,
                    params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create order with validation."""
        normalized = self._normalize_symbol(symbol)
        
        # Validate inputs
        amount = float(amount)
        if amount <= 0:
            raise ValueError("Amount must be positive")
        
        if price is not None:
            price = float(price)
            if price <= 0:
                raise ValueError("Price must be positive")
        
        # Enforce trading rules
        amount, price = self.enforce_trade_rules(normalized, side, amount, price)
        
        # Prepare parameters
        order_params = params or {}
        
        # Add position side for hedge mode
        if self.config.enable_futures and self.config.hedge_mode:
            if "positionSide" not in order_params:
                order_params["positionSide"] = side.upper()
        
        return self._safe_call("create_order", self.ex.create_order,
                             normalized, order_type, side, amount, price, order_params)
    
    def create_market_order(self, symbol: str, side: str, amount: float,
                           params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create market order."""
        return self.create_order(symbol, "market", side, amount, None, params)
    
    def create_limit_order(self, symbol: str, side: str, amount: float, price: float,
                          params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create limit order."""
        return self.create_order(symbol, "limit", side, amount, price, params)
    
    def create_stop_loss_order(self, symbol: str, side: str, amount: float,
                              stop_price: float, limit_price: Optional[float] = None,
                              params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create stop loss order."""
        normalized = self._normalize_symbol(symbol)
        
        order_params = params or {}
        order_params["stopPrice"] = float(stop_price)
        
        if limit_price:
            return self.create_order(normalized, "stop_loss_limit", side, amount, limit_price, order_params)
        else:
            return self.create_order(normalized, "stop_loss", side, amount, None, order_params)
    
    def create_take_profit_order(self, symbol: str, side: str, amount: float,
                                take_price: float, limit_price: Optional[float] = None,
                                params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create take profit order."""
        normalized = self._normalize_symbol(symbol)
        
        order_params = params or {}
        order_params["stopPrice"] = float(take_price)
        
        if limit_price:
            return self.create_order(normalized, "take_profit_limit", side, amount, limit_price, order_params)
        else:
            return self.create_order(normalized, "take_profit", side, amount, None, order_params)
    
    def cancel_order(self, order_id: str, symbol: str,
                    params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Cancel order."""
        normalized = self._normalize_symbol(symbol)
        return self._safe_call("cancel_order", self.ex.cancel_order,
                             order_id, normalized, params or {})
    
    def cancel_all_orders(self, symbol: Optional[str] = None):
        """Cancel all orders."""
        try:
            if symbol:
                normalized = self._normalize_symbol(symbol)
                self._safe_call("cancel_all_orders", self.ex.cancel_all_orders, normalized)
            else:
                self._safe_call("cancel_all_orders", self.ex.cancel_all_orders)
        
        except Exception as e:
            self._log("warning", f"Failed to cancel all orders: {e}")
            
            # Fallback: cancel orders one by one
            orders = self.fetch_open_orders(symbol)
            for order in orders:
                try:
                    self.cancel_order(order["id"], order["symbol"])
                except Exception:
                    continue
    
    def fetch_order(self, order_id: str, symbol: str) -> Dict[str, Any]:
        """Fetch order by ID."""
        normalized = self._normalize_symbol(symbol)
        return self._safe_call("fetch_order", self.ex.fetch_order, order_id, normalized)
    
    # ------------------------------------------------------------------------
    # Futures Operations
    # ------------------------------------------------------------------------
    
    def set_leverage(self, symbol: str, leverage: int):
        """Set leverage for symbol."""
        if not self.config.enable_futures:
            raise RuntimeError("Futures not enabled")
        
        leverage = int(leverage)
        if leverage < 1 or leverage > self.config.max_leverage:
            raise ValueError(f"Leverage must be between 1 and {self.config.max_leverage}")
        
        normalized = self._normalize_symbol(symbol)
        
        if hasattr(self.ex, "set_leverage"):
            self._safe_call("set_leverage", self.ex.set_leverage, leverage, normalized)
        else:
            self._log("warning", "set_leverage not supported")
    
    def set_margin_mode(self, symbol: str, mode: str = "isolated"):
        """Set margin mode for symbol."""
        if not self.config.enable_futures:
            raise RuntimeError("Futures not enabled")
        
        mode = mode.lower()
        if mode not in ("isolated", "cross"):
            raise ValueError("Margin mode must be 'isolated' or 'cross'")
        
        normalized = self._normalize_symbol(symbol)
        
        if hasattr(self.ex, "set_margin_mode"):
            self._safe_call("set_margin_mode", self.ex.set_margin_mode, mode, normalized)
        else:
            self._log("warning", "set_margin_mode not supported")
    
    def set_position_mode(self, hedge: bool):
        """Set position mode (hedge or one-way)."""
        if not self.config.enable_futures:
            raise RuntimeError("Futures not enabled")
        
        if hasattr(self.ex, "set_position_mode"):
            self._safe_call("set_position_mode", self.ex.set_position_mode, bool(hedge))
        else:
            self._log("warning", "set_position_mode not supported")
    
    def fetch_funding_rate(self, symbol: str) -> Optional[float]:
        """Fetch funding rate for symbol."""
        if not self.config.enable_futures:
            return None
        
        normalized = self._normalize_symbol(symbol)
        
        try:
            funding = self._safe_call("fetch_funding_rate", self.ex.fetch_funding_rate, normalized)
            
            if isinstance(funding, dict):
                rate = funding.get("fundingRate") or funding.get("info", {}).get("fundingRate")
                if rate is not None:
                    return float(rate)
            
            return None
        
        except Exception as e:
            self._log("debug", f"Failed to fetch funding rate: {e}")
            return None
    
    # ------------------------------------------------------------------------
    # Risk Management and Validation
    # ------------------------------------------------------------------------
    
    def enforce_trade_rules(self, symbol: str, side: str, 
                           amount: float, price: Optional[float]) -> Tuple[float, float]:
        """Enforce trading rules (min amounts, costs, etc.)."""
        amount = float(amount)
        
        # Get symbol info
        info = self._get_symbol_info(symbol)
        if not info:
            self._log("warning", f"No market info for {symbol}, skipping validation")
            return amount, price if price else 0.0
        
        # Get limits
        limits = info.get("limits", {})
        amount_limits = limits.get("amount", {})
        price_limits = limits.get("price", {})
        cost_limits = limits.get("cost", {})
        
        # Amount precision
        precision = info.get("precision", {}).get("amount", 8)
        amount = round(amount, precision)
        
        # Min amount
        min_amount = amount_limits.get("min")
        if min_amount and amount < float(min_amount):
            amount = float(min_amount)
        
        # Max amount
        max_amount = amount_limits.get("max")
        if max_amount and amount > float(max_amount):
            amount = float(max_amount)
        
        # Price validation
        if price is not None:
            price = float(price)
            price_precision = info.get("precision", {}).get("price", 8)
            price = round(price, price_precision)
            
            # Min price
            min_price = price_limits.get("min")
            if min_price and price < float(min_price):
                price = float(min_price)
            
            # Max price
            max_price = price_limits.get("max")
            if max_price and price > float(max_price):
                price = float(max_price)
            
            # Min cost
            min_cost = cost_limits.get("min")
            if min_cost and amount * price < float(min_cost):
                # Increase amount to meet min cost
                required_amount = float(min_cost) / price
                if required_amount <= (max_amount or float('inf')):
                    amount = required_amount
        
        return amount, price if price is not None else 0.0
    
    def calculate_position_size(self, symbol: str, risk_per_trade: float,
                               stop_loss_pct: float, account_size: float) -> float:
        """Calculate position size based on risk management."""
        if stop_loss_pct <= 0:
            raise ValueError("Stop loss percentage must be positive")
        
        # Get current price
        ticker = self.fetch_ticker(symbol)
        current_price = float(ticker.get("last", 0))
        
        if current_price <= 0:
            raise ValueError("Invalid current price")
        
        # Calculate position size
        risk_amount = account_size * (risk_per_trade / 100)
        risk_per_unit = current_price * (stop_loss_pct / 100)
        
        if risk_per_unit <= 0:
            raise ValueError("Risk per unit must be positive")
        
        position_size = risk_amount / risk_per_unit
        
        # Apply trading rules
        position_size, _ = self.enforce_trade_rules(symbol, "buy", position_size, current_price)
        
        return position_size
    
    # ------------------------------------------------------------------------
    # Batch Operations
    # ------------------------------------------------------------------------
    
    def fetch_multiple_tickers(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Fetch multiple tickers efficiently."""
        results = {}
        
        # Use ThreadPoolExecutor for parallel fetching
        with ThreadPoolExecutor(max_workers=min(10, len(symbols))) as executor:
            futures = {
                executor.submit(self.fetch_ticker, sym): sym
                for sym in symbols
            }
            
            for future in futures:
                symbol = futures[future]
                try:
                    results[symbol] = future.result(timeout=10.0)
                except Exception as e:
                    self._log("warning", f"Failed to fetch ticker for {symbol}: {e}")
                    results[symbol] = {}
        
        return results
    
    def place_multiple_orders(self, orders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Place multiple orders with rate limiting."""
        results = []
        
        for order in orders:
            try:
                result = self.create_order(
                    symbol=order["symbol"],
                    order_type=order.get("type", "market"),
                    side=order["side"],
                    amount=order["amount"],
                    price=order.get("price"),
                    params=order.get("params")
                )
                results.append({"success": True, "result": result})
            
            except Exception as e:
                results.append({"success": False, "error": str(e)})
            
            # Small delay between orders
            time.sleep(0.1)
        
        return results
    
    # ------------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------------
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        return {
            "config": {
                "exchange": self.config.exchange_id,
                "mode": self.config.mode,
                "type": self.config.default_type,
                "has_api_keys": self.config.has_api_keys,
            },
            "metrics": self.metrics.to_dict(),
            "cache": {
                "ticker": self.ticker_cache.stats(),
                "order_book": self.order_book_cache.stats(),
                "markets": self.markets_cache.stats(),
            },
            "rate_limiter": self.rate_limiter.stats() if self.rate_limiter else None,
            "circuit_breaker": self.circuit_breaker.stats(),
            "markets_loaded": bool(self._markets),
            "markets_count": len(self._markets),
        }
    
    def clear_caches(self):
        """Clear all caches."""
        self.ticker_cache.clear()
        self.order_book_cache.clear()
        self.markets_cache.clear()
        self._log("info", "All caches cleared")
    
    def reset_metrics(self):
        """Reset all metrics."""
        self.metrics = ExchangeMetrics()
        self._log("info", "Metrics reset")
    
    def close(self):
        """Cleanup resources."""
        self._shutdown = True
        
        if self._health_check_thread:
            self._health_check_thread.join(timeout=5.0)
        
        self.thread_pool.shutdown(wait=True)
        self.clear_caches()
        
        self._log("info", "Exchange client closed")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ============================================================================
# Factory Function
# ============================================================================

def create_exchange_client(cfg: Dict[str, Any], log: Any = None, ws_cache: Any = None) -> ExchangeClient:
    """Factory function to create exchange client."""
    return ExchangeClient(cfg, log, ws_cache)


# ============================================================================
# Async Support (Optional)
# ============================================================================

try:
    import asyncio
    import ccxt.async_support as ccxt_async
    
    class AsyncExchangeClient:
        """Async version of ExchangeClient using CCXT async support."""
        
        def __init__(self, cfg: Dict[str, Any], log: Any = None):
            self.config = ExchangeConfig.from_dict(cfg)
            self.log = log or self._create_default_logger()
            self.ex = self._create_async_exchange()
            self._lock = asyncio.Lock()
        
        def _create_async_exchange(self):
            """Create async CCXT exchange."""
            ex_class = getattr(ccxt_async, self.config.exchange_id, None)
            if ex_class is None:
                raise ValueError(f"Exchange {self.config.exchange_id} not found")
            
            params = {
                "enableRateLimit": self.config.enable_rate_limit,
                "options": {"defaultType": self.config.default_type},
            }
            
            if self.config.has_api_keys:
                params["apiKey"] = self.config.api_key
                params["secret"] = self.config.api_secret
                if self.config.passphrase:
                    params["password"] = self.config.passphrase
            
            return ex_class(params)
        
        async def fetch_ticker_async(self, symbol: str) -> Dict[str, Any]:
            """Async fetch ticker."""
            async with self._lock:
                return await self.ex.fetch_ticker(symbol)
        
        async def create_order_async(self, symbol: str, order_type: str, side: str,
                                   amount: float, price: Optional[float] = None) -> Dict[str, Any]:
            """Async create order."""
            async with self._lock:
                return await self.ex.create_order(symbol, order_type, side, amount, price)
        
        async def close_async(self):
            """Close async client."""
            await self.ex.close()

except ImportError:
    # Async support not available
    pass


# ============================================================================
# Testing Helper
# ============================================================================

class MockExchangeClient(ExchangeClient):
    """Mock exchange client for testing."""
    
    def __init__(self, cfg: Dict[str, Any], log: Any = None):
        super().__init__(cfg, log)
        
        # Mock data storage
        self._mock_balance = {"USDT": 10000.0, "BTC": 0.0}
        self._mock_positions = []
        self._mock_orders = []
        self._mock_tickers = {}
        
        self._log("info", "Using mock exchange client")
    
    def fetch_balance(self) -> Dict[str, Any]:
        """Mock fetch balance."""
        return {
            "total": self._mock_balance,
            "free": self._mock_balance.copy(),
            "used": {k: 0.0 for k in self._mock_balance},
        }
    
    def create_order(self, symbol: str, order_type: str, side: str,
                    amount: float, price: Optional[float] = None,
                    params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Mock create order."""
        order_id = f"mock_order_{int(time.time() * 1000)}"
        order = {
            "id": order_id,
            "symbol": symbol,
            "type": order_type,
            "side": side,
            "amount": amount,
            "price": price,
            "status": "open",
            "timestamp": int(time.time() * 1000),
        }
        
        self._mock_orders.append(order)
        return order
    
    def fetch_ticker(self, symbol: str, use_cache: bool = True) -> Dict[str, Any]:
        """Mock fetch ticker."""
        if symbol in self._mock_tickers:
            return self._mock_tickers[symbol]
        
        # Generate random ticker
        import random
        base_price = 50000.0 if "BTC" in symbol else 3000.0 if "ETH" in symbol else 100.0
        price = base_price * random.uniform(0.95, 1.05)
        
        ticker = {
            "symbol": symbol,
            "bid": price * 0.999,
            "ask": price * 1.001,
            "last": price,
            "high": price * 1.02,
            "low": price * 0.98,
            "volume": random.uniform(1000, 10000),
        }
        
        self._mock_tickers[symbol] = ticker
        return ticker
    
    def set_mock_balance(self, asset: str, amount: float):
        """Set mock balance."""
        self._mock_balance[asset.upper()] = float(amount)
    
    def set_mock_ticker(self, symbol: str, ticker: Dict[str, Any]):
        """Set mock ticker."""
        self._mock_tickers[symbol] = ticker
# Patch: autonomy.py + ai_brain.py (2026-01-31)

## autonomy.py
- Thread-safety: `_learned_risk_mult` state is copied under lock before use.
- Observability: `evaluate_entry()` now guarantees a non-empty `reason` ("ok" when nothing special).
- Veto cooldown observability: veto decisions now include `cooldown_until` and `cooldown_remaining_s` inside `details`.
- `_remember_veto()` returns the computed cooldown-until timestamp (callers may ignore it).

## ai_brain.py
- Added internal lock + optional local cooldown tracking.
- New config option: `ai_brain.enforce_cooldown` (default False). When enabled, the brain blocks entries during cooldown.
- Reasons are normalized to never be empty (falls back to `['ok']`).
- Confidence is filled heuristically if not explicitly set.

from __future__ import annotations

import time
import threading
import json
from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, List, Optional, Tuple, Callable, Union
from functools import lru_cache
import sys
import traceback

_LEVEL_ORDER = {"debug": 10, "info": 20, "warning": 30, "warn": 30, "error": 40, "critical": 50}


def _norm_level(level: str) -> str:
    """Normalize log level string."""
    lv = str(level or "info").lower().strip() or "info"
    return "warning" if lv == "warn" else lv


def _level_value(level: str) -> int:
    """Get numeric value for log level."""
    return int(_LEVEL_ORDER.get(_norm_level(level), 20))


@dataclass
class TraceEvent:
    """Single trace event with context and timing."""
    ts: float
    level: str
    msg: str
    ctx: Dict[str, Any]
    repeat: int = 1
    ts_last: float = 0.0
    event_id: int = 0
    source: str = ""  # Module/function that emitted the event

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON serialization."""
        return {
            "id": int(self.event_id),
            "ts": float(self.ts),
            "ts_last": float(self.ts_last or self.ts),
            "level": str(self.level),
            "msg": str(self.msg),
            "repeat": int(self.repeat),
            "ctx": dict(self.ctx or {}),
            "source": str(self.source),
        }


class TraceBuffer:
    """In-memory ring buffer for human-readable, debug-friendly traces.

    Goals:
      - show "what the bot is thinking" in UI
      - avoid flooding via rate-limit + dedupe
      - protect secrets via ctx redaction/sanitization
      - optionally mirror to audit/log
    """

    def __init__(
        self,
        cfg: Optional[Dict[str, Any]] = None,
        log: Any = None,
        audit: Any = None,
        maxlen: int = 4000,
        rate_limit_per_min: int = 180,
    ):
        self.cfg = cfg or {}
        self.log = log
        self.audit = audit

        dbg = (self.cfg.get("debug") or {}) if isinstance(self.cfg, dict) else {}

        # Core settings
        self.enabled = bool(dbg.get("trace_enabled", True))
        self.level = _norm_level(dbg.get("trace_level", "info"))
        self.to_audit = bool(dbg.get("trace_to_audit", True))
        self.to_log = bool(dbg.get("trace_to_log", True))
        self.log_prefix = str(dbg.get("trace_log_prefix", "[think]")).strip() or "[think]"

        # Buffer settings
        maxlen = int(dbg.get("trace_maxlen", maxlen))
        rate_limit_per_min = int(dbg.get("trace_rate_limit_per_min", rate_limit_per_min))

        # Deduplication
        self.dedupe_enabled = bool(dbg.get("trace_dedupe_enabled", True))
        self.dedupe_window_sec = float(dbg.get("trace_dedupe_window_sec", 3.0))

        # Context sanitization
        self.ctx_max_keys = int(dbg.get("trace_ctx_max_keys", 30))
        self.ctx_max_str = int(dbg.get("trace_ctx_max_str", 400))
        self.ctx_max_depth = int(dbg.get("trace_ctx_max_depth", 3))
        self.redact_keys = set(
            str(x).lower()
            for x in dbg.get(
                "trace_redact_keys",
                [
                    "api_key",
                    "apikey",
                    "secret",
                    "password",
                    "pass",
                    "token",
                    "access_token",
                    "refresh_token",
                    "auth",
                    "credential",
                    "private",
                    "key",
                ],
            )
        )
        self.redact_substring = bool(dbg.get("trace_redact_substring", True))
        
        # Sampling for log mirror only
        self.log_sample_every = int(dbg.get("trace_log_sample_every", 1))

        # Performance optimizations
        self.use_cache = bool(dbg.get("trace_use_cache", True))
        self.cache_maxsize = int(dbg.get("trace_cache_maxsize", 1024))

        # Buffer and state
        self._buf: Deque[TraceEvent] = deque(maxlen=int(maxlen))
        self._rate_limit_per_min = int(rate_limit_per_min)

        # Rate limiting state
        self._window_start = 0.0
        self._window_count = 0
        self._dropped_in_window = 0
        self._dropped_total = 0
        self._last_drop_report_ts = 0.0

        # Deduplication state
        self._last_sig: Optional[Tuple[str, str, Tuple[Tuple[str, Any], ...]]] = None
        self._last_event: Optional[TraceEvent] = None

        # Concurrency and IDs
        self._lock = threading.Lock()
        self._next_id = 1

        # Log sampling counter
        self._emit_count = 0
        
        # Metrics
        self._coalesced_count = 0
        self._total_emit_time = 0.0
        self._started_ts = time.time()
        
        # Mock time for testing
        self._mock_time: Optional[float] = None
        
        # Hooks for extensibility
        self._pre_processors: List[Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]] = []
        self._post_processors: List[Callable[[TraceEvent], Optional[TraceEvent]]] = []

    # -----------------------------
    # Time management for testing
    # -----------------------------
    def _get_time(self) -> float:
        """Get current time, with support for mocking in tests."""
        return self._mock_time if self._mock_time is not None else time.time()

    def set_mock_time(self, mock_time: float) -> None:
        """Set mock time for deterministic testing."""
        self._mock_time = float(mock_time)

    # -----------------------------
    # Hook management
    # -----------------------------
    def add_pre_processor(self, fn: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]) -> None:
        """Add a pre-processor that can modify or filter context before emission."""
        with self._lock:
            self._pre_processors.append(fn)

    def add_post_processor(self, fn: Callable[[TraceEvent], Optional[TraceEvent]]) -> None:
        """Add a post-processor that can modify or filter events after creation."""
        with self._lock:
            self._post_processors.append(fn)

    # -----------------------------
    # Core controls
    # -----------------------------
    def set_enabled(self, enabled: bool) -> None:
        """Enable or disable trace emission."""
        with self._lock:
            self.enabled = bool(enabled)

    def set_level(self, level: str) -> None:
        """Set minimum log level for traces."""
        with self._lock:
            self.level = _norm_level(level)

    def _level_allows(self, level: str) -> bool:
        """Check if a given level passes the current filter."""
        return _level_value(level) >= _level_value(self.level)

    def _allow_rate(self, now: float) -> bool:
        """Check rate limiting, return True if event should be allowed."""
        if self._rate_limit_per_min <= 0:
            return True
        if (now - self._window_start) >= 60.0:
            self._window_start = now
            self._window_count = 0
            self._dropped_in_window = 0
        if self._window_count >= self._rate_limit_per_min:
            self._dropped_in_window += 1
            self._dropped_total += 1
            return False
        self._window_count += 1
        return True

    # -----------------------------
    # Context sanitization with caching
    # -----------------------------
    def _is_redacted_key(self, k: str) -> bool:
        """Check if a key should be redacted."""
        kk = (k or "").lower()
        if kk in self.redact_keys:
            return True
        if self.redact_substring:
            for rk in self.redact_keys:
                if rk and rk in kk:
                    return True
        return False

    def _sanitize_value(self, v: Any, depth: int) -> Any:
        """Recursively sanitize values with depth limiting."""
        if depth <= 0:
            return str(v)[: self.ctx_max_str] if v else v
        if v is None:
            return None
        if isinstance(v, (bool, int, float)):
            return v
        if isinstance(v, str):
            return v[: self.ctx_max_str]
        if isinstance(v, (list, tuple)):
            out = []
            for item in v[: min(len(v), 20)]:
                out.append(self._sanitize_value(item, depth - 1))
            return out
        if isinstance(v, dict):
            out = {}
            for k, val in list(v.items())[: self.ctx_max_keys]:
                kk = str(k)
                if self._is_redacted_key(kk):
                    out[kk] = "***"
                else:
                    out[kk] = self._sanitize_value(val, depth - 1)
            return out
        return str(v)[: self.ctx_max_str]

    def _sanitize_ctx(self, ctx: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Sanitize context dictionary with size limits and redaction."""
        d = dict(ctx or {})
        out: Dict[str, Any] = {}
        for k, v in list(d.items())[: self.ctx_max_keys]:
            kk = str(k)
            if self._is_redacted_key(kk):
                out[kk] = "***"
            else:
                out[kk] = self._sanitize_value(v, self.ctx_max_depth)
        return out

    @lru_cache(maxsize=1024)
    def _ctx_signature(self, ctx: Dict[str, Any]) -> Tuple[Tuple[str, Any], ...]:
        """
        Compact signature for deduplication with caching.
        Creates a stable, sorted representation of context.
        """
        if not ctx:
            return tuple()
        keys = sorted(list(ctx.keys()))
        items = []
        for k in keys[:10]:  # Limit to first 10 keys for performance
            v = ctx.get(k)
            if isinstance(v, (str, int, float, bool)) or v is None:
                vv = v
            else:
                vv = str(v)[:80]  # Truncate complex values
            items.append((k, vv))
        return tuple(items)

    # -----------------------------
    # Auto-source detection
    # -----------------------------
    def _get_caller_source(self, depth: int = 3) -> str:
        """Automatically detect caller source for trace events."""
        try:
            frame = sys._getframe(depth)
            module = frame.f_globals.get('__name__', 'unknown')
            func = frame.f_code.co_name
            return f"{module}.{func}"
        except (ValueError, AttributeError):
            return "unknown"

    # -----------------------------
    # Emit with enhanced features
    # -----------------------------
    def emit(
        self,
        msg: str,
        level: str = "info",
        ctx: Optional[Union[Dict[str, Any], Callable[[], Dict[str, Any]]]] = None,
        source: Optional[str] = None,
        **kwargs,
    ) -> bool:
        """
        Emit a trace event.
        
        Args:
            msg: Message text
            level: Log level
            ctx: Context dictionary or callable that returns context
            source: Optional source identifier (auto-detected if None)
            **kwargs: Additional context passed as keyword arguments
        
        Returns:
            True if event was emitted, False otherwise
        """
        start_time = self._get_time()
        level = _norm_level(level)
        msg_s = str(msg)
        
        # Merge kwargs into context
        ctx_kwargs = {}
        if kwargs:
            ctx_kwargs = dict(kwargs)
        
        # Fast path: avoid expensive operations if disabled or level filtered
        with self._lock:
            if not self.enabled:
                return False
            if not self._level_allows(level):
                return False

            now = self._get_time()
            if not self._allow_rate(now):
                # Periodic "dropped" notice
                if (now - self._last_drop_report_ts) >= 10.0 and self._dropped_in_window > 0:
                    self._last_drop_report_ts = now
                    drop_msg = f"trace rate-limited: dropped={self._dropped_in_window} in last 60s (total={self._dropped_total})"
                    ev = TraceEvent(
                        ts=now,
                        ts_last=now,
                        level="warning",
                        msg=drop_msg,
                        ctx={},
                        repeat=1,
                        event_id=self._next_id,
                        source="trace.buffer",
                    )
                    self._next_id += 1
                    self._buf.append(ev)
                return False

        # Build context outside lock (may be expensive)
        ctx_in: Optional[Dict[str, Any]] = None
        try:
            if callable(ctx):
                ctx_in = ctx()
            elif isinstance(ctx, dict):
                ctx_in = ctx
            else:
                ctx_in = {}
                
            # Merge kwargs into context
            if ctx_kwargs:
                if ctx_in is None:
                    ctx_in = {}
                ctx_in.update(ctx_kwargs)
        except Exception as e:
            ctx_in = {"ctx_error": str(e)}

        # Apply pre-processors
        if ctx_in and self._pre_processors:
            for processor in self._pre_processors:
                try:
                    result = processor(ctx_in)
                    if result is None:
                        return False  # Pre-processor filtered out event
                    ctx_in = result
                except Exception:
                    pass  # Continue with original context if processor fails

        # Sanitize context
        ctx_d = self._sanitize_ctx(ctx_in)
        
        # Auto-detect source if not provided
        if source is None:
            source = self._get_caller_source()

        # Main critical section: deduplication and buffer update
        coalesced = False
        repeat_n = 1
        with self._lock:
            if self.dedupe_enabled:
                sig = (level, msg_s, self._ctx_signature(ctx_d))
                if self._last_event and self._last_sig == sig:
                    time_diff = now - float(self._last_event.ts_last or self._last_event.ts)
                    if time_diff <= self.dedupe_window_sec:
                        self._last_event.repeat += 1
                        self._last_event.ts_last = now
                        coalesced = True
                        repeat_n = int(self._last_event.repeat)
                        self._coalesced_count += 1
                        # Update existing event
                    else:
                        self._last_sig = None
                        self._last_event = None

            if not coalesced:
                ev = TraceEvent(
                    ts=now,
                    ts_last=now,
                    level=level,
                    msg=msg_s,
                    ctx=ctx_d,
                    repeat=1,
                    event_id=self._next_id,
                    source=source,
                )
                self._next_id += 1
                
                # Apply post-processors
                if self._post_processors:
                    for processor in self._post_processors:
                        try:
                            processed = processor(ev)
                            if processed is None:
                                return False  # Post-processor filtered out event
                            ev = processed
                        except Exception:
                            pass  # Continue with original event
                
                self._buf.append(ev)
                if self.dedupe_enabled:
                    self._last_sig = sig
                    self._last_event = ev
                repeat_n = 1

        # Update metrics
        emit_time = self._get_time() - start_time
        with self._lock:
            self._total_emit_time += emit_time

        # Mirror to log and audit (outside lock to avoid blocking)
        self._mirror(level, msg_s, ctx_d, source, coalesced=coalesced, repeat=repeat_n)
        self._audit(level, msg_s, ctx_d, source, coalesced=coalesced, repeat=repeat_n)
        return True

    # Convenience methods with auto-source detection
    def debug(self, msg: str, ctx: Optional[Dict[str, Any]] = None, **kwargs) -> bool:
        return self.emit(msg, "debug", ctx, **kwargs)

    def info(self, msg: str, ctx: Optional[Dict[str, Any]] = None, **kwargs) -> bool:
        return self.emit(msg, "info", ctx, **kwargs)

    def warning(self, msg: str, ctx: Optional[Dict[str, Any]] = None, **kwargs) -> bool:
        return self.emit(msg, "warning", ctx, **kwargs)

    def error(self, msg: str, ctx: Optional[Dict[str, Any]] = None, **kwargs) -> bool:
        return self.emit(msg, "error", ctx, **kwargs)

    def critical(self, msg: str, ctx: Optional[Dict[str, Any]] = None, **kwargs) -> bool:
        return self.emit(msg, "critical", ctx, **kwargs)

    def exception(self, msg: str, exc: Exception, ctx: Optional[Dict[str, Any]] = None, **kwargs) -> bool:
        """Convenience method for logging exceptions."""
        exc_ctx = dict(ctx or {})
        exc_ctx.update({
            "exception_type": type(exc).__name__,
            "exception_msg": str(exc),
            "exception_traceback": traceback.format_exc(),
        })
        return self.emit(msg, "error", exc_ctx, **kwargs)

    # -----------------------------
    # Mirroring
    # -----------------------------
    def _mirror(self, level: str, msg: str, ctx: Dict[str, Any], source: str, *, coalesced: bool, repeat: int) -> None:
        """Mirror trace to log system with sampling."""
        if not self.to_log or self.log is None:
            return
        try:
            self._emit_count += 1
            if self.log_sample_every > 1 and (self._emit_count % self.log_sample_every) != 0:
                return

            line = f"{self.log_prefix} [{source}] {msg}"
            if coalesced and repeat > 1:
                line = f"{line} (x{repeat})"
            if ctx:
                subset = {k: ctx.get(k) for k in list(ctx.keys())[:5]}  # Show only first 5
                line = f"{line} | {json.dumps(subset, ensure_ascii=False)[:200]}"

            if level == "debug":
                self.log.debug(line)
            elif level == "warning":
                if hasattr(self.log, "warning"):
                    self.log.warning(line)
                else:
                    self.log.warn(line)  # type: ignore
            elif level == "error":
                self.log.error(line)
            elif level == "critical":
                self.log.critical(line)
            else:
                self.log.info(line)
        except Exception:
            pass  # Don't let logging errors break trace

    def _audit(self, level: str, msg: str, ctx: Dict[str, Any], source: str, *, coalesced: bool, repeat: int) -> None:
        """Write to audit system if available."""
        if not self.to_audit or self.audit is None or not hasattr(self.audit, "write"):
            return
        try:
            self.audit.write({
                "type": "trace",
                "ts": self._get_time(),
                "level": level,
                "msg": msg,
                "source": source,
                "ctx": ctx,
                "coalesced": bool(coalesced),
                "repeat": int(repeat),
            })
        except Exception:
            pass  # Don't let audit errors break trace

    # -----------------------------
    # Read API
    # -----------------------------
    def tail(self, n: int = 200) -> List[Dict[str, Any]]:
        """Get last N events as dictionaries."""
        n = max(1, int(n))
        with self._lock:
            items = list(self._buf)[-n:]
        return [e.to_dict() for e in items]

    def since(self, ts: float, limit: int = 500) -> List[Dict[str, Any]]:
        """Return events with ts_last >= ts (useful for incremental UI polling)."""
        ts = float(ts or 0.0)
        limit = max(1, int(limit))
        out: List[TraceEvent] = []
        with self._lock:
            for e in reversed(self._buf):
                if float(e.ts_last or e.ts) < ts:
                    break
                out.append(e)
                if len(out) >= limit:
                    break
        out.reverse()
        return [e.to_dict() for e in out]

    def search(self, query: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Search events by message content (case-insensitive)."""
        query = query.lower()
        limit = max(1, int(limit))
        out: List[Dict[str, Any]] = []
        with self._lock:
            for e in reversed(self._buf):
                if query in e.msg.lower():
                    out.append(e.to_dict())
                    if len(out) >= limit:
                        break
        return out

    def stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics about trace buffer."""
        with self._lock:
            last_id = int(self._next_id - 1)
            emit_count = self._emit_count
            avg_emit_time = self._total_emit_time / max(1, emit_count) if emit_count > 0 else 0
            
            # Estimate memory usage (rough approximation)
            buf_size = len(self._buf)
            avg_event_size = 500  # Conservative estimate in bytes
            memory_estimate = buf_size * avg_event_size
            
            return {
                "enabled": bool(self.enabled),
                "level": str(self.level),
                "buffer_size": int(buf_size),
                "buffer_maxlen": int(self._buf.maxlen or 0),
                "rate_limit_per_min": int(self._rate_limit_per_min),
                "window_start": float(self._window_start),
                "window_count": int(self._window_count),
                "dropped_in_window": int(self._dropped_in_window),
                "dropped_total": int(self._dropped_total),
                "dedupe_enabled": bool(self.dedupe_enabled),
                "dedupe_window_sec": float(self.dedupe_window_sec),
                "coalesced_events": int(self._coalesced_count),
                "last_event_id": last_id,
                "emit_count": int(emit_count),
                "avg_emit_time_ms": round(avg_emit_time * 1000, 3),
                "memory_estimate_bytes": int(memory_estimate),
                "uptime_sec": float(self._get_time() - self._started_ts),
                "pre_processors": len(self._pre_processors),
                "post_processors": len(self._post_processors),
            }

    def clear(self) -> None:
        """Clear all events and reset counters."""
        with self._lock:
            self._buf.clear()
            self._dropped_in_window = 0
            self._dropped_total = 0
            self._window_start = 0.0
            self._window_count = 0
            self._last_sig = None
            self._last_event = None
            self._coalesced_count = 0
            self._total_emit_time = 0.0
            self._emit_count = 0

    # -----------------------------
    # Export and debugging
    # -----------------------------
    def dump_jsonl(self, path: str, n: int = 2000) -> int:
        """Dump last n events to JSONL file for incident review."""
        n = max(1, int(n))
        rows = self.tail(n)
        try:
            with open(path, "w", encoding="utf-8") as f:
                for r in rows:
                    f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
            return len(rows)
        except Exception:
            return 0

    def export_stats_csv(self, path: str) -> bool:
        """Export event statistics to CSV for analysis."""
        try:
            import csv
            events = self.tail(10000)  # Export up to 10k events
            
            if not events:
                return False
                
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow([
                    "id", "timestamp", "level", "source", "message", 
                    "repeat", "context_keys"
                ])
                
                # Write data
                for event in events:
                    writer.writerow([
                        event["id"],
                        event["ts"],
                        event["level"],
                        event.get("source", ""),
                        event["msg"][:100],  # Truncate long messages
                        event["repeat"],
                        len(event.get("ctx", {}))
                    ])
            return True
        except Exception:
            return False

    def _estimate_memory_usage(self) -> int:
        """Estimate memory usage of buffer in bytes."""
        with self._lock:
            total = 0
            for event in self._buf:
                # Rough estimate: sum of string lengths + overhead
                total += len(event.msg) * 2  # UTF-8 worst case
                for k, v in event.ctx.items():
                    total += len(k) * 2
                    if isinstance(v, str):
                        total += len(v) * 2
                    elif isinstance(v, (list, dict)):
                        total += 100  # Rough estimate for small structures
                total += 100  # Event overhead
            return total


# Example usage and testing
if __name__ == "__main__":
    # Example configuration
    config = {
        "debug": {
            "trace_enabled": True,
            "trace_level": "debug",
            "trace_maxlen": 1000,
            "trace_rate_limit_per_min": 100,
            "trace_to_log": True,
            "trace_to_audit": False,
        }
    }
    
    # Create buffer
    buffer = TraceBuffer(config)
    
    # Add some example events
    buffer.info("System initialized", {"version": "1.0.0", "mode": "production"})
    buffer.debug("Processing request", {"request_id": "123", "user": "test@example.com"})
    buffer.warning("High memory usage detected", {"memory_mb": 850, "threshold": 800})
    
    # Simulate duplicate events
    for i in range(5):
        buffer.info("Heartbeat", {"iteration": i})
        time.sleep(0.1)
    
    # Show statistics
    print("Buffer Stats:")
    for k, v in buffer.stats().items():
        print(f"  {k}: {v}")
    
    # Show recent events
    print(f"\nLast 5 events:")
    for event in buffer.tail(5):
        print(f"  [{event['level']}] {event['msg']} (x{event['repeat']})")
from __future__ import annotations

import time
import csv
import json
import threading
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional, List, Tuple


# ============================================================
# Trade Recorder (fix: crypto_bot_gui.py imports TradeRecorder from here)
# ============================================================

@dataclass
class TradeRecord:
    ts: float
    exchange: str
    mode: str
    symbol: str
    side: str
    qty: float
    price: float
    notional: float
    fee: float
    reason: str
    realized_pnl: float = 0.0
    meta: Dict[str, Any] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if d.get("meta") is None:
            d["meta"] = {}
        return d


class TradeRecorder:
    """
    Lightweight in-memory trade recorder + optional persistence helpers.

    Designed to be safe as a dependency used by UI (Streamlit/Tkinter) while engine is running:
      - thread-safe
      - never throws for common bad inputs
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._trades: List[TradeRecord] = []

    def add(
        self,
        ts: Optional[float] = None,
        exchange: str = "",
        mode: str = "",
        symbol: str = "",
        side: str = "",
        qty: float = 0.0,
        price: float = 0.0,
        notional: float = 0.0,
        fee: float = 0.0,
        reason: str = "",
        realized_pnl: float = 0.0,
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        try:
            rec = TradeRecord(
                ts=float(ts if ts is not None else time.time()),
                exchange=str(exchange or ""),
                mode=str(mode or ""),
                symbol=str(symbol or ""),
                side=str(side or ""),
                qty=float(qty or 0.0),
                price=float(price or 0.0),
                notional=float(notional or 0.0),
                fee=float(fee or 0.0),
                reason=str(reason or ""),
                realized_pnl=float(realized_pnl or 0.0),
                meta=dict(meta or {}),
            )
            with self._lock:
                self._trades.append(rec)
        except Exception:
            # fail-safe: do not crash caller
            return

    def add_record(self, rec: TradeRecord) -> None:
        try:
            with self._lock:
                self._trades.append(rec)
        except Exception:
            return

    def list(self, limit: int = 500) -> List[Dict[str, Any]]:
        try:
            lim = max(1, int(limit))
        except Exception:
            lim = 500
        with self._lock:
            items = self._trades[-lim:]
            return [t.to_dict() for t in items]

    def count(self) -> int:
        with self._lock:
            return len(self._trades)

    def export_csv(self, path: str) -> None:
        cols = [
            "ts", "exchange", "mode", "symbol", "side",
            "qty", "price", "notional", "fee", "reason", "realized_pnl", "meta_json"
        ]
        with self._lock:
            rows = list(self._trades)

        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(cols)
            for t in rows:
                meta_json = ""
                try:
                    meta_json = json.dumps(t.meta or {}, ensure_ascii=False)
                except Exception:
                    meta_json = "{}"
                w.writerow([
                    f"{float(t.ts):.6f}",
                    t.exchange,
                    t.mode,
                    t.symbol,
                    t.side,
                    f"{float(t.qty):.12f}",
                    f"{float(t.price):.12f}",
                    f"{float(t.notional):.12f}",
                    f"{float(t.fee):.12f}",
                    t.reason,
                    f"{float(t.realized_pnl):.12f}",
                    meta_json,
                ])

    def dump_json(self, path: str, limit: int = 100000) -> None:
        data = self.list(limit=limit)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def load_json(self, path: str, max_items: int = 200000) -> None:
        try:
            with open(path, "r", encoding="utf-8") as f:
                arr = json.load(f)
            if not isinstance(arr, list):
                return
            out: List[TradeRecord] = []
            for it in arr[: max_items]:
                if not isinstance(it, dict):
                    continue
                try:
                    out.append(
                        TradeRecord(
                            ts=float(it.get("ts", time.time())),
                            exchange=str(it.get("exchange", "")),
                            mode=str(it.get("mode", "")),
                            symbol=str(it.get("symbol", "")),
                            side=str(it.get("side", "")),
                            qty=float(it.get("qty", 0.0)),
                            price=float(it.get("price", 0.0)),
                            notional=float(it.get("notional", 0.0)),
                            fee=float(it.get("fee", 0.0)),
                            reason=str(it.get("reason", "")),
                            realized_pnl=float(it.get("realized_pnl", 0.0)),
                            meta=dict(it.get("meta") or {}),
                        )
                    )
                except Exception:
                    continue
            with self._lock:
                self._trades = out
        except Exception:
            return


# ============================================================
# Market regime detector (your existing code, kept)
# ============================================================

@dataclass
class RegimeState:
    regime: str
    strength: float
    details: Dict[str, Any]
    ts: float


def _now() -> float:
    return time.time()


def _f(x: Any, d: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(d)


def _clamp(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def _safe_list(x: Any) -> List[Any]:
    if isinstance(x, list):
        return x
    if isinstance(x, tuple):
        return list(x)
    return []


class MarketRegimeDetector:
    """Computes and caches market regime per symbol + global.

    Prefers AutonomyController.predict_market_regime(df) when available.
    Fallback uses ATR% + EMA slope (+ optional ADX).
    Adds:
      - TTL caching with force
      - hysteresis (anti-flapping)
      - global aggregation by most-liquid / highest-score symbols (best-effort)
    """

    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log
        self._per: Dict[str, RegimeState] = {}
        self._global: RegimeState = RegimeState(regime="na", strength=0.0, details={}, ts=0.0)

        # hysteresis tracking
        self._per_hold_until: Dict[str, float] = {}
        self._global_hold_until: float = 0.0

    def _emit(self, level: str, msg: str) -> None:
        try:
            if self.log is None:
                return
            fn = getattr(self.log, level, None)
            if callable(fn):
                fn(msg)
            elif hasattr(self.log, "info") and callable(getattr(self.log, "info")):
                self.log.info(msg)
        except Exception:
            pass

    def get_global(self) -> Dict[str, Any]:
        return {
            "regime": self._global.regime,
            "strength": float(self._global.strength),
            "details": dict(self._global.details),
            "ts": float(self._global.ts),
        }

    def get_symbol(self, symbol: str) -> Dict[str, Any]:
        rs = self._per.get(symbol)
        if not rs:
            return {"regime": "na", "strength": 0.0, "details": {}, "ts": 0.0}
        return {"regime": rs.regime, "strength": float(rs.strength), "details": dict(rs.details), "ts": float(rs.ts)}

    def update(self, engine: Any, symbol: Optional[str] = None, force: bool = False) -> None:
        cfg = (self.cfg.get("regime") or {})
        ttl_sym = float(cfg.get("refresh_sec", 30.0))
        ttl_global = float(cfg.get("global_refresh_sec", max(10.0, ttl_sym)))
        now = _now()

        # hysteresis knobs
        min_hold_sec = float(cfg.get("min_hold_sec", 45.0))
        min_switch_gain = float(cfg.get("min_switch_gain", 0.12))  # candidate strength must exceed old by this

        def should_sym(sym: str) -> bool:
            rs = self._per.get(sym)
            return force or (not rs) or ((now - float(rs.ts)) >= ttl_sym)

        # symbols list
        syms: List[str]
        if symbol:
            syms = [symbol]
        else:
            # prefer engine.pairs, fallback watchlist
            syms = _safe_list(getattr(engine, "pairs", None)) or _safe_list(getattr(engine, "watchlist", None))
        syms = [s for s in syms if isinstance(s, str) and s.strip()]
        if not syms:
            return

        # compute per-symbol regimes
        out: Dict[str, RegimeState] = {}
        for sym in syms:
            if not should_sym(sym):
                continue
            cand = self._compute_one(engine, sym)

            # apply per-symbol hysteresis
            prev = self._per.get(sym)
            hold_until = float(self._per_hold_until.get(sym, 0.0))
            if prev and cand.regime != prev.regime and not force:
                if now < hold_until:
                    # still holding previous regime
                    cand = RegimeState(regime=prev.regime, strength=prev.strength, details=dict(prev.details), ts=now)
                    cand.details["hysteresis"] = f"hold:{hold_until - now:.1f}s"
                else:
                    # require meaningful gain to switch
                    if float(cand.strength) < float(prev.strength) + float(min_switch_gain):
                        cand = RegimeState(regime=prev.regime, strength=prev.strength, details=dict(prev.details), ts=now)
                        cand.details["hysteresis"] = "insufficient_gain"
                    else:
                        self._per_hold_until[sym] = now + min_hold_sec

            out[sym] = cand

        if out:
            self._per.update(out)

        # global regime update (TTL + sample selection)
        if not force and (now - float(self._global.ts)) < ttl_global:
            return

        sample = self._select_global_sample(engine, syms, cfg)
        if not sample:
            sample = syms[: max(3, int(cfg.get("global_sample", 8)))]

        votes: Dict[str, float] = {}
        det_votes: Dict[str, Dict[str, Any]] = {}
        for s in sample:
            rs = self._per.get(s)
            if not rs:
                continue
            w = float(rs.strength)
            votes[rs.regime] = votes.get(rs.regime, 0.0) + w
            det_votes.setdefault(rs.regime, {"symbols": []})["symbols"].append({"symbol": s, "w": w})

        if not votes:
            self._global = RegimeState(regime="na", strength=0.0, details={"reason": "no_votes"}, ts=now)
            return

        best_reg, best_score = max(votes.items(), key=lambda kv: kv[1])
        total = max(1e-12, sum(votes.values()))
        best_strength = float(best_score / total)

        cand_global = RegimeState(
            regime=str(best_reg),
            strength=_clamp(best_strength, 0.0, 1.0),
            details={
                "votes": dict(votes),
                "vote_details": det_votes,
                "sample": list(sample),
                "ttl_global": ttl_global,
            },
            ts=now,
        )

        # global hysteresis
        prev_g = self._global
        if prev_g and cand_global.regime != prev_g.regime and not force:
            if now < float(self._global_hold_until):
                cand_global = RegimeState(regime=prev_g.regime, strength=prev_g.strength, details=dict(prev_g.details), ts=now)
                cand_global.details["hysteresis"] = f"hold:{self._global_hold_until - now:.1f}s"
            else:
                if float(cand_global.strength) < float(prev_g.strength) + float(min_switch_gain):
                    cand_global = RegimeState(regime=prev_g.regime, strength=prev_g.strength, details=dict(prev_g.details), ts=now)
                    cand_global.details["hysteresis"] = "insufficient_gain"
                else:
                    self._global_hold_until = now + min_hold_sec

        self._global = cand_global

    def _select_global_sample(self, engine: Any, syms: List[str], cfg: Dict[str, Any]) -> List[str]:
        """Best-effort choose the most liquid / highest score symbols for global regime aggregation."""
        k = max(3, int(cfg.get("global_sample", 8)))

        # 1) If engine has watchlist_scores or something similar
        for attr in ("watchlist_scores", "pair_scores", "scores"):
            sc = getattr(engine, attr, None)
            if isinstance(sc, dict) and sc:
                items = []
                for s in syms:
                    if s in sc:
                        items.append((s, _f(sc.get(s), 0.0)))
                items.sort(key=lambda x: x[1], reverse=True)
                return [s for s, _ in items[:k]]

        # 2) Try tickers (quoteVolume) if client supports it
        try:
            client = getattr(engine, "client", None)
            ex = getattr(client, "exchange", None)
            if ex is None and hasattr(client, "ccxt"):
                ex = getattr(client, "ccxt", None)
            if ex is not None and hasattr(ex, "fetch_tickers"):
                tickers = ex.fetch_tickers()
                vols = []
                for s in syms:
                    t = (tickers or {}).get(s) or {}
                    qv = t.get("quoteVolume")
                    v = _f(qv, 0.0)
                    if v > 0:
                        vols.append((s, v))
                vols.sort(key=lambda x: x[1], reverse=True)
                if vols:
                    return [s for s, _ in vols[:k]]
        except Exception:
            pass

        # fallback: first k
        return syms[:k]

    def _compute_one(self, engine: Any, symbol: str) -> RegimeState:
        now = _now()
        cfg = (self.cfg.get("regime") or {})
        tf = str(cfg.get("timeframe", self.cfg.get("signal_timeframe", "5m")))
        lookback = int(cfg.get("lookback", 240))

        # Prefer autonomy model
        try:
            auto = getattr(engine, "autonomy", None)
            if auto and hasattr(auto, "predict_market_regime"):
                df = engine.client.fetch_ohlcv_df(symbol, tf, limit=lookback)
                if df is None or getattr(df, "empty", False) or len(df) < 50:
                    return RegimeState(regime="na", strength=0.0, details={"reason": "no_data", "tf": tf, "lookback": lookback}, ts=now)
                out = auto.predict_market_regime(df) or {}
                reg = str(out.get("regime") or "na").lower().strip()
                st = _clamp(_f(out.get("strength"), 0.0), 0.0, 1.0)
                det = dict(out.get("details") or {})
                det.update({"tf": tf, "lookback": lookback, "src": "autonomy"})
                return RegimeState(regime=reg, strength=st, details=det, ts=now)
        except Exception:
            pass

        # Fallback heuristic based on ATR% and EMA slope (+ optional ADX)
        try:
            from .indicators import atr, ema  # required in your project
            # optional ADX
            adx_fn = None
            try:
                from .indicators import adx as adx_fn  # type: ignore
            except Exception:
                adx_fn = None

            df = engine.client.fetch_ohlcv_df(symbol, tf, limit=lookback)
            if df is None or getattr(df, "empty", False) or len(df) < 80:
                return RegimeState(regime="na", strength=0.0, details={"reason": "no_data", "tf": tf, "lookback": lookback}, ts=now)

            last = float(df["close"].iloc[-1])
            if last <= 0:
                return RegimeState(regime="na", strength=0.0, details={"reason": "bad_last", "tf": tf}, ts=now)

            a = float(atr(df, 14).iloc[-1])
            atr_pct = a / max(1e-12, last)

            e20 = float(ema(df["close"], 20).iloc[-1])
            e80 = float(ema(df["close"], 80).iloc[-1])
            trend_strength = abs(e20 - e80) / max(1e-12, last)

            adx_val = None
            if callable(adx_fn):
                try:
                    adx_val = float(adx_fn(df, 14).iloc[-1])
                except Exception:
                    adx_val = None

            high_vol_atr = float(cfg.get("high_vol_atr_pct", 0.05))
            trend_th = float(cfg.get("trend_strength", 0.01))
            adx_trend_th = float(cfg.get("adx_trend", 22.0))

            # Determine regime
            reg = "range"
            # High vol dominates
            if atr_pct >= high_vol_atr:
                reg = "high_vol"
                # map atr_pct 0.05..0.10 -> strength 0..1
                st = _clamp((atr_pct - high_vol_atr) / max(1e-12, (0.10 - high_vol_atr)), 0.0, 1.0)

            else:
                # If ADX present, require it for "trend" or allow EMA slope alone
                is_trend = trend_strength >= trend_th
                if adx_val is not None:
                    is_trend = is_trend and (adx_val >= adx_trend_th)

                if is_trend:
                    reg = "trend"
                    # map trend_strength 0.01..0.03 -> 0..1
                    st = _clamp((trend_strength - trend_th) / max(1e-12, (0.03 - trend_th)), 0.0, 1.0)
                else:
                    reg = "range"
                    # stronger range when ATR is low and trend is low
                    # map atr_pct 0.01..0.05 inverse + penalty for trend
                    inv = _clamp((0.05 - atr_pct) / 0.04, 0.0, 1.0)
                    pen = _clamp(trend_strength / max(1e-12, trend_th), 0.0, 1.0)
                    st = _clamp(inv * (1.0 - 0.5 * pen), 0.0, 1.0)

            det = {
                "src": "heuristic",
                "tf": tf,
                "lookback": lookback,
                "atr_pct": float(atr_pct),
                "trend_strength": float(trend_strength),
                "adx": None if adx_val is None else float(adx_val),
                "thresholds": {
                    "high_vol_atr_pct": high_vol_atr,
                    "trend_strength": trend_th,
                    "adx_trend": adx_trend_th,
                },
            }
            return RegimeState(regime=reg, strength=float(st), details=det, ts=now)

        except Exception as e:
            return RegimeState(regime="na", strength=0.0, details={"error": f"{type(e).__name__}: {e}", "tf": tf}, ts=now)
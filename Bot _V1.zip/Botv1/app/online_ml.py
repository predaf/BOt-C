# online_ml_test.py
import pytest
import sqlite3
import tempfile
import time
import math
import threading
from pathlib import Path
from unittest.mock import Mock, patch
from online_ml import (
    OnlineWinModel, OnlineAdvice, _f, _clamp, _sigmoid,
    OnlineWinModel, _welford_update
)


class TestHelperFunctions:
    """Test the helper utility functions"""
    
    def test_safe_float_conversion(self):
        """Test _f function for safe float conversion"""
        assert _f("123") == 123.0
        assert _f(123) == 123.0
        assert _f(3.14) == 3.14
        assert _f(None, 99.0) == 99.0
        assert _f("not a number", 42.0) == 42.0
        
    def test_clamp_function(self):
        """Test _clamp function"""
        assert _clamp(5, 0, 10) == 5.0
        assert _clamp(-5, 0, 10) == 0.0
        assert _clamp(15, 0, 10) == 10.0
        assert _clamp(3.14, 0.0, 1.0) == 1.0
        assert _clamp(-3.14, -5.0, 5.0) == -3.14
        
    def test_sigmoid_function(self):
        """Test _sigmoid function"""
        # Test known values
        assert _sigmoid(0) == 0.5
        assert _sigmoid(100) == pytest.approx(1.0, abs=1e-10)  # Very large positive
        assert _sigmoid(-100) == pytest.approx(0.0, abs=1e-10)  # Very large negative
        
        # Test symmetry
        for x in [-5, -1, 0, 1, 5]:
            assert _sigmoid(x) + _sigmoid(-x) == pytest.approx(1.0)
            
        # Test monotonic
        assert _sigmoid(0) < _sigmoid(1)
        assert _sigmoid(-1) < _sigmoid(0)
        
    def test_welford_update_static_method(self):
        """Test the static Welford update method"""
        # Initial state
        mean, m2, n = 0.0, 0.0, 0
        
        # Add first value
        mean, m2, n = OnlineWinModel._welford_update(mean, m2, n, 10.0)
        assert n == 1
        assert mean == 10.0
        assert m2 == 0.0
        
        # Add second value
        mean, m2, n = OnlineWinModel._welford_update(mean, m2, n, 20.0)
        assert n == 2
        assert mean == 15.0
        assert m2 == 50.0  # Variance * (n-1)
        
        # Add third value
        mean, m2, n = OnlineWinModel._welford_update(mean, m2, n, 30.0)
        assert n == 3
        assert mean == 20.0
        assert m2 == 200.0
        
        # Test with existing variance
        mean, m2, n = 100.0, 200.0, 5  # std ≈ sqrt(200/4) = 7.07
        mean2, m22, n2 = OnlineWinModel._welford_update(mean, m2, n, 110.0)
        assert n2 == 6
        assert mean2 > mean  # Mean should increase


class TestOnlineAdvice:
    """Test the OnlineAdvice dataclass"""
    
    def test_online_advice_creation(self):
        """Test creating OnlineAdvice instance"""
        advice = OnlineAdvice(
            enabled=True,
            p_win=0.75,
            exp_return=0.25,
            risk_mult=1.5,
            leverage_mult=1.3,
            reason="test reason"
        )
        
        assert advice.enabled is True
        assert advice.p_win == 0.75
        assert advice.exp_return == 0.25
        assert advice.risk_mult == 1.5
        assert advice.leverage_mult == 1.3
        assert advice.reason == "test reason"
        
    def test_online_advice_to_dict(self):
        """Test converting OnlineAdvice to dictionary"""
        advice = OnlineAdvice(
            enabled=False,
            p_win=0.4,
            exp_return=-0.1,
            risk_mult=0.8,
            leverage_mult=0.9,
            reason="disabled test"
        )
        
        advice_dict = advice.to_dict()
        assert advice_dict["enabled"] is False
        assert advice_dict["p_win"] == 0.4
        assert advice_dict["exp_return"] == -0.1
        assert advice_dict["risk_mult"] == 0.8
        assert advice_dict["leverage_mult"] == 0.9
        assert advice_dict["reason"] == "disabled test"


class TestOnlineWinModel:
    """Test the OnlineWinModel class"""
    
    @pytest.fixture
    def temp_db(self):
        """Create a temporary database for testing"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        yield db_path
        # Cleanup
        try:
            Path(db_path).unlink(missing_ok=True)
        except:
            pass
    
    @pytest.fixture
    def model(self, temp_db):
        """Create an OnlineWinModel instance for testing"""
        model = OnlineWinModel(
            db_path=temp_db,
            table_prefix="test",
            warmup_n=5,
            feature_clip=5.0,
            grad_clip=3.0,
            weight_clip=10.0
        )
        yield model
        model.close()
    
    def test_initialization(self, temp_db):
        """Test model initialization creates correct tables"""
        model = OnlineWinModel(temp_db, table_prefix="test_init")
        
        # Check tables exist
        cur = model.conn.cursor()
        tables = cur.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name LIKE 'test_init_%'
        """).fetchall()
        
        table_names = [t[0] for t in tables]
        assert "test_init_weights" in table_names
        assert "test_init_stats" in table_names
        assert "test_init_featstats" in table_names
        
        # Check indices
        indices = cur.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND name LIKE 'idx_test_init_%'
        """).fetchall()
        
        index_names = [i[0] for i in indices]
        assert "idx_test_init_w_sym" in index_names
        assert "idx_test_init_fs_sym" in index_names
        
        model.close()
    
    def test_default_features(self, model):
        """Test that bias is always included in features"""
        assert "bias" in model.features
        assert model.features[0] == "bias"  # Bias should be first
        
        # Check default features
        default_features = OnlineWinModel.DEFAULT_FEATURES
        assert "bias" not in default_features  # bias should be added automatically
        
        # Test custom features
        custom_features = ["atr_pct", "trend_strength"]
        custom_model = OnlineWinModel(":memory:", features=custom_features)
        assert custom_model.features == ["bias", "atr_pct", "trend_strength"]
        custom_model.close()
    
    def test_predict_warmup(self, model):
        """Test prediction during warmup period returns disabled advice"""
        symbol = "BTC/USDT"
        features = {"atr_pct": 0.02, "trend_strength": 0.5}
        
        advice = model.predict(symbol, features)
        
        assert advice.enabled is False
        assert advice.p_win == 0.5  # Default during warmup
        assert advice.exp_return == 0.0
        assert advice.risk_mult == 1.0
        assert advice.leverage_mult == 1.0
        assert "warmup" in advice.reason.lower()
    
    def test_single_update_and_predict(self, model):
        """Test a single update followed by prediction"""
        symbol = "BTC/USDT"
        features = {
            "atr_pct": 0.02,
            "trend_strength": 0.8,
            "spread_bps": 1.5,
            "funding_rate": 0.0001,
            "vol_quote_usd_24h": 1000000.0,
            "signal_strength": 0.9
        }
        
        # Update with a win
        model.update(symbol, features, win=True, lr=0.1)
        
        # Check stats after one update
        stats = model.stats(symbol)
        assert stats["n"] == 1
        assert stats["loss_avg"] > 0  # Should have some loss
        
        # Predict (still in warmup, so should be disabled)
        advice = model.predict(symbol, features)
        assert advice.enabled is False  # n=1 < warmup_n=5
    
    def test_multiple_updates_and_convergence(self, model):
        """Test multiple updates and convergence behavior"""
        symbol = "BTC/USDT"
        
        # Simple feature that strongly predicts win
        features = {"signal_strength": 1.0}
        
        # Perform multiple updates with wins
        for i in range(20):
            model.update(symbol, features, win=True, lr=0.1)
        
        # Check we're past warmup
        stats = model.stats(symbol)
        assert stats["n"] == 20
        assert stats["n"] >= model.warmup_n
        
        # Predict should now be enabled
        advice = model.predict(symbol, features)
        assert advice.enabled is True
        assert advice.p_win > 0.5  # Should learn that this predicts win
        assert advice.risk_mult > 1.0  # Higher risk for higher win probability
        assert advice.leverage_mult > 1.0  # Higher leverage for higher win probability
        
        # Now update with losses for same feature
        for i in range(20):
            model.update(symbol, features, win=False, lr=0.1)
        
        # Prediction should now be lower
        advice2 = model.predict(symbol, features)
        assert advice2.p_win < advice.p_win  # Should decrease after losses
    
    def test_feature_normalization(self, model):
        """Test feature normalization and Welford stats"""
        symbol = "BTC/USDT"
        
        # Add features with different scales
        features1 = {"atr_pct": 0.01, "trend_strength": 100.0}
        features2 = {"atr_pct": 0.02, "trend_strength": 200.0}
        features3 = {"atr_pct": 0.03, "trend_strength": 300.0}
        
        model.update(symbol, features1, win=True)
        model.update(symbol, features2, win=True)
        model.update(symbol, features3, win=True)
        
        # Check feature stats
        feat_stats = model.feature_stats(symbol)
        
        assert "atr_pct" in feat_stats
        assert "trend_strength" in feat_stats
        
        # Check means are calculated
        atr_stats = feat_stats["atr_pct"]
        assert atr_stats["mean"] == pytest.approx(0.02)  # (0.01+0.02+0.03)/3
        assert atr_stats["std"] > 0  # Should have some std
        
        trend_stats = feat_stats["trend_strength"]
        assert trend_stats["mean"] == pytest.approx(200.0)  # (100+200+300)/3
    
    def test_feature_clipping(self, model):
        """Test that extreme feature values are clipped"""
        symbol = "BTC/USDT"
        
        # Extreme feature value
        features = {"atr_pct": 1000.0}  # Very large value
        
        model.update(symbol, features, win=True)
        
        # Check that feature was clipped in normalization
        feat_stats = model.feature_stats(symbol)
        atr_stats = feat_stats["atr_pct"]
        
        # Mean should be clipped value, not 1000
        assert abs(atr_stats["mean"]) <= model.feature_clip
    
    def test_weight_clipping(self, model):
        """Test that weights are clipped during updates"""
        symbol = "BTC/USDT"
        features = {"signal_strength": 1.0}
        
        # Use large learning rate to try to create large weights
        for i in range(50):
            model.update(symbol, features, win=True, lr=1.0)
        
        weights = model.weights(symbol)
        
        # Check all weights are within clipping bounds
        for feat, weight in weights.items():
            assert -model.weight_clip <= weight <= model.weight_clip
    
    def test_multiple_symbols(self, model):
        """Test that model works correctly with multiple symbols"""
        symbol1 = "BTC/USDT"
        symbol2 = "ETH/USDT"
        
        features1 = {"signal_strength": 1.0}
        features2 = {"signal_strength": -1.0}
        
        # Train symbol1 to predict wins
        for i in range(10):
            model.update(symbol1, features1, win=True)
        
        # Train symbol2 to predict losses
        for i in range(10):
            model.update(symbol2, features2, win=False)
        
        # Predict should give different results
        advice1 = model.predict(symbol1, features1)
        advice2 = model.predict(symbol2, features2)
        
        # Symbol1 should have higher win probability
        assert advice1.p_win > advice2.p_win
        
        # Check stats are separate
        stats1 = model.stats(symbol1)
        stats2 = model.stats(symbol2)
        
        assert stats1["symbol"] == symbol1
        assert stats2["symbol"] == symbol2
        assert stats1["n"] == 10
        assert stats2["n"] == 10
    
    def test_learning_rate_schedule(self, model):
        """Test that learning rate decreases with more samples"""
        symbol = "BTC/USDT"
        features = {"signal_strength": 1.0}
        
        # Get initial weights
        initial_weights = model.weights(symbol)
        initial_bias = initial_weights.get("bias", 0.0)
        
        # First update with large effect
        model.update(symbol, features, win=True, lr=0.1)
        
        weights_after1 = model.weights(symbol)
        delta1 = abs(weights_after1.get("bias", 0.0) - initial_bias)
        
        # Second update should have smaller effect (lr/sqrt(2))
        model.update(symbol, features, win=True, lr=0.1)
        
        weights_after2 = model.weights(symbol)
        delta2 = abs(weights_after2.get("bias", 0.0) - weights_after1.get("bias", 0.0))
        
        # Third update should have even smaller effect (lr/sqrt(3))
        model.update(symbol, features, win=True, lr=0.1)
        
        weights_after3 = model.weights(symbol)
        delta3 = abs(weights_after3.get("bias", 0.0) - weights_after2.get("bias", 0.0))
        
        # Updates should generally get smaller (not strictly due to randomness in gradient)
        # But early updates should be larger than later ones
        assert delta1 > 0
        # delta2 should be smaller than delta1 (lr/sqrt(2) < lr)
        # delta3 should be smaller than delta2 (lr/sqrt(3) < lr/sqrt(2))
    
    def test_empty_or_missing_features(self, model):
        """Test handling of empty or missing features"""
        symbol = "BTC/USDT"
        
        # Update with empty features
        model.update(symbol, {}, win=True)
        
        # Predict with empty features
        advice = model.predict(symbol, {})
        
        # Should work without errors
        assert advice is not None
        
        # Update with partial features
        model.update(symbol, {"atr_pct": 0.01}, win=True)
        
        # Missing features should be treated as 0
        feat_stats = model.feature_stats(symbol)
        assert "atr_pct" in feat_stats
        assert "trend_strength" in feat_stats  # Default entry
    
    def test_thread_safety(self, model):
        """Test thread safety with concurrent updates"""
        symbol = "BTC/USDT"
        features = {"signal_strength": 0.5}
        
        num_threads = 5
        updates_per_thread = 10
        
        def update_thread():
            for _ in range(updates_per_thread):
                model.update(symbol, features, win=True, lr=0.01)
        
        threads = []
        for _ in range(num_threads):
            t = threading.Thread(target=update_thread)
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
        
        # Check total updates
        stats = model.stats(symbol)
        assert stats["n"] == num_threads * updates_per_thread
    
    def test_phi_normalization(self, model):
        """Test the internal _phi feature normalization method"""
        symbol = "BTC/USDT"
        
        # Add some data to establish statistics
        features_list = [
            {"atr_pct": 0.01, "trend_strength": 100.0},
            {"atr_pct": 0.02, "trend_strength": 200.0},
            {"atr_pct": 0.03, "trend_strength": 300.0},
        ]
        
        for features in features_list:
            model.update(symbol, features, win=True)
        
        # Now test _phi normalization
        test_features = {"atr_pct": 0.02, "trend_strength": 200.0}
        phi = model._phi(symbol, test_features)
        
        # Should include bias
        assert "bias" in phi
        assert phi["bias"] == 1.0
        
        # Features should be normalized (z-scored)
        assert "atr_pct" in phi
        assert "trend_strength" in phi
        
        # Since we're testing with the mean value, it should be close to 0
        assert abs(phi["atr_pct"]) < 0.1  # Should be near 0
        assert abs(phi["trend_strength"]) < 0.1  # Should be near 0
    
    def test_shrink_toward_zero(self, model):
        """Test shrinkage toward 0.5 when n is not huge"""
        symbol = "BTC/USDT"
        features = {"signal_strength": 1.0}
        
        # Train just past warmup
        for i in range(model.warmup_n + 1):
            model.update(symbol, features, win=True)
        
        advice = model.predict(symbol, features)
        
        # With shrink factor, p_win should be less than without shrinkage
        # But still greater than 0.5 since we're training with wins
        assert 0.5 < advice.p_win < 1.0
        
        # Train many more times
        for i in range(100):
            model.update(symbol, features, win=True)
        
        advice2 = model.predict(symbol, features)
        
        # With more samples, shrinkage should be less aggressive
        # So p_win should be higher (closer to 1.0)
        assert advice2.p_win > advice.p_win
    
    def test_close_method(self, temp_db):
        """Test that close method works without errors"""
        model = OnlineWinModel(temp_db)
        
        # Should not raise an exception
        model.close()
        
        # Closing twice should also not raise
        model.close()
    
    def test_sqlite_connection_settings(self, temp_db):
        """Test that SQLite connection has correct settings"""
        model = OnlineWinModel(temp_db)
        
        cur = model.conn.cursor()
        
        # Check journal mode
        journal_mode = cur.execute("PRAGMA journal_mode").fetchone()[0]
        assert journal_mode.upper() == "WAL"
        
        # Check synchronous mode
        synchronous = cur.execute("PRAGMA synchronous").fetchone()[0]
        assert synchronous == 1  # NORMAL mode
        
        # Check busy timeout
        busy_timeout = cur.execute("PRAGMA busy_timeout").fetchone()[0]
        assert busy_timeout == 8000
        
        model.close()


class TestEdgeCases:
    """Test edge cases and error conditions"""
    
    @pytest.fixture
    def model(self):
        with tempfile.NamedTemporaryFile(suffix='.db') as f:
            model = OnlineWinModel(f.name, warmup_n=2)
            yield model
            model.close()
    
    def test_extreme_feature_values(self, model):
        """Test with extremely large or small feature values"""
        symbol = "BTC/USDT"
        
        # Very large positive
        model.update(symbol, {"atr_pct": 1e6}, win=True)
        
        # Very large negative
        model.update(symbol, {"atr_pct": -1e6}, win=False)
        
        # NaN and infinity (should be handled by _f)
        model.update(symbol, {"atr_pct": float('nan')}, win=True)
        model.update(symbol, {"atr_pct": float('inf')}, win=False)
        
        # Should not crash
        advice = model.predict(symbol, {"atr_pct": 0.01})
        assert advice is not None
    
    def test_special_symbol_names(self, model):
        """Test with special characters in symbol names"""
        symbols = [
            "BTC-USD",  # Dash
            "BTC/USD:PERP",  # Colon
            "BTC.USD",  # Dot
            "BTC USD",  # Space
            "BTC_USD",  # Underscore
        ]
        
        for symbol in symbols:
            model.update(symbol, {"signal_strength": 0.5}, win=True)
            advice = model.predict(symbol, {"signal_strength": 0.5})
            assert advice is not None
    
    def test_very_small_learning_rate(self, model):
        """Test with very small learning rate (should still work)"""
        symbol = "BTC/USDT"
        features = {"signal_strength": 1.0}
        
        # Update with tiny LR
        model.update(symbol, features, win=True, lr=1e-10)
        
        # Weights should barely change
        advice = model.predict(symbol, features)
        assert advice.p_win == pytest.approx(0.5, abs=0.01)  # Very little change
    
    def test_very_large_learning_rate(self, model):
        """Test with very large learning rate (should be clipped)"""
        symbol = "BTC/USDT"
        features = {"signal_strength": 1.0}
        
        # Update with huge LR
        model.update(symbol, features, win=True, lr=100.0)
        
        # Gradients should be clipped, so weights shouldn't explode
        weights = model.weights(symbol)
        for weight in weights.values():
            assert -model.weight_clip <= weight <= model.weight_clip


def test_online_win_model_as_context_manager():
    """Test that OnlineWinModel can be used as context manager"""
    with tempfile.NamedTemporaryFile(suffix='.db') as f:
        with OnlineWinModel(f.name) as model:
            # Should work inside context
            model.update("BTC/USDT", {"signal_strength": 0.5}, win=True)
            advice = model.predict("BTC/USDT", {"signal_strength": 0.5})
            assert advice is not None
        
        # Should be closed after context
        # (Note: OnlineWinModel doesn't have __exit__ by default, 
        # but we can test that it doesn't crash)


if __name__ == "__main__":
    # Run tests
    pytest.main(["-v", __file__])
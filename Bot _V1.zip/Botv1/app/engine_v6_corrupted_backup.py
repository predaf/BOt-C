from __future__ import annotations
import time, math, json, random
import os
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from collections import deque
import numpy as np
import pandas as pd

from .exchange import ExchangeClient
from .marketdata_ws import MarketDataWS
from .strategy import StrategyEngine
from .paper import PaperPortfolio
from .records import TradeRecorder, TradeRecord
from .watchdog import ErrorWatchdog
from .micro_model import orderbook_metrics, maker_fill_probability, expected_market_slippage_bps
from .indicators import atr, ema
from .portfolio import corr_ok
from .state import StateManager
from .metrics import Metrics
from .utils import safe_float, now_utc_iso, clamp
from .approvals import ApprovalQueue
from .store_sqlite import SQLiteStore
from .notifier import Notifier
from .market_guard import MarketGuard

@dataclass
class LivePosition:
    symbol: str
    qty: float
    entry: float
    stop: float
    tp: float
    trailing: Optional[float] = None
    tp1_done: bool = False
    opened_ts: float = field(default_factory=time.time)

@dataclass
class PendingOrder:
    symbol: str
    side: str
    qty: float
    price: float
    order_id: str
    created_ts: float
    reposts: int = 0
    reason: str = ""
    is_maker: bool = True
    atr_pct: float = 0.0
    filled_qty: float = 0.0

class PairSelector:
    def __init__(self, cfg: dict, log: Any):
        self.cfg=cfg
        self.log=log

    def _is_symbol_ok(self, sym: str, m: Dict[str, Any], quote: str) -> bool:
        if not m.get("active", True):
            return False
        if m.get("spot") is False:
            return False
        # avoid derivatives symbols when ccxt returns them in same map
        if ":" in sym:
            return False
        if not sym.endswith(f"/{quote}"):
            return False
        if self.cfg["pair_filters"].get("exclude_leveraged_tokens", True):
            for b in ["UP/","DOWN/","BULL/","BEAR/"]:
                if b in sym:
                    return False
        return True

    def select(self, client: ExchangeClient) -> List[str]:
        markets = client.load_markets()

        # Multi-quote support: pick the quote that yields the most viable symbols after filters
        quote = str(self.cfg.get("quote_asset", "USDT")).upper().strip()
        qlist = self.cfg.get("quote_assets") or []
        if isinstance(qlist, list) and qlist:
            best_quote = quote
            best_count = -1
            for q in qlist:
                q = str(q).upper().strip()
                if not q:
                    continue
                c = 0
                for sym, m in markets.items():
                    if self._is_symbol_ok(sym, m, q):
                        c += 1
                if c > best_count:
                    best_count = c
                    best_quote = q
            quote = best_quote
            self.cfg["quote_asset"] = quote

        w=[s.upper().strip() for s in (self.cfg["pair_filters"].get("whitelist") or []) if str(s).strip()]
        bl=set([s.upper().strip() for s in (self.cfg["pair_filters"].get("blacklist") or []) if str(s).strip()])

        # whitelist has priority; supports either BASE or full SYMBOL
        if w:
            top=[]
            for s in w:
                if "/" in s:
                    sym=s
                else:
                    sym=f"{s}/{quote}"
                if sym in markets and self._is_symbol_ok(sym, markets[sym], quote) and sym.upper() not in bl and s.upper() not in bl:
                    top.append(sym)
            self.log.info(f"PairSelector: WHITELIST {top}")
            return top[: int(self.cfg["max_pairs"])]

        candidates=[s for s,m in markets.items() if self._is_symbol_ok(s,m,quote)]
        candidates=[s for s in candidates if s.upper() not in bl and s.split("/")[0].upper() not in bl]

        min_qv=float(self.cfg["pair_filters"]["min_quote_volume_usd"])
        min_px=float(self.cfg["pair_filters"]["min_price_usd"])
        max_spread=float(self.cfg["pair_filters"]["max_spread_bps"])

        scored=[]
        for sym in candidates:
            try:
                t=client.fetch_ticker_cached(sym)
                bid=safe_float(t.get("bid")); ask=safe_float(t.get("ask")); last=safe_float(t.get("last"))
                if not np.isfinite(last) or last<=0:
                    continue
                if not (np.isfinite(bid) and np.isfinite(ask) and bid>0 and ask>0):
                    continue

                spread_bps=(ask-bid)/bid*10_000
                if spread_bps>max_spread:
                    continue
                qv=safe_float(t.get("quoteVolume"), 0.0)
                if qv < min_qv:
                    continue

                df=client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=180)
                if len(df) < 120:
                    continue
                if df["close"].iloc[-1] < min_px:
                    continue

                a=float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
                atr_pct=(a/df["close"].iloc[-1])
                trend=abs(ema(df["close"],12).iloc[-1] - ema(df["close"],26).iloc[-1]) / df["close"].iloc[-1]

                # Symbol health heuristics: penalize abnormal wicks/gaps/low-volume bars
                closes=df["close"].values.astype(float)
                highs=df["high"].values.astype(float)
                lows=df["low"].values.astype(float)
                opens=df["open"].values.astype(float)
                vols=df["volume"].values.astype(float)

                wick=float(np.nanmean((highs-lows)/np.maximum(1e-12, closes)))
                gap=float(np.nanmean(np.abs(opens[1:]-closes[:-1])/np.maximum(1e-12, closes[:-1])))
                zvol=float(np.mean(vols < (np.nanpercentile(vols, 5) + 1e-12)))
                health_pen=3.5*max(0.0, wick-0.010) + 4.0*max(0.0, gap-0.004) + 0.8*zvol

                s=0.6*math.log10(max(qv,1.0)) + 2.2*atr_pct + 4.0*trend - 0.15*(spread_bps/max_spread) - health_pen
                scored.append((s,sym))
            except Exception:
                continue

        scored.sort(reverse=True, key=lambda x:x[0])
        return [sym for _,sym in scored[: int(self.cfg["max_pairs"])]]

class RiskManager:
    def __init__(self, cfg: dict, log: Any):
        self.cfg=cfg; self.log=log
        self.last_trade_ts: Dict[str,float] = {}
        self.trades_today=0
        self.day_key=pd.Timestamp.utcnow().strftime("%Y-%m-%d")

    def new_day_if_needed(self):
        dk=pd.Timestamp.utcnow().strftime("%Y-%m-%d")
        if dk!=self.day_key:
            self.day_key=dk; self.trades_today=0

    def in_cooldown(self, symbol: str) -> bool:
        cd=float(self.cfg["risk"]["cooldown_sec"])
        return (time.time()-self.last_trade_ts.get(symbol,0.0)) < cd

    def mark_trade(self, symbol: str):
        self.last_trade_ts[symbol]=time.time()
        self.new_day_if_needed()
        self.trades_today += 1

    def max_trades_reached(self) -> bool:
        self.new_day_if_needed()
        return self.trades_today >= int(self.cfg["risk"]["kill_switch"]["max_trades_per_day"])

    def size_qty(self, equity: float, price: float, atr_val: float, markets: Dict[str,Any], symbol: str) -> float:
        r=self.cfg["risk"]
        risk_amt=float(r["risk_per_trade"])*equity
        stop_dist=max(atr_val*float(r["stop_atr_mult"]), price*0.002)
        qty=risk_amt/stop_dist
        max_notional=float(r["max_position_pct"])*equity
        qty=min(qty, max_notional/price)
        # limits via ccxt market
        m=markets.get(symbol,{})
        lim=(m.get("limits") or {}).get("amount") or {}
        min_amt=lim.get("min")
        if min_amt is not None:
            qty=max(qty, float(min_amt))
        return max(0.0, qty)

    def stop_tp(self, price: float, atr_val: float) -> Tuple[float,float]:
        r=self.cfg["risk"]
        return (price-atr_val*float(r["stop_atr_mult"]), price+atr_val*float(r["tp_atr_mult"]))

    def tp1_level(self, entry: float, atr_val: float) -> float:
        so=self.cfg["risk"]["scale_out"]
        return entry + atr_val*float(so["tp1_atr_mult"])

    def update_trailing(self, pos: LivePosition, last: float, atr_val: float):
        if not self.cfg["risk"].get("use_trailing", True):
            return
        trail=atr_val*float(self.cfg["risk"]["trail_atr_mult"])
        cand=last-trail
        pos.trailing = cand if pos.trailing is None else max(pos.trailing, cand)

class TradingEngine:
    def __init__(self, cfg: dict, log: Any, recorder: TradeRecorder, base_dir: str):
        self.cfg=cfg; self.log=log; self.rec=recorder; self.base_dir=base_dir
        self.metrics=Metrics(cfg, log)
        self.ws=MarketDataWS(cfg, log)
        self.client=ExchangeClient(cfg, log, ws_cache=self.ws)
        self.selector=PairSelector(cfg, log)
        self.strategy=StrategyEngine(cfg, log)
        self.risk=RiskManager(cfg, log)
        self.watchdog=ErrorWatchdog(cfg, log)
        self.state=StateManager(cfg, base_dir, log)
        # V6 additions
        self.pause_entries = False
        self._mg_paused = False
        approvals_cfg = cfg.get("approvals", {})
        self.approvals = ApprovalQueue(timeout_sec=int(approvals_cfg.get("timeout_sec", 300))) if approvals_cfg.get("enabled", True) else None

        sqlite_cfg = cfg.get("sqlite", {})
        self.store = SQLiteStore(os.path.join(base_dir, sqlite_cfg.get("path", "bot.db"))) if sqlite_cfg.get("enabled", True) else None

        self.notifier = Notifier(cfg, log)
        mg_cfg = cfg.get("market_guard", {})
        self.market_guard = MarketGuard(cfg, log) if mg_cfg.get("enabled", True) else None

        self.paper=PaperPortfolio(cfg) if cfg["mode"]=="paper" else None
        self.positions: Dict[str, LivePosition] = {}
        self.pending: Dict[str, PendingOrder] = {}
        self.pairs: List[str] = []
        self._stop=False

        # Guardrails
        self.halted=False
        self.day_start_equity=None
        self.peak_equity=None
        self.equity_window = deque(maxlen=5000)  # (ts, equity)

        # Auto-opt schedule
        self._last_opt_ts = 0.0

        # persistence resume
        if self.cfg["state"].get("resume_on_start", False):
            self._resume()

    def stop(self):
        self._stop=True
        try: self.ws.stop()
        except Exception: pass

    def manual_resume(self):
        self.watchdog.force_resume()

    def _resume(self):
        d=self.state.load()
        if not d: return
        if d.get("cfg_exchange") != self.cfg["exchange"]:
            self.log.warn("State found but exchange mismatch; skipping resume.")
            return
        if self.cfg["mode"]=="paper" and d.get("paper"):
            self.paper=PaperPortfolio.from_dict(self.cfg, d["paper"])
        self.positions={}
        for k,v in (d.get("positions_meta") or {}).items():
            self.positions[k]=LivePosition(**v)
        self.pending={}
        for k,v in (d.get("pending") or {}).items():
            self.pending[k]=PendingOrder(**v)
        self.pairs=list(d.get("pairs") or [])
        try:
            self.rec.trades = TradeRecorder.from_list(d.get("trades") or []).trades
        except Exception:
            pass
        self.halted=bool((d.get("guard") or {}).get("halted", False))
        self.day_start_equity=(d.get("guard") or {}).get("day_start_equity")
        self.peak_equity=(d.get("guard") or {}).get("peak_equity")
        self.log.info(f"Resumed state from {self.cfg['state']['path']}")

    def _snapshot(self) -> Dict[str, Any]:
        return {
            "cfg_exchange": self.cfg["exchange"],
            "cfg_mode": self.cfg["mode"],
            "paper": self.paper.to_dict() if self.paper else None,
            "positions_meta": {k: pos.__dict__ for k,pos in self.positions.items()},
            "pending": {k: po.__dict__ for k,po in self.pending.items()},
            "pairs": self.pairs,
            "guard": {"halted": self.halted, "day_start_equity": self.day_start_equity, "peak_equity": self.peak_equity},
            "trades": self.rec.to_list(5000),
        }

    def _save_state_periodic(self, last_save: float) -> float:
        interval=float(self.cfg["state"].get("save_interval_sec", 30))
        if time.time()-last_save >= interval:
            self.state.save(self._snapshot())
            return time.time()
        return last_save

    def _mark_prices(self) -> Dict[str,float]:
        syms=set(self.pairs) | set(self.positions.keys())
        if self.paper:
            syms |= set(self.paper.positions.keys())
        prices={}
        for sym in syms:
            try:
                t=self.client.fetch_ticker_cached(sym)
                last=safe_float(t.get("last"))
                if np.isfinite(last) and last>0:
                    prices[sym]=float(last)
            except Exception:
                continue
        return prices

    def equity(self) -> float:
        quote=self.cfg["quote_asset"]
        if self.cfg["mode"]=="paper" and self.paper:
            return self.paper.equity(self._mark_prices())
        eq=0.0
        try:
            eq += float(self.client.fetch_balance_quote(quote))
        except Exception:
            pass
        prices=self._mark_prices()
        for sym,pos in self.positions.items():
            px=prices.get(sym)
            if px: eq += pos.qty*px
        return eq

    def _new_day_check(self):
        dk=pd.Timestamp.utcnow().strftime("%Y-%m-%d")
        cur=getattr(self, "_day_key", None)
        if cur != dk:
            self._day_key=dk
            eq=self.equity()
            self.day_start_equity=eq
            self.peak_equity=eq
            self.halted=False
            self.risk.new_day_if_needed()
            self.equity_window.clear()
            self.log.info(f"New trading day {dk}. day_start_equity={eq:.2f}")

    def _apply_kill_switch(self):
        ks=self.cfg["risk"]["kill_switch"]
        eq=self.equity()
        if self.day_start_equity is None:
            self.day_start_equity=eq
        if self.peak_equity is None:
            self.peak_equity=eq
        self.peak_equity=max(self.peak_equity, eq)

        daily_loss=(self.day_start_equity-eq)/max(1e-9,self.day_start_equity)
        dd=(self.peak_equity-eq)/max(1e-9,self.peak_equity)

        # intraday shock
        shock=ks.get("intraday_shock", {})
        if shock.get("enabled", True):
            win=int(shock.get("window_min",30))*60
            drop=float(shock.get("drop_pct",0.015))
            self.equity_window.append((time.time(), eq))
            # find oldest within window
            t0=None; e0=None
            for t,e in self.equity_window:
                if time.time()-t <= win:
                    t0=t; e0=e; break
            if e0 is not None and (e0-eq)/max(1e-9,e0) >= drop:
                self._halt(f"Intraday shock: equity drop {(e0-eq)/e0*100:.2f}% in {win/60:.0f}min")

        if daily_loss >= float(ks["max_daily_loss_pct"]):
            self._halt(f"Max DAILY loss reached: {daily_loss*100:.2f}%")
        if dd >= float(ks["max_drawdown_pct"]):
            self._halt(f"Max DRAWDOWN reached: {dd*100:.2f}%")
        if self.risk.max_trades_reached():
            self._halt("Max trades/day reached")

        # metrics
        realized = self.paper.realized_pnl if self.paper else 0.0
        fees = self.paper.fees_paid if self.paper else 0.0
        self.metrics.update(equity=eq, realized_pnl=realized, fees=fees,
                            open_positions=len([p for p in self.positions.values() if p.qty>0]),
                            pending_orders=len(self.pending))

    def _halt(self, reason: str):
        if self.halted: return
        self.halted=True
        self.log.warn(f"KILL SWITCH HALT: {reason}")
        if self.cfg["risk"]["kill_switch"].get("close_all_on_halt", False):
            self.log.warn("close_all_on_halt enabled -> closing all positions.")
            self.close_all(reason="halt")

    def _refresh_pairs(self):
        self.client.load_markets()
        self.pairs=self.selector.select(self.client)
        self.ws.set_symbols(self.pairs)
        self.log.info(f"Selected pairs: {', '.join(self.pairs[:20])}")

    def _compute_returns_map(self, symbols: List[str]) -> Dict[str, np.ndarray]:
        look=int(self.cfg["risk"]["portfolio"]["correlation_filter"].get("lookback", 120))
        ret={}
        for sym in symbols:
            try:
                df=self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=look+50)
                c=df["close"].values.astype(float)
                r=np.diff(np.log(c+1e-12))
                ret[sym]=r[-look:]
            except Exception:
                continue
        return ret

    def _volatility_pause(self, df: pd.DataFrame) -> bool:
        thr=float(self.cfg["risk"].get("volatility_pause_atr_pct", 1e9))
        if thr<=0: return False
        a=float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        px=float(df["close"].iloc[-1])
        if px<=0: return False
        return (a/px) >= thr

    def _auto_opt_if_needed(self):
        auto=self.cfg.get("auto_opt", {})
        if not auto.get("enabled", False):
            return
        interval_h=float(auto.get("interval_hours", 12))
        if time.time() - self._last_opt_ts < interval_h*3600:
            return
        # Optimize on a single benchmark symbol if available (first pair)
        if not self.pairs:
            return
        sym=self.pairs[0]
        try:
            from .backtest import walk_forward_optimize
            df=self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=int(self.cfg["ohlcv_limit"]))
            df_tr=self.client.fetch_ohlcv_df(sym, self.cfg["trend_timeframe"], limit=min(2400, int(self.cfg["ohlcv_limit"])*4))
            new_cfg=walk_forward_optimize(self.cfg, df, df_tr)
            note=new_cfg.get("_auto_opt_note")
            # Apply only strategy params (safe scope)
            self.cfg["strategies"]["ema_cross"]["fast"]=new_cfg["strategies"]["ema_cross"]["fast"]
            self.cfg["strategies"]["ema_cross"]["slow"]=new_cfg["strategies"]["ema_cross"]["slow"]
            self.cfg["strategies"]["rsi_reversion"]["buy_below"]=new_cfg["strategies"]["rsi_reversion"]["buy_below"]
            self.cfg["strategies"]["rsi_reversion"]["sell_above"]=new_cfg["strategies"]["rsi_reversion"]["sell_above"]
            self._last_opt_ts=time.time()
            self.log.info(f"AUTO-OPT applied on {sym}. {note or ''}")
        except Exception as e:
            self.log.warn(f"AUTO-OPT failed: {e}")
            self._last_opt_ts=time.time()

    def _get_bid_ask_last(self, symbol: str) -> Tuple[float,float,float]:
        t=self.client.fetch_ticker_cached(symbol)
        bid=safe_float(t.get("bid")); ask=safe_float(t.get("ask")); last=safe_float(t.get("last"))
        return float(bid), float(ask), float(last)

    def _atr_pct(self, df: pd.DataFrame) -> float:
        a=float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        px=float(df["close"].iloc[-1])
        return (a/px) if px>0 else 0.0

    def _choose_maker_offset_bps(self, symbol: str, side: str, atr_pct: float) -> Tuple[float, Dict[str,float], float]:
        mm=self.cfg.get("micro_model", {})
        base=float(self.cfg["execution"]["maker_offset_bps"])
        if not mm.get("enabled", True):
            return base, {}, float("nan")
        depth=int(mm.get("orderbook_depth", 20))
        ob=self.client.fetch_order_book(symbol, limit=depth)
        met=orderbook_metrics(ob, depth=depth)
        spread=met.get("spread_bps", float("nan"))
        imb=met.get("imbalance", 0.0)

        off_min=float(mm.get("offset_min_bps",1.0))
        off_max=float(mm.get("offset_max_bps",14.0))
        dyn=bool(mm.get("dynamic_offset", True))
        if not dyn or not np.isfinite(spread):
            off=clamp(base, off_min, off_max)
        else:
            off=base + 0.25*(spread-5.0)/5.0 + 120.0*max(0.0, atr_pct-0.01)
            off=clamp(off, off_min, off_max)
        p_fill=maker_fill_probability(self.cfg, side, distance_bps=off, atr_pct=atr_pct, imbalance=imb)
        return off, met, p_fill

    def _market_fallback_decision(self, symbol: str, side: str, qty: float, atr_pct: float) -> Tuple[bool,str]:
        # Use order book to estimate slippage; avoid market if expected slippage too high.
        mm=self.cfg.get("micro_model", {})
        if not self.cfg["execution"].get("allow_market_fallback", True):
            return False, ""
        depth=int(mm.get("orderbook_depth", 20))
        ob=self.client.fetch_order_book(symbol, limit=depth)
        slip_bps=expected_market_slippage_bps(ob, side, qty, depth=depth)
        # Threshold heuristic: allow market fallback if slip is acceptable
        thr= max(10.0, 500.0*atr_pct)  # e.g., 10 bps minimum, scale with vol
        if np.isfinite(slip_bps) and slip_bps <= thr:
            return True, f"slip_ok({slip_bps:.1f}bps<=thr{thr:.1f})"
        return False, f"slip_high({slip_bps:.1f}bps>thr{thr:.1f})"

    def _place_order(self, symbol: str, side: str, qty: float, reason: str, atr_pct: float=0.0):
        qty=float(self.client.format_amount(symbol, qty))
        if qty<=0: return
        bid, ask, last = self._get_bid_ask_last(symbol)
        if not np.isfinite(last) or last<=0: return

        ex_type=self.cfg["execution"]["type"]
        if ex_type=="market":
            self._fill_market(symbol, side, qty, last, reason)
            return

        off_bps, met, p_fill = self._choose_maker_offset_bps(symbol, side, atr_pct)
        mm=self.cfg.get("micro_model", {})
        spread=met.get("spread_bps", float("nan"))
        imb=met.get("imbalance", 0.0)
        self.log.info(f"{symbol}: micro spread={spread:.2f}bps imb={imb:+.2f} ATR%={atr_pct*100:.2f}% off={off_bps:.2f} p_fill={p_fill:.2f}")

        # If maker looks bad, maybe market fallback
        max_sp=float(mm.get("max_spread_bps_for_maker",35.0))
        min_p=float(mm.get("min_p_fill_for_maker",0.25))
        if mm.get("enabled", True) and ((np.isfinite(spread) and spread>max_sp) or (np.isfinite(p_fill) and p_fill<min_p)):
            ok, why = self._market_fallback_decision(symbol, side, qty, atr_pct)
            if ok:
                self.log.warn(f"{symbol}: maker undesirable -> MARKET fallback ({why})")
                self._fill_market(symbol, side, qty, last, reason+"|maker_bad_market")
                return
            else:
                self.log.warn(f"{symbol}: maker undesirable but market rejected ({why}) -> keep maker attempt")

        off=off_bps/10_000.0
        if side=="buy":
            base=bid if np.isfinite(bid) and bid>0 else last
            px=base*(1.0-off)
        else:
            base=ask if np.isfinite(ask) and ask>0 else last
            px=base*(1.0+off)
        px=float(self.client.format_price(symbol, px))
        qty, px = self.client.enforce_trade_rules(symbol, side, qty, px)

        if self.cfg["mode"]=="paper":
            oid=f"paper-{int(time.time()*1000)}-{random.randint(1000,9999)}"
            self.pending[symbol]=PendingOrder(symbol, side, qty, px, oid, time.time(), reason=reason, is_maker=True, atr_pct=atr_pct)
            self.log.info(f"[PAPER] LIMIT PENDING {side.upper()} {symbol} qty={qty:.8f} price={px:.8f} id={oid} reason={reason}")
            return

        post_only=bool(self.cfg["execution"].get("post_only", True))
        params={"postOnly": True} if post_only else {}
        try:
            resp=self.client.create_order(symbol, "limit", side, qty, px, params=params)
        except Exception as e:
            # retry without post-only
            if post_only:
                self.log.warn(f"Post-only rejected; retry normal limit. ({type(e).__name__})")
                resp=self.client.create_order(symbol, "limit", side, qty, px, params={})
            else:
                raise
        oid=str(resp.get("id"))
        self.pending[symbol]=PendingOrder(symbol, side, qty, px, oid, time.time(), reason=reason, is_maker=True, atr_pct=atr_pct)
        self.log.info(f"[LIVE] LIMIT {side.upper()} {symbol} qty={qty:.8f} price={px:.8f} id={oid} reason={reason}")

    def _fill_market(self, symbol: str, side: str, qty: float, last: float, reason: str):
        qty=float(self.client.format_amount(symbol, qty))
        qty,_=self.client.enforce_trade_rules(symbol, side, qty, last)
        if qty<=0: return
        if self.cfg["mode"]=="paper":
            self._fill_paper(symbol, side, qty, last, maker=False, reason=reason)
            return
        resp=self.client.create_order(symbol, "market", side, qty, None, params={})
        fill=safe_float(resp.get("average") or resp.get("price"), last)
        self._on_live_fill(symbol, side, qty, float(fill), maker=False, reason=reason)

def _fill_paper(self, symbol: str, side: str, qty: float, price: float, maker: bool, reason: str):
    assert self.paper is not None
    exch=self.cfg["exchange"]; mode="paper"
    if side=="buy":
        fill, fee, aq = self.paper.buy(symbol, qty, price, maker)
        if fill<=0 or aq<=0:
            return
        ts=now_utc_iso()
        notional=aq*fill
        self.rec.add(TradeRecord(ts, exch, mode, symbol, "buy", aq, fill, notional, fee, reason, 0.0))
        if self.store:
            self.store.trade({
                "ts": ts,
                "exchange": exch,
                "mode": mode,
                "symbol": symbol,
                "side": "buy",
                "qty": float(aq),
                "price": float(fill),
                "notional": float(notional),
                "fee": float(fee),
                "realized_pnl": 0.0,
                "reason": reason,
            }, meta={"maker": bool(maker)})
        self.risk.mark_trade(symbol); self.metrics.inc_trade()
        self.log.info(f"[PAPER] BUY {symbol} qty={aq:.8f} @ {fill:.8f} fee={fee:.4f} reason={reason}")
    else:
        fill, fee, realized, aq = self.paper.sell(symbol, qty, price, maker)
        if fill<=0 or aq<=0:
            return
        ts=now_utc_iso()
        notional=aq*fill
        self.rec.add(TradeRecord(ts, exch, mode, symbol, "sell", aq, fill, notional, fee, reason, realized))
        if self.store:
            self.store.trade({
                "ts": ts,
                "exchange": exch,
                "mode": mode,
                "symbol": symbol,
                "side": "sell",
                "qty": float(aq),
                "price": float(fill),
                "notional": float(notional),
                "fee": float(fee),
                "realized_pnl": float(realized),
                "reason": reason,
            }, meta={"maker": bool(maker)})
        self.risk.mark_trade(symbol); self.metrics.inc_trade()
        self.log.info(f"[PAPER] SELL {symbol} qty={aq:.8f} @ {fill:.8f} realized={realized:.4f} reason={reason}")

def _on_live_fill(self, symbol: str, side: str, qty: float, fill: float, maker: bool, reason: str):
    exch=self.cfg["exchange"]; mode="live"
    fee=0.0
    notional=qty*fill
    if side=="buy":
        pos=self.positions.get(symbol)
        if not pos:
            self.positions[symbol]=LivePosition(symbol, qty, fill, 0.0, 0.0)
        else:
            new_qty=pos.qty+qty
            pos.entry=(pos.entry*pos.qty + fill*qty)/new_qty
            pos.qty=new_qty
        ts=now_utc_iso()
        self.rec.add(TradeRecord(ts, exch, mode, symbol, "buy", qty, fill, notional, fee, reason, 0.0))
        if self.store:
            self.store.trade({
                "ts": ts,
                "exchange": exch,
                "mode": mode,
                "symbol": symbol,
                "side": "buy",
                "qty": float(qty),
                "price": float(fill),
                "notional": float(notional),
                "fee": float(fee),
                "realized_pnl": 0.0,
                "reason": reason,
            }, meta={"maker": bool(maker)})
        self.risk.mark_trade(symbol); self.metrics.inc_trade()
        self.log.info(f"[LIVE] BUY {symbol} qty={qty:.8f} @ {fill:.8f} reason={reason}")
    else:
        pos=self.positions.get(symbol)
        realized=0.0
        if pos:
            close_qty=min(qty,pos.qty)
            realized=(fill-pos.entry)*close_qty
            pos.qty -= close_qty
            if pos.qty <= 1e-12:
                del self.positions[symbol]
        ts=now_utc_iso()
        self.rec.add(TradeRecord(ts, exch, mode, symbol, "sell", qty, fill, notional, fee, reason, realized))
        if self.store:
            self.store.trade({
                "ts": ts,
                "exchange": exch,
                "mode": mode,
                "symbol": symbol,
                "side": "sell",
                "qty": float(qty),
                "price": float(fill),
                "notional": float(notional),
                "fee": float(fee),
                "realized_pnl": float(realized),
                "reason": reason,
            }, meta={"maker": bool(maker)})
        self.risk.mark_trade(symbol); self.metrics.inc_trade()
        self.log.info(f"[LIVE] SELL {symbol} qty={qty:.8f} @ {fill:.8f} realized~{realized:.4f} reason={reason}")

    def _paper_should_fill(self, po: PendingOrder, last: float, met: Dict[str,float]) -> bool:
        # Use micro-model if enabled (p based on distance and atr)
        if self.cfg.get("micro_model", {}).get("enabled", True) and met:
            dist_bps = abs(last - po.price)/max(1e-12, po.price)*10_000
            p=maker_fill_probability(self.cfg, po.side, dist_bps, po.atr_pct, met.get("imbalance", 0.0))
            return random.random() < p
        model=self.cfg["paper"]["limit_fill_model"]
        near=float(model.get("near_bps",6.0)); p_near=float(model.get("p_near",0.35))
        if po.side=="buy":
            if last <= po.price: return True
            dist=(last-po.price)/max(1e-12,po.price)*10_000
            return (0<=dist<=near) and (random.random()<p_near)
        else:
            if last >= po.price: return True
            dist=(po.price-last)/max(1e-12,po.price)*10_000
            return (0<=dist<=near) and (random.random()<p_near)

    def _check_pending(self):
        if not self.pending: return
        if self.cfg["mode"]=="paper":
            model=self.cfg["paper"]["limit_fill_model"]
            timeout=float(model.get("timeout_sec",240))
            action=str(model.get("timeout_action","cancel")).lower()
            for sym in list(self.pending.keys()):
                po=self.pending[sym]
                try:
                    bid,ask,last=self._get_bid_ask_last(sym)
                    met={}
                    if self.cfg.get("micro_model", {}).get("enabled", True):
                        ob=self.client.fetch_order_book(sym, limit=int(self.cfg["micro_model"].get("orderbook_depth", 20)))
                        met=orderbook_metrics(ob, depth=int(self.cfg["micro_model"].get("orderbook_depth", 20)))
                    if self._paper_should_fill(po, last, met):
                        self._fill_paper(sym, po.side, po.qty, po.price, maker=True, reason=po.reason)
                        del self.pending[sym]
                        continue
                    if time.time()-po.created_ts >= timeout:
                        self.log.warn(f"[PAPER] LIMIT timeout {sym} action={action}")
                        if action=="market":
                            self._fill_market(sym, po.side, po.qty, last, po.reason+"|timeout_market")
                        del self.pending[sym]
                except Exception:
                    continue
            return

        # LIVE: handle partial fills + repost
        repost_sec=float(self.cfg["execution"]["repost_sec"])
        max_reposts=int(self.cfg["execution"]["max_reposts"])
        for sym in list(self.pending.keys()):
            po=self.pending[sym]
            try:
                o=self.client.fetch_order(po.order_id, sym)
                status=(o.get("status") or "").lower()
                filled=safe_float(o.get("filled"), 0.0)
                avg=safe_float(o.get("average") or o.get("price"), po.price)
                # incremental fill handling
                if filled > po.filled_qty + 1e-12:
                    delta = float(filled - po.filled_qty)
                    po.filled_qty = float(filled)
                    self.log.info(f"[LIVE] PARTIAL fill {sym} side={po.side} +{delta:.8f} avg~{avg:.8f}")
                    self._on_live_fill(sym, po.side, delta, float(avg), maker=True, reason=po.reason+"|partial")

                if status in ("closed","filled") or (filled and filled >= po.qty*0.999):
                    self.log.info(f"[LIVE] LIMIT filled {sym} side={po.side} total={filled:.8f} avg={avg:.8f}")
                    if sym in self.pending:
                        del self.pending[sym]
                    continue

                age=time.time()-po.created_ts
                if age >= repost_sec:
                    if po.reposts >= max_reposts:
                        self.log.warn(f"[LIVE] LIMIT max reposts reached -> cancel {sym}")
                        try: self.client.cancel_order(po.order_id, sym)
                        except Exception: pass
                        del self.pending[sym]
                        continue
                    try: self.client.cancel_order(po.order_id, sym)
                    except Exception: pass
                    po.reposts += 1
                    po.created_ts = time.time()
                    # repost remaining qty
                    remaining = max(0.0, po.qty - po.filled_qty)
                    if remaining <= 0:
                        del self.pending[sym]
                        continue
                    self.log.info(f"[LIVE] Repost {sym}: remaining={remaining:.8f} repost={po.reposts}")
                    # place new order for remaining
                    po.qty = remaining
                    po.filled_qty = 0.0
                    # use current price/off
                    bid,ask,last=self._get_bid_ask_last(sym)
                    off_bps, met, p_fill = self._choose_maker_offset_bps(sym, po.side, atr_pct=po.atr_pct)
                    off=off_bps/10_000.0
                    if po.side=="buy":
                        base=bid if np.isfinite(bid) and bid>0 else last
                        px=float(self.client.format_price(sym, base*(1.0-off)))
                    else:
                        base=ask if np.isfinite(ask) and ask>0 else last
                        px=float(self.client.format_price(sym, base*(1.0+off)))
                    remaining, px = self.client.enforce_trade_rules(sym, po.side, remaining, px)
                    post_only=bool(self.cfg["execution"].get("post_only", True))
                    params={"postOnly": True} if post_only else {}
                    try:
                        resp=self.client.create_order(sym, "limit", po.side, remaining, px, params=params)
                    except Exception:
                        resp=self.client.create_order(sym, "limit", po.side, remaining, px, params={})
                    po.order_id=str(resp.get("id"))
                    po.price=float(px)
                    self.pending[sym]=po
            except Exception as e:
                self.metrics.inc_error()
                self.watchdog.record_error(e)

    def _manage_position(self, sym: str, df: pd.DataFrame):
        pos=self.positions.get(sym)
        if not pos or pos.qty<=0: return
        last=float(df["close"].iloc[-1])
        a=float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
        self.risk.update_trailing(pos, last, a)
        stop_level=max(pos.stop, pos.trailing) if pos.trailing is not None else pos.stop

        so=self.cfg["risk"]["scale_out"]
        if so.get("enabled", True) and (not pos.tp1_done):
            tp1=self.risk.tp1_level(pos.entry, a)
            if last >= tp1:
                frac=float(so.get("tp1_pct",0.5))
                frac=clamp(frac, 0.05, 0.95)
                qty_to_sell=pos.qty*frac
                self.log.info(f"{sym}: TP1 scale-out -> sell {frac*100:.0f}%")
                self._place_order(sym, "sell", qty_to_sell, "tp1_scale_out", atr_pct=0.0)
                pos.tp1_done=True
                if bool(so.get("move_stop_to_be", True)):
                    pos.stop=max(pos.stop, pos.entry)

        if last <= stop_level:
            self.log.warn(f"{sym}: STOP triggered (last={last:.8f} stop={stop_level:.8f})")
            self._place_order(sym, "sell", pos.qty, "stop", atr_pct=0.0)
        elif last >= pos.tp:
            self.log.info(f"{sym}: TAKE PROFIT (last={last:.8f} tp={pos.tp:.8f})")
            self._place_order(sym, "sell", pos.qty, "take_profit", atr_pct=0.0)

def _process_approvals(self):
    aq = getattr(self, "approvals", None)
    if not aq:
        return
    # do not open new positions while halted/paused
    if self.halted or self.watchdog.is_paused() or self.pause_entries:
        return
    # execute approved entries
    for a in aq.list(status="approved"):
        sym = a.symbol
        try:
            # position already exists -> mark executed to avoid loop
            if sym in self.positions and self.positions[sym].qty > 0:
                aq.mark_executed(a.id, by="engine_skip_exists")
                continue

            self.client.load_markets()
            t = self.client.fetch_ticker_cached(sym)
            px = safe_float(t.get("last"), 0.0)
            if not np.isfinite(px) or px <= 0:
                continue

            qty = float(self.client.format_amount(sym, a.qty))
            qty, _ = self.client.enforce_trade_rules(sym, "buy", qty, px)
            if qty <= 0:
                aq.reject(a.id, by="engine_invalid_qty")
                continue

            stop = a.meta.get("stop")
            tp = a.meta.get("tp")
            atr_pct = float(a.meta.get("atr_pct", 0.0))
            if stop is None or tp is None:
                df = self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=int(self.cfg["ohlcv_limit"]))
                a_val = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
                stop, tp = self.risk.stop_tp(px, a_val)
                atr_pct = a_val / max(1e-12, px)

            stop = float(self.client.format_price(sym, stop))
            tp = float(self.client.format_price(sym, tp))

            self.positions[sym] = LivePosition(sym, qty, px, stop, tp)
            self._place_order(sym, "buy", qty, f"approved_buy:{a.id}", atr_pct=atr_pct)

            if self.store:
                self.store.signal(time.time(), sym, "buy", 1.0, "approved_entry", a.id, "executed", dict(a.meta))
            self.notifier.notify("entry_executed", f"{sym} BUY executed (approval {a.id})")
            aq.mark_executed(a.id, by="engine")
        except Exception as e:
            self.log.warn(f"Approval exec failed id={a.id} sym={sym}: {e}")
            continue

def _open_long(self, sym: str, df: pd.DataFrame, df_trend: pd.DataFrame, returns_map: Dict[str, np.ndarray]):
    # Global / safety gates
    if self.halted or self.watchdog.is_paused() or self.pause_entries:
        return
    if self.market_guard and self.market_guard.is_tripped():
        return

    # Risk gates
    if self.risk.in_cooldown(sym) or self.risk.max_trades_reached():
        return
    if self._volatility_pause(df):
        self.log.warn(f"{sym}: volatility pause -> skip entry")
        return

    # Position gates
    if sym in self.positions and self.positions[sym].qty > 0:
        return
    if len([p for p in self.positions.values() if p.qty > 0]) >= int(self.cfg["risk"]["max_open_positions"]):
        return

    # Correlation filter (portfolio)
    cf = self.cfg["risk"]["portfolio"]["correlation_filter"]
    if cf.get("enabled", True):
        open_syms=[s for s,p in self.positions.items() if p.qty>0]
        if open_syms:
            if not corr_ok(returns_map, sym, open_syms, float(cf.get("max_corr", 0.75))):
                self.log.info(f"{sym}: correlation filter -> skip entry")
                return

    # Size & levels
    self.client.load_markets()
    eq = self.equity()
    px = float(df["close"].iloc[-1])
    a = float(atr(df, int(self.cfg["risk"]["atr_period"])).iloc[-1])
    atr_pct = self._atr_pct(df)

    qty = self.risk.size_qty(eq, px, a, self.client.markets, sym)
    qty = float(self.client.format_amount(sym, qty))
    qty, _ = self.client.enforce_trade_rules(sym, "buy", qty, px)
    if qty <= 0:
        return

    stop, tp = self.risk.stop_tp(px, a)
    stop = float(self.client.format_price(sym, stop))
    tp = float(self.client.format_price(sym, tp))

    # Approval gate (human-in-the-loop)
    appr_cfg = self.cfg.get("approvals", {}) or {}
    require = False
    if self.cfg.get("mode") == "live" and appr_cfg.get("require_for_live", False):
        require = True
    if self.cfg.get("mode") == "paper" and appr_cfg.get("require_for_paper", False):
        require = True

    if require and getattr(self, "approvals", None):
        aobj = self.approvals.create(
            symbol=sym,
            side="buy",
            qty=qty,
            price_ref=px,
            reason="signal_buy",
            meta={"stop": stop, "tp": tp, "atr_pct": atr_pct},
        )
        self.log.warn(f"{sym}: entry requires approval -> PENDING id={aobj.id}")
        if self.store:
            self.store.signal(time.time(), sym, "buy", 1.0, "signal_buy", aobj.id, "pending", dict(aobj.meta))
        self.notifier.notify("approval_required", f"{sym} BUY pending approval {aobj.id} qty={qty:.6f} px={px:.6f}")
        return

    # Execute immediately
    self.positions[sym] = LivePosition(sym, qty, px, stop, tp)
    self._place_order(sym, "buy", qty, "signal_buy", atr_pct=atr_pct)

    def close_all(self, reason: str="manual_close_all"):
        if self.cfg["mode"]=="paper" and self.paper:
            for sym,pos in list(self.paper.positions.items()):
                try:
                    _,_,last=self._get_bid_ask_last(sym)
                    self._fill_paper(sym, "sell", pos.qty, last, maker=False, reason=reason)
                except Exception:
                    continue
            self.positions.clear(); self.pending.clear()
            return
        for sym,pos in list(self.positions.items()):
            try:
                self._place_order(sym, "sell", pos.qty, reason, atr_pct=0.0)
            except Exception:
                continue

    def loop(self):
        self.log.info(f"Engine start: exchange={self.cfg['exchange']} mode={self.cfg['mode']} exec={self.cfg['execution']['type']}")
        self.client.load_markets()
        if self.cfg.get("websocket", {}).get("enabled", True):
            self.ws.start()
        last_pairs_ts=0.0
        last_state_save=0.0
        while not self._stop:
            try:
                self._new_day_check()
                self._apply_kill_switch()
                if self.halted:
                    time.sleep(1.0)
                    continue

                # watchdog pause: manage pending & exits, skip new entries
                if self.watchdog.is_paused():
                    self._check_pending()
                    time.sleep(1.0)
                    continue

                # refresh pairs
                if (time.time()-last_pairs_ts) >= float(self.cfg["pair_refresh_sec"]) or not self.pairs:
                    self._refresh_pairs()
                    last_pairs_ts=time.time()

                self._auto_opt_if_needed()
                # market guard (circuit breaker) -> pause new entries during cooldown
                if self.market_guard:
                    reason = self.market_guard.check(self.client, self.pairs)
                    if reason:
                        self.pause_entries = True
                        self._mg_paused = True
                        self.log.warn(f"MarketGuard TRIPPED: {reason} (cooldown {self.market_guard.seconds_left()}s)")
                        if self.store:
                            self.store.event("WARN", "market_guard", reason, {"cooldown_sec": self.market_guard.seconds_left()})
                        self.notifier.notify("market_guard", reason)
                    elif self._mg_paused and not self.market_guard.is_tripped():
                        self.pause_entries = False
                        self._mg_paused = False
                        self.log.info("MarketGuard cleared: entries resumed")

                # execute any approved entries (if enabled)
                self._process_approvals()

                # compute correlation returns map (subset for speed)
                symbols_for_corr = list(set(self.pairs[:min(10,len(self.pairs))] + list(self.positions.keys())))
                returns_map = self._compute_returns_map(symbols_for_corr) if self.cfg["risk"]["portfolio"]["correlation_filter"].get("enabled", True) else {}

                # loop pairs
                for sym in self.pairs:
                    if self._stop: break
                    try:
                        df=self.client.fetch_ohlcv_df(sym, self.cfg["signal_timeframe"], limit=int(self.cfg["ohlcv_limit"]))
                        df_tr=self.client.fetch_ohlcv_df(sym, self.cfg["trend_timeframe"], limit=min(2400, int(self.cfg["ohlcv_limit"])*4))
                        self._manage_position(sym, df)
                        sig=self.strategy.compute(df, df_tr, sym)

                        if sig.action=="buy":
                            self.log.info(f"{sym}: BUY signal {sig.strength:.2f} :: {sig.reason}")
                            self._open_long(sym, df, df_tr, returns_map)
                        elif sig.action=="sell":
                            if sym in self.positions and self.positions[sym].qty>0:
                                self.log.info(f"{sym}: SELL signal {sig.strength:.2f} :: {sig.reason}")
                                self._place_order(sym, "sell", self.positions[sym].qty, "signal_sell", atr_pct=0.0)

                        self.watchdog.record_success()
                    except Exception as e:
                        self.metrics.inc_error()
                        self.watchdog.record_error(e)

                # pending orders
                self._check_pending()

                # sync paper meta qty
                if self.cfg["mode"]=="paper" and self.paper:
                    for sym in list(self.positions.keys()):
                        if sym in self.paper.positions:
                            self.positions[sym].qty=self.paper.positions[sym].qty
                            self.positions[sym].entry=self.paper.positions[sym].avg_price
                        else:
                            del self.positions[sym]

                last_state_save=self._save_state_periodic(last_state_save)

            except Exception as e:
                self.metrics.inc_error()
                self.watchdog.record_error(e)

            time.sleep(max(0.2, float(self.cfg["scan_interval_sec"])))

        # final save
        self.state.save(self._snapshot())
        self.log.warn("Engine stopped.")

# app/llm_local.py
from __future__ import annotations

"""
Local deterministic LLM-like advisor.

Goal:
- Zero-cost, always-available logic layer that can veto entries or apply bounded
  score/risk multipliers based on market context.
- Safe-by-default: it never forces trading; only allows (default) or veto/derisk.

Expected by llm_router.py:
- attribute: enabled: bool
- method: advise(ctx: dict) -> dict
- function: from_cfg(cfg: dict, log=None) -> LocalAdvisor

Return schema (always):
{
  allow_entries: bool,
  score_mult: float,
  risk_mult: float,
  sentiment_score: float,   # [-1..1]
  confidence: float,        # [0..1]
  reason: str,
  reasons: list[str],
  meta: dict                # optional debugging info
}
"""

import time
import threading
import json
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, List, Tuple, TypedDict, Callable
from enum import Enum, IntEnum
from abc import ABC, abstractmethod
from collections import OrderedDict, defaultdict
import warnings


# ============================================================================
# Data Types
# ============================================================================

class LogLevel(IntEnum):
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50


class TradeContext(TypedDict, total=False):
    symbol: str
    side: str
    atr_pct: float
    spread_bps: float
    volume_usd: float
    quote_volume_usd: float
    vol_24h_usd: float
    funding_rate: float
    funding: float
    market_regime: str
    trend_dir: float
    price: float
    position_size: float
    unrealized_pnl: float
    realized_pnl: float
    max_drawdown: float
    win_rate: float
    sharpe_ratio: float
    volatility: float
    correlation: Dict[str, float]


class AdviceResult(TypedDict, total=False):
    allow_entries: bool
    score_mult: float
    risk_mult: float
    sentiment_score: float
    confidence: float
    reason: str
    reasons: List[str]
    meta: Dict[str, Any]


class VetoMode(Enum):
    HARD = "hard"       # Strict veto above threshold
    SOFT = "soft"       # Only derisk, no hard veto
    HYBRID = "hybrid"   # Derisk + veto only for extreme cases
    ADAPTIVE = "adaptive"  # Adjust based on market conditions


class MarketRegime(Enum):
    TREND_UP = "trend_up"
    TREND_DOWN = "trend_down"
    RANGE = "range"
    HIGH_VOL = "high_vol"
    LOW_VOL = "low_vol"
    RISK_OFF = "risk_off"
    PANIC = "panic"
    BEAR = "bear"
    BULL = "bull"
    UNKNOWN = "unknown"


# ============================================================================
# Utility Functions
# ============================================================================

def _now() -> float:
    return time.time()


def _f(x: Any, d: float = 0.0) -> float:
    try:
        if x is None:
            return float(d)
        return float(x)
    except Exception:
        return float(d)


def _i(x: Any, d: int = 0) -> int:
    try:
        if x is None:
            return int(d)
        return int(x)
    except Exception:
        return int(d)


def _b(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    if isinstance(x, bool):
        return x
    s = str(x).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


def _clamp(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def _norm_side(side: Any) -> str:
    s = str(side or "").strip().lower()
    if s in ("buy", "long", "l"):
        return "LONG"
    if s in ("sell", "short", "s"):
        return "SHORT"
    if s in ("both", "neutral", "n"):
        return "NEUTRAL"
    return s.upper()


def _sigmoid(x: float) -> float:
    """Smooth sigmoid function for transitions."""
    return 1.0 / (1.0 + np.exp(-x))


def _smooth_step(x: float, edge0: float = 0.0, edge1: float = 1.0) -> float:
    """Smooth step function between edge0 and edge1."""
    x = _clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def _exponential_decay(x: float, half_life: float) -> float:
    """Exponential decay factor."""
    return 2.0 ** (-x / half_life)


# ============================================================================
# Configuration Classes
# ============================================================================

@dataclass
class LiquidityConfig:
    """Configuration for liquidity checks."""
    min_liquidity_usd: float = 2_000_000.0
    warning_threshold_frac: float = 0.15  # Warn when within 15% of minimum
    critical_threshold_frac: float = 0.05  # Critical when within 5% of minimum
    volume_lookback_hours: int = 24
    use_average_volume: bool = True
    average_window: int = 20


@dataclass
class SpreadConfig:
    """Configuration for spread checks."""
    max_spread_bps: float = 40.0
    warning_threshold_bps: float = 5.0  # Warn when within 5bps of max
    critical_threshold_bps: float = 2.0  # Critical when within 2bps of max
    use_relative_spread: bool = True
    spread_smoothing_period: int = 10


@dataclass
class VolatilityConfig:
    """Configuration for volatility checks."""
    max_atr_pct: float = 0.06
    atr_veto_mode: VetoMode = VetoMode.HYBRID
    soft_start_frac: float = 0.60  # Start derisk after 60% of max
    score_penalty: float = 0.60    # Up to -60% score near max
    risk_penalty: float = 0.50     # Up to -50% risk near max
    extreme_multiplier: float = 1.25  # Veto only when >1.25x max
    adaptive_mode: bool = True     # Adjust thresholds based on regime
    atr_period: int = 14


@dataclass
class FundingConfig:
    """Configuration for funding rate checks."""
    veto_abs: float = 0.003  # 0.30%
    warning_abs: float = 0.002  # 0.20%
    smoothing_period: int = 8
    consider_trend: bool = True  # Consider trend when evaluating funding
    max_position_size_mult: float = 0.5  # Reduce position size when funding extreme


@dataclass
class TrendConfig:
    """Configuration for trend alignment checks."""
    enable_trend_filter: bool = True
    against_trend_score_mult: float = 0.92
    against_trend_risk_mult: float = 0.90
    trend_lookback_period: int = 20
    trend_strength_threshold: float = 0.3
    use_multiple_timeframes: bool = False
    timeframe_weights: Dict[str, float] = field(default_factory=lambda: {"1h": 0.5, "4h": 0.3, "1d": 0.2})


@dataclass
class RegimeConfig:
    """Configuration for market regime adjustments."""
    risk_off_score_mult: float = 0.90
    risk_off_risk_mult: float = 0.85
    panic_score_mult: float = 0.70
    panic_risk_mult: float = 0.60
    bull_score_mult: float = 1.05
    bull_risk_mult: float = 1.02
    regime_detection_method: str = "composite"  # simple, composite, ml
    regime_lookback: int = 50
    confidence_threshold: float = 0.7


@dataclass
class PositionManagementConfig:
    """Configuration for position management."""
    max_drawdown_multiplier: float = 0.8  # Reduce risk when near max drawdown
    win_rate_multiplier: float = 1.1  # Increase confidence with high win rate
    pnl_adjustment_enabled: bool = True
    correlation_penalty_enabled: bool = True
    max_correlation: float = 0.7  # Reduce risk for highly correlated positions
    sharpe_adjustment_enabled: bool = True
    min_sharpe_ratio: float = 0.5  # Adjust risk based on Sharpe ratio


@dataclass
class CooldownConfig:
    """Configuration for veto cooldowns."""
    veto_cooldown_sec: int = 45
    warning_cooldown_sec: int = 15
    progressive_cooldown: bool = True  # Increase cooldown for repeated vetos
    max_cooldown_sec: int = 300
    decay_factor: float = 0.8  # Cooldown decay factor


@dataclass
class ClampingConfig:
    """Configuration for output clamping."""
    score_mult_min: float = 0.60
    score_mult_max: float = 1.25
    risk_mult_min: float = 0.60
    risk_mult_max: float = 1.10
    sentiment_min: float = -0.5
    sentiment_max: float = 0.5
    confidence_min: float = 0.2
    confidence_max: float = 0.95
    smooth_transitions: bool = True  # Use smooth transitions instead of hard clamps


@dataclass
class LocalAdvisorConfig:
    """Main configuration for the local advisor."""
    enabled: bool = False
    name: str = "local_advisor"
    
    # Sub-configurations
    liquidity: LiquidityConfig = field(default_factory=LiquidityConfig)
    spread: SpreadConfig = field(default_factory=SpreadConfig)
    volatility: VolatilityConfig = field(default_factory=VolatilityConfig)
    funding: FundingConfig = field(default_factory=FundingConfig)
    trend: TrendConfig = field(default_factory=TrendConfig)
    regime: RegimeConfig = field(default_factory=RegimeConfig)
    position_mgmt: PositionManagementConfig = field(default_factory=PositionManagementConfig)
    cooldown: CooldownConfig = field(default_factory=CooldownConfig)
    clamping: ClampingConfig = field(default_factory=ClampingConfig)
    
    # Advanced features
    enable_caching: bool = True
    cache_ttl_sec: float = 5.0
    enable_learning: bool = False  # Learn from past decisions
    learning_rate: float = 0.01
    enable_metrics: bool = True
    log_level: LogLevel = LogLevel.INFO
    
    # Plugin system
    custom_rules: List[Callable] = field(default_factory=list)
    
    # Performance
    max_processing_time_ms: float = 10.0
    batch_processing: bool = False
    parallel_processing: bool = False


# ============================================================================
# Cache Implementation
# ============================================================================

class AdviceCache:
    """Cache for advice results to avoid redundant calculations."""
    
    def __init__(self, max_size: int = 1000, ttl_seconds: float = 5.0):
        self.cache: OrderedDict[str, Tuple[float, AdviceResult]] = OrderedDict()
        self.max_size = max_size
        self.ttl = ttl_seconds
        self.lock = threading.RLock()
        self.stats = {"hits": 0, "misses": 0, "evictions": 0}
    
    def _generate_key(self, ctx: TradeContext) -> str:
        """Generate a cache key from context."""
        key_parts = []
        
        # Include essential context fields
        essential_fields = ["symbol", "side", "atr_pct", "spread_bps", "funding_rate"]
        for field in essential_fields:
            value = ctx.get(field)
            if value is not None:
                key_parts.append(f"{field}={value}")
        
        # Add timestamp for minute-level granularity
        current_minute = int(_now() / 60)
        key_parts.append(f"minute={current_minute}")
        
        return "_".join(key_parts)
    
    def get(self, ctx: TradeContext) -> Optional[AdviceResult]:
        """Get cached advice if available and not expired."""
        key = self._generate_key(ctx)
        
        with self.lock:
            if key not in self.cache:
                self.stats["misses"] += 1
                return None
            
            timestamp, result = self.cache[key]
            if _now() - timestamp > self.ttl:
                del self.cache[key]
                self.stats["misses"] += 1
                return None
            
            self.stats["hits"] += 1
            # Move to end (most recently used)
            self.cache.move_to_end(key)
            return result
    
    def set(self, ctx: TradeContext, result: AdviceResult):
        """Cache advice result."""
        key = self._generate_key(ctx)
        
        with self.lock:
            self.cache[key] = (_now(), result)
            
            # Evict if over size limit
            if len(self.cache) > self.max_size:
                self.cache.popitem(last=False)
                self.stats["evictions"] += 1
    
    def clear(self):
        """Clear the cache."""
        with self.lock:
            self.cache.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.lock:
            total = self.stats["hits"] + self.stats["misses"]
            hit_rate = self.stats["hits"] / total if total > 0 else 0.0
            return {
                **self.stats,
                "hit_rate": hit_rate,
                "size": len(self.cache),
                "max_size": self.max_size,
                "ttl": self.ttl
            }


# ============================================================================
# Metrics Collection
# ============================================================================

class AdvisorMetrics:
    """Collect metrics about advisor performance."""
    
    def __init__(self):
        self.decisions = 0
        self.vetos = 0
        self.warnings = 0
        self.avg_processing_time = 0.0
        self.last_decisions: List[Tuple[float, str, bool]] = []  # (timestamp, symbol, allowed)
        self.rule_triggers = defaultdict(int)
        self.confidence_distribution = []
        self.error_count = 0
        
    def record_decision(self, symbol: str, allowed: bool, processing_time: float, 
                       reason: str, confidence: float):
        """Record a decision."""
        self.decisions += 1
        if not allowed:
            self.vetos += 1
        if "warning" in reason.lower() or "near" in reason.lower():
            self.warnings += 1
            
        # Update average processing time (exponential moving average)
        alpha = 0.1
        self.avg_processing_time = (
            alpha * processing_time + (1 - alpha) * self.avg_processing_time
        )
        
        # Store last decisions (keep last 100)
        self.last_decisions.append((_now(), symbol, allowed))
        if len(self.last_decisions) > 100:
            self.last_decisions.pop(0)
            
        # Record confidence
        self.confidence_distribution.append(confidence)
        if len(self.confidence_distribution) > 1000:
            self.confidence_distribution.pop(0)
            
        # Record rule trigger
        self.rule_triggers[reason] += 1
    
    def record_error(self):
        """Record an error."""
        self.error_count += 1
    
    def record_rule_trigger(self, rule_name: str):
        """Record a rule trigger."""
        self.rule_triggers[rule_name] += 1
    
    def get_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        if self.decisions == 0:
            return {"decisions": 0}
        
        # Calculate veto rate
        veto_rate = self.vetos / self.decisions if self.decisions > 0 else 0.0
        warning_rate = self.warnings / self.decisions if self.decisions > 0 else 0.0
        
        # Calculate recent decisions (last 10 minutes)
        recent_cutoff = _now() - 600
        recent_decisions = [d for d in self.last_decisions if d[0] > recent_cutoff]
        recent_allowed = sum(1 for d in recent_decisions if d[2])
        recent_total = len(recent_decisions)
        recent_allow_rate = recent_allowed / recent_total if recent_total > 0 else 0.0
        
        # Confidence statistics
        if self.confidence_distribution:
            conf_array = np.array(self.confidence_distribution)
            conf_stats = {
                "mean": float(np.mean(conf_array)),
                "std": float(np.std(conf_array)),
                "min": float(np.min(conf_array)),
                "max": float(np.max(conf_array))
            }
        else:
            conf_stats = {}
        
        return {
            "total_decisions": self.decisions,
            "vetos": self.vetos,
            "veto_rate": veto_rate,
            "warnings": self.warnings,
            "warning_rate": warning_rate,
            "errors": self.error_count,
            "avg_processing_time_ms": self.avg_processing_time * 1000,
            "recent_decisions": recent_total,
            "recent_allow_rate": recent_allow_rate,
            "confidence_stats": conf_stats,
            "rule_triggers": dict(self.rule_triggers),
            "timestamp": _now()
        }


# ============================================================================
# Structured Logger
# ============================================================================

class StructuredLogger:
    """Structured logging for the local advisor."""
    
    def __init__(self, min_level: LogLevel = LogLevel.INFO, log_callback=None):
        self.min_level = min_level
        self.log_callback = log_callback
        self.enabled = True
    
    def log(self, level: LogLevel, event: str, data: Dict[str, Any], symbol: str = None):
        """Log a structured event."""
        if not self.enabled or level < self.min_level:
            return
        
        log_entry = {
            "timestamp": _now(),
            "level": level.name,
            "event": event,
            "symbol": symbol,
            "data": data,
            "source": "llm_local"
        }
        
        # Call callback if provided
        if self.log_callback:
            try:
                self.log_callback(log_entry)
            except Exception:
                pass
        
        # Print warnings and errors to console
        if level >= LogLevel.WARNING:
            print(f"[LLM Local {level.name}] {event}: {json.dumps(data, default=str)}")
    
    def disable(self):
        """Disable logging."""
        self.enabled = False
    
    def enable(self):
        """Enable logging."""
        self.enabled = True


# ============================================================================
# Rule System
# ============================================================================

class Rule(ABC):
    """Base class for advisory rules."""
    
    def __init__(self, name: str, enabled: bool = True, weight: float = 1.0):
        self.name = name
        self.enabled = enabled
        self.weight = weight
    
    @abstractmethod
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        """
        Evaluate the rule.
        
        Returns:
            Tuple of (allow_entries, score_mult, risk_mult, reasons)
        """
        pass


class LiquidityRule(Rule):
    """Rule for liquidity checks."""
    
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        reasons = []
        score_mult = 1.0
        risk_mult = 1.0
        allow = True
        
        liq_usd = _f(ctx.get("quote_volume_usd"), 
                    _f(ctx.get("volume_usd"), 
                      _f(ctx.get("vol_24h_usd"), 0.0)))
        
        if liq_usd <= 0:
            return allow, score_mult, risk_mult, reasons
        
        cfg = config.liquidity
        
        # Hard veto for critically low liquidity
        if liq_usd < cfg.min_liquidity_usd:
            allow = False
            reasons.append(f"liquidity_critical:{liq_usd:.0f}<{cfg.min_liquidity_usd:.0f}")
            return allow, 0.0, 0.0, reasons
        
        # Warning zone
        warning_threshold = cfg.min_liquidity_usd * (1.0 + cfg.warning_threshold_frac)
        critical_threshold = cfg.min_liquidity_usd * (1.0 + cfg.critical_threshold_frac)
        
        if liq_usd < critical_threshold:
            reasons.append(f"liquidity_near_critical:{liq_usd:.0f}<{critical_threshold:.0f}")
            # Strong derisk in critical zone
            ratio = (liq_usd - cfg.min_liquidity_usd) / (critical_threshold - cfg.min_liquidity_usd)
            penalty = 1.0 - _smooth_step(ratio, 0.0, 1.0)
            score_mult *= (1.0 - penalty * 0.4)
            risk_mult *= (1.0 - penalty * 0.5)
        
        elif liq_usd < warning_threshold:
            reasons.append(f"liquidity_warning:{liq_usd:.0f}<{warning_threshold:.0f}")
            # Mild derisk in warning zone
            ratio = (liq_usd - critical_threshold) / (warning_threshold - critical_threshold)
            penalty = 1.0 - _smooth_step(ratio, 0.0, 1.0)
            score_mult *= (1.0 - penalty * 0.2)
            risk_mult *= (1.0 - penalty * 0.3)
        
        return allow, score_mult, risk_mult, reasons


class SpreadRule(Rule):
    """Rule for spread checks."""
    
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        reasons = []
        score_mult = 1.0
        risk_mult = 1.0
        allow = True
        
        spread_bps = abs(_f(ctx.get("spread_bps"), 0.0))
        
        if spread_bps <= 0:
            return allow, score_mult, risk_mult, reasons
        
        cfg = config.spread
        
        # Hard veto for critically high spread
        if spread_bps > cfg.max_spread_bps:
            allow = False
            reasons.append(f"spread_critical:{spread_bps:.2f}>{cfg.max_spread_bps:.2f}")
            return allow, 0.0, 0.0, reasons
        
        # Warning zones
        critical_threshold = cfg.max_spread_bps - cfg.critical_threshold_bps
        warning_threshold = cfg.max_spread_bps - cfg.warning_threshold_bps
        
        if spread_bps > critical_threshold:
            reasons.append(f"spread_near_critical:{spread_bps:.2f}>{critical_threshold:.2f}")
            # Strong derisk in critical zone
            ratio = (spread_bps - critical_threshold) / (cfg.max_spread_bps - critical_threshold)
            penalty = _smooth_step(ratio, 0.0, 1.0)
            score_mult *= (1.0 - penalty * 0.3)
            risk_mult *= (1.0 - penalty * 0.4)
        
        elif spread_bps > warning_threshold:
            reasons.append(f"spread_warning:{spread_bps:.2f}>{warning_threshold:.2f}")
            # Mild derisk in warning zone
            ratio = (spread_bps - warning_threshold) / (critical_threshold - warning_threshold)
            penalty = _smooth_step(ratio, 0.0, 1.0)
            score_mult *= (1.0 - penalty * 0.15)
            risk_mult *= (1.0 - penalty * 0.2)
        
        return allow, score_mult, risk_mult, reasons


class VolatilityRule(Rule):
    """Rule for volatility checks."""
    
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        reasons = []
        score_mult = 1.0
        risk_mult = 1.0
        allow = True
        
        atr_pct = abs(_f(ctx.get("atr_pct"), 0.0))
        
        if atr_pct <= 0:
            return allow, score_mult, risk_mult, reasons
        
        cfg = config.volatility
        
        # Apply different veto modes
        if cfg.atr_veto_mode == VetoMode.HARD:
            if atr_pct > cfg.max_atr_pct:
                allow = False
                reasons.append(f"volatility_hard_veto:{atr_pct:.4f}>{cfg.max_atr_pct:.4f}")
                return allow, 0.0, 0.0, reasons
        
        elif cfg.atr_veto_mode == VetoMode.HYBRID:
            # Veto only for extreme volatility
            if atr_pct > (cfg.max_atr_pct * cfg.extreme_multiplier):
                allow = False
                reasons.append(f"volatility_extreme_veto:{atr_pct:.4f}>{cfg.max_atr_pct*cfg.extreme_multiplier:.4f}")
                return allow, 0.0, 0.0, reasons
        
        # Soft derisk based on volatility level
        soft_start = cfg.max_atr_pct * cfg.soft_start_frac
        
        if atr_pct >= soft_start:
            ratio = _clamp((atr_pct - soft_start) / max(1e-9, (cfg.max_atr_pct - soft_start)), 0.0, 2.0)
            
            # Smooth penalty application
            penalty = _smooth_step(ratio, 0.0, 1.0)
            
            # For HYBRID mode, use reduced penalties
            if cfg.atr_veto_mode == VetoMode.HYBRID and atr_pct > cfg.max_atr_pct:
                # Already above max but not extreme - apply stronger penalties
                extra_ratio = (atr_pct - cfg.max_atr_pct) / (cfg.max_atr_pct * (cfg.extreme_multiplier - 1))
                penalty = 0.5 + 0.5 * _smooth_step(extra_ratio, 0.0, 1.0)
            
            score_mult *= (1.0 - penalty * cfg.score_penalty)
            risk_mult *= (1.0 - penalty * cfg.risk_penalty)
            
            if penalty > 0.33:
                reasons.append(f"high_volatility:{atr_pct:.4f}")
        
        return allow, score_mult, risk_mult, reasons


class FundingRule(Rule):
    """Rule for funding rate checks."""
    
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        reasons = []
        score_mult = 1.0
        risk_mult = 1.0
        allow = True
        
        funding = _f(ctx.get("funding_rate"), _f(ctx.get("funding"), 0.0))
        side = _norm_side(ctx.get("side"))
        
        if funding == 0 or side == "NEUTRAL":
            return allow, score_mult, risk_mult, reasons
        
        cfg = config.funding
        
        # Check for extreme funding against position
        funding_abs = abs(funding)
        
        if funding_abs >= cfg.veto_abs:
            # Check if funding is against our position
            if (side == "LONG" and funding > 0) or (side == "SHORT" and funding < 0):
                allow = False
                reasons.append(f"funding_veto:{side}:{funding:.6f}")
                return allow, 0.0, 0.0, reasons
        
        # Warning zone
        if funding_abs >= cfg.warning_abs:
            # Check if funding is against our position
            if (side == "LONG" and funding > 0) or (side == "SHORT" and funding < 0):
                reasons.append(f"funding_warning:{side}:{funding:.6f}")
                
                # Apply penalty proportional to funding level
                ratio = _clamp((funding_abs - cfg.warning_abs) / max(1e-9, (cfg.veto_abs - cfg.warning_abs)), 0.0, 1.0)
                penalty = _smooth_step(ratio, 0.0, 1.0)
                
                score_mult *= (1.0 - penalty * 0.3)
                risk_mult *= (1.0 - penalty * 0.4)
        
        return allow, score_mult, risk_mult, reasons


class TrendRule(Rule):
    """Rule for trend alignment checks."""
    
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        reasons = []
        score_mult = 1.0
        risk_mult = 1.0
        allow = True
        
        if not config.trend.enable_trend_filter:
            return allow, score_mult, risk_mult, reasons
        
        side = _norm_side(ctx.get("side"))
        trend_dir = _f(ctx.get("trend_dir"), 0.0)
        
        if trend_dir == 0.0 or side == "NEUTRAL":
            return allow, score_mult, risk_mult, reasons
        
        # Determine desired direction
        want = 1.0 if side == "LONG" else -1.0
        
        # Check if against trend
        if (trend_dir * want) < 0:
            reasons.append("against_trend")
            
            # Apply penalties
            trend_strength = abs(trend_dir)
            if trend_strength > config.trend.trend_strength_threshold:
                # Stronger penalty for stronger trends
                strength_ratio = _clamp(
                    (trend_strength - config.trend.trend_strength_threshold) / 
                    (1.0 - config.trend.trend_strength_threshold), 0.0, 1.0
                )
                
                # Base penalty from config, scaled by trend strength
                score_penalty = 1.0 - config.trend.against_trend_score_mult
                risk_penalty = 1.0 - config.trend.against_trend_risk_mult
                
                score_mult *= (1.0 - score_penalty * strength_ratio)
                risk_mult *= (1.0 - risk_penalty * strength_ratio)
            else:
                # Mild penalty for weak trends
                score_mult *= config.trend.against_trend_score_mult
                risk_mult *= config.trend.against_trend_risk_mult
        
        return allow, score_mult, risk_mult, reasons


class RegimeRule(Rule):
    """Rule for market regime adjustments."""
    
    def evaluate(self, ctx: TradeContext, config: LocalAdvisorConfig) -> Tuple[bool, float, float, List[str]]:
        reasons = []
        score_mult = 1.0
        risk_mult = 1.0
        allow = True
        
        regime = str(ctx.get("market_regime") or "").lower().strip()
        
        if not regime:
            return allow, score_mult, risk_mult, reasons
        
        cfg = config.regime
        
        # Apply regime-specific multipliers
        if regime in ("risk_off", "bear", "panic"):
            reasons.append(f"regime:{regime}")
            
            if regime == "panic":
                score_mult *= cfg.panic_score_mult
                risk_mult *= cfg.panic_risk_mult
            else:
                score_mult *= cfg.risk_off_score_mult
                risk_mult *= cfg.risk_off_risk_mult
        
        elif regime in ("bull", "trend_up"):
            reasons.append(f"regime:{regime}")
            score_mult *= cfg.bull_score_mult
            risk_mult *= cfg.bull_risk_mult
        
        return allow, score_mult, risk_mult, reasons


# ============================================================================
# Main Advisor Class
# ============================================================================

@dataclass
class LocalAdvisor:
    """Local deterministic LLM-like advisor."""
    
    # Configuration
    config: LocalAdvisorConfig
    logger: StructuredLogger
    
    # Internal state
    _cache: AdviceCache = field(init=False)
    _metrics: AdvisorMetrics = field(init=False, default_factory=AdvisorMetrics)
    _veto_history: List[Tuple[float, str, str]] = field(init=False, default_factory=list)  # (timestamp, symbol, reason)
    _rules: List[Rule] = field(init=False)
    _last_advice: Dict[str, AdviceResult] = field(init=False, default_factory=dict)
    _lock: threading.RLock = field(init=False, default_factory=threading.RLock)
    
    def __post_init__(self):
        """Initialize the advisor."""
        self._cache = AdviceCache(ttl_seconds=self.config.cache_ttl_sec)
        self._initialize_rules()
        
        if self.config.enabled:
            self.logger.log(LogLevel.INFO, "advisor_initialized", {
                "config": self._get_config_summary(),
                "rules": [rule.name for rule in self._rules if rule.enabled]
            })
    
    @property
    def enabled(self) -> bool:
        return self.config.enabled
    
    def _initialize_rules(self):
        """Initialize the rule system."""
        self._rules = [
            LiquidityRule("liquidity", enabled=True, weight=1.2),
            SpreadRule("spread", enabled=True, weight=1.1),
            VolatilityRule("volatility", enabled=True, weight=1.3),
            FundingRule("funding", enabled=True, weight=1.0),
            TrendRule("trend", enabled=self.config.trend.enable_trend_filter, weight=0.8),
            RegimeRule("regime", enabled=True, weight=0.9),
        ]
        
        # Add custom rules
        for custom_rule in self.config.custom_rules:
            if callable(custom_rule):
                # Wrap callable in a Rule object
                class CustomRuleWrapper(Rule):
                    def __init__(self, func, name):
                        super().__init__(name)
                        self.func = func
                    
                    def evaluate(self, ctx, config):
                        return self.func(ctx, config)
                
                self._rules.append(CustomRuleWrapper(custom_rule, f"custom_{len(self.config.custom_rules)}"))
    
    def _get_config_summary(self) -> Dict[str, Any]:
        """Get a summary of the configuration."""
        return {
            "enabled": self.config.enabled,
            "liquidity_min": self.config.liquidity.min_liquidity_usd,
            "spread_max": self.config.spread.max_spread_bps,
            "volatility_max": self.config.volatility.max_atr_pct,
            "funding_veto": self.config.funding.veto_abs,
            "cache_enabled": self.config.enable_caching,
            "cache_ttl": self.config.cache_ttl_sec,
        }
    
    def _neutral(self, reason: str = "neutral") -> AdviceResult:
        """Return neutral advice."""
        return {
            "allow_entries": True,
            "score_mult": 1.0,
            "risk_mult": 1.0,
            "sentiment_score": 0.0,
            "confidence": 0.5,
            "reason": reason,
            "reasons": [],
            "meta": {},
        }
    
    def _check_cooldown(self, symbol: str) -> Tuple[bool, Optional[str]]:
        """Check if symbol is in cooldown period."""
        with self._lock:
            now = _now()
            cfg = self.config.cooldown
            
            # Find recent vetos for this symbol
            recent_vetos = [
                (ts, reason) for ts, sym, reason in self._veto_history
                if sym == symbol and (now - ts) < cfg.max_cooldown_sec
            ]
            
            if not recent_vetos:
                return False, None
            
            # Check if still in cooldown
            last_veto_ts, last_reason = max(recent_vetos, key=lambda x: x[0])
            
            # Calculate cooldown duration (progressive if enabled)
            if cfg.progressive_cooldown:
                # Increase cooldown for repeated vetos
                veto_count = len(recent_vetos)
                cooldown_duration = cfg.veto_cooldown_sec * (cfg.decay_factor ** (veto_count - 1))
                cooldown_duration = max(cooldown_duration, cfg.veto_cooldown_sec / 4)
            else:
                cooldown_duration = cfg.veto_cooldown_sec
            
            if now - last_veto_ts < cooldown_duration:
                return True, last_reason
            
            return False, None
    
    def _record_veto(self, symbol: str, reason: str):
        """Record a veto for cooldown tracking."""
        with self._lock:
            self._veto_history.append((_now(), symbol, reason))
            
            # Keep only recent history
            cutoff = _now() - 3600  # Keep last hour
            self._veto_history = [(ts, sym, r) for ts, sym, r in self._veto_history if ts > cutoff]
    
    def _calculate_confidence(self, reasons: List[str], rule_results: Dict[str, Tuple[bool, float, float]]) -> float:
        """Calculate confidence score based on rule results and reasons."""
        if not reasons:
            # No issues detected, high confidence
            return 0.8
        
        # Base confidence
        confidence = 0.5
        
        # Adjust based on number and severity of issues
        warning_count = sum(1 for r in reasons if "warning" in r.lower() or "near" in r.lower())
        critical_count = sum(1 for r in reasons if "critical" in r.lower() or "veto" in r.lower())
        
        # Reduce confidence for warnings
        confidence -= warning_count * 0.05
        
        # Reduce more for critical issues (if not vetoed)
        confidence -= critical_count * 0.15
        
        # Adjust based on rule agreement
        if rule_results:
            allowed_rules = sum(1 for allow, _, _ in rule_results.values() if allow)
            total_rules = len(rule_results)
            rule_agreement = allowed_rules / total_rules if total_rules > 0 else 1.0
            confidence *= (0.3 + 0.7 * rule_agreement)  # Weight rule agreement
        
        return _clamp(confidence, 0.2, 0.95)
    
    def _apply_position_management(self, ctx: TradeContext, score_mult: float, risk_mult: float, 
                                 reasons: List[str]) -> Tuple[float, float, List[str]]:
        """Apply position management adjustments."""
        cfg = self.config.position_mgmt
        
        if not cfg.pnl_adjustment_enabled:
            return score_mult, risk_mult, reasons
        
        # Adjust based on drawdown
        max_drawdown = _f(ctx.get("max_drawdown"), 0.0)
        if max_drawdown > 0.1:  # >10% drawdown
            drawdown_ratio = _clamp(max_drawdown / 0.5, 0.0, 1.0)  # Cap at 50% drawdown
            penalty = drawdown_ratio * cfg.max_drawdown_multiplier
            risk_mult *= (1.0 - penalty)
            if penalty > 0.2:
                reasons.append(f"high_drawdown:{max_drawdown:.2f}")
        
        # Adjust based on win rate
        win_rate = _f(ctx.get("win_rate"), 0.5)
        if win_rate > 0.6:  # >60% win rate
            bonus = (win_rate - 0.6) / 0.4  # 0 to 1 as win rate goes from 0.6 to 1.0
            confidence_mult = 1.0 + bonus * (cfg.win_rate_multiplier - 1.0)
            # Win rate affects confidence, not directly score/risk
        
        # Adjust based on correlation
        if cfg.correlation_penalty_enabled:
            correlation = ctx.get("correlation", {})
            if isinstance(correlation, dict):
                avg_correlation = np.mean(list(correlation.values())) if correlation else 0.0
                if avg_correlation > cfg.max_correlation:
                    excess = (avg_correlation - cfg.max_correlation) / (1.0 - cfg.max_correlation)
                    penalty = _clamp(excess, 0.0, 1.0)
                    risk_mult *= (1.0 - penalty * 0.3)
                    if penalty > 0.3:
                        reasons.append(f"high_correlation:{avg_correlation:.2f}")
        
        # Adjust based on Sharpe ratio
        if cfg.sharpe_adjustment_enabled:
            sharpe = _f(ctx.get("sharpe_ratio"), 1.0)
            if sharpe < cfg.min_sharpe_ratio:
                ratio = sharpe / cfg.min_sharpe_ratio
                risk_mult *= ratio
                if ratio < 0.7:
                    reasons.append(f"low_sharpe:{sharpe:.2f}")
        
        return score_mult, risk_mult, reasons
    
    def advise(self, ctx: TradeContext) -> AdviceResult:
        """
        Main advice method.
        
        Args:
            ctx: Trading context dictionary
        
        Returns:
            AdviceResult with recommendations
        """
        start_time = _now()
        symbol = ctx.get("symbol", "unknown")
        
        try:
            # Check if advisor is enabled
            if not self.enabled:
                result = self._neutral("advisor_disabled")
                result["meta"]["processing_time_ms"] = (_now() - start_time) * 1000
                return result
            
            # Check cache
            if self.config.enable_caching:
                cached = self._cache.get(ctx)
                if cached is not None:
                    self._metrics.record_decision(symbol, cached["allow_entries"], 
                                                 _now() - start_time, cached["reason"], 
                                                 cached.get("confidence", 0.5))
                    return cached
            
            # Check cooldown
            in_cooldown, cooldown_reason = self._check_cooldown(symbol)
            if in_cooldown:
                result = {
                    "allow_entries": False,
                    "score_mult": 0.0,
                    "risk_mult": 0.0,
                    "sentiment_score": 0.0,
                    "confidence": 0.95,
                    "reason": "cooldown_active",
                    "reasons": [cooldown_reason or "cooldown"],
                    "meta": {
                        "cooldown_reason": cooldown_reason,
                        "symbol": symbol
                    }
                }
                
                # Apply clamping
                result = self._apply_clamping(result)
                result["meta"]["processing_time_ms"] = (_now() - start_time) * 1000
                
                # Cache and record
                if self.config.enable_caching:
                    self._cache.set(ctx, result)
                self._metrics.record_decision(symbol, False, _now() - start_time, 
                                             "cooldown", result["confidence"])
                
                self.logger.log(LogLevel.INFO, "cooldown_active", {
                    "symbol": symbol,
                    "reason": cooldown_reason
                }, symbol)
                
                return result
            
            # Execute rules
            allow_entries = True
            final_score_mult = 1.0
            final_risk_mult = 1.0
            all_reasons = []
            rule_results = {}
            
            for rule in self._rules:
                if not rule.enabled:
                    continue
                
                try:
                    rule_allow, rule_score, rule_risk, rule_reasons = rule.evaluate(ctx, self.config)
                    
                    # Store rule result
                    rule_results[rule.name] = (rule_allow, rule_score, rule_risk)
                    
                    # Update overall result
                    if not rule_allow:
                        allow_entries = False
                    
                    # Apply rule multipliers with weighting
                    weight = rule.weight
                    weighted_score = (rule_score ** weight) * (final_score_mult ** (1 - weight))
                    weighted_risk = (rule_risk ** weight) * (final_risk_mult ** (1 - weight))
                    
                    final_score_mult = weighted_score
                    final_risk_mult = weighted_risk
                    
                    all_reasons.extend(rule_reasons)
                    
                    # If rule vetoed, we can break early
                    if not rule_allow:
                        self._record_veto(symbol, f"rule_veto:{rule.name}")
                        break
                        
                except Exception as e:
                    self.logger.log(LogLevel.ERROR, "rule_evaluation_error", {
                        "rule": rule.name,
                        "error": str(e)
                    }, symbol)
            
            # Apply position management adjustments
            final_score_mult, final_risk_mult, pm_reasons = self._apply_position_management(
                ctx, final_score_mult, final_risk_mult, all_reasons
            )
            all_reasons.extend(pm_reasons)
            
            # Calculate confidence
            confidence = self._calculate_confidence(all_reasons, rule_results)
            
            # Determine final reason
            if not allow_entries:
                final_reason = "local_veto"
                if all_reasons:
                    # Use the first veto reason
                    for reason in all_reasons:
                        if "veto" in reason:
                            final_reason = reason.split(":")[0] if ":" in reason else reason
                            break
            elif all_reasons:
                final_reason = "local_warnings"
            else:
                final_reason = "local_ok"
            
            # Prepare result
            result: AdviceResult = {
                "allow_entries": allow_entries,
                "score_mult": float(final_score_mult),
                "risk_mult": float(final_risk_mult),
                "sentiment_score": 0.0,  # Local advisor doesn't provide sentiment
                "confidence": float(confidence),
                "reason": final_reason,
                "reasons": all_reasons[:10],  # Limit reasons
                "meta": {
                    "symbol": symbol,
                    "timestamp": _now(),
                    "rules_evaluated": len(rule_results),
                    "rule_results": {name: {"allow": allow, "score": score, "risk": risk} 
                                    for name, (allow, score, risk) in rule_results.items()}
                }
            }
            
            # Apply clamping
            result = self._apply_clamping(result)
            result["meta"]["processing_time_ms"] = (_now() - start_time) * 1000
            
            # Cache result
            if self.config.enable_caching:
                self._cache.set(ctx, result)
            
            # Store last advice
            self._last_advice[symbol] = result
            
            # Record metrics
            self._metrics.record_decision(symbol, allow_entries, _now() - start_time, 
                                         final_reason, confidence)
            
            # Log the decision
            log_level = LogLevel.WARNING if not allow_entries else LogLevel.INFO
            self.logger.log(log_level, "advice_generated", {
                "allow_entries": allow_entries,
                "score_mult": result["score_mult"],
                "risk_mult": result["risk_mult"],
                "confidence": result["confidence"],
                "reason": result["reason"],
                "reasons_count": len(all_reasons)
            }, symbol)
            
            return result
            
        except Exception as e:
            # Error handling - return neutral advice
            processing_time = (_now() - start_time) * 1000
            self._metrics.record_error()
            
            self.logger.log(LogLevel.ERROR, "advice_error", {
                "symbol": symbol,
                "error": str(e),
                "processing_time_ms": processing_time
            }, symbol)
            
            result = self._neutral(f"error: {type(e).__name__}")
            result["meta"]["error"] = str(e)
            result["meta"]["processing_time_ms"] = processing_time
            
            return result
    
    def _apply_clamping(self, result: AdviceResult) -> AdviceResult:
        """Apply clamping to output values."""
        cfg = self.config.clamping
        
        if cfg.smooth_transitions:
            # Use smooth transitions instead of hard clamps
            result["score_mult"] = _clamp(result["score_mult"], 
                                         cfg.score_mult_min * 0.8, 
                                         cfg.score_mult_max * 1.2)
            result["score_mult"] = _smooth_step(
                result["score_mult"], 
                cfg.score_mult_min, 
                cfg.score_mult_max
            )
            
            result["risk_mult"] = _clamp(result["risk_mult"],
                                        cfg.risk_mult_min * 0.8,
                                        cfg.risk_mult_max * 1.2)
            result["risk_mult"] = _smooth_step(
                result["risk_mult"],
                cfg.risk_mult_min,
                cfg.risk_mult_max
            )
        else:
            # Hard clamps
            result["score_mult"] = _clamp(result["score_mult"], 
                                         cfg.score_mult_min, 
                                         cfg.score_mult_max)
            result["risk_mult"] = _clamp(result["risk_mult"],
                                        cfg.risk_mult_min,
                                        cfg.risk_mult_max)
        
        # Clamp confidence
        result["confidence"] = _clamp(result["confidence"],
                                     cfg.confidence_min,
                                     cfg.confidence_max)
        
        return result
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get advisor metrics."""
        metrics = self._metrics.get_summary()
        metrics["cache"] = self._cache.get_stats()
        metrics["veto_history_count"] = len(self._veto_history)
        metrics["last_advice_count"] = len(self._last_advice)
        return metrics
    
    def clear_cache(self):
        """Clear the advice cache."""
        self._cache.clear()
        self.logger.log(LogLevel.INFO, "cache_cleared", {})
    
    def clear_veto_history(self, symbol: Optional[str] = None):
        """Clear veto history for a symbol or all symbols."""
        with self._lock:
            if symbol:
                self._veto_history = [(ts, sym, r) for ts, sym, r in self._veto_history if sym != symbol]
                self.logger.log(LogLevel.INFO, "veto_history_cleared", {"symbol": symbol})
            else:
                self._veto_history.clear()
                self.logger.log(LogLevel.INFO, "veto_history_cleared_all", {})
    
    def add_custom_rule(self, rule_func: Callable, name: str, enabled: bool = True, weight: float = 1.0):
        """Add a custom rule to the advisor."""
        class CustomRule(Rule):
            def __init__(self):
                super().__init__(name, enabled, weight)
                self.func = rule_func
            
            def evaluate(self, ctx, config):
                return self.func(ctx, config)
        
        self._rules.append(CustomRule())
        self.logger.log(LogLevel.INFO, "custom_rule_added", {"name": name, "enabled": enabled, "weight": weight})
    
    def update_config(self, new_config: LocalAdvisorConfig):
        """Update configuration dynamically."""
        old_enabled = self.config.enabled
        self.config = new_config
        
        # Reinitialize rules if configuration changed significantly
        self._initialize_rules()
        
        # Update cache TTL
        self._cache.ttl = new_config.cache_ttl_sec
        
        # Log config update
        self.logger.log(LogLevel.INFO, "config_updated", {
            "old_enabled": old_enabled,
            "new_enabled": new_config.enabled,
            "changes": self._get_config_summary()
        })
    
    def get_last_advice(self, symbol: str) -> Optional[AdviceResult]:
        """Get the last advice for a symbol."""
        return self._last_advice.get(symbol)


# ============================================================================
# Factory Function for Backward Compatibility
# ============================================================================

def from_cfg(cfg: Dict[str, Any], log: Optional[Any] = None) -> LocalAdvisor:
    """
    Factory function for backward compatibility.
    
    Args:
        cfg: Configuration dictionary
        log: Logger object
    
    Returns:
        LocalAdvisor instance
    """
    # Parse configuration
    llm_cfg = cfg.get("llm", {}) or {}
    local_cfg = llm_cfg.get("local", {}) or {}
    
    # Create logger
    logger = StructuredLogger(
        min_level=LogLevel.INFO,
        log_callback=log
    )
    
    # Build configuration
    config = LocalAdvisorConfig(
        enabled=_b(local_cfg.get("enabled"), False),
        name="local_advisor",
        
        liquidity=LiquidityConfig(
            min_liquidity_usd=_f(local_cfg.get("min_liquidity_usd"), 2_000_000.0),
            warning_threshold_frac=_f(local_cfg.get("soft_liquidity_zone_frac"), 0.15),
            critical_threshold_frac=0.05,
        ),
        
        spread=SpreadConfig(
            max_spread_bps=_f(local_cfg.get("max_spread_bps"), 40.0),
            warning_threshold_bps=_f(local_cfg.get("soft_spread_zone_bps"), 5.0),
            critical_threshold_bps=2.0,
        ),
        
        volatility=VolatilityConfig(
            max_atr_pct=_f(local_cfg.get("max_atr_pct"), 0.06),
            atr_veto_mode=VetoMode(local_cfg.get("atr_veto_mode", "hybrid")),
            soft_start_frac=_f(local_cfg.get("atr_soft_start_frac"), 0.60),
            score_penalty=_f(local_cfg.get("atr_score_penalty"), 0.60),
            risk_penalty=_f(local_cfg.get("atr_risk_penalty"), 0.50),
            extreme_multiplier=1.25,
        ),
        
        funding=FundingConfig(
            veto_abs=_f(local_cfg.get("funding_veto_abs"), 0.003),
            warning_abs=0.002,
        ),
        
        trend=TrendConfig(
            enable_trend_filter=True,
            against_trend_score_mult=_f(local_cfg.get("against_trend_score_mult"), 0.92),
            against_trend_risk_mult=_f(local_cfg.get("against_trend_risk_mult"), 0.90),
        ),
        
        regime=RegimeConfig(
            risk_off_score_mult=_f(local_cfg.get("risk_off_score_mult"), 0.90),
            risk_off_risk_mult=_f(local_cfg.get("risk_off_risk_mult"), 0.85),
            panic_score_mult=0.70,
            panic_risk_mult=0.60,
            bull_score_mult=1.05,
            bull_risk_mult=1.02,
        ),
        
        cooldown=CooldownConfig(
            veto_cooldown_sec=_i(local_cfg.get("veto_cooldown_sec"), 45),
            warning_cooldown_sec=15,
            progressive_cooldown=True,
        ),
        
        clamping=ClampingConfig(
            score_mult_min=_f(local_cfg.get("score_mult_min"), _f(llm_cfg.get("score_mult_min", 0.60))),
            score_mult_max=_f(local_cfg.get("score_mult_max"), 1.25),
            risk_mult_min=_f(local_cfg.get("risk_mult_min"), _f(llm_cfg.get("risk_mult_min", 0.60))),
            risk_mult_max=_f(local_cfg.get("risk_mult_max"), 1.10),
        ),
        
        enable_caching=True,
        cache_ttl_sec=5.0,
        log_level=LogLevel.INFO,
    )
    
    # Create advisor
    advisor = LocalAdvisor(config=config, logger=logger)
    
    return advisor


# ============================================================================
# Test Functions
# ============================================================================

def test_local_advisor():
    """Test the local advisor."""
    
    # Create advisor with default config
    config = LocalAdvisorConfig(
        enabled=True,
        name="test_advisor"
    )
    
    logger = StructuredLogger(min_level=LogLevel.DEBUG)
    advisor = LocalAdvisor(config=config, logger=logger)
    
    # Test 1: Normal conditions
    print("Test 1: Normal conditions")
    ctx1: TradeContext = {
        "symbol": "BTCUSDT",
        "side": "LONG",
        "atr_pct": 0.02,
        "spread_bps": 10.0,
        "volume_usd": 10_000_000.0,
        "funding_rate": 0.0001,
        "market_regime": "range",
        "trend_dir": 0.5,
    }
    
    result1 = advisor.advise(ctx1)
    assert result1["allow_entries"] == True, "Should allow in normal conditions"
    assert result1["score_mult"] > 0.9, "Score should be near 1.0"
    print(f"✓ Normal conditions: {result1['reason']}")
    
    # Test 2: High volatility
    print("\nTest 2: High volatility")
    ctx2: TradeContext = {
        "symbol": "ETHUSDT",
        "side": "SHORT",
        "atr_pct": 0.08,  # Above max (0.06)
        "spread_bps": 15.0,
        "volume_usd": 5_000_000.0,
        "funding_rate": -0.0005,
    }
    
    result2 = advisor.advise(ctx2)
    # Should veto or significantly derisk
    if result2["allow_entries"]:
        assert result2["score_mult"] < 0.8, "Should derisk for high volatility"
    print(f"✓ High volatility: {result2['reason']}")
    
    # Test 3: Low liquidity
    print("\nTest 3: Low liquidity")
    ctx3: TradeContext = {
        "symbol": "XRPUSDT",
        "side": "LONG",
        "atr_pct": 0.03,
        "spread_bps": 20.0,
        "volume_usd": 500_000.0,  # Below minimum
        "funding_rate": 0.0002,
    }
    
    result3 = advisor.advise(ctx3)
    assert result3["allow_entries"] == False, "Should veto for low liquidity"
    print(f"✓ Low liquidity: {result3['reason']}")
    
    # Test 4: High spread
    print("\nTest 4: High spread")
    ctx4: TradeContext = {
        "symbol": "SOLUSDT",
        "side": "SHORT",
        "atr_pct": 0.04,
        "spread_bps": 45.0,  # Above max (40.0)
        "volume_usd": 3_000_000.0,
        "funding_rate": -0.001,
    }
    
    result4 = advisor.advise(ctx4)
    assert result4["allow_entries"] == False, "Should veto for high spread"
    print(f"✓ High spread: {result4['reason']}")
    
    # Test 5: Against trend
    print("\nTest 5: Against trend")
    ctx5: TradeContext = {
        "symbol": "ADAUSDT",
        "side": "SHORT",
        "atr_pct": 0.025,
        "spread_bps": 12.0,
        "volume_usd": 4_000_000.0,
        "funding_rate": 0.0003,
        "trend_dir": 0.8,  # Strong uptrend
    }
    
    result5 = advisor.advise(ctx5)
    if result5["allow_entries"]:
        assert result5["score_mult"] < 1.0, "Should derisk when against trend"
    print(f"✓ Against trend: {result5['reason']}")
    
    # Test metrics
    print("\nTest metrics:")
    metrics = advisor.get_metrics()
    print(f"Total decisions: {metrics['total_decisions']}")
    print(f"Veto rate: {metrics['veto_rate']:.2%}")
    print(f"Average processing time: {metrics['avg_processing_time_ms']:.2f}ms")
    
    print("\n✅ All tests passed!")
    return True


if __name__ == "__main__":
    # Run tests if module is executed directly
    test_passed = test_local_advisor()
    if test_passed:
        print("\n🎉 Local advisor module is working correctly!")
from __future__ import annotations

import os
import json
import sqlite3
import time
import datetime
import math
import threading
import contextlib
from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, List, Tuple, Iterator, Union, Callable
from enum import Enum
from pathlib import Path
import logging

# Configure logger
logger = logging.getLogger(__name__)


def _now() -> float:
    return time.time()


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        v = float(x)
        return v if math.isfinite(v) else float(default)
    except Exception:
        return float(default)


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return int(default)


def _safe_str(x: Any, default: str = "") -> str:
    try:
        return str(x)
    except Exception:
        return default


def _sanitize_jsonable(x: Any) -> Any:
    """Make data JSON-safe: remove NaN/Inf, handle dataclasses/sets/objects."""
    try:
        if x is None or isinstance(x, (bool, int, str)):
            return x
        if isinstance(x, float):
            return x if math.isfinite(x) else None
        if isinstance(x, (list, tuple)):
            return [_sanitize_jsonable(v) for v in x]
        if isinstance(x, set):
            return [_sanitize_jsonable(v) for v in list(x)]
        if isinstance(x, dict):
            return {str(k): _sanitize_jsonable(v) for k, v in x.items()}
        if is_dataclass(x):
            return _sanitize_jsonable(asdict(x))
        if hasattr(x, "to_dict") and callable(getattr(x, "to_dict")):
            return _sanitize_jsonable(x.to_dict())
        if hasattr(x, "as_dict") and callable(getattr(x, "as_dict")):
            return _sanitize_jsonable(x.as_dict())
        if hasattr(x, "__dict__"):
            return _sanitize_jsonable(dict(x.__dict__))
        # numpy/pandas scalar
        if hasattr(x, "item") and callable(getattr(x, "item")):
            try:
                return _sanitize_jsonable(x.item())
            except Exception:
                pass
        return repr(x)
    except Exception as e:
        logger.debug(f"Failed to sanitize object: {e}")
        return repr(x)


class MigrationError(Exception):
    """Exception raised for migration errors."""
    pass


class TableName(str, Enum):
    """Enum for table names to prevent typos."""
    EVENTS = "events"
    TRADES = "trades"
    SIGNALS = "signals"
    SNAPSHOTS = "snapshots"
    DECISIONS = "decisions"
    ORDERS = "orders"
    POSITIONS = "positions"
    PERFORMANCE = "performance"


class SQLiteStore:
    """Enhanced SQLite persistence layer for events/trades/signals/snapshots/decisions.

    Major Improvements:
      - Connection pooling with connection factory
      - Async support with async context manager
      - Comprehensive migrations system with versioning
      - Enhanced indexing and query optimization
      - Bulk operations for better performance
      - Backup and restore functionality
      - Transaction management with savepoints
      - Metrics collection for performance monitoring
      - Extended schema with orders, positions, and performance tables
      - Better error handling and logging
      - Configurable WAL mode and optimization
    """

    VERSION = 2  # Schema version

    def __init__(
        self,
        path: Union[str, Path],
        *,
        sqlite_timeout_sec: float = 10.0,
        busy_timeout_ms: int = 3000,
        retry_attempts: int = 5,
        retry_base_sleep: float = 0.05,
        pool_size: int = 1,
        wal_mode: bool = True,
        optimize_on_close: bool = True,
        enable_metrics: bool = True,
        **kwargs,
    ):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

        self._conn_pool: List[sqlite3.Connection] = []
        self._pool_size = max(1, pool_size)
        self._pool_lock = threading.RLock()
        
        self._config = {
            "timeout": float(sqlite_timeout_sec),
            "busy_timeout_ms": int(busy_timeout_ms),
            "retry_attempts": max(1, int(retry_attempts)),
            "retry_base_sleep": float(retry_base_sleep),
            "wal_mode": wal_mode,
            "optimize_on_close": optimize_on_close,
            "enable_metrics": enable_metrics,
        }
        
        self._metrics: Dict[str, Any] = {
            "queries": 0,
            "errors": 0,
            "transaction_count": 0,
            "bulk_inserts": 0,
            "avg_query_time": 0.0,
        }
        
        self._init_pool()
        self._run_migrations()
        
        logger.info(f"SQLiteStore initialized at {self.path} (version {self.VERSION})")

    def __enter__(self) -> "SQLiteStore":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    async def __aenter__(self) -> "SQLiteStore":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        self.close()

    # ---------------------------
    # Connection Pool Management
    # ---------------------------
    def _init_pool(self) -> None:
        """Initialize the connection pool."""
        for _ in range(self._pool_size):
            conn = self._create_connection()
            self._conn_pool.append(conn)

    def _create_connection(self) -> sqlite3.Connection:
        """Create a new database connection."""
        conn = sqlite3.connect(
            str(self.path),
            timeout=self._config["timeout"],
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        
        # Apply pragmas
        cur = conn.cursor()
        if self._config["wal_mode"]:
            cur.execute("PRAGMA journal_mode=WAL;")
        cur.execute(f"PRAGMA busy_timeout={self._config['busy_timeout_ms']};")
        cur.execute("PRAGMA synchronous=NORMAL;")
        cur.execute("PRAGMA temp_store=MEMORY;")
        cur.execute("PRAGMA foreign_keys=ON;")
        conn.commit()
        
        return conn

    @contextlib.contextmanager
    def _get_connection(self) -> Iterator[sqlite3.Connection]:
        """Context manager to get a connection from the pool."""
        with self._pool_lock:
            if not self._conn_pool:
                conn = self._create_connection()
                yield conn
                conn.close()
            else:
                conn = self._conn_pool.pop()
                try:
                    yield conn
                finally:
                    self._conn_pool.append(conn)

    # ---------------------------
    # Migrations System
    # ---------------------------
    def _run_migrations(self) -> None:
        """Run database migrations."""
        with self._get_connection() as conn:
            cur = conn.cursor()
            
            # Create migrations table if it doesn't exist
            cur.execute("""
                CREATE TABLE IF NOT EXISTS _migrations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    version INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Get current version
            cur.execute("SELECT MAX(version) as max_version FROM _migrations")
            row = cur.fetchone()
            current_version = row["max_version"] if row and row["max_version"] else 0
            
            # Run migrations
            if current_version < self.VERSION:
                logger.info(f"Running migrations from version {current_version} to {self.VERSION}")
                self._apply_migrations(conn, current_version)
                conn.commit()
    
    def _apply_migrations(self, conn: sqlite3.Connection, from_version: int) -> None:
        """Apply migrations sequentially."""
        migrations = [
            (1, self._migration_v1),
            (2, self._migration_v2),
        ]
        
        for version, migration_func in migrations:
            if version > from_version and version <= self.VERSION:
                try:
                    logger.info(f"Applying migration v{version}")
                    migration_func(conn)
                    
                    # Record migration
                    cur = conn.cursor()
                    cur.execute(
                        "INSERT INTO _migrations (version, name) VALUES (?, ?)",
                        (version, migration_func.__name__)
                    )
                except Exception as e:
                    logger.error(f"Migration v{version} failed: {e}")
                    raise MigrationError(f"Migration v{version} failed") from e
    
    def _migration_v1(self, conn: sqlite3.Connection) -> None:
        """Initial schema creation."""
        cur = conn.cursor()
        
        # Original tables
        cur.execute("""
            CREATE TABLE IF NOT EXISTS events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL NOT NULL,
              level TEXT NOT NULL,
              type TEXT NOT NULL,
              message TEXT NOT NULL,
              meta_json TEXT
            )
        """)
        
        cur.execute("""
            CREATE TABLE IF NOT EXISTS trades(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts TEXT NOT NULL,
              exchange TEXT NOT NULL,
              mode TEXT NOT NULL,
              symbol TEXT NOT NULL,
              side TEXT NOT NULL,
              qty REAL NOT NULL,
              price REAL NOT NULL,
              notional REAL NOT NULL,
              fee REAL NOT NULL,
              realized_pnl REAL NOT NULL,
              reason TEXT,
              meta_json TEXT,
              ts_epoch REAL DEFAULT 0
            )
        """)
        
        cur.execute("""
            CREATE TABLE IF NOT EXISTS signals(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              created_ts REAL NOT NULL,
              symbol TEXT NOT NULL,
              action TEXT NOT NULL,
              strength REAL NOT NULL,
              reason TEXT,
              approval_id TEXT,
              status TEXT NOT NULL,
              meta_json TEXT
            )
        """)
        
        cur.execute("""
            CREATE TABLE IF NOT EXISTS snapshots(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL NOT NULL,
              equity REAL NOT NULL,
              open_positions INTEGER NOT NULL,
              pending_orders INTEGER NOT NULL,
              meta_json TEXT
            )
        """)
        
        cur.execute("""
            CREATE TABLE IF NOT EXISTS decisions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL NOT NULL,
              symbol TEXT,
              dtype TEXT NOT NULL,
              payload_json TEXT
            )
        """)
        
        # Create indexes
        cur.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_trades_ts_epoch ON trades(ts_epoch);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_signals_created_ts ON signals(created_ts);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_decisions_ts ON decisions(ts);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_decisions_dtype ON decisions(dtype);")
    
    def _migration_v2(self, conn: sqlite3.Connection) -> None:
        """Add orders, positions, and performance tables."""
        cur = conn.cursor()
        
        # Orders table (for tracking order lifecycle)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS orders(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              order_id TEXT NOT NULL UNIQUE,
              client_order_id TEXT,
              exchange TEXT NOT NULL,
              symbol TEXT NOT NULL,
              side TEXT NOT NULL,
              order_type TEXT NOT NULL,
              quantity REAL NOT NULL,
              price REAL,
              filled_quantity REAL DEFAULT 0,
              avg_fill_price REAL,
              status TEXT NOT NULL,
              created_ts REAL NOT NULL,
              updated_ts REAL NOT NULL,
              reason TEXT,
              meta_json TEXT
            )
        """)
        
        # Positions table (current positions)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS positions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              exchange TEXT NOT NULL,
              symbol TEXT NOT NULL,
              side TEXT NOT NULL,
              quantity REAL NOT NULL,
              avg_entry_price REAL NOT NULL,
              current_price REAL,
              unrealized_pnl REAL,
              realized_pnl REAL DEFAULT 0,
              leverage REAL DEFAULT 1,
              created_ts REAL NOT NULL,
              updated_ts REAL NOT NULL,
              meta_json TEXT,
              UNIQUE(exchange, symbol, side)
            )
        """)
        
        # Performance metrics table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS performance(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL NOT NULL,
              period TEXT NOT NULL,
              total_trades INTEGER DEFAULT 0,
              winning_trades INTEGER DEFAULT 0,
              losing_trades INTEGER DEFAULT 0,
              win_rate REAL DEFAULT 0,
              total_pnl REAL DEFAULT 0,
              avg_win REAL DEFAULT 0,
              avg_loss REAL DEFAULT 0,
              profit_factor REAL DEFAULT 0,
              max_drawdown REAL DEFAULT 0,
              sharpe_ratio REAL DEFAULT 0,
              sortino_ratio REAL DEFAULT 0,
              calmar_ratio REAL DEFAULT 0,
              meta_json TEXT
            )
        """)
        
        # Create additional indexes
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_orders_created_ts ON orders(created_ts);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_positions_symbol ON positions(symbol);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_performance_ts ON performance(ts);")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_performance_period ON performance(period);")

    # ---------------------------
    # Enhanced Exec with Metrics
    # ---------------------------
    def _exec(
        self,
        sql: str,
        params: Tuple[Any, ...] = (),
        *,
        commit: bool = False,
        fetch: bool = False,
        many: bool = False,
    ) -> Union[sqlite3.Cursor, List[Dict[str, Any]]]:
        """Execute SQL with retry, metrics, and error handling."""
        start_time = time.time()
        last_exc: Optional[Exception] = None
        
        for attempt in range(self._config["retry_attempts"]):
            try:
                with self._get_connection() as conn:
                    cur = conn.cursor()
                    
                    if many and params:
                        cur.executemany(sql, params)
                    else:
                        cur.execute(sql, params)
                    
                    if commit:
                        conn.commit()
                    
                    # Update metrics
                    self._metrics["queries"] += 1
                    query_time = time.time() - start_time
                    self._metrics["avg_query_time"] = (
                        (self._metrics["avg_query_time"] * (self._metrics["queries"] - 1) + query_time) 
                        / self._metrics["queries"]
                    )
                    
                    if fetch:
                        rows = cur.fetchall()
                        return [dict(r) for r in rows]
                    
                    return cur
                    
            except sqlite3.OperationalError as e:
                last_exc = e
                msg = str(e).lower()
                if "locked" in msg or "busy" in msg:
                    sleep_time = self._config["retry_base_sleep"] * (attempt + 1)
                    logger.debug(f"Database locked, retrying in {sleep_time}s (attempt {attempt + 1})")
                    time.sleep(sleep_time)
                    continue
                self._metrics["errors"] += 1
                logger.error(f"SQLite operational error: {e}")
                raise
            except sqlite3.Error as e:
                self._metrics["errors"] += 1
                logger.error(f"SQLite error: {e}")
                raise
            except Exception as e:
                self._metrics["errors"] += 1
                logger.error(f"Unexpected error during SQL execution: {e}")
                raise
        
        if last_exc:
            raise last_exc
        raise sqlite3.OperationalError("SQL execution failed after retries")

    # ---------------------------
    # Transaction Management
    # ---------------------------
    @contextlib.contextmanager
    def transaction(self, savepoint: Optional[str] = None) -> Iterator[None]:
        """Context manager for transactions with optional savepoints."""
        savepoint_name = savepoint or f"sp_{int(time.time() * 1000)}"
        
        with self._get_connection() as conn:
            cur = conn.cursor()
            
            try:
                if savepoint:
                    cur.execute(f"SAVEPOINT {savepoint_name}")
                else:
                    cur.execute("BEGIN TRANSACTION")
                
                self._metrics["transaction_count"] += 1
                
                yield
                
                if savepoint:
                    cur.execute(f"RELEASE SAVEPOINT {savepoint_name}")
                else:
                    conn.commit()
                    
            except Exception as e:
                if savepoint:
                    cur.execute(f"ROLLBACK TO SAVEPOINT {savepoint_name}")
                else:
                    conn.rollback()
                logger.error(f"Transaction failed: {e}")
                raise

    # ---------------------------
    # Data Conversion Utilities
    # ---------------------------
    def _j(self, d: Any) -> Optional[str]:
        """Convert data to JSON string."""
        if d is None:
            return None
        try:
            return json.dumps(_sanitize_jsonable(d), ensure_ascii=False, separators=(',', ':'))
        except Exception as e:
            logger.warning(f"Failed to serialize JSON: {e}")
            return None
    
    def _parse_json(self, json_str: Optional[str]) -> Any:
        """Parse JSON string back to Python object."""
        if json_str is None:
            return None
        try:
            return json.loads(json_str)
        except Exception as e:
            logger.warning(f"Failed to parse JSON: {e}")
            return None

    @staticmethod
    def _iso_to_epoch(ts: str) -> float:
        """Convert ISO timestamp to epoch seconds; returns 0.0 on failure."""
        try:
            s = str(ts).strip()
            if not s:
                return 0.0
            s = s.replace("Z", "+00:00")
            dt = datetime.datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            return float(dt.timestamp())
        except Exception:
            return 0.0
    
    @staticmethod
    def _epoch_to_iso(epoch: float) -> str:
        """Convert epoch seconds to ISO string."""
        try:
            dt = datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
            return dt.isoformat().replace("+00:00", "Z")
        except Exception:
            return ""

    # ---------------------------
    # CRUD Operations (Original)
    # ---------------------------
    def event(self, level: str, typ: str, message: str, meta: Any = None, *, commit: bool = True) -> int:
        """Log an event and return its ID."""
        cur = self._exec(
            "INSERT INTO events(ts,level,type,message,meta_json) VALUES(?,?,?,?,?)",
            (_now(), str(level), str(typ), str(message), self._j(meta)),
            commit=commit,
        )
        return cur.lastrowid or 0

    def trade(self, row: Dict[str, Any], meta: Any = None, *, commit: bool = True) -> int:
        """Record a trade and return its ID."""
        ts_txt = str(row.get("ts", "") or "")
        ts_epoch = self._iso_to_epoch(ts_txt)
        
        cur = self._exec(
            "INSERT INTO trades(ts,ts_epoch,exchange,mode,symbol,side,qty,price,notional,fee,realized_pnl,reason,meta_json) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                ts_txt,
                float(ts_epoch),
                str(row.get("exchange", "")),
                str(row.get("mode", "")),
                str(row.get("symbol", "")),
                str(row.get("side", "")),
                _safe_float(row.get("qty", 0.0)),
                _safe_float(row.get("price", 0.0)),
                _safe_float(row.get("notional", 0.0)),
                _safe_float(row.get("fee", 0.0)),
                _safe_float(row.get("realized_pnl", 0.0)),
                str(row.get("reason", "")),
                self._j(meta),
            ),
            commit=commit,
        )
        return cur.lastrowid or 0

    def signal(
        self,
        created_ts: float,
        symbol: str,
        action: str,
        strength: float,
        reason: str,
        approval_id: Optional[str],
        status: str,
        meta: Any = None,
        *,
        commit: bool = True,
    ) -> int:
        """Record a signal and return its ID."""
        cur = self._exec(
            "INSERT INTO signals(created_ts,symbol,action,strength,reason,approval_id,status,meta_json) VALUES(?,?,?,?,?,?,?,?)",
            (
                float(created_ts),
                str(symbol),
                str(action),
                _safe_float(strength),
                str(reason),
                approval_id,
                str(status),
                self._j(meta),
            ),
            commit=commit,
        )
        return cur.lastrowid or 0

    def snapshot(self, equity: float, open_positions: int, pending_orders: int, meta: Any = None, *, commit: bool = True) -> int:
        """Record a snapshot and return its ID."""
        cur = self._exec(
            "INSERT INTO snapshots(ts,equity,open_positions,pending_orders,meta_json) VALUES(?,?,?,?,?)",
            (_now(), _safe_float(equity), _safe_int(open_positions), _safe_int(pending_orders), self._j(meta)),
            commit=commit,
        )
        return cur.lastrowid or 0

    def decision(self, dtype: str, payload: Dict[str, Any], symbol: Optional[str] = None, *, commit: bool = True) -> int:
        """Record a decision and return its ID."""
        cur = self._exec(
            "INSERT INTO decisions(ts,symbol,dtype,payload_json) VALUES(?,?,?,?)",
            (_now(), symbol, str(dtype), self._j(payload)),
            commit=commit,
        )
        return cur.lastrowid or 0

    # ---------------------------
    # New CRUD Operations (Version 2)
    # ---------------------------
    def order(
        self,
        order_id: str,
        exchange: str,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        status: str,
        price: Optional[float] = None,
        client_order_id: Optional[str] = None,
        filled_quantity: float = 0.0,
        avg_fill_price: Optional[float] = None,
        reason: Optional[str] = None,
        meta: Any = None,
        *,
        commit: bool = True,
    ) -> int:
        """Record an order and return its ID."""
        now = _now()
        cur = self._exec(
            """
            INSERT INTO orders(
                order_id, client_order_id, exchange, symbol, side, order_type,
                quantity, price, filled_quantity, avg_fill_price, status,
                created_ts, updated_ts, reason, meta_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(order_id) DO UPDATE SET
                status=excluded.status,
                filled_quantity=excluded.filled_quantity,
                avg_fill_price=excluded.avg_fill_price,
                updated_ts=excluded.updated_ts,
                reason=excluded.reason,
                meta_json=excluded.meta_json
            """,
            (
                str(order_id),
                client_order_id,
                str(exchange),
                str(symbol),
                str(side),
                str(order_type),
                _safe_float(quantity),
                price,
                _safe_float(filled_quantity),
                avg_fill_price,
                str(status),
                now,
                now,
                reason,
                self._j(meta),
            ),
            commit=commit,
        )
        return cur.lastrowid or 0

    def position(
        self,
        exchange: str,
        symbol: str,
        side: str,
        quantity: float,
        avg_entry_price: float,
        current_price: Optional[float] = None,
        unrealized_pnl: Optional[float] = None,
        realized_pnl: float = 0.0,
        leverage: float = 1.0,
        meta: Any = None,
        *,
        commit: bool = True,
    ) -> int:
        """Record or update a position and return its ID."""
        now = _now()
        
        # Calculate unrealized PNL if not provided
        if unrealized_pnl is None and current_price is not None:
            if side.lower() == "long":
                unrealized_pnl = (current_price - avg_entry_price) * quantity
            else:  # short
                unrealized_pnl = (avg_entry_price - current_price) * quantity
        
        cur = self._exec(
            """
            INSERT INTO positions(
                exchange, symbol, side, quantity, avg_entry_price,
                current_price, unrealized_pnl, realized_pnl, leverage,
                created_ts, updated_ts, meta_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(exchange, symbol, side) DO UPDATE SET
                quantity=excluded.quantity,
                avg_entry_price=excluded.avg_entry_price,
                current_price=excluded.current_price,
                unrealized_pnl=excluded.unrealized_pnl,
                realized_pnl=excluded.realized_pnl,
                leverage=excluded.leverage,
                updated_ts=excluded.updated_ts,
                meta_json=excluded.meta_json
            """,
            (
                str(exchange),
                str(symbol),
                str(side),
                _safe_float(quantity),
                _safe_float(avg_entry_price),
                current_price,
                unrealized_pnl,
                _safe_float(realized_pnl),
                _safe_float(leverage),
                now,
                now,
                self._j(meta),
            ),
            commit=commit,
        )
        return cur.lastrowid or 0

    def performance(
        self,
        period: str,
        total_trades: int = 0,
        winning_trades: int = 0,
        losing_trades: int = 0,
        win_rate: float = 0.0,
        total_pnl: float = 0.0,
        avg_win: float = 0.0,
        avg_loss: float = 0.0,
        profit_factor: float = 0.0,
        max_drawdown: float = 0.0,
        sharpe_ratio: float = 0.0,
        sortino_ratio: float = 0.0,
        calmar_ratio: float = 0.0,
        meta: Any = None,
        *,
        commit: bool = True,
    ) -> int:
        """Record performance metrics and return its ID."""
        cur = self._exec(
            """
            INSERT INTO performance(
                ts, period, total_trades, winning_trades, losing_trades,
                win_rate, total_pnl, avg_win, avg_loss, profit_factor,
                max_drawdown, sharpe_ratio, sortino_ratio, calmar_ratio, meta_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                _now(),
                str(period),
                _safe_int(total_trades),
                _safe_int(winning_trades),
                _safe_int(losing_trades),
                _safe_float(win_rate),
                _safe_float(total_pnl),
                _safe_float(avg_win),
                _safe_float(avg_loss),
                _safe_float(profit_factor),
                _safe_float(max_drawdown),
                _safe_float(sharpe_ratio),
                _safe_float(sortino_ratio),
                _safe_float(calmar_ratio),
                self._j(meta),
            ),
            commit=commit,
        )
        return cur.lastrowid or 0

    # ---------------------------
    # Bulk Operations
    # ---------------------------
    def bulk_insert(self, table: TableName, data: List[Dict[str, Any]]) -> int:
        """Bulk insert multiple records."""
        if not data:
            return 0
        
        columns = list(data[0].keys())
        placeholders = ",".join(["?" for _ in columns])
        sql = f"INSERT INTO {table.value} ({','.join(columns)}) VALUES ({placeholders})"
        
        values = []
        for row in data:
            values.append(tuple(row.get(col, None) for col in columns))
        
        with self.transaction():
            cur = self._exec(sql, tuple(values), many=True, commit=False)
            self._metrics["bulk_inserts"] += 1
        
        return len(data)

    def bulk_update_trades(self, trades: List[Dict[str, Any]]) -> int:
        """Bulk update trades with ts_epoch calculation."""
        if not trades:
            return 0
        
        updated = 0
        with self.transaction():
            for trade in trades:
                ts_txt = str(trade.get("ts", "") or "")
                ts_epoch = self._iso_to_epoch(ts_txt)
                
                self._exec(
                    """
                    UPDATE trades 
                    SET ts_epoch = ?, exchange = ?, mode = ?, symbol = ?, side = ?,
                        qty = ?, price = ?, notional = ?, fee = ?, realized_pnl = ?, reason = ?
                    WHERE ts = ?
                    """,
                    (
                        float(ts_epoch),
                        str(trade.get("exchange", "")),
                        str(trade.get("mode", "")),
                        str(trade.get("symbol", "")),
                        str(trade.get("side", "")),
                        _safe_float(trade.get("qty", 0.0)),
                        _safe_float(trade.get("price", 0.0)),
                        _safe_float(trade.get("notional", 0.0)),
                        _safe_float(trade.get("fee", 0.0)),
                        _safe_float(trade.get("realized_pnl", 0.0)),
                        str(trade.get("reason", "")),
                        ts_txt,
                    ),
                    commit=False,
                )
                updated += 1
        
        return updated

    # ---------------------------
    # Enhanced Query Methods
    # ---------------------------
    def list_trades(
        self,
        limit: int = 200,
        since_ts: Optional[float] = None,
        symbol: Optional[str] = None,
        side: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List trades with filtering options."""
        limit = max(1, min(int(limit or 200), 5000))
        
        conditions = []
        params = []
        
        if since_ts is not None:
            conditions.append("ts_epoch >= ?")
            params.append(float(since_ts))
        
        if symbol:
            conditions.append("symbol = ?")
            params.append(str(symbol))
        
        if side:
            conditions.append("side = ?")
            params.append(str(side))
        
        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.append(limit)
        
        rows = self._exec(
            f"""
            SELECT ts, exchange, mode, symbol, side, qty, price, notional, fee, reason, realized_pnl
            FROM trades
            {where_clause}
            ORDER BY id DESC
            LIMIT ?
            """,
            tuple(params),
            fetch=True,
        )
        
        return rows

    def get_trade_stats(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Get trade statistics."""
        conditions = []
        params = []
        
        if symbol:
            conditions.append("symbol = ?")
            params.append(str(symbol))
        
        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        
        rows = self._exec(
            f"""
            SELECT 
                COUNT(*) as total_trades,
                SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as winning_trades,
                SUM(CASE WHEN realized_pnl < 0 THEN 1 ELSE 0 END) as losing_trades,
                SUM(realized_pnl) as total_pnl,
                AVG(CASE WHEN realized_pnl > 0 THEN realized_pnl END) as avg_win,
                AVG(CASE WHEN realized_pnl < 0 THEN realized_pnl END) as avg_loss,
                SUM(fee) as total_fees
            FROM trades
            {where_clause}
            """,
            tuple(params),
            fetch=True,
        )
        
        if rows:
            stats = rows[0]
            win_rate = (stats["winning_trades"] / stats["total_trades"] * 100) if stats["total_trades"] > 0 else 0
            profit_factor = abs(stats["avg_win"] / stats["avg_loss"]) if stats["avg_loss"] else float('inf')
            
            return {
                "total_trades": stats["total_trades"],
                "winning_trades": stats["winning_trades"],
                "losing_trades": stats["losing_trades"],
                "win_rate": win_rate,
                "total_pnl": stats["total_pnl"],
                "avg_win": stats["avg_win"],
                "avg_loss": stats["avg_loss"],
                "profit_factor": profit_factor,
                "total_fees": stats["total_fees"],
            }
        
        return {}

    def list_orders(
        self,
        status: Optional[str] = None,
        symbol: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List orders with filtering."""
        conditions = []
        params = []
        
        if status:
            conditions.append("status = ?")
            params.append(str(status))
        
        if symbol:
            conditions.append("symbol = ?")
            params.append(str(symbol))
        
        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.append(min(limit, 1000))
        
        rows = self._exec(
            f"""
            SELECT *
            FROM orders
            {where_clause}
            ORDER BY created_ts DESC
            LIMIT ?
            """,
            tuple(params),
            fetch=True,
        )
        
        # Parse JSON fields
        for row in rows:
            if "meta_json" in row:
                row["meta"] = self._parse_json(row["meta_json"])
                del row["meta_json"]
        
        return rows

    def list_positions(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """List current positions."""
        conditions = []
        params = []
        
        if symbol:
            conditions.append("symbol = ?")
            params.append(str(symbol))
        
        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        
        rows = self._exec(
            f"""
            SELECT *
            FROM positions
            {where_clause}
            ORDER BY updated_ts DESC
            """,
            tuple(params),
            fetch=True,
        )
        
        # Parse JSON fields
        for row in rows:
            if "meta_json" in row:
                row["meta"] = self._parse_json(row["meta_json"])
                del row["meta_json"]
        
        return rows

    # ---------------------------
    # Advanced Queries
    # ---------------------------
    def get_daily_performance(self, days: int = 30) -> List[Dict[str, Any]]:
        """Get daily performance metrics."""
        rows = self._exec(
            """
            SELECT 
                DATE(datetime(ts_epoch, 'unixepoch')) as date,
                COUNT(*) as trades,
                SUM(realized_pnl) as pnl,
                SUM(fee) as fees,
                SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
                SUM(CASE WHEN realized_pnl < 0 THEN 1 ELSE 0 END) as losses
            FROM trades
            WHERE ts_epoch >= strftime('%s', date('now', ?))
            GROUP BY date
            ORDER BY date DESC
            """,
            (f"-{days} days",),
            fetch=True,
        )
        return rows

    def get_symbol_performance(self, top_n: int = 10) -> List[Dict[str, Any]]:
        """Get performance by symbol."""
        rows = self._exec(
            """
            SELECT 
                symbol,
                COUNT(*) as trades,
                SUM(realized_pnl) as total_pnl,
                AVG(realized_pnl) as avg_pnl,
                SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) as wins,
                SUM(CASE WHEN realized_pnl < 0 THEN 1 ELSE 0 END) as losses,
                (SUM(CASE WHEN realized_pnl > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) as win_rate
            FROM trades
            GROUP BY symbol
            ORDER BY total_pnl DESC
            LIMIT ?
            """,
            (top_n,),
            fetch=True,
        )
        return rows

    # ---------------------------
    # Export and Backup
    # ---------------------------
    def export_to_csv(self, table: TableName, path: Union[str, Path], limit: int = 100000) -> None:
        """Export table to CSV file."""
        import csv
        
        rows = self._exec(
            f"SELECT * FROM {table.value} ORDER BY id DESC LIMIT ?",
            (min(limit, 100000),),
            fetch=True,
        )
        
        if not rows:
            Path(path).write_text("")
            return
        
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    
    def backup(self, backup_path: Union[str, Path]) -> None:
        """Create a backup of the database."""
        backup_path = Path(backup_path)
        
        with self._get_connection() as conn:
            try:
                # Create backup connection
                backup_conn = sqlite3.connect(str(backup_path))
                
                # Use SQLite backup API
                conn.backup(backup_conn)
                backup_conn.close()
                
                logger.info(f"Database backed up to {backup_path}")
            except Exception as e:
                logger.error(f"Backup failed: {e}")
                raise
    
    def restore(self, backup_path: Union[str, Path]) -> None:
        """Restore database from backup."""
        backup_path = Path(backup_path)
        
        if not backup_path.exists():
            raise FileNotFoundError(f"Backup file not found: {backup_path}")
        
        # Close existing connections
        self.close()
        
        # Restore backup
        import shutil
        shutil.copy2(backup_path, self.path)
        
        # Reinitialize pool
        self._init_pool()
        
        logger.info(f"Database restored from {backup_path}")

    # ---------------------------
    # Maintenance and Utilities
    # ---------------------------
    def vacuum(self) -> None:
        """Vacuum the database to reclaim space."""
        with self._get_connection() as conn:
            conn.execute("VACUUM")
            logger.info("Database vacuum completed")
    
    def analyze(self) -> None:
        """Analyze database for query optimization."""
        with self._get_connection() as conn:
            conn.execute("ANALYZE")
            logger.info("Database analysis completed")
    
    def get_database_info(self) -> Dict[str, Any]:
        """Get database information and statistics."""
        info = {}
        
        with self._get_connection() as conn:
            cur = conn.cursor()
            
            # Table sizes
            cur.execute("""
                SELECT name, COUNT(*) as row_count
                FROM sqlite_master 
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
                GROUP BY name
                ORDER BY name
            """)
            
            tables = {}
            for row in cur.fetchall():
                table_name = row["name"]
                count_cur = conn.cursor()
                count_cur.execute(f"SELECT COUNT(*) as cnt FROM {table_name}")
                count_row = count_cur.fetchone()
                tables[table_name] = {
                    "row_count": count_row["cnt"] if count_row else 0,
                }
            
            info["tables"] = tables
            info["path"] = str(self.path)
            info["size_mb"] = self.path.stat().st_size / (1024 * 1024)
            info["metrics"] = self._metrics
            info["schema_version"] = self.VERSION
        
        return info
    
    def commit(self) -> None:
        """Commit any pending transactions."""
        with self._get_connection() as conn:
            conn.commit()
    
    def close(self) -> None:
        """Close all database connections."""
        with self._pool_lock:
            if self._config.get("optimize_on_close"):
                try:
                    with self._get_connection() as conn:
                        conn.execute("PRAGMA optimize;")
                except Exception:
                    pass
            
            for conn in self._conn_pool:
                try:
                    conn.close()
                except Exception:
                    pass
            self._conn_pool.clear()
    
    def __del__(self) -> None:
        """Destructor to ensure connections are closed."""
        self.close()


# ---------------------------
# Factory Functions
# ---------------------------
def create_store(
    path: Union[str, Path],
    *,
    in_memory: bool = False,
    readonly: bool = False,
    **kwargs,
) -> SQLiteStore:
    """Factory function to create SQLiteStore with different configurations."""
    if in_memory:
        path = ":memory:"
    
    if readonly:
        # Readonly mode requires special handling
        path_str = str(path)
        if path_str != ":memory:":
            if not os.path.exists(path_str):
                raise FileNotFoundError(f"Database file not found: {path_str}")
        
        # Override connection creation for readonly
        original_init = SQLiteStore.__init__
        
        def readonly_init(self, *args, **kwargs):
            kwargs["sqlite_timeout_sec"] = kwargs.get("sqlite_timeout_sec", 30.0)
            kwargs["busy_timeout_ms"] = kwargs.get("busy_timeout_ms", 5000)
            original_init(self, *args, **kwargs)
            
            # Make connections readonly
            for conn in self._conn_pool:
                conn.execute("PRAGMA query_only=ON;")
        
        SQLiteStore.__init__ = readonly_init
    
    return SQLiteStore(path, **kwargs)


# ---------------------------
# Migration Utilities
# ---------------------------
def migrate_database(old_path: Union[str, Path], new_path: Union[str, Path]) -> bool:
    """Migrate database from old schema to new schema."""
    try:
        old_store = SQLiteStore(old_path)
        new_store = SQLiteStore(new_path)
        
        # Export all data from old store
        tables = [
            TableName.EVENTS,
            TableName.TRADES,
            TableName.SIGNALS,
            TableName.SNAPSHOTS,
            TableName.DECISIONS,
        ]
        
        for table in tables:
            rows = old_store._exec(
                f"SELECT * FROM {table.value}",
                fetch=True,
            )
            if rows:
                new_store.bulk_insert(table, rows)
        
        old_store.close()
        new_store.close()
        
        logger.info(f"Database migrated from {old_path} to {new_path}")
        return True
        
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        return False
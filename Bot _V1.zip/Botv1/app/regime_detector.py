from __future__ import annotations

import time
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, List, Tuple, Union, Callable
from enum import Enum
from collections import deque
import warnings
import logging

# Configure logger
logger = logging.getLogger(__name__)


class RegimeType(str, Enum):
    """Market regime types with hierarchical classification."""
    # Primary regimes
    TRENDING_BULL = "trending_bull"
    TRENDING_BEAR = "trending_bear"
    RANGING = "ranging"
    HIGH_VOLATILITY = "high_vol"
    LOW_VOLATILITY = "low_vol"
    
    # Secondary regimes
    BREAKOUT_BULL = "breakout_bull"
    BREAKOUT_BEAR = "breakout_bear"
    REVERSAL_BULL = "reversal_bull"
    REVERSAL_BEAR = "reversal_bear"
    ACCUMULATION = "accumulation"
    DISTRIBUTION = "distribution"
    
    # Special regimes
    CRASH = "crash"
    RALLY = "rally"
    CHOPPY = "choppy"
    UNCERTAIN = "uncertain"
    NA = "na"
    
    @property
    def is_trending(self) -> bool:
        """Check if regime is trending."""
        return self in [
            RegimeType.TRENDING_BULL, RegimeType.TRENDING_BEAR,
            RegimeType.BREAKOUT_BULL, RegimeType.BREAKOUT_BEAR
        ]
    
    @property
    def is_bullish(self) -> bool:
        """Check if regime is bullish."""
        return self in [
            RegimeType.TRENDING_BULL, RegimeType.BREAKOUT_BULL,
            RegimeType.REVERSAL_BULL, RegimeType.RALLY
        ]
    
    @property
    def is_bearish(self) -> bool:
        """Check if regime is bearish."""
        return self in [
            RegimeType.TRENDING_BEAR, RegimeType.BREAKOUT_BEAR,
            RegimeType.REVERSAL_BEAR, RegimeType.CRASH
        ]
    
    @property
    def is_volatile(self) -> bool:
        """Check if regime is high volatility."""
        return self in [
            RegimeType.HIGH_VOLATILITY, RegimeType.CRASH,
            RegimeType.RALLY, RegimeType.BREAKOUT_BULL,
            RegimeType.BREAKOUT_BEAR
        ]


@dataclass
class RegimeFeatures:
    """Computed features for regime detection."""
    # Price features
    returns_mean: float = 0.0
    returns_std: float = 0.0
    returns_skew: float = 0.0
    returns_kurtosis: float = 0.0
    
    # Volatility features
    atr_pct: float = 0.0
    volatility_ratio: float = 0.0  # Short-term vs long-term volatility
    bb_width_pct: float = 0.0  # Bollinger Band width %
    
    # Trend features
    ema_slope_20: float = 0.0
    ema_slope_50: float = 0.0
    ema_distance: float = 0.0  # Distance between EMAs
    trend_strength: float = 0.0
    
    # Momentum features
    rsi: float = 50.0
    macd: float = 0.0
    macd_signal: float = 0.0
    stochastic_k: float = 50.0
    stochastic_d: float = 50.0
    
    # Volume features
    volume_ratio: float = 0.0  # Recent volume vs average
    obv_slope: float = 0.0  # On Balance Volume slope
    volume_atr_ratio: float = 0.0  # Volume relative to volatility
    
    # Market structure features
    support_levels: int = 0
    resistance_levels: int = 0
    pivot_points: int = 0
    consolidation_score: float = 0.0
    
    # Derived scores
    volatility_score: float = 0.0
    trend_score: float = 0.0
    momentum_score: float = 0.0
    volume_score: float = 0.0


@dataclass
class RegimeState:
    """Market regime state for a symbol or global market."""
    regime: RegimeType
    strength: float
    confidence: float
    features: RegimeFeatures = field(default_factory=RegimeFeatures)
    details: Dict[str, Any] = field(default_factory=dict)
    transition_probabilities: Dict[RegimeType, float] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "regime": self.regime.value,
            "strength": float(self.strength),
            "confidence": float(self.confidence),
            "features": {
                "returns_mean": float(self.features.returns_mean),
                "returns_std": float(self.features.returns_std),
                "atr_pct": float(self.features.atr_pct),
                "trend_strength": float(self.features.trend_strength),
                "rsi": float(self.features.rsi),
                "volume_ratio": float(self.features.volume_ratio),
                "volatility_score": float(self.features.volatility_score),
                "trend_score": float(self.features.trend_score),
            },
            "details": dict(self.details),
            "transition_probabilities": {
                k.value: float(v) for k, v in self.transition_probabilities.items()
            },
            "ts": float(self.ts),
        }


class RegimeHistory:
    """Maintain history of regime transitions for analysis."""
    
    def __init__(self, max_length: int = 1000):
        self.history: List[RegimeState] = []
        self.transitions: List[Dict[str, Any]] = []
        self.max_length = max_length
    
    def add(self, state: RegimeState) -> None:
        """Add a new regime state to history."""
        self.history.append(state)
        if len(self.history) > 1:
            prev = self.history[-2]
            transition = {
                "from": prev.regime.value,
                "to": state.regime.value,
                "duration": state.ts - prev.ts,
                "strength_change": state.strength - prev.strength,
                "confidence_change": state.confidence - prev.confidence,
                "ts": state.ts,
            }
            self.transitions.append(transition)
        
        # Trim history if too long
        if len(self.history) > self.max_length:
            self.history = self.history[-self.max_length:]
        if len(self.transitions) > self.max_length:
            self.transitions = self.transitions[-self.max_length:]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about regime history."""
        if not self.history:
            return {}
        
        durations: Dict[RegimeType, List[float]] = {}
        strengths: Dict[RegimeType, List[float]] = {}
        
        for i, state in enumerate(self.history):
            regime = state.regime
            if regime not in durations:
                durations[regime] = []
                strengths[regime] = []
            
            strengths[regime].append(state.strength)
            
            # Calculate duration
            if i < len(self.history) - 1:
                next_state = self.history[i + 1]
                if next_state.regime == regime:
                    durations[regime].append(next_state.ts - state.ts)
        
        stats = {}
        for regime in durations:
            dur_list = durations[regime]
            str_list = strengths[regime]
            stats[regime.value] = {
                "count": len(str_list),
                "avg_duration": np.mean(dur_list) if dur_list else 0,
                "avg_strength": np.mean(str_list) if str_list else 0,
                "frequency": len(str_list) / len(self.history) if self.history else 0,
            }
        
        # Transition matrix
        if self.transitions:
            transition_counts: Dict[Tuple[str, str], int] = {}
            for t in self.transitions:
                key = (t["from"], t["to"])
                transition_counts[key] = transition_counts.get(key, 0) + 1
            
            transition_matrix = {}
            for (from_regime, to_regime), count in transition_counts.items():
                transition_matrix[f"{from_regime}->{to_regime}"] = {
                    "count": count,
                    "probability": count / len(self.transitions),
                }
            
            stats["transitions"] = transition_matrix
        
        return stats


class MarketRegimeDetector:
    """Advanced market regime detection with multiple methodologies.
    
    Features:
      - Hierarchical regime classification
      - Multiple detection methodologies (heuristic, ML, ensemble)
      - Transition analysis and probability estimation
      - Multi-timeframe analysis
      - Hysteresis and momentum-based switching
      - Global market regime aggregation
      - Performance metrics and validation
    """
    
    def __init__(self, cfg: Dict[str, Any], log: Any = None):
        self.cfg = cfg or {}
        self.log = log or logger
        
        # Storage
        self._per_symbol: Dict[str, RegimeState] = {}
        self._global: RegimeState = RegimeState(
            regime=RegimeType.NA,
            strength=0.0,
            confidence=0.0,
            details={"reason": "initialized"}
        )
        
        # Hysteresis and switching
        self._symbol_hold_until: Dict[str, float] = {}
        self._global_hold_until: float = 0.0
        self._min_switch_gain: float = 0.15
        self._min_hold_sec: float = 60.0
        
        # History tracking
        self.symbol_history: Dict[str, RegimeHistory] = {}
        self.global_history = RegimeHistory()
        
        # Ensemble weights
        self.method_weights = {
            "heuristic": 0.4,
            "ml": 0.4,
            "momentum": 0.2,
        }
        
        # Configuration
        self._load_config()
        
        # ML model (optional)
        self.ml_model = None
        self._load_ml_model()
        
        self.log.info(f"MarketRegimeDetector initialized with {len(self.supported_regimes)} regime types")
    
    def _load_config(self) -> None:
        """Load and validate configuration."""
        regime_cfg = self.cfg.get("regime", {})
        
        # Timeframes
        self.timeframes = regime_cfg.get("timeframes", ["5m", "15m", "1h"])
        self.primary_tf = regime_cfg.get("primary_timeframe", "15m")
        
        # Thresholds
        self.high_vol_atr_pct = float(regime_cfg.get("high_vol_atr_pct", 0.03))
        self.low_vol_atr_pct = float(regime_cfg.get("low_vol_atr_pct", 0.01))
        self.trend_strength_th = float(regime_cfg.get("trend_strength", 0.015))
        self.rsi_trend_th = float(regime_cfg.get("rsi_trend", 60.0))
        self.macd_trend_th = float(regime_cfg.get("macd_trend", 0.0))
        
        # Hysteresis
        self.ttl_symbol = float(regime_cfg.get("refresh_sec", 30.0))
        self.ttl_global = float(regime_cfg.get("global_refresh_sec", 60.0))
        self._min_hold_sec = float(regime_cfg.get("min_hold_sec", 45.0))
        self._min_switch_gain = float(regime_cfg.get("min_switch_gain", 0.12))
        
        # Ensemble
        method_weights = regime_cfg.get("method_weights", {})
        self.method_weights.update(method_weights)
        
        # Supported regimes
        self.supported_regimes = [
            RegimeType.TRENDING_BULL,
            RegimeType.TRENDING_BEAR,
            RegimeType.RANGING,
            RegimeType.HIGH_VOLATILITY,
            RegimeType.LOW_VOLATILITY,
            RegimeType.BREAKOUT_BULL,
            RegimeType.BREAKOUT_BEAR,
            RegimeType.CHOPPY,
        ]
    
    def _load_ml_model(self) -> None:
        """Load ML model if configured."""
        ml_cfg = self.cfg.get("regime", {}).get("ml", {})
        if not ml_cfg.get("enabled", False):
            return
        
        model_path = ml_cfg.get("model_path")
        if not model_path:
            return
        
        try:
            # Example: using joblib or pickle for model loading
            import joblib
            self.ml_model = joblib.load(model_path)
            self.log.info(f"Loaded ML model from {model_path}")
        except Exception as e:
            self.log.warning(f"Failed to load ML model: {e}")
    
    def update(self, engine: Any, symbol: Optional[str] = None, force: bool = False) -> None:
        """Update regime detection for specified symbol(s)."""
        now = time.time()
        
        # Get symbols to update
        symbols = self._get_symbols_to_update(engine, symbol)
        if not symbols:
            return
        
        # Update per-symbol regimes
        updated_symbols = []
        for sym in symbols:
            if self._should_update_symbol(sym, now, force):
                try:
                    state = self._detect_regime(engine, sym)
                    self._apply_hysteresis(sym, state, now, force)
                    updated_symbols.append(sym)
                    
                    # Update history
                    if sym not in self.symbol_history:
                        self.symbol_history[sym] = RegimeHistory()
                    self.symbol_history[sym].add(state)
                    
                except Exception as e:
                    self.log.error(f"Failed to detect regime for {sym}: {e}")
        
        # Update global regime if needed
        if updated_symbols and (force or now - self._global.ts >= self.ttl_global):
            self._update_global_regime(updated_symbols, now, force)
    
    def _get_symbols_to_update(self, engine: Any, symbol: Optional[str]) -> List[str]:
        """Get list of symbols to update."""
        if symbol:
            return [symbol.strip()]
        
        # Get symbols from engine
        sym_sources = [
            getattr(engine, "pairs", None),
            getattr(engine, "watchlist", None),
            getattr(engine, "symbols", None),
        ]
        
        for source in sym_sources:
            if source and isinstance(source, (list, tuple)):
                symbols = [str(s).strip() for s in source if s]
                if symbols:
                    return symbols
        
        return []
    
    def _should_update_symbol(self, symbol: str, now: float, force: bool) -> bool:
        """Check if symbol regime should be updated."""
        state = self._per_symbol.get(symbol)
        return force or not state or (now - state.ts >= self.ttl_symbol)
    
    def _detect_regime(self, engine: Any, symbol: str) -> RegimeState:
        """Detect regime using ensemble of methods."""
        now = time.time()
        
        # Fetch data for multiple timeframes
        data_by_tf = {}
        for tf in self.timeframes:
            try:
                df = self._fetch_ohlcv(engine, symbol, tf)
                if df is not None and len(df) > 50:
                    data_by_tf[tf] = df
            except Exception as e:
                self.log.debug(f"Failed to fetch {tf} data for {symbol}: {e}")
        
        if not data_by_tf:
            return RegimeState(
                regime=RegimeType.NA,
                strength=0.0,
                confidence=0.0,
                details={"error": "no_data"},
                ts=now,
            )
        
        # Compute features
        features = self._compute_features(data_by_tf, symbol)
        
        # Apply ensemble methods
        method_results = []
        
        # 1. Heuristic method
        heuristic_result = self._detect_heuristic(features, data_by_tf)
        method_results.append(("heuristic", heuristic_result))
        
        # 2. ML method (if available)
        if self.ml_model:
            ml_result = self._detect_ml(features, data_by_tf)
            method_results.append(("ml", ml_result))
        
        # 3. Momentum method
        momentum_result = self._detect_momentum(features, data_by_tf)
        method_results.append(("momentum", momentum_result))
        
        # 4. Autonomy controller (if available)
        auto_result = self._detect_autonomy(engine, symbol, data_by_tf)
        if auto_result:
            method_results.append(("autonomy", auto_result))
        
        # Ensemble aggregation
        final_regime, final_strength, final_confidence = self._aggregate_results(
            method_results, features
        )
        
        # Calculate transition probabilities
        transition_probs = self._calculate_transition_probabilities(
            symbol, final_regime, features
        )
        
        return RegimeState(
            regime=final_regime,
            strength=final_strength,
            confidence=final_confidence,
            features=features,
            details={
                "timeframes_used": list(data_by_tf.keys()),
                "methods": [m[0] for m in method_results],
                "method_results": {m[0]: m[1].regime.value for m in method_results},
            },
            transition_probabilities=transition_probs,
            ts=now,
        )
    
    def _fetch_ohlcv(self, engine: Any, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Fetch OHLCV data for a symbol and timeframe."""
        try:
            client = getattr(engine, "client", None)
            if client and hasattr(client, "fetch_ohlcv_df"):
                return client.fetch_ohlcv_df(symbol, timeframe, limit=500)
        except Exception as e:
            self.log.debug(f"Error fetching OHLCV for {symbol} {timeframe}: {e}")
        return None
    
    def _compute_features(self, data_by_tf: Dict[str, pd.DataFrame], symbol: str) -> RegimeFeatures:
        """Compute comprehensive features from OHLCV data."""
        if self.primary_tf not in data_by_tf:
            primary_tf = list(data_by_tf.keys())[0]
        else:
            primary_tf = self.primary_tf
        
        df = data_by_tf[primary_tf]
        
        # Ensure we have enough data
        if len(df) < 100:
            return RegimeFeatures()
        
        features = RegimeFeatures()
        
        # Price returns
        returns = df["close"].pct_change().dropna()
        if len(returns) > 0:
            features.returns_mean = float(returns.mean())
            features.returns_std = float(returns.std())
            features.returns_skew = float(returns.skew())
            features.returns_kurtosis = float(returns.kurtosis())
        
        # Volatility features
        features.atr_pct = self._compute_atr_pct(df)
        features.volatility_ratio = self._compute_volatility_ratio(df)
        features.bb_width_pct = self._compute_bb_width(df)
        
        # Trend features
        features.ema_slope_20 = self._compute_ema_slope(df, 20)
        features.ema_slope_50 = self._compute_ema_slope(df, 50)
        features.ema_distance = self._compute_ema_distance(df, 20, 50)
        features.trend_strength = self._compute_trend_strength(df)
        
        # Momentum features
        features.rsi = self._compute_rsi(df)
        macd, macd_signal = self._compute_macd(df)
        features.macd = macd
        features.macd_signal = macd_signal
        stoch_k, stoch_d = self._compute_stochastic(df)
        features.stochastic_k = stoch_k
        features.stochastic_d = stoch_d
        
        # Volume features
        features.volume_ratio = self._compute_volume_ratio(df)
        features.obv_slope = self._compute_obv_slope(df)
        features.volume_atr_ratio = self._compute_volume_atr_ratio(df)
        
        # Market structure features
        features.consolidation_score = self._compute_consolidation_score(df)
        
        # Derived scores
        features.volatility_score = self._compute_volatility_score(features)
        features.trend_score = self._compute_trend_score(features)
        features.momentum_score = self._compute_momentum_score(features)
        features.volume_score = self._compute_volume_score(features)
        
        return features
    
    def _detect_heuristic(self, features: RegimeFeatures, data_by_tf: Dict) -> RegimeState:
        """Heuristic-based regime detection."""
        # Initialize scores for each regime
        regime_scores = {regime: 0.0 for regime in self.supported_regimes}
        
        # Volatility-based scoring
        if features.atr_pct >= self.high_vol_atr_pct:
            regime_scores[RegimeType.HIGH_VOLATILITY] += features.volatility_score * 1.5
            # High volatility with trend
            if features.trend_strength > self.trend_strength_th:
                if features.returns_mean > 0:
                    regime_scores[RegimeType.BREAKOUT_BULL] += features.trend_score
                else:
                    regime_scores[RegimeType.BREAKOUT_BEAR] += features.trend_score
        elif features.atr_pct <= self.low_vol_atr_pct:
            regime_scores[RegimeType.LOW_VOLATILITY] += (1.0 - features.volatility_score) * 1.5
        
        # Trend-based scoring
        if features.trend_strength > self.trend_strength_th:
            if features.returns_mean > 0:
                regime_scores[RegimeType.TRENDING_BULL] += features.trend_score
            else:
                regime_scores[RegimeType.TRENDING_BEAR] += features.trend_score
        else:
            # Ranging or choppy
            if features.consolidation_score > 0.7:
                regime_scores[RegimeType.RANGING] += features.consolidation_score
            else:
                regime_scores[RegimeType.CHOPPY] += 0.5
        
        # Momentum-based adjustments
        if abs(features.macd) > self.macd_trend_th:
            if features.macd > 0:
                regime_scores[RegimeType.TRENDING_BULL] *= 1.2
            else:
                regime_scores[RegimeType.TRENDING_BEAR] *= 1.2
        
        # Volume confirmation
        if features.volume_score > 0.7:
            for regime in [RegimeType.BREAKOUT_BULL, RegimeType.BREAKOUT_BEAR,
                          RegimeType.TRENDING_BULL, RegimeType.TRENDING_BEAR]:
                regime_scores[regime] *= 1.1
        
        # Find best regime
        best_regime = max(regime_scores.items(), key=lambda x: x[1])
        
        # Normalize strength
        total_score = sum(regime_scores.values())
        strength = best_regime[1] / total_score if total_score > 0 else 0.0
        
        # Confidence based on feature agreement
        confidence = self._compute_confidence(features, best_regime[0])
        
        return RegimeState(
            regime=best_regime[0],
            strength=strength,
            confidence=confidence,
            features=features,
            details={"method": "heuristic", "scores": {k.value: v for k, v in regime_scores.items()}},
        )
    
    def _detect_ml(self, features: RegimeFeatures, data_by_tf: Dict) -> RegimeState:
        """ML-based regime detection."""
        if not self.ml_model:
            return RegimeState(
                regime=RegimeType.NA,
                strength=0.0,
                confidence=0.0,
                features=features,
                details={"method": "ml", "error": "no_model"},
            )
        
        try:
            # Prepare feature vector
            feature_vector = np.array([
                features.returns_mean,
                features.returns_std,
                features.atr_pct,
                features.trend_strength,
                features.rsi,
                features.macd,
                features.volume_ratio,
                features.volatility_score,
                features.trend_score,
                features.momentum_score,
            ]).reshape(1, -1)
            
            # Predict
            prediction = self.ml_model.predict(feature_vector)[0]
            probabilities = self.ml_model.predict_proba(feature_vector)[0]
            
            # Convert prediction to RegimeType
            regime_map = {
                0: RegimeType.TRENDING_BULL,
                1: RegimeType.TRENDING_BEAR,
                2: RegimeType.RANGING,
                3: RegimeType.HIGH_VOLATILITY,
                4: RegimeType.LOW_VOLATILITY,
            }
            
            regime = regime_map.get(prediction, RegimeType.NA)
            confidence = float(max(probabilities))
            
            return RegimeState(
                regime=regime,
                strength=confidence,
                confidence=confidence,
                features=features,
                details={
                    "method": "ml",
                    "probabilities": {regime_map.get(i, RegimeType.NA).value: float(p) 
                                    for i, p in enumerate(probabilities)},
                },
            )
        except Exception as e:
            self.log.warning(f"ML prediction failed: {e}")
            return RegimeState(
                regime=RegimeType.NA,
                strength=0.0,
                confidence=0.0,
                features=features,
                details={"method": "ml", "error": str(e)},
            )
    
    def _detect_momentum(self, features: RegimeFeatures, data_by_tf: Dict) -> RegimeState:
        """Momentum-based regime detection."""
        # Simple momentum-based classification
        regime = RegimeType.RANGING
        strength = 0.5
        confidence = 0.5
        
        # Check momentum indicators
        if features.rsi > 70 and features.macd > 0:
            regime = RegimeType.TRENDING_BULL
            strength = features.trend_score
            confidence = min(features.trend_score, (features.rsi - 50) / 30)
        elif features.rsi < 30 and features.macd < 0:
            regime = RegimeType.TRENDING_BEAR
            strength = features.trend_score
            confidence = min(features.trend_score, (50 - features.rsi) / 30)
        elif 40 < features.rsi < 60 and abs(features.macd) < 0.001:
            regime = RegimeType.RANGING
            strength = 1.0 - features.trend_score
            confidence = 0.7
        
        return RegimeState(
            regime=regime,
            strength=strength,
            confidence=confidence,
            features=features,
            details={"method": "momentum"},
        )
    
    def _detect_autonomy(self, engine: Any, symbol: str, data_by_tf: Dict) -> Optional[RegimeState]:
        """Use autonomy controller if available."""
        try:
            auto = getattr(engine, "autonomy", None)
            if auto and hasattr(auto, "predict_market_regime"):
                df = data_by_tf.get(self.primary_tf)
                if df is not None and len(df) > 50:
                    out = auto.predict_market_regime(df) or {}
                    regime_str = str(out.get("regime") or "na").lower()
                    
                    # Map autonomy regime to our regime types
                    regime_map = {
                        "trend": RegimeType.TRENDING_BULL if out.get("direction") == "bull" else RegimeType.TRENDING_BEAR,
                        "range": RegimeType.RANGING,
                        "high_vol": RegimeType.HIGH_VOLATILITY,
                        "low_vol": RegimeType.LOW_VOLATILITY,
                    }
                    
                    regime = regime_map.get(regime_str, RegimeType.NA)
                    strength = float(out.get("strength", 0.0))
                    confidence = float(out.get("confidence", 0.5))
                    
                    return RegimeState(
                        regime=regime,
                        strength=strength,
                        confidence=confidence,
                        details={"method": "autonomy", "raw_output": out},
                    )
        except Exception as e:
            self.log.debug(f"Autonomy detection failed for {symbol}: {e}")
        
        return None
    
    def _aggregate_results(self, method_results: List[Tuple[str, RegimeState]], 
                          features: RegimeFeatures) -> Tuple[RegimeType, float, float]:
        """Aggregate results from multiple detection methods."""
        if not method_results:
            return RegimeType.NA, 0.0, 0.0
        
        # Weighted voting
        votes: Dict[RegimeType, float] = {}
        confidences: Dict[RegimeType, List[float]] = {}
        
        for method_name, result in method_results:
            weight = self.method_weights.get(method_name, 0.0)
            if weight <= 0 or result.regime == RegimeType.NA:
                continue
            
            regime = result.regime
            votes[regime] = votes.get(regime, 0.0) + weight * result.strength
            
            if regime not in confidences:
                confidences[regime] = []
            confidences[regime].append(result.confidence)
        
        if not votes:
            return RegimeType.NA, 0.0, 0.0
        
        # Select regime with highest weighted vote
        best_regime = max(votes.items(), key=lambda x: x[1])
        
        # Calculate aggregate confidence
        regime_confidences = confidences.get(best_regime[0], [])
        avg_confidence = np.mean(regime_confidences) if regime_confidences else 0.0
        
        # Adjust strength based on feature consistency
        strength = best_regime[1] / sum(self.method_weights.values())
        strength = min(1.0, max(0.0, strength))
        
        return best_regime[0], strength, float(avg_confidence)
    
    def _apply_hysteresis(self, symbol: str, candidate: RegimeState, now: float, force: bool) -> None:
        """Apply hysteresis to prevent rapid regime switching."""
        prev = self._per_symbol.get(symbol)
        hold_until = self._symbol_hold_until.get(symbol, 0.0)
        
        if prev and candidate.regime != prev.regime and not force:
            # Still in hold period
            if now < hold_until:
                candidate.regime = prev.regime
                candidate.strength = prev.strength
                candidate.confidence = prev.confidence * 0.9  # Decay confidence
                candidate.details["hysteresis"] = f"hold:{hold_until - now:.1f}s"
            # Check switching gain
            elif candidate.strength < prev.strength + self._min_switch_gain:
                candidate.regime = prev.regime
                candidate.strength = prev.strength
                candidate.confidence = prev.confidence
                candidate.details["hysteresis"] = "insufficient_gain"
            else:
                # Allow switch, set new hold period
                self._symbol_hold_until[symbol] = now + self._min_hold_sec
        
        self._per_symbol[symbol] = candidate
    
    def _update_global_regime(self, updated_symbols: List[str], now: float, force: bool) -> None:
        """Update global market regime based on symbol regimes."""
        # Weight symbols by liquidity/volume
        weighted_votes: Dict[RegimeType, float] = {}
        details = {
            "symbols": [],
            "sample_size": len(updated_symbols),
        }
        
        for symbol in updated_symbols:
            state = self._per_symbol.get(symbol)
            if not state or state.regime == RegimeType.NA:
                continue
            
            # Weight by confidence and strength
            weight = state.confidence * state.strength
            
            # Additional weighting by symbol importance
            # (could be based on volume, market cap, etc.)
            weight *= self._get_symbol_weight(symbol)
            
            weighted_votes[state.regime] = weighted_votes.get(state.regime, 0.0) + weight
            
            details["symbols"].append({
                "symbol": symbol,
                "regime": state.regime.value,
                "strength": state.strength,
                "confidence": state.confidence,
                "weight": weight,
            })
        
        if not weighted_votes:
            self._global = RegimeState(
                regime=RegimeType.NA,
                strength=0.0,
                confidence=0.0,
                details={"reason": "no_valid_symbols"},
                ts=now,
            )
            return
        
        # Select global regime
        best_regime = max(weighted_votes.items(), key=lambda x: x[1])
        total_weight = sum(weighted_votes.values())
        
        # Apply global hysteresis
        prev_global = self._global
        candidate = RegimeState(
            regime=best_regime[0],
            strength=best_regime[1] / total_weight,
            confidence=min(0.95, best_regime[1] / total_weight),
            details=details,
            ts=now,
        )
        
        if prev_global and candidate.regime != prev_global.regime and not force:
            if now < self._global_hold_until:
                candidate = prev_global
                candidate.details["hysteresis"] = f"hold:{self._global_hold_until - now:.1f}s"
            elif candidate.strength < prev_global.strength + self._min_switch_gain:
                candidate = prev_global
                candidate.details["hysteresis"] = "insufficient_gain"
            else:
                self._global_hold_until = now + self._min_hold_sec
        
        self._global = candidate
        self.global_history.add(candidate)
    
    def _get_symbol_weight(self, symbol: str) -> float:
        """Get weight for a symbol in global regime calculation."""
        # Base implementation: equal weighting
        # Could be extended to use volume, market cap, etc.
        return 1.0
    
    def _calculate_transition_probabilities(self, symbol: str, current_regime: RegimeType,
                                          features: RegimeFeatures) -> Dict[RegimeType, float]:
        """Calculate probabilities of transitioning to other regimes."""
        probs = {}
        history = self.symbol_history.get(symbol)
        
        if history and len(history.history) > 5:
            # Use historical transition frequencies
            stats = history.get_statistics()
            transitions = stats.get("transitions", {})
            
            for transition_key, data in transitions.items():
                from_regime, to_regime = transition_key.split("->")
                if from_regime == current_regime.value:
                    try:
                        to_enum = RegimeType(to_regime)
                        probs[to_enum] = data["probability"]
                    except ValueError:
                        continue
        
        # Add feature-based probabilities
        probs[RegimeType.RANGING] = max(probs.get(RegimeType.RANGING, 0.0), 
                                      1.0 - features.trend_score)
        probs[RegimeType.TRENDING_BULL] = max(probs.get(RegimeType.TRENDING_BULL, 0.0),
                                            features.trend_score if features.returns_mean > 0 else 0.0)
        probs[RegimeType.TRENDING_BEAR] = max(probs.get(RegimeType.TRENDING_BEAR, 0.0),
                                            features.trend_score if features.returns_mean < 0 else 0.0)
        
        # Normalize probabilities
        total = sum(probs.values())
        if total > 0:
            probs = {k: v / total for k, v in probs.items()}
        
        return probs
    
    # Feature computation methods
    def _compute_atr_pct(self, df: pd.DataFrame, period: int = 14) -> float:
        """Compute ATR as percentage of price."""
        try:
            high = df["high"]
            low = df["low"]
            close = df["close"]
            
            tr1 = high - low
            tr2 = abs(high - close.shift())
            tr3 = abs(low - close.shift())
            tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            atr = tr.rolling(period).mean().iloc[-1]
            
            return float(atr / close.iloc[-1])
        except Exception:
            return 0.0
    
    def _compute_volatility_ratio(self, df: pd.DataFrame) -> float:
        """Compute ratio of short-term to long-term volatility."""
        try:
            returns = df["close"].pct_change()
            short_vol = returns.tail(20).std()
            long_vol = returns.tail(100).std()
            return float(short_vol / long_vol) if long_vol > 0 else 1.0
        except Exception:
            return 1.0
    
    def _compute_bb_width(self, df: pd.DataFrame, period: int = 20) -> float:
        """Compute Bollinger Band width as percentage."""
        try:
            close = df["close"]
            sma = close.rolling(period).mean()
            std = close.rolling(period).std()
            upper = sma + 2 * std
            lower = sma - 2 * std
            width = (upper.iloc[-1] - lower.iloc[-1]) / sma.iloc[-1]
            return float(width)
        except Exception:
            return 0.0
    
    def _compute_ema_slope(self, df: pd.DataFrame, period: int) -> float:
        """Compute EMA slope as percentage change."""
        try:
            close = df["close"]
            ema = close.ewm(span=period, adjust=False).mean()
            slope = (ema.iloc[-1] - ema.iloc[-5]) / ema.iloc[-5]
            return float(slope)
        except Exception:
            return 0.0
    
    def _compute_ema_distance(self, df: pd.DataFrame, short: int = 20, long: int = 50) -> float:
        """Compute distance between short and long EMAs."""
        try:
            close = df["close"]
            ema_short = close.ewm(span=short, adjust=False).mean().iloc[-1]
            ema_long = close.ewm(span=long, adjust=False).mean().iloc[-1]
            return float((ema_short - ema_long) / ema_long)
        except Exception:
            return 0.0
    
    def _compute_trend_strength(self, df: pd.DataFrame) -> float:
        """Compute trend strength using multiple indicators."""
        try:
            # Use ADX if available
            if "adx" in df.columns:
                return float(df["adx"].iloc[-1] / 100.0)
            
            # Fallback: use EMA distance magnitude
            ema_distance = abs(self._compute_ema_distance(df, 20, 50))
            return min(1.0, ema_distance * 10.0)
        except Exception:
            return 0.0
    
    def _compute_rsi(self, df: pd.DataFrame, period: int = 14) -> float:
        """Compute RSI."""
        try:
            close = df["close"]
            delta = close.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            return float(rsi.iloc[-1])
        except Exception:
            return 50.0
    
    def _compute_macd(self, df: pd.DataFrame) -> Tuple[float, float]:
        """Compute MACD and signal line."""
        try:
            close = df["close"]
            exp1 = close.ewm(span=12, adjust=False).mean()
            exp2 = close.ewm(span=26, adjust=False).mean()
            macd = exp1 - exp2
            signal = macd.ewm(span=9, adjust=False).mean()
            return float(macd.iloc[-1]), float(signal.iloc[-1])
        except Exception:
            return 0.0, 0.0
    
    def _compute_stochastic(self, df: pd.DataFrame, k_period: int = 14, d_period: int = 3) -> Tuple[float, float]:
        """Compute Stochastic oscillator."""
        try:
            high = df["high"].rolling(k_period).max()
            low = df["low"].rolling(k_period).min()
            close = df["close"]
            
            k = 100 * ((close - low) / (high - low))
            d = k.rolling(d_period).mean()
            
            return float(k.iloc[-1]), float(d.iloc[-1])
        except Exception:
            return 50.0, 50.0
    
    def _compute_volume_ratio(self, df: pd.DataFrame) -> float:
        """Compute ratio of recent volume to average volume."""
        try:
            volume = df["volume"]
            recent_vol = volume.tail(5).mean()
            avg_vol = volume.tail(50).mean()
            return float(recent_vol / avg_vol) if avg_vol > 0 else 1.0
        except Exception:
            return 1.0
    
    def _compute_obv_slope(self, df: pd.DataFrame) -> float:
        """Compute On Balance Volume slope."""
        try:
            close = df["close"]
            volume = df["volume"]
            
            obv = pd.Series(0.0, index=close.index)
            for i in range(1, len(close)):
                if close.iloc[i] > close.iloc[i-1]:
                    obv.iloc[i] = obv.iloc[i-1] + volume.iloc[i]
                elif close.iloc[i] < close.iloc[i-1]:
                    obv.iloc[i] = obv.iloc[i-1] - volume.iloc[i]
                else:
                    obv.iloc[i] = obv.iloc[i-1]
            
            # Compute slope over last 20 periods
            if len(obv) >= 20:
                x = np.arange(20)
                y = obv.tail(20).values
                slope = np.polyfit(x, y, 1)[0]
                return float(slope / np.mean(y)) if np.mean(y) != 0 else 0.0
        except Exception:
            pass
        return 0.0
    
    def _compute_volume_atr_ratio(self, df: pd.DataFrame) -> float:
        """Compute volume relative to volatility."""
        try:
            volume_ratio = self._compute_volume_ratio(df)
            atr_pct = self._compute_atr_pct(df)
            return float(volume_ratio / max(atr_pct, 0.001))
        except Exception:
            return 1.0
    
    def _compute_consolidation_score(self, df: pd.DataFrame) -> float:
        """Compute consolidation/range score."""
        try:
            close = df["close"]
            high = df["high"]
            low = df["low"]
            
            # Check if price is within recent range
            recent_range = high.tail(20).max() - low.tail(20).min()
            price_range = high.tail(5).max() - low.tail(5).min()
            
            if recent_range > 0:
                return float(price_range / recent_range)
        except Exception:
            pass
        return 0.5
    
    def _compute_volatility_score(self, features: RegimeFeatures) -> float:
        """Compute volatility score from features."""
        # Normalize ATR% to 0-1 range
        atr_norm = min(1.0, features.atr_pct / 0.05)
        vol_ratio_norm = min(2.0, features.volatility_ratio) / 2.0
        bb_width_norm = min(1.0, features.bb_width_pct / 0.1)
        
        return float((atr_norm + vol_ratio_norm + bb_width_norm) / 3.0)
    
    def _compute_trend_score(self, features: RegimeFeatures) -> float:
        """Compute trend score from features."""
        trend_score = min(1.0, features.trend_strength * 2.0)
        ema_slope_score = min(1.0, abs(features.ema_slope_20) * 20.0)
        ema_distance_score = min(1.0, abs(features.ema_distance) * 10.0)
        
        return float((trend_score + ema_slope_score + ema_distance_score) / 3.0)
    
    def _compute_momentum_score(self, features: RegimeFeatures) -> float:
        """Compute momentum score from features."""
        rsi_score = min(1.0, abs(features.rsi - 50) / 30.0)
        macd_score = min(1.0, abs(features.macd) * 100.0)
        stoch_score = min(1.0, abs(features.stochastic_k - 50) / 30.0)
        
        return float((rsi_score + macd_score + stoch_score) / 3.0)
    
    def _compute_volume_score(self, features: RegimeFeatures) -> float:
        """Compute volume score from features."""
        vol_ratio_score = min(1.0, features.volume_ratio / 2.0)
        obv_score = min(1.0, abs(features.obv_slope) * 10.0)
        vol_atr_score = min(1.0, features.volume_atr_ratio / 2.0)
        
        return float((vol_ratio_score + obv_score + vol_atr_score) / 3.0)
    
    def _compute_confidence(self, features: RegimeFeatures, regime: RegimeType) -> float:
        """Compute confidence score based on feature consistency."""
        confidence_factors = []
        
        if regime.is_trending:
            # For trending regimes, check trend indicators alignment
            if features.trend_score > 0.7:
                confidence_factors.append(0.8)
            if regime.is_bullish and features.rsi > 60:
                confidence_factors.append(0.6)
            elif regime.is_bearish and features.rsi < 40:
                confidence_factors.append(0.6)
            if abs(features.macd) > 0.002:
                confidence_factors.append(0.7)
        
        elif regime == RegimeType.RANGING:
            # For ranging, low volatility and neutral momentum
            if features.volatility_score < 0.3:
                confidence_factors.append(0.8)
            if 40 < features.rsi < 60:
                confidence_factors.append(0.7)
            if abs(features.macd) < 0.001:
                confidence_factors.append(0.6)
        
        elif regime == RegimeType.HIGH_VOLATILITY:
            if features.volatility_score > 0.7:
                confidence_factors.append(0.9)
        
        elif regime == RegimeType.LOW_VOLATILITY:
            if features.volatility_score < 0.3:
                confidence_factors.append(0.9)
        
        # Volume confirmation
        if features.volume_score > 0.6:
            confidence_factors.append(0.5)
        
        return float(np.mean(confidence_factors)) if confidence_factors else 0.5
    
    # Public API methods
    def get_global(self) -> Dict[str, Any]:
        """Get current global market regime."""
        return self._global.to_dict()
    
    def get_symbol(self, symbol: str) -> Dict[str, Any]:
        """Get current regime for a symbol."""
        state = self._per_symbol.get(symbol)
        if not state:
            return {
                "regime": RegimeType.NA.value,
                "strength": 0.0,
                "confidence": 0.0,
                "details": {"reason": "no_data"},
                "ts": 0.0,
            }
        return state.to_dict()
    
    def get_statistics(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Get regime statistics for a symbol or globally."""
        if symbol:
            history = self.symbol_history.get(symbol)
            if not history:
                return {}
            return history.get_statistics()
        else:
            return self.global_history.get_statistics()
    
    def get_regime_advice(self, symbol: str, strategy_type: str) -> Dict[str, Any]:
        """Get trading advice based on current regime."""
        state = self._per_symbol.get(symbol)
        if not state:
            return {"error": "no_regime_data"}
        
        advice = {
            "symbol": symbol,
            "regime": state.regime.value,
            "strength": state.strength,
            "confidence": state.confidence,
            "recommended_actions": [],
            "risk_adjustment": 1.0,
            "position_size_multiplier": 1.0,
        }
        
        # Strategy-specific recommendations
        if strategy_type == "trend_following":
            if state.regime.is_trending:
                advice["recommended_actions"].append("enter_trend")
                advice["risk_adjustment"] = 1.2
                advice["position_size_multiplier"] = 1.0
            elif state.regime == RegimeType.RANGING:
                advice["recommended_actions"].append("avoid_trending")
                advice["risk_adjustment"] = 0.5
                advice["position_size_multiplier"] = 0.7
            elif state.regime == RegimeType.HIGH_VOLATILITY:
                advice["recommended_actions"].extend(["reduce_size", "tighten_stops"])
                advice["risk_adjustment"] = 0.7
                advice["position_size_multiplier"] = 0.8
        
        elif strategy_type == "mean_reversion":
            if state.regime == RegimeType.RANGING:
                advice["recommended_actions"].append("fade_extremes")
                advice["risk_adjustment"] = 1.0
                advice["position_size_multiplier"] = 1.0
            elif state.regime.is_trending:
                advice["recommended_actions"].append("avoid_mean_reversion")
                advice["risk_adjustment"] = 0.3
                advice["position_size_multiplier"] = 0.5
            elif state.regime == RegimeType.HIGH_VOLATILITY:
                advice["recommended_actions"].append("wait_for_volatility_decrease")
                advice["risk_adjustment"] = 0.5
                advice["position_size_multiplier"] = 0.6
        
        elif strategy_type == "breakout":
            if state.regime == RegimeType.HIGH_VOLATILITY:
                advice["recommended_actions"].append("watch_for_breakouts")
                advice["risk_adjustment"] = 1.0
                advice["position_size_multiplier"] = 1.0
            elif state.regime == RegimeType.LOW_VOLATILITY:
                advice["recommended_actions"].append("wait_for_volatility_increase")
                advice["risk_adjustment"] = 0.3
                advice["position_size_multiplier"] = 0.5
            elif state.regime.is_trending:
                advice["recommended_actions"].append("follow_trend_breakouts")
                advice["risk_adjustment"] = 0.8
                advice["position_size_multiplier"] = 0.9
        
        # Add transition warnings
        if state.transition_probabilities:
            likely_transitions = sorted(
                [(k, v) for k, v in state.transition_probabilities.items()],
                key=lambda x: x[1],
                reverse=True
            )[:2]
            
            if likely_transitions:
                advice["likely_transitions"] = [
                    {"to": k.value, "probability": v}
                    for k, v in likely_transitions
                ]
        
        return advice
    
    def validate_detection(self, symbol: str, actual_regime: RegimeType) -> Dict[str, Any]:
        """Validate regime detection against actual regime (for backtesting)."""
        detected = self._per_symbol.get(symbol)
        if not detected:
            return {"error": "no_detection"}
        
        correct = detected.regime == actual_regime
        confidence = detected.confidence if correct else 1.0 - detected.confidence
        
        return {
            "symbol": symbol,
            "detected": detected.regime.value,
            "actual": actual_regime.value,
            "correct": correct,
            "confidence": detected.confidence,
            "strength": detected.strength,
            "validation_score": confidence * detected.strength,
            "ts": detected.ts,
        }
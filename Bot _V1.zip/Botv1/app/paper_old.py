from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Tuple
from .utils import clamp

@dataclass
class PaperPosition:
    symbol: str
    qty: float
    avg_price: float

class PaperPortfolio:
    def __init__(self, cfg: Dict[str, Any]):
        p = cfg["paper"]
        self.cash = float(p["initial_cash_quote"])
        self.positions: Dict[str, PaperPosition] = {}
        self.realized_pnl = 0.0
        self.fees_paid = 0.0
        self.taker_fee = float(p["taker_fee_rate"])
        self.maker_fee = float(p["maker_fee_rate"])
        self.market_slip_bps = float(p["market_slippage_bps"])
        self.limit_slip_bps = float(p["limit_slippage_bps"])

    def equity(self, mark_prices: Dict[str, float]) -> float:
        eq = self.cash
        for sym, pos in self.positions.items():
            px = mark_prices.get(sym)
            if px and px > 0:
                eq += pos.qty * px
        return eq

    def has_position(self, symbol: str) -> bool:
        return symbol in self.positions and self.positions[symbol].qty > 0

    def _fee_rate(self, maker: bool) -> float:
        return self.maker_fee if maker else self.taker_fee

    def _slip(self, price: float, side: str, maker: bool) -> float:
        bps = self.limit_slip_bps if maker else self.market_slip_bps
        s = bps/10_000.0
        return price*(1+s) if side=="buy" else price*(1-s)

    def buy(self, symbol: str, qty: float, price: float, maker: bool) -> Tuple[float,float,float]:
        fill = self._slip(price,"buy",maker)
        notional = qty*fill
        fee = notional*self._fee_rate(maker)
        total = notional+fee
        if total > self.cash:
            if self.cash <= 0:
                return 0.0,0.0,0.0
            qty = max(0.0, self.cash / (fill*(1+self._fee_rate(maker))))
            fill = self._slip(price,"buy",maker)
            notional = qty*fill
            fee = notional*self._fee_rate(maker)
            total = notional+fee
        if qty <= 0:
            return 0.0,0.0,0.0
        self.cash -= total
        self.fees_paid += fee
        pos = self.positions.get(symbol)
        if not pos:
            self.positions[symbol]=PaperPosition(symbol, qty, fill)
        else:
            new_qty = pos.qty+qty
            pos.avg_price=(pos.avg_price*pos.qty+fill*qty)/new_qty
            pos.qty=new_qty
        return fill, fee, qty

    def sell(self, symbol: str, qty: float, price: float, maker: bool) -> Tuple[float,float,float,float]:
        pos = self.positions.get(symbol)
        if not pos or pos.qty<=0:
            return 0.0,0.0,0.0,0.0
        qty=min(qty,pos.qty)
        fill=self._slip(price,"sell",maker)
        notional=qty*fill
        fee=notional*self._fee_rate(maker)
        proceeds=notional-fee
        realized=(fill-pos.avg_price)*qty-fee
        self.cash += proceeds
        self.fees_paid += fee
        self.realized_pnl += realized
        pos.qty -= qty
        if pos.qty <= 1e-12:
            del self.positions[symbol]
        return fill, fee, realized, qty

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cash": self.cash,
            "positions": {k: {"symbol": v.symbol, "qty": v.qty, "avg_price": v.avg_price} for k,v in self.positions.items()},
            "realized_pnl": self.realized_pnl,
            "fees_paid": self.fees_paid
        }

    @staticmethod
    def from_dict(cfg: Dict[str, Any], d: Dict[str, Any]) -> "PaperPortfolio":
        p = PaperPortfolio(cfg)
        p.cash = float(d.get("cash", p.cash))
        p.realized_pnl=float(d.get("realized_pnl",0.0))
        p.fees_paid=float(d.get("fees_paid",0.0))
        pos={}
        for k,v in (d.get("positions") or {}).items():
            pos[k]=PaperPosition(symbol=v["symbol"], qty=float(v["qty"]), avg_price=float(v["avg_price"]))
        p.positions=pos
        return p

# app/marketdata_ws.py
from __future__ import annotations

import threading
import time
from typing import Any, Dict, Optional, Tuple, List


class MarketDataWS:
    """
    Lightweight market-data cache.

    The engine/exchange layer can query this cache to avoid hitting REST too often.
    This implementation is intentionally conservative: it is *not* a full websocket client.
    You can later upgrade it to CCXT Pro websockets (or native exchange streams) without
    changing the public interface used by ExchangeClient/TradingEngine.

    Public API expected by the rest of the bot:
      - set_symbols(symbols)
      - start()/stop() (safe no-op)
      - get_ticker(symbol) -> dict | None
      - get_orderbook(symbol) -> dict | None
      - set_ticker / set_orderbook
      - close()
    """

    def __init__(self, cfg: Dict[str, Any], log: Any):
        self.cfg = cfg or {}
        self.log = log
        self._lock = threading.RLock()
        self._closed = False
        self._running = False
        self._symbols: List[str] = []

        # key = (kind, symbol), where kind in {'ticker','orderbook'}
        self._cache: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self._ts: Dict[Tuple[str, str], float] = {}

        # soft TTLs (seconds)
        ws_cfg = self.cfg.get("ws_cache", {}) if isinstance(self.cfg, dict) else {}
        self._ttl_ticker = float(ws_cfg.get("ticker_ttl_sec", 2.0))
        self._ttl_orderbook = float(ws_cfg.get("orderbook_ttl_sec", 1.0))

    # --- lifecycle / subscriptions (no-op safe) ---
    def set_symbols(self, symbols: List[str]) -> None:
        """Engine calls this after pair selection to allow WS subscriptions.

        In this lightweight implementation we only store the list.
        """
        try:
            with self._lock:
                self._symbols = [str(s) for s in (symbols or [])]
        except Exception:
            return

    def start(self) -> None:
        """Start websocket subsystem (no-op safe implementation)."""
        try:
            with self._lock:
                self._running = True
                self._closed = False
        except Exception:
            pass

    def stop(self) -> None:
        """Stop websocket subsystem (no-op safe implementation)."""
        try:
            with self._lock:
                self._running = False
        except Exception:
            pass

    @property
    def running(self) -> bool:
        try:
            with self._lock:
                return bool(self._running) and not bool(self._closed)
        except Exception:
            return False

    # --- cache utils ---
    def _is_fresh(self, key: Tuple[str, str], ttl: float) -> bool:
        ts = self._ts.get(key, 0.0)
        return (time.time() - ts) <= ttl

    def get_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        key = ("ticker", str(symbol))
        with self._lock:
            if key in self._cache and self._is_fresh(key, self._ttl_ticker):
                return dict(self._cache[key])
        return None

    def set_ticker(self, symbol: str, data: Dict[str, Any]) -> None:
        if not isinstance(data, dict):
            return
        key = ("ticker", str(symbol))
        with self._lock:
            self._cache[key] = dict(data)
            self._ts[key] = time.time()

    def get_orderbook(self, symbol: str) -> Optional[Dict[str, Any]]:
        key = ("orderbook", str(symbol))
        with self._lock:
            if key in self._cache and self._is_fresh(key, self._ttl_orderbook):
                return dict(self._cache[key])
        return None

    def set_orderbook(self, symbol: str, data: Dict[str, Any]) -> None:
        if not isinstance(data, dict):
            return
        key = ("orderbook", str(symbol))
        with self._lock:
            self._cache[key] = dict(data)
            self._ts[key] = time.time()

    def close(self) -> None:
        with self._lock:
            self._closed = True
            self._running = False
            self._cache.clear()
            self._ts.clear()
            self._symbols = []

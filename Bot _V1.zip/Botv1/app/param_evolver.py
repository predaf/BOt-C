# app/param_evolver.py
from __future__ import annotations

import os
import sqlite3
import time
import random
import math
import threading
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


def _f(x: Any, d: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(d)


def _i(x: Any, d: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return int(d)


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(float(lo), min(float(hi), float(x)))


def _now() -> float:
    return float(time.time())


def _safe_log(log: Any, level: str, msg: str) -> None:
    try:
        fn = getattr(log, level, None)
        if callable(fn):
            fn(msg)
        elif hasattr(log, "info") and callable(getattr(log, "info")):
            log.info(msg)
    except Exception:
        pass


@dataclass
class EvoParamSet:
    symbol: str
    tactic: str
    param_id: str
    stop_atr_mult: float
    tp_atr_mult: float
    n: int = 0
    mean: float = 0.0
    m2: float = 0.0
    created_ts: float = 0.0
    updated_ts: float = 0.0
    active: int = 1
    source: str = "seed"

    def var(self) -> float:
        if self.n <= 1:
            return 0.0
        return float(self.m2) / max(1.0, float(self.n - 1))

    def std(self) -> float:
        return math.sqrt(max(0.0, self.var()))


class ParamSetEvolver:
    """
    Per-symbol + per-tactic param-set evolution (SQLite backed).

    Improvements:
      - thread-safe (RLock)
      - busy_timeout + retry on SQLITE_BUSY
      - UCB-based selection (exploration/exploitation)
      - safer cap enforcement (never deactivate top-K elites)
      - stronger signal path for trade reward (normalized/clamped)
      - helper APIs: choose_param_set(), best_param_set()
    """

    def __init__(self, db_path: str, cfg: Dict[str, Any], log: Any = None, *, table_prefix: str = "evo"):
        self.db_path = str(db_path or "").strip()
        self.cfg = cfg or {}
        self.log = log
        self.pfx = str(table_prefix)
        self._lock = threading.RLock()

        if not self.db_path:
            self.conn = None
            return

        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=10.0)
        self.conn.row_factory = sqlite3.Row

        self._init()

    # -----------------------------
    # Config helpers
    # -----------------------------
    def _cfg(self) -> Dict[str, Any]:
        return (self.cfg.get("param_evolver") or {}) if isinstance(self.cfg.get("param_evolver"), dict) else {}

    def enabled(self) -> bool:
        c = self._cfg()
        return bool(c.get("enabled", True))

    def max_sets(self) -> int:
        c = self._cfg()
        return max(2, int(c.get("max_sets_per_symbol_tactic", 6) or 6))

    def elite_keep(self) -> int:
        """Never deactivate top-N by mean/n to preserve 'best so far' memory."""
        c = self._cfg()
        return max(1, int(c.get("elite_keep", 2) or 2))

    def evolve_interval_sec(self) -> float:
        c = self._cfg()
        return float(c.get("evolve_interval_sec", 3600) or 3600)

    def min_samples_to_rank(self) -> int:
        c = self._cfg()
        return max(0, int(c.get("min_samples_to_rank", 3) or 3))

    def mutation_strength(self) -> float:
        c = self._cfg()
        return float(c.get("mutation_strength", 0.12) or 0.12)

    def mutation_strength_tp(self) -> float:
        c = self._cfg()
        return float(c.get("mutation_strength_tp", self.mutation_strength()) or self.mutation_strength())

    def ucb_c(self) -> float:
        c = self._cfg()
        return float(c.get("ucb_c", 0.8) or 0.8)

    def exploration_eps(self) -> float:
        c = self._cfg()
        return _clamp(float(c.get("exploration_eps", 0.10) or 0.10), 0.0, 0.5)

    def trade_reward_weight(self) -> int:
        c = self._cfg()
        return max(1, min(10, int(c.get("trade_reward_weight", 3) or 3)))

    def reward_clip(self) -> float:
        c = self._cfg()
        return float(c.get("reward_clip", 0.05) or 0.05)  # normalize reward, clamp to +/-5% by default

    def min_rr(self) -> float:
        c = self._cfg()
        return float(c.get("min_rr", 1.0) or 1.0)

    def bounds(self) -> Tuple[Tuple[float, float], Tuple[float, float]]:
        c = self._cfg()
        sb = c.get("stop_bounds") or [0.6, 6.0]
        tb = c.get("tp_bounds") or [0.8, 12.0]
        slo = float(sb[0]) if isinstance(sb, (list, tuple)) and len(sb) >= 2 else 0.6
        shi = float(sb[1]) if isinstance(sb, (list, tuple)) and len(sb) >= 2 else 6.0
        tlo = float(tb[0]) if isinstance(tb, (list, tuple)) and len(tb) >= 2 else 0.8
        thi = float(tb[1]) if isinstance(tb, (list, tuple)) and len(tb) >= 2 else 12.0
        return (slo, shi), (tlo, thi)

    def busy_timeout_ms(self) -> int:
        c = self._cfg()
        return max(1000, int(c.get("busy_timeout_ms", 8000) or 8000))

    # -----------------------------
    # SQLite helpers
    # -----------------------------
    def _execute(self, sql: str, params: Tuple[Any, ...] = ()) -> sqlite3.Cursor:
        """Execute with small retry on SQLITE_BUSY/locked."""
        if not self.conn:
            raise RuntimeError("no sqlite connection")
        retries = 3
        delay = 0.05
        last_exc: Optional[Exception] = None
        for _ in range(retries):
            try:
                cur = self.conn.cursor()
                return cur.execute(sql, params)
            except sqlite3.OperationalError as e:
                last_exc = e
                msg = str(e).lower()
                if "locked" in msg or "busy" in msg:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise
        raise last_exc  # type: ignore

    def _init(self) -> None:
        if not self.conn:
            return
        with self._lock:
            cur = self.conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("PRAGMA synchronous=NORMAL;")
            cur.execute(f"PRAGMA busy_timeout={int(self.busy_timeout_ms())};")

            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.pfx}_params(
                  symbol TEXT NOT NULL,
                  tactic TEXT NOT NULL,
                  param_id TEXT NOT NULL,
                  stop_atr_mult REAL NOT NULL,
                  tp_atr_mult REAL NOT NULL,
                  n INTEGER DEFAULT 0,
                  mean REAL DEFAULT 0,
                  m2 REAL DEFAULT 0,
                  created_ts REAL DEFAULT 0,
                  updated_ts REAL DEFAULT 0,
                  active INTEGER DEFAULT 1,
                  source TEXT DEFAULT 'seed',
                  PRIMARY KEY(symbol, tactic, param_id)
                );
                """
            )

            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.pfx}_meta(
                  symbol TEXT NOT NULL,
                  tactic TEXT NOT NULL,
                  last_evolve_ts REAL DEFAULT 0,
                  PRIMARY KEY(symbol, tactic)
                );
                """
            )

            # helpful indices
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{self.pfx}_params_active ON {self.pfx}_params(symbol,tactic,active);")
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{self.pfx}_params_rank ON {self.pfx}_params(symbol,tactic,mean,n,updated_ts);")

            self.conn.commit()

    # -----------------------------
    # Seeding / retrieval
    # -----------------------------
    def _default_seeds(self, tactic: str, cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
        base_risk = (cfg.get("risk") or {}) if isinstance(cfg.get("risk"), dict) else {}
        stop_mult_default = _f(base_risk.get("stop_atr_mult", 2.5), 2.5)
        tp_mult_default = _f(base_risk.get("tp_atr_mult", 4.0), 4.0)

        t = str(tactic or "").strip()
        if t == "trend_follow":
            return [
                {"id": "tf_a", "stop_atr_mult": max(2.0, stop_mult_default), "tp_atr_mult": max(tp_mult_default, 3.5)},
                {"id": "tf_b", "stop_atr_mult": max(2.2, stop_mult_default), "tp_atr_mult": max(tp_mult_default, 4.5)},
            ]
        if t == "range_reversion":
            return [
                {"id": "rr_a", "stop_atr_mult": min(stop_mult_default, 2.5), "tp_atr_mult": min(tp_mult_default, 3.0)},
                {"id": "rr_b", "stop_atr_mult": min(stop_mult_default, 2.2), "tp_atr_mult": min(tp_mult_default, 2.5)},
            ]
        if t == "scalp":
            return [{"id": "sc_a", "stop_atr_mult": min(stop_mult_default, 1.8), "tp_atr_mult": min(tp_mult_default, 2.0)}]
        if t == "grid":
            return [{"id": "gr_a", "stop_atr_mult": max(stop_mult_default, 3.0), "tp_atr_mult": min(tp_mult_default, 2.5)}]
        if t == "breakout":
            return [{"id": "br_a", "stop_atr_mult": max(stop_mult_default, 2.5), "tp_atr_mult": max(tp_mult_default, 4.0)}]
        if t == "high_vol_event":
            return [{"id": "hv_a", "stop_atr_mult": max(stop_mult_default, 3.0), "tp_atr_mult": min(tp_mult_default, 3.0)}]
        return [{"id": "base", "stop_atr_mult": stop_mult_default, "tp_atr_mult": tp_mult_default}]

    def _cfg_param_sets(self, tactic: str, cfg: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
        bt_cfg = (cfg.get("decision_factor") or {}).get("backtest") or {}
        param_sets_cfg = (bt_cfg.get("param_sets") or {}) if isinstance(bt_cfg.get("param_sets"), dict) else {}
        raw = param_sets_cfg.get(str(tactic))
        if isinstance(raw, list) and raw:
            out: List[Dict[str, Any]] = []
            for p in raw:
                if isinstance(p, dict):
                    out.append(dict(p))
            return out or None
        return None

    def _seed_if_missing(self, symbol: str, tactic: str) -> None:
        if not self.conn:
            return
        with self._lock:
            row = self._execute(
                f"SELECT COUNT(1) AS c FROM {self.pfx}_params WHERE symbol=? AND tactic=?",
                (str(symbol), str(tactic)),
            ).fetchone()
            c = int(row["c"]) if row and "c" in row.keys() else 0
            if c > 0:
                return

            seeds = self._cfg_param_sets(tactic, self.cfg) or self._default_seeds(tactic, self.cfg)
            now = _now()
            cur = self.conn.cursor()
            for p in seeds:
                pid = str(p.get("id") or f"seed_{int(now)}")
                stop = _f(p.get("stop_atr_mult"), 2.5)
                tp = _f(p.get("tp_atr_mult"), 4.0)
                cur.execute(
                    f"""
                    INSERT OR IGNORE INTO {self.pfx}_params(symbol,tactic,param_id,stop_atr_mult,tp_atr_mult,n,mean,m2,created_ts,updated_ts,active,source)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (str(symbol), str(tactic), pid, float(stop), float(tp), 0, 0.0, 0.0, now, now, 1, "seed"),
                )
            self.conn.commit()

    def get_param_sets(self, symbol: str, tactic: str) -> List[Dict[str, Any]]:
        if not self.conn or not self.enabled():
            return []
        sym = str(symbol)
        tac = str(tactic)
        self._seed_if_missing(sym, tac)

        with self._lock:
            rows = self._execute(
                f"""
                SELECT param_id, stop_atr_mult, tp_atr_mult, n, mean, m2, created_ts, updated_ts, active, source
                FROM {self.pfx}_params
                WHERE symbol=? AND tactic=? AND active=1
                ORDER BY mean DESC, n DESC, updated_ts DESC
                """,
                (sym, tac),
            ).fetchall() or []

        out: List[Dict[str, Any]] = []
        for r in rows:
            out.append(
                {
                    "id": str(r["param_id"]),
                    "stop_atr_mult": float(r["stop_atr_mult"]),
                    "tp_atr_mult": float(r["tp_atr_mult"]),
                    "n": int(r["n"]),
                    "mean": float(r["mean"]),
                    "std": math.sqrt(max(0.0, float(r["m2"]) / max(1.0, float(int(r["n"]) - 1)))) if int(r["n"]) > 1 else 0.0,
                    "source": str(r["source"] or ""),
                    "updated_ts": float(r["updated_ts"] or 0.0),
                }
            )
        return out[: self.max_sets()]

    def param_sets_override_for_symbol(self, symbol: str, tactics: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        if not self.conn or not self.enabled():
            return {}
        out: Dict[str, List[Dict[str, Any]]] = {}
        for t in tactics:
            t = str(t)
            if not t or t == "none":
                continue
            psets = self.get_param_sets(symbol, t)
            if psets:
                # UI/engine often expects only stop/tp/id
                out[t] = [{"id": p["id"], "stop_atr_mult": p["stop_atr_mult"], "tp_atr_mult": p["tp_atr_mult"]} for p in psets]
        return out

    # -----------------------------
    # Online updates
    # -----------------------------
    def _welford_update(self, mean: float, m2: float, n: int, x: float) -> Tuple[float, float, int]:
        n2 = int(n) + 1
        delta = float(x) - float(mean)
        mean2 = float(mean) + delta / max(1, n2)
        delta2 = float(x) - float(mean2)
        m2_2 = float(m2) + delta * delta2
        return mean2, m2_2, n2

    def record_micro_score(self, symbol: str, tactic: str, param_id: str, score: float) -> None:
        """Record micro-backtest score as a weak signal."""
        if not self.conn or not self.enabled():
            return
        sym, tac, pid = str(symbol), str(tactic), str(param_id)
        now = _now()
        x = float(score)

        with self._lock:
            row = self._execute(
                f"SELECT n, mean, m2 FROM {self.pfx}_params WHERE symbol=? AND tactic=? AND param_id=?",
                (sym, tac, pid),
            ).fetchone()
            if not row:
                return

            n = _i(row["n"], 0)
            mean = _f(row["mean"], 0.0)
            m2 = _f(row["m2"], 0.0)

            mean2, m2_2, n2 = self._welford_update(mean, m2, n, x)

            self._execute(
                f"UPDATE {self.pfx}_params SET n=?, mean=?, m2=?, updated_ts=? WHERE symbol=? AND tactic=? AND param_id=?",
                (int(n2), float(mean2), float(m2_2), now, sym, tac, pid),
            )
            self.conn.commit()

    def record_trade_reward(self, symbol: str, tactic: str, param_id: str, reward: float) -> None:
        """
        Record realized reward for chosen param-set (stronger signal).
        reward should be normalized (ex: realized_pnl/notional).
        We clamp to avoid one-off outliers dominating the mean.
        """
        if not self.conn or not self.enabled():
            return

        clip = float(self.reward_clip())
        r = float(reward)
        r = _clamp(r, -clip, clip)

        w = int(self.trade_reward_weight())
        # stronger than micro score: replicate few times (cheap weighting)
        for _ in range(w):
            self.record_micro_score(symbol, tactic, param_id, r)

    # -----------------------------
    # Selection (exploration/exploitation)
    # -----------------------------
    def _ucb_score(self, mean: float, n: int, total_n: int, c: float) -> float:
        if n <= 0:
            return float("inf")
        return float(mean) + float(c) * math.sqrt(math.log(max(2, total_n)) / float(n))

    def choose_param_set(self, symbol: str, tactic: str) -> Optional[Dict[str, Any]]:
        """
        Choose a param set for execution:
          - epsilon-greedy for exploration
          - within exploitation: UCB1 among active sets
        """
        sets = self.get_param_sets(symbol, tactic)
        if not sets:
            return None

        # epsilon explore: random among all sets (bias newer slightly)
        if random.random() < float(self.exploration_eps()):
            return random.choice(sets)

        total_n = sum(int(s.get("n", 0)) for s in sets) + 1
        c = float(self.ucb_c())
        best = None
        best_score = -1e9
        for s in sets:
            sc = self._ucb_score(float(s.get("mean", 0.0)), int(s.get("n", 0)), int(total_n), c)
            if sc > best_score:
                best_score = sc
                best = s
        return best or sets[0]

    def best_param_set(self, symbol: str, tactic: str) -> Optional[Dict[str, Any]]:
        sets = self.get_param_sets(symbol, tactic)
        if not sets:
            return None
        # already ordered by mean,n,updated_ts
        return sets[0]

    # -----------------------------
    # Evolution step
    # -----------------------------
    def _last_evolve_ts(self, symbol: str, tactic: str) -> float:
        if not self.conn:
            return 0.0
        with self._lock:
            row = self._execute(
                f"SELECT last_evolve_ts FROM {self.pfx}_meta WHERE symbol=? AND tactic=?",
                (str(symbol), str(tactic)),
            ).fetchone()
        if not row:
            return 0.0
        return _f(row["last_evolve_ts"], 0.0)

    def _set_last_evolve_ts(self, symbol: str, tactic: str, ts: float) -> None:
        if not self.conn:
            return
        with self._lock:
            self._execute(
                f"INSERT OR REPLACE INTO {self.pfx}_meta(symbol,tactic,last_evolve_ts) VALUES(?,?,?)",
                (str(symbol), str(tactic), float(ts)),
            )
            self.conn.commit()

    def _active_rows(self, symbol: str, tactic: str) -> List[sqlite3.Row]:
        if not self.conn:
            return []
        with self._lock:
            rows = self._execute(
                f"""
                SELECT param_id, stop_atr_mult, tp_atr_mult, n, mean, m2, updated_ts, created_ts, source
                FROM {self.pfx}_params
                WHERE symbol=? AND tactic=? AND active=1
                ORDER BY mean DESC, n DESC, updated_ts DESC
                """,
                (str(symbol), str(tactic)),
            ).fetchall() or []
        return list(rows)

    def _pick_parent_ucb(self, rows: List[sqlite3.Row]) -> sqlite3.Row:
        if not rows:
            raise ValueError("no rows")
        total_n = sum(_i(r["n"], 0) for r in rows) + 1
        c = float(self.ucb_c())
        best = rows[0]
        best_sc = -1e9
        for r in rows:
            mean = _f(r["mean"], 0.0)
            n = _i(r["n"], 0)
            sc = self._ucb_score(mean, n, total_n, c)
            if sc > best_sc:
                best_sc = sc
                best = r
        return best

    def evolve_once(self, symbol: str, tactic: str) -> bool:
        """Mutate a child param-set from selected parents and enforce cap safely."""
        if not self.conn or not self.enabled():
            return False

        sym, tac = str(symbol), str(tactic)
        self._seed_if_missing(sym, tac)

        rows = self._active_rows(sym, tac)
        if not rows:
            return False

        max_sets = self.max_sets()
        elite_keep = min(self.elite_keep(), max_sets)
        min_n = self.min_samples_to_rank()

        # Prefer sampled rows for parent selection; otherwise use all.
        ranked = [r for r in rows if _i(r["n"], 0) >= min_n]
        pool = ranked if len(ranked) >= 2 else rows

        p1 = self._pick_parent_ucb(pool)
        # pick second parent different if possible
        pool2 = [r for r in pool if str(r["param_id"]) != str(p1["param_id"])] or pool
        p2 = self._pick_parent_ucb(pool2)

        stop_lo_hi, tp_lo_hi = self.bounds()
        mut_s = float(self.mutation_strength())
        mut_t = float(self.mutation_strength_tp())
        rr_min = float(self.min_rr())

        def _mutate_logn(x: float, strength: float) -> float:
            # log-normal multiplicative: exp(N(0, sigma))
            sigma = max(1e-6, float(strength))
            step = random.gauss(0.0, sigma)
            return float(x) * float(math.exp(step))

        # mix parents then mutate
        stop_base = 0.5 * float(p1["stop_atr_mult"]) + 0.5 * float(p2["stop_atr_mult"])
        tp_base = 0.5 * float(p1["tp_atr_mult"]) + 0.5 * float(p2["tp_atr_mult"])

        # correlated mutation: share a common factor + individual noise
        common = random.gauss(0.0, 0.5 * min(mut_s, mut_t))
        stop_new = float(stop_base) * float(math.exp(common))  # common push
        tp_new = float(tp_base) * float(math.exp(common))

        stop_new = _mutate_logn(stop_new, mut_s)
        tp_new = _mutate_logn(tp_new, mut_t)

        stop_new = _clamp(stop_new, stop_lo_hi[0], stop_lo_hi[1])
        tp_new = _clamp(tp_new, tp_lo_hi[0], tp_lo_hi[1])

        # enforce minimum RR: tp >= stop * rr_min (within bounds)
        if rr_min > 0:
            tp_new = max(tp_new, min(tp_lo_hi[1], stop_new * rr_min))

        now = _now()
        pid = f"e{int(now)}_{random.randint(100,999)}"
        source = f"mut:{p1['param_id']}+{p2['param_id']}"

        with self._lock:
            cur = self.conn.cursor()
            cur.execute(
                f"""
                INSERT OR IGNORE INTO {self.pfx}_params(symbol,tactic,param_id,stop_atr_mult,tp_atr_mult,n,mean,m2,created_ts,updated_ts,active,source)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (sym, tac, pid, float(stop_new), float(tp_new), 0, 0.0, 0.0, now, now, 1, source),
            )

            # Enforce cap: never deactivate top elites
            rows2 = self._active_rows(sym, tac)
            if len(rows2) > max_sets:
                elites = rows2[:elite_keep]  # already sorted best-first
                elite_ids = {str(r["param_id"]) for r in elites}

                # worst first (mean asc, n asc, updated asc), skipping elites
                worst = sorted(
                    [r for r in rows2 if str(r["param_id"]) not in elite_ids],
                    key=lambda r: (_f(r["mean"], 0.0), _i(r["n"], 0), _f(r["updated_ts"], 0.0)),
                )
                to_deactivate = max(0, len(rows2) - max_sets)
                for r in worst[:to_deactivate]:
                    cur.execute(
                        f"UPDATE {self.pfx}_params SET active=0, updated_ts=? WHERE symbol=? AND tactic=? AND param_id=?",
                        (now, sym, tac, str(r["param_id"])),
                    )

            self.conn.commit()

        self._set_last_evolve_ts(sym, tac, now)
        _safe_log(self.log, "info", f"[evolver] evolved {sym}/{tac} -> {pid} stop={stop_new:.3f} tp={tp_new:.3f} src={source}")
        return True

    def tick(self, symbols: List[str], tactics: List[str]) -> None:
        """Run periodic evolution for a set of symbols/tactics."""
        if not self.conn or not self.enabled():
            return
        now = _now()
        interval = self.evolve_interval_sec()
        for sym in symbols:
            for t in tactics:
                t = str(t)
                if not t or t == "none":
                    continue
                try:
                    last = self._last_evolve_ts(sym, t)
                    if interval > 0 and (now - float(last)) < float(interval):
                        continue
                    self.evolve_once(sym, t)
                except Exception as e:
                    _safe_log(self.log, "warning", f"[evolver] tick failed {sym}/{t}: {type(e).__name__}: {e}")
                    continue
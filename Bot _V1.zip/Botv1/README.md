# Self-hosted Crypto Spot Bot (Binance + Bybit) — V7

Educational project. No profit is guaranteed. Start in PAPER mode.

## V7 additions (stability + explainability + journal)
- **API auto-port**: avoids `Errno 10048` bind errors by auto-selecting a free port.
- **Clean shutdown**: STOP closes engine + local API thread safely.
- **Signals tab + explain**: GUI shows latest signals + structured explanation (components/indicators).
- **SQLite journal enhanced**: signals/trades/snapshots persist locally; GUI can export trades/signals CSV.
- **Prometheus exporter singleton**: prevents duplicated timeseries when restarting the engine from the GUI.


## Implemented improvements (the 12 items)
1) **WebSocket market data**: native WS ticker cache (Binance + Bybit v5 spot) to reduce polling.
2) **Order placement safe layer**: enforces min amount/cost/precision; tick/step handled via CCXT precision helpers.
3) **Partial fills**: live pending orders track `filled_qty`; incremental fills update positions.
4) **Portfolio allocation (correlation filter)**: blocks new entries if correlation vs open positions exceeds threshold.
5) **Order book slippage model**: estimates expected market slippage from depth before market fallback.
6) **Kill switch extended**: daily loss, max drawdown, trades/day + **intraday shock** window.
7) **Multi-timeframe confirmation**: trend bias from higher TF dampens conflicting signals.
8) **Regime detection (range/trend)**: lightweight regime classifier adjusts signal scoring.
9) **Walk-forward optimization (optional)**: light grid search on TRAIN and validate on TEST; applies strategy params safely.
10) **Metrics dashboard**: GUI Metrics tab + equity history, trades/errors/fees/PNL counters.
11) **Docker + .env + secrets hygiene**: `.env.example`, docker-compose; read keys from env (`BOT_API_KEY`, `BOT_API_SECRET`).
12) **Test suite + CI**: pytest tests + GitHub Actions workflow.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python crypto_bot_gui.py
```

## Environment variables (recommended for LIVE)
- `BOT_API_KEY`
- `BOT_API_SECRET`
- `BOT_EXCHANGE` (binance/bybit)
- `BOT_MODE` (paper/live)

## Prometheus exporter
Enabled by default (port 9108). Disable via `config.json -> metrics.prometheus.enabled=false`.

## Docker
```bash
cp .env.example .env
docker compose up --build
```

> NOTE: GUI apps in docker depend on platform. For server/VPS you usually run headless and expose metrics + logs.
> This project keeps GUI as primary; docker here is mainly for dependency pinning and CI parity.

## V6 additions

- Local-only control API (FastAPI) bound to `127.0.0.1` (no external exposure by default)
- Human-in-the-loop approvals (optional, recommended for LIVE)
- SQLite audit log (`bot.db`) for trades, signals, events, snapshots
- MarketGuard circuit breaker (ATR% + breadth)
- Multi-quote universe support via `quote_assets`
- Profiles: `profiles/conservative.json`, `profiles/balanced.json`, `profiles/aggressive.json`

### Headless run (local)

```bash
pip install -r requirements.txt
python -m app.run --config config.json --api --i-understand-live-risks
```

### Approvals

If `approvals.require_for_live=true`, BUY entries in LIVE mode will be queued as pending approvals.
You can approve/reject from:

- GUI tab **Approvals**
- API endpoints:
  - `GET /approvals`
  - `POST /approvals/{id}/approve`
  - `POST /approvals/{id}/reject`

### Safety note

This project is for educational / experimentation use. There is no guarantee of profit. Use paper mode first.

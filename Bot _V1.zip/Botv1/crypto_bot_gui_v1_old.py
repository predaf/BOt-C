
from __future__ import annotations
import os, threading, time, json

from dotenv import load_dotenv
load_dotenv()
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from app.config import load_config, save_config, apply_env_overrides
from app.utils import UILogger, CompositeLogger, setup_file_logger
from app.records import TradeRecorder
from app.engine import TradingEngine

# Optional local API
try:
    import uvicorn
    from app.api import create_app
except Exception:
    uvicorn = None
    create_app = None

DEFAULT_CONFIG = {
  "mode": "paper",
  "exchange": "binance",
  "api_key": "",
  "api_secret": "",
  "sandbox": False,
  "bybit_testnet": False,
  "quote_asset": "USDT",
  "signal_timeframe": "5m",
  "trend_timeframe": "1h",
  "ohlcv_limit": 500,
  "max_pairs": 12,
  "pair_refresh_sec": 900,
  "scan_interval_sec": 15,
  "pair_filters": {
    "min_quote_volume_usd": 5000000,
    "min_price_usd": 0.01,
    "max_spread_bps": 25,
    "exclude_leveraged_tokens": True,
    "whitelist": [],
    "blacklist": []
  },
  "execution": {
    "type": "maker_limit",
    "post_only": True,
    "maker_offset_bps": 2.0,
    "repost_sec": 15,
    "max_reposts": 8,
    "allow_market_fallback": True,
    "retry": {
      "enabled": True,
      "max_retries": 6,
      "base_delay_ms": 250,
      "max_delay_ms": 5000,
      "jitter_ms": 250
    },
    "idempotency": {
      "enabled": True,
      "prefix": "bot"
    },
    "smart_limit": {
      "edge_bps": 6,
      "max_move_bps": 25,
      "max_wait_sec": 15
    }
  },
  "micro_model": {
    "enabled": True,
    "orderbook_depth": 20,
    "max_spread_bps_for_maker": 35.0,
    "min_p_fill_for_maker": 0.25,
    "dynamic_offset": True,
    "offset_min_bps": 1.0,
    "offset_max_bps": 14.0,
    "k_distance": 0.22,
    "k_vol": 8.0,
    "use_imbalance": True
  },
  "websocket": {
    "enabled": True,
    "provider": "native",
    "symbols_max": 60,
    "reconnect_sec": 5
  },
  "paper": {
    "initial_cash_quote": 2000.0,
    "taker_fee_rate": 0.001,
    "maker_fee_rate": 0.0008,
    "market_slippage_bps": 8.0,
    "limit_slippage_bps": 0.0,
    "limit_fill_model": {
      "near_bps": 6.0,
      "p_near": 0.35,
      "timeout_sec": 240,
      "timeout_action": "cancel"
    }
  },
  "risk": {
    "risk_per_trade": 0.005,
    "max_position_pct": 0.15,
    "max_open_positions": 3,
    "cooldown_sec": 120,
    "atr_period": 14,
    "stop_atr_mult": 2.5,
    "tp_atr_mult": 3.5,
    "use_trailing": True,
    "trail_atr_mult": 2.0,
    "volatility_pause_atr_pct": 0.03,
    "scale_out": {
      "enabled": True,
      "tp1_atr_mult": 2.0,
      "tp1_pct": 0.5,
      "move_stop_to_be": True
    },
    "kill_switch": {
      "max_daily_loss_pct": 0.03,
      "max_drawdown_pct": 0.08,
      "max_trades_per_day": 50,
      "close_all_on_halt": False,
      "intraday_shock": {
        "enabled": True,
        "window_min": 30,
        "drop_pct": 0.015
      }
    },
    "portfolio": {
      "correlation_filter": {
        "enabled": True,
        "lookback": 120,
        "max_corr": 0.8
      },
      "sector_limit": {
        "enabled": False,
        "max_per_tag": 2,
        "tags": {}
      }
    }
  },
  "strategies": {
    "ema_cross": {
      "enabled": True,
      "fast": 12,
      "slow": 26
    },
    "rsi_reversion": {
      "enabled": True,
      "period": 14,
      "buy_below": 30,
      "sell_above": 70
    },
    "donchian_breakout": {
      "enabled": True,
      "lookback": 20
    },
    "momentum_filter": {
      "enabled": True,
      "lookback": 20,
      "min_return": 0.003
    },
    "mtf_confirm": {
      "enabled": True,
      "require_trend_agree": True
    },
    "regime": {
      "enabled": True,
      "mode": "auto"
    }
  },
  "auto_opt": {
    "enabled": False,
    "interval_hours": 12,
    "walk_forward": {
      "train_frac": 0.7,
      "candidates": {
        "ema_fast": [
          8,
          12,
          16
        ],
        "ema_slow": [
          21,
          26,
          34
        ],
        "rsi_buy": [
          28,
          30,
          32
        ],
        "rsi_sell": [
          68,
          70,
          72
        ]
      }
    }
  },
  "metrics": {
    "enabled": True,
    "prometheus": {
      "enabled": True,
      "port": 9108
    }
  },
  "state": {
    "enable_persistence": True,
    "resume_on_start": False,
    "save_interval_sec": 30,
    "path": "state.json"
  },
  "watchdog": {
    "enabled": True,
    "max_consecutive_errors": 8,
    "pause_sec": 120,
    "backoff_factor": 1.7,
    "max_pause_sec": 1800,
    "auto_resume": True
  },
  "paths": {
    "log_file": "logs/bot.log",
    "trades_csv": "trades.csv"
  },
  "quote_assets": [
    "USDT",
    "USDC"
  ],
  "api": {
    "enabled": False,
    "host": "127.0.0.1",
    "port": 8000,
    "auto_port": True,
    "max_port_tries": 50
  },
  "approvals": {
    "enabled": True,
    "timeout_sec": 300,
    "require_for_live": True,
    "require_for_paper": False
  },
  "sqlite": {
    "enabled": True,
    "path": "bot.db"
  },
  "notifier": {
    "enabled": False,
    "telegram": {
      "enabled": False,
      "bot_token": "",
      "chat_id": ""
    },
    "email": {
      "enabled": False,
      "smtp_host": "",
      "smtp_port": 587,
      "username": "",
      "password": "",
      "to": "",
      "use_tls": True
    }
  },
  "market_guard": {
    "enabled": True,
    "timeframe": "5m",
    "symbols": [
      "BTC/USDT",
      "ETH/USDT"
    ],
    "atr_period": 14,
    "atr_pct_halt": 0.02,
    "cooldown_sec": 300,
    "breadth_universe_max": 40,
    "breadth_drop_pct": 0.65,
    "breadth_lookback_bars": 6
  },
  "signal_thresholds": {
    "buy": 1.0,
    "sell": -1.0
  },
  "signals": {
    "history_max": 2000,
    "record_hold": False,
    "snapshot_interval_sec": 10
  }
}



# ---- Robust config loading ----
def safe_load_config(path: str, default_cfg: dict):
    """Load config.json safely. If invalid JSON, it backs up the file and recreates defaults."""
    try:
        return load_config(path, default_cfg)
    except json.JSONDecodeError as e:
        # Backup broken file and recreate defaults
        try:
            import shutil, datetime
            ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            bak = f"{path}.broken_{ts}"
            shutil.copy2(path, bak)
        except Exception:
            bak = None
        try:
            save_config(path, default_cfg)
        except Exception:
            pass
        msg = f"Config JSON invalid: {e}. Reset to defaults." + (f" Backup: {bak}" if bak else '')
        return json.loads(json.dumps(default_cfg)), msg
    except Exception as e:
        return json.loads(json.dumps(default_cfg)), f"Config load failed: {e}. Using defaults."
def _parse_list(text: str):
    items=[]
    for line in text.replace(",", "\n").splitlines():
        s=line.strip().upper()
        if s:
            items.append(s)
    out=[]; seen=set()
    for s in items:
        if s not in seen:
            seen.add(s); out.append(s)
    return out

class BotGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Crypto Bot — V8.2 (Binance + Bybit)")
        self.geometry("1600x950")
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.cfg_path = os.path.join(self.base_dir, "config.json")
        loaded = safe_load_config(self.cfg_path, DEFAULT_CONFIG)
        if isinstance(loaded, tuple):
            self.cfg, self._cfg_warn = loaded
        else:
            self.cfg, self._cfg_warn = loaded, None
        self.cfg = apply_env_overrides(self.cfg)

        self.ui = UILogger()
        self.log = CompositeLogger(self.ui, setup_file_logger(os.path.join(self.base_dir, self.cfg["paths"]["log_file"])))

        if getattr(self, '_cfg_warn', None):
            try:
                messagebox.showwarning('Config reset', self._cfg_warn)
            except Exception:
                pass
            try:
                self.log.warn(self._cfg_warn)
            except Exception:
                pass
        self.rec = TradeRecorder()

        self.engine: TradingEngine|None = None
        self.t_engine: threading.Thread|None = None
        self.api_server = None
        self.t_api: threading.Thread|None = None

        self._build()
        self._load_to_ui()

        self.after(250, self._pump_logs)
        self.after(900, self._refresh)

    def _build(self):
        from gui_tabs import build_tabs
        build_tabs(self)


    def _on_select_signal(self, _evt=None):
        try:
            sel = self.sig_tree.selection()
            if not sel:
                return
            iid = sel[0]
            idx = int(self.sig_tree.item(iid, "tags")[0])
            row = self._signals_cache[idx]
            self.sig_explain.delete("1.0", "end")
            self.sig_explain.insert("end", json.dumps(row.get("details", {}), indent=2))
        except Exception:
            pass

    def _refresh_signals(self):
        try:
            if not self.engine:
                self.lbl_sig.config(text="Signals: engine not running")
                self.after(1000, self._refresh_signals)
                return
            items = []
            try:
                items = self.engine.get_signals_latest()
            except Exception:
                items = []
            self._signals_cache = items

            # refresh tree
            for x in self.sig_tree.get_children():
                self.sig_tree.delete(x)
            for i, row in enumerate(items):
                ts = row.get("ts","")
                sym = row.get("symbol","")
                act = row.get("action","")
                st = float(row.get("strength",0.0))
                pr = row.get("price", "")
                rs = row.get("reason","")
                iid = self.sig_tree.insert("", "end", values=(ts, sym, act, f"{st:.2f}", f"{pr}", rs), tags=(str(i),))
            self.lbl_sig.config(text=f"Signals: {len(items)}")
        finally:
            self.after(1500, self._refresh_signals)

    def _export_signals_csv(self):
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if not p:
            return
        # Prefer sqlite journal if available
        try:
            if self.engine and getattr(self.engine, "store", None):
                self.engine.store.export_signals_csv(p)
                self.log.info(f"Signals exported to {p}")
                return
        except Exception:
            pass
        # Fallback: export latest
        try:
            import csv
            rows = self.engine.get_signals_latest() if self.engine else []
            cols = ["ts","symbol","action","strength","price","reason"]
            with open(p, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=cols)
                w.writeheader()
                for r in rows:
                    w.writerow({k: r.get(k,"") for k in cols})
            self.log.info(f"Signals exported to {p}")
        except Exception as e:
            messagebox.showerror("Export", str(e))


    # ---------------- Backtest / Optimizer ----------------
    def _build_backtest(self):
        frm = self.t_backtest

        top = ttk.Frame(frm)
        top.pack(fill="x", padx=10, pady=8)

        # Symbols input
        ttk.Label(top, text="Symbols (comma-separated)").pack(side="left")
        self.var_bt_symbols = tk.StringVar(value=self._default_bt_symbols())
        ent = ttk.Entry(top, textvariable=self.var_bt_symbols, width=55)
        ent.pack(side="left", padx=6)

        ttk.Label(top, text="Bars").pack(side="left", padx=(10,0))
        self.var_bt_bars = tk.IntVar(value=int(self.cfg.get("auto_opt", {}).get("backtest_bars", 1500) or 1500))
        ttk.Entry(top, textvariable=self.var_bt_bars, width=8).pack(side="left", padx=6)

        ttk.Label(top, text="Signal TF").pack(side="left", padx=(10,0))
        self.var_bt_tf = tk.StringVar(value=str(self.cfg.get("signal_timeframe","5m")))
        ttk.Combobox(top, textvariable=self.var_bt_tf, width=6, values=("1m","3m","5m","15m","30m","1h","2h","4h","1d"), state="readonly").pack(side="left", padx=6)

        ttk.Label(top, text="Trend TF").pack(side="left", padx=(10,0))
        self.var_bt_trend_tf = tk.StringVar(value=str(self.cfg.get("trend_timeframe","15m")))
        ttk.Combobox(top, textvariable=self.var_bt_trend_tf, width=6, values=("5m","15m","30m","1h","2h","4h","1d"), state="readonly").pack(side="left", padx=6)

        self.var_bt_use_wfo = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="Walk-forward optimize (WFO light)", variable=self.var_bt_use_wfo).pack(side="left", padx=(12,0))

        btns = ttk.Frame(frm)
        btns.pack(fill="x", padx=10, pady=(0,8))

        self.btn_bt_run = ttk.Button(btns, text="Run", command=self._bt_start_run)
        self.btn_bt_run.pack(side="left")

        self.btn_bt_opt = ttk.Button(btns, text="Optimize (global)", command=self._bt_start_global_opt)
        self.btn_bt_opt.pack(side="left", padx=8)

        self.btn_bt_cancel = ttk.Button(btns, text="Cancel", command=self._bt_cancel_run, state="disabled")
        self.btn_bt_cancel.pack(side="left", padx=8)

        ttk.Button(btns, text="Export results CSV", command=self._bt_export_csv).pack(side="left", padx=8)

        self.lbl_bt = ttk.Label(btns, text="Backtest: idle")
        self.lbl_bt.pack(side="right")

        body = ttk.Frame(frm)
        body.pack(fill="both", expand=True, padx=10, pady=8)

        cols = ("symbol","trades","win_rate","return_pct","max_dd","profit_factor","equity_end","note")
        self.bt_tree = ttk.Treeview(body, columns=cols, show="headings", height=18)
        for c in cols:
            self.bt_tree.heading(c, text=c)
            self.bt_tree.column(c, width=120 if c not in ("note",) else 420, anchor="w")
        self.bt_tree.column("symbol", width=120)
        self.bt_tree.column("trades", width=70, anchor="e")
        self.bt_tree.column("win_rate", width=90, anchor="e")
        self.bt_tree.column("return_pct", width=90, anchor="e")
        self.bt_tree.column("max_dd", width=90, anchor="e")
        self.bt_tree.column("profit_factor", width=90, anchor="e")
        self.bt_tree.column("equity_end", width=110, anchor="e")

        ysb = ttk.Scrollbar(body, orient="vertical", command=self.bt_tree.yview)
        self.bt_tree.configure(yscroll=ysb.set)
        self.bt_tree.pack(side="left", fill="both", expand=True)
        ysb.pack(side="right", fill="y")

        self._bt_results = []
        self._bt_running = False
        self._bt_cancel_flag = False
        self._bt_mode = "run"
        self._bt_thread = None

    def _default_bt_symbols(self) -> str:
        wl = (self.cfg.get("pair_filters", {}) or {}).get("whitelist", []) or []
        if wl:
            return ",".join(wl[:12])
        # sensible defaults
        return "BTC/USDT,ETH/USDT,BNB/USDT,SOL/USDT,XRP/USDT,ADA/USDT,DOGE/USDT"

    def _bt_start_run(self):
        if self._bt_running:
            return
        # Pull latest settings into cfg
        try:
            self._save_from_ui()
        except Exception:
            pass
        self._bt_cancel_flag = False
        self._bt_running = True
        self._bt_mode = "run"
        self.btn_bt_run.config(state="disabled")
        self.btn_bt_opt.config(state="disabled")
        self.btn_bt_cancel.config(state="normal")
        self.lbl_bt.config(text="Backtest: running...")

        t = threading.Thread(target=self._bt_worker, daemon=True)
        self._bt_thread = t
        t.start()

    def _bt_start_global_opt(self):
        if self._bt_running:
            return
        try:
            self._save_from_ui()
        except Exception:
            pass
        self._bt_cancel_flag = False
        self._bt_running = True
        self._bt_mode = "optimize"
        self.btn_bt_run.config(state="disabled")
        self.btn_bt_opt.config(state="disabled")
        self.btn_bt_cancel.config(state="normal")
        self.lbl_bt.config(text="Optimizer: running...")

        t = threading.Thread(target=self._bt_worker, daemon=True)
        self._bt_thread = t
        t.start()


    def _bt_cancel_run(self):
        self._bt_cancel_flag = True
        self.lbl_bt.config(text="Backtest: cancelling...")

    def _bt_worker(self):
        # Runs in background thread
        import json
        from app.exchange import ExchangeClient
        from app.backtest import simulate, walk_forward_optimize

        cfg = json.loads(json.dumps(self.cfg))
        # ensure paper mode for simulation
        cfg["mode"] = "paper"

        symbols = [s.strip() for s in str(self.var_bt_symbols.get()).split(",") if s.strip()]
        bars = max(250, int(self.var_bt_bars.get() or 1500))
        tf = str(self.var_bt_tf.get() or cfg.get("signal_timeframe","5m"))
        trend_tf = str(self.var_bt_trend_tf.get() or cfg.get("trend_timeframe","15m"))
        use_wfo = bool(self.var_bt_use_wfo.get())

        # Helpers shared by run + optimizer
        log = self.log
        client = ExchangeClient(cfg, log)

        def tf_minutes(x: str) -> int:
            x = str(x).strip().lower()
            if x.endswith('m'):
                return int(x[:-1])
            if x.endswith('h'):
                return int(x[:-1]) * 60
            if x.endswith('d'):
                return int(x[:-1]) * 1440
            return 5

        ratio = max(1.0, tf_minutes(trend_tf) / max(1.0, tf_minutes(tf)))
        trend_bars = int(bars / ratio) + 250
        trend_bars = max(250, min(5000, trend_bars))

        # Global optimizer: grid-search candidate params across symbols on TRAIN set, then backtest full period.
        if getattr(self, "_bt_mode", "run") == "optimize":
            auto = cfg.get("auto_opt", {}) or {}
            wf = auto.get("walk_forward", {}) or {}
            train_frac = float(wf.get("train_frac", 0.7))
            cand = wf.get("candidates", {}) or {}

            # Pre-fetch data for all symbols (so we don't refetch per combo)
            data = []
            for sym in symbols:
                if self._bt_cancel_flag:
                    break
                try:
                    df_sym = client.fetch_ohlcv_df(sym, tf, bars)
                    df_tr_sym = client.fetch_ohlcv_df(sym, trend_tf, trend_bars)
                    data.append((sym, df_sym, df_tr_sym))
                except Exception as e:
                    data.append((sym, None, None))
                    log.warn(f"Optimizer fetch failed for {sym}: {e}")

            best_score = None
            best_params = None

            def score_result(r):
                pf = (r.profit_factor if (r.profit_factor is not None and r.profit_factor == r.profit_factor) else 0.0)
                return (pf if pf != float("inf") else 5.0) + 0.02*r.total_return_pct - 0.02*r.max_dd_pct

            for fast in cand.get("ema_fast", [12]):
                for slow in cand.get("ema_slow", [26]):
                    if slow <= fast:
                        continue
                    for rb in cand.get("rsi_buy", [30]):
                        for rs in cand.get("rsi_sell", [70]):
                            if self._bt_cancel_flag:
                                break
                            # build candidate cfg
                            c_try = json.loads(json.dumps(cfg))
                            c_try["strategies"]["ema_cross"]["fast"] = fast
                            c_try["strategies"]["ema_cross"]["slow"] = slow
                            c_try["strategies"]["rsi_reversion"]["buy_below"] = rb
                            c_try["strategies"]["rsi_reversion"]["sell_above"] = rs

                            # average score across symbols on TRAIN slice
                            scores=[]
                            for sym, df_sym, df_tr_sym in data:
                                if df_sym is None or df_tr_sym is None or len(df_sym) < 200:
                                    continue
                                cut = int(len(df_sym) * train_frac)
                                df_tr = df_sym.iloc[:cut].copy()
                                t_end = df_tr["ts"].iloc[-1]
                                df_trend_tr = df_tr_sym[df_tr_sym["ts"] <= t_end].copy()
                                if len(df_trend_tr) < 120:
                                    df_trend_tr = df_tr_sym
                                r_tr = simulate(c_try, df_tr, df_trend_tr)
                                scores.append(score_result(r_tr))
                            if not scores:
                                continue
                            s_avg = sum(scores)/len(scores)
                            if (best_score is None) or (s_avg > best_score):
                                best_score = s_avg
                                best_params = (fast, slow, rb, rs)

            # If no best, fall back to normal run
            if best_params is None:
                self._bt_mode = "run"
            else:
                fast, slow, rb, rs = best_params
                cfg_best = json.loads(json.dumps(cfg))
                cfg_best["strategies"]["ema_cross"]["fast"] = fast
                cfg_best["strategies"]["ema_cross"]["slow"] = slow
                cfg_best["strategies"]["rsi_reversion"]["buy_below"] = rb
                cfg_best["strategies"]["rsi_reversion"]["sell_above"] = rs
                note_global = f"GLOBAL OPT ema_fast={fast} ema_slow={slow} rsi_buy={rb} rsi_sell={rs} score={best_score:.3f}"

                results=[]
                for i, (sym, df_sym, df_tr_sym) in enumerate(data, start=1):
                    if self._bt_cancel_flag:
                        break
                    if df_sym is None or df_tr_sym is None:
                        results.append({
                            "symbol": sym, "trades": 0, "win_rate": 0.0, "return_pct": 0.0, "max_dd": 0.0,
                            "profit_factor": 0.0, "equity_end": 0.0, "note": "ERROR: fetch failed"
                        })
                        continue
                    r = simulate(cfg_best, df_sym, df_tr_sym)
                    results.append({
                        "symbol": sym,
                        "trades": int(r.trades),
                        "win_rate": float(r.win_rate_pct),
                        "return_pct": float(r.total_return_pct),
                        "max_dd": float(r.max_dd_pct),
                        "profit_factor": float(r.profit_factor) if r.profit_factor != float("inf") else 9999.0,
                        "equity_end": float(r.equity_end),
                        "note": note_global
                    })
                    self.after(0, lambda cur=i, total=len(symbols): self.lbl_bt.config(text=f"Optimizer: {cur}/{total}"))

                results.sort(key=lambda x: (x.get("return_pct",0.0), x.get("profit_factor",0.0)), reverse=True)
                self.after(0, lambda res=results: self._bt_set_results(res))
                return


        # apply selected TFs to cfg for strategy computations
        cfg["signal_timeframe"] = tf
        cfg["trend_timeframe"] = trend_tf


        results=[]
        for i, sym in enumerate(symbols, start=1):
            if self._bt_cancel_flag:
                break
            try:
                df = client.fetch_ohlcv_df(sym, tf, bars)
                df_trend = client.fetch_ohlcv_df(sym, trend_tf, trend_bars)
                # WFO light (per-symbol), using cfg.auto_opt.walk_forward candidates
                c_run = cfg
                note=""
                if use_wfo:
                    c_run = walk_forward_optimize(cfg, df, df_trend)
                    note = str(c_run.get("_auto_opt_note",""))
                r = simulate(c_run, df, df_trend)
                results.append({
                    "symbol": sym,
                    "trades": int(r.trades),
                    "win_rate": float(r.win_rate_pct),
                    "return_pct": float(r.total_return_pct),
                    "max_dd": float(r.max_dd_pct),
                    "profit_factor": float(r.profit_factor) if r.profit_factor != float("inf") else 9999.0,
                    "equity_end": float(r.equity_end),
                    "note": note
                })
            except Exception as e:
                results.append({
                    "symbol": sym,
                    "trades": 0,
                    "win_rate": 0.0,
                    "return_pct": 0.0,
                    "max_dd": 0.0,
                    "profit_factor": 0.0,
                    "equity_end": 0.0,
                    "note": f"ERROR: {e}"
                })
            # schedule UI update
            self.after(0, lambda cur=i, total=len(symbols): self.lbl_bt.config(text=f"Backtest: {cur}/{total}"))

        # sort by return desc then PF
        results.sort(key=lambda x: (x.get("return_pct",0.0), x.get("profit_factor",0.0)), reverse=True)
        self.after(0, lambda res=results: self._bt_set_results(res))

    def _bt_set_results(self, results):
        self._bt_results = results
        for iid in self.bt_tree.get_children():
            self.bt_tree.delete(iid)
        for row in results:
            vals = (
                row["symbol"],
                row["trades"],
                f"{row['win_rate']:.1f}",
                f"{row['return_pct']:.2f}",
                f"{row['max_dd']:.2f}",
                f"{row['profit_factor']:.2f}",
                f"{row['equity_end']:.2f}",
                row.get("note","")[:400],
            )
            self.bt_tree.insert("", "end", values=vals)

        self._bt_running = False
        self.btn_bt_run.config(state="normal")
        try:
            self.btn_bt_opt.config(state="normal")
        except Exception:
            pass
        self.btn_bt_cancel.config(state="disabled")
        if self._bt_cancel_flag:
            self.lbl_bt.config(text="Backtest: cancelled")
        else:
            self.lbl_bt.config(text=f"Backtest: done ({len(results)} symbols)")

    def _bt_export_csv(self):
        import csv
        if not self._bt_results:
            messagebox.showinfo("Export", "No backtest results to export.")
            return
        fp = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if not fp:
            return
        with open(fp, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["symbol","trades","win_rate","return_pct","max_dd","profit_factor","equity_end","note"])
            w.writeheader()
            for r in self._bt_results:
                w.writerow(r)
        messagebox.showinfo("Export", f"Saved: {fp}")

    def _log_append(self, s: str):
        self.txt.configure(state="normal")
        self.txt.insert("end", s + "\n")
        self.txt.see("end")
        self.txt.configure(state="disabled")

    def _pump_logs(self):
        try:
            while True:
                self._log_append(self.ui.q.get_nowait())
        except Exception:
            pass
        self.after(250, self._pump_logs)

    def _apply_profile(self):
        p=self.var_profile.get()
        if p=="(none)":
            return
        prof=os.path.join(self.base_dir,"profiles",f"{p}.json")
        if not os.path.exists(prof):
            messagebox.showerror("Missing profile", prof); return
        self.cfg=load_config(prof, DEFAULT_CONFIG)
        self.cfg=apply_env_overrides(self.cfg)
        self._load_to_ui()
        self.log.info(f"Applied profile: {p}")

    def _load_to_ui(self):
        c=self.cfg
        self.var_mode.set(c.get("mode","paper"))
        self.var_exchange.set(c.get("exchange","binance"))
        self.ent_key.delete(0,"end"); self.ent_key.insert(0, c.get("api_key",""))
        self.ent_secret.delete(0,"end"); self.ent_secret.insert(0, c.get("api_secret",""))
        self.var_scan.set(int(c.get("scan_interval_sec", 15)))
        self.var_exec.set(c.get("execution",{}).get("type","smart_limit"))
        self.var_post.set(bool(c.get("execution",{}).get("post_only", True)))
        self.var_allow_fb.set(bool(c.get("execution",{}).get("allow_market_fallback", True)))
        self.txt_w.delete("1.0","end"); self.txt_w.insert("end","\n".join(c.get("pair_filters",{}).get("whitelist") or []))
        self.txt_b.delete("1.0","end"); self.txt_b.insert("end","\n".join(c.get("pair_filters",{}).get("blacklist") or []))
        self.var_require_appr.set(bool(c.get("approvals",{}).get("require_for_live", True)))
        self.var_api.set(bool(c.get("api",{}).get("enabled", False)))

    def _save_from_ui(self):
        c=self.cfg
        c["mode"]=self.var_mode.get()
        c["exchange"]=self.var_exchange.get()
        c["api_key"]=self.ent_key.get().strip()
        c["api_secret"]=self.ent_secret.get().strip()
        c["scan_interval_sec"]=int(self.var_scan.get())
        c.setdefault("execution", {})["type"]=self.var_exec.get()
        c["execution"]["post_only"]=bool(self.var_post.get())
        c["execution"]["allow_market_fallback"]=bool(self.var_allow_fb.get())
        c.setdefault("pair_filters", {})["whitelist"]=_parse_list(self.txt_w.get("1.0","end"))
        c["pair_filters"]["blacklist"]=_parse_list(self.txt_b.get("1.0","end"))
        c.setdefault("approvals", {})["require_for_live"]=bool(self.var_require_appr.get())
        c.setdefault("api", {})["enabled"]=bool(self.var_api.get())
        c["api"]["host"]="127.0.0.1"
        save_config(self.cfg_path, c)
        self.log.info("Config saved.")

    def _load_cfg(self):
        p=filedialog.askopenfilename(title="Select config.json", filetypes=[("JSON","*.json")])
        if not p: return
        self.cfg=load_config(p, DEFAULT_CONFIG)
        self.cfg=apply_env_overrides(self.cfg)
        self.cfg_path=p
        self._load_to_ui()
        self.log.info(f"Loaded config: {p}")

    def _export_trades(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if not p: return
        # Prefer sqlite journal if available
        try:
            if self.engine and getattr(self.engine, "store", None):
                self.engine.store.export_trades_csv(p)
                self.log.info(f"Trades exported to {p}")
                return
        except Exception:
            pass
        # Fallback to in-memory recorder
        self.rec.export_csv(p)
        self.log.info(f"Trades exported to {p}")


    def _validate_live(self):
        if self.cfg.get("mode")!="live":
            return
        r=float(self.cfg.get("risk",{}).get("risk_per_trade", 0.005))
        if r>0.02:
            raise ValueError("risk_per_trade too high (>2%)")
        if not self.cfg.get("api_key") or not self.cfg.get("api_secret"):
            raise ValueError("Live requires API key+secret (or env vars).")
        if self.cfg.get("approvals",{}).get("require_for_live", True) and not self.cfg.get("api",{}).get("enabled", False):
            raise ValueError("Live approvals are required but local API is disabled. Enable API in Settings.")

    
    def _is_port_free(self, host: str, port: int) -> bool:
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, int(port)))
            s.close()
            return True
        except Exception:
            return False

    def _pick_free_port(self, host: str, start_port: int, tries: int = 50) -> int:
        p = int(start_port)
        for _ in range(max(1, int(tries))):
            if self._is_port_free(host, p):
                return p
            p += 1
        return int(start_port)

    def _stop_api(self):
        try:
            if getattr(self, "api_server", None):
                self.api_server.should_exit = True
            if getattr(self, "t_api", None):
                try:
                    self.t_api.join(timeout=2.0)
                except Exception:
                    pass
        except Exception:
            pass
        self.api_server = None
        self.t_api = None
    def _start_api(self):
        if not (uvicorn and create_app and self.engine):
            return
        api_cfg = self.cfg.get("api", {}) or {}
        if not api_cfg.get("enabled", False):
            return
        host = str(api_cfg.get("host", "127.0.0.1"))
        port = int(api_cfg.get("port", 8000))
        auto_port = bool(api_cfg.get("auto_port", True))
        max_tries = int(api_cfg.get("max_port_tries", 50))

        if auto_port:
            port = self._pick_free_port(host, port, tries=max_tries)
        app = create_app(self.engine)
        try:
            routes = []
            for r in getattr(app, "routes", []):
                p = getattr(r, "path", None)
                m = getattr(r, "methods", None)
                if p:
                    routes.append({"path": p, "methods": sorted(list(m)) if m else []})
            self.log.info("API routes: " + json.dumps(routes, indent=2))
        except Exception as e:
            self.log.warn(f"Could not enumerate API routes: {e}")
        server = uvicorn.Server(uvicorn.Config(app, host=host, port=port, log_level="warning"))
        self.api_server = server
        self.t_api = threading.Thread(target=server.run, daemon=True)
        self.t_api.start()
        self.log.info(f"Local API started: http://{host}:{port}")


    def _start(self):
        self._save_from_ui()
        try:
            self._validate_live()
        except Exception as e:
            messagebox.showerror("Validation", str(e)); return

        self.engine=TradingEngine(self.cfg, self.log, self.rec, base_dir=self.base_dir)
        self.t_engine=threading.Thread(target=self.engine.loop, daemon=True)
        self.t_engine.start()
        self._start_api()
        self.btn_start.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.log.info("Engine started.")

    def _stop(self):
        if self.engine:
            self.engine.stop()
        self._stop_api()
        self.btn_start.config(state="normal")
        self.btn_stop.config(state="disabled")
        self.log.info("Stop requested.")

    def _close_all(self):
        if self.engine:
            self.engine.close_all(reason="manual_close_all")

    def _pause_entries(self):
        if self.engine:
            self.engine.pause_entries = True

    def _resume_entries(self):
        if self.engine:
            self.engine.pause_entries = False


    def _refresh(self):
        running = bool(self.t_engine and self.t_engine.is_alive())
        self.lbl_run.config(text=f"Running: {'YES' if running else 'NO'}")

        if self.engine:
            self.lbl_eq.config(text=f"Equity({self.engine.cfg.get('quote_asset','USDT')}): {self.engine.metrics.state.equity:.2f}")
            self.lbl_halt.config(text=f"Halted: {'YES' if self.engine.halted else 'NO'}")
            self.lbl_pause.config(text=f"Entries paused: {'YES' if self.engine.pause_entries else 'NO'}")

            # -----------------------------
            # Open positions
            # -----------------------------
            for i in self.tree_pos.get_children():
                self.tree_pos.delete(i)

            positions = []
            fn = getattr(self.engine, "get_positions_snapshot", None)
            if callable(fn):
                try:
                    positions = fn() or []
                except Exception:
                    positions = []

            if not positions:
                try:
                    for sym, pos in (getattr(self.engine, "positions", None) or {}).items():
                        positions.append({
                            "symbol": sym,
                            "qty": float(getattr(pos, "qty", 0.0) or 0.0),
                            "entry": float(getattr(pos, "entry", 0.0) or 0.0),
                            "stop": float(getattr(pos, "stop", 0.0) or 0.0),
                            "tp": float(getattr(pos, "tp", 0.0) or 0.0),
                        })
                except Exception:
                    positions = []

            # De-dup by symbol (GUI previously inserted multiple times)
            seen = set()
            for p in positions:
                sym = str(p.get("symbol", "") or "")
                if not sym or sym in seen:
                    continue
                seen.add(sym)
                self.tree_pos.insert(
                    "", "end",
                    values=(
                        sym,
                        f"{float(p.get('qty', 0.0) or 0.0):.8f}",
                        f"{float(p.get('entry', 0.0) or 0.0):.8f}",
                        f"{float(p.get('stop', 0.0) or 0.0):.8f}",
                        f"{float(p.get('tp', 0.0) or 0.0):.8f}",
                    )
                )

            # -----------------------------
            # Pending orders
            # -----------------------------
            if getattr(self, "tree_ord", None):
                for i in self.tree_ord.get_children():
                    self.tree_ord.delete(i)

            pendings = []
            fnp = getattr(self.engine, "get_pending_snapshot", None)
            if callable(fnp):
                try:
                    pendings = fnp() or []
                except Exception:
                    pendings = []

            if not pendings:
                # engine.pending dict (PendingOrder) is the canonical source
                pend_dict = getattr(self.engine, "pending", None)
                if isinstance(pend_dict, dict):
                    for v in pend_dict.values():
                        if isinstance(v, dict):
                            pendings.append(v)
                        else:
                            pendings.append(getattr(v, "__dict__", {"repr": str(v)}))

            if not pendings:
                pend_list = getattr(self.engine, "pending_orders", None)
                if isinstance(pend_list, list):
                    for v in pend_list:
                        pendings.append(v if isinstance(v, dict) else getattr(v, "__dict__", {"repr": str(v)}))

            for o in pendings:
                if not getattr(self, "tree_ord", None):
                    break
                # Normalize common keys
                oid = o.get("id") or o.get("order_id") or ""
                sym = o.get("symbol") or ""
                side = o.get("side") or ""
                qty = float(o.get("qty", 0.0) or 0.0)
                price = o.get("price")
                typ = o.get("type")
                if not typ:
                    typ = "limit" if bool(o.get("is_maker", True)) else "market"
                status = o.get("status") or "pending"

                self.tree_ord.insert(
                    "", "end",
                    values=(
                        str(oid),
                        str(sym),
                        str(side),
                        str(typ),
                        f"{qty:.8f}",
                        (f"{float(price):.8f}" if price is not None else ""),
                        str(status),
                    )
                )

            self._refresh_approvals()

        self.after(900, self._refresh)

    def _refresh_approvals(self):
        if not self.engine or not getattr(self.engine, "approvals", None):
            return
        for i in self.tree_app.get_children():
            self.tree_app.delete(i)
        for a in self.engine.approvals.list():
            self.tree_app.insert("", "end", values=(a.id, int(a.created_ts), a.symbol, a.side, f"{a.qty:.8f}", f"{a.price_ref:.8f}", a.status))

    def _selected_approval(self):
        sel=self.tree_app.selection()
        if not sel:
            return None
        vals=self.tree_app.item(sel[0], "values")
        return vals[0] if vals else None

    def _approve(self):
        if not self.engine or not getattr(self.engine, "approvals", None): return
        aid=self._selected_approval()
        if not aid: return
        self.engine.approvals.approve(aid, by="gui")
        self._refresh_approvals()

    def _reject(self):
        if not self.engine or not getattr(self.engine, "approvals", None): return
        aid=self._selected_approval()
        if not aid: return
        self.engine.approvals.reject(aid, by="gui")
        self._refresh_approvals()


    def _on_close(self):
        try:
            if self.engine:
                self.engine.stop()
        except Exception:
            pass
        self._stop_api()
        try:
            self.destroy()
        except Exception:
            pass

def main():
    cfg_path=os.path.join(os.path.dirname(__file__), "config.json")
    if not os.path.exists(cfg_path):
        save_config(cfg_path, DEFAULT_CONFIG)
    BotGUI().mainloop()

if __name__=="__main__":
    main()
